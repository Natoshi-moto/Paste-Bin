# Single-ZIP Relay Protocol — Round 019

## Immutable areas

Do not modify:

- `01_ORIGINAL_ARTIFACTS/`;
- `02_EXTRACTED_CORPUS/`;
- every prior directory under `03_EXCHANGE/`, including Round 018;
- `00_CONTROL/AUTHORITY.md`.

Tests and mutations must use `/tmp` or disposable complete copies.

## Writable areas

- `03_EXCHANGE/ROUND_019_INDEPENDENT_PHASE0A_SPEC_REREVIEW/**`;
- the exact control/tool/manifest paths listed in `CURRENT_STATE.json`.

## Required returned archive

`Pioneer-Alignment-Single-Relay-v10.zip`

The archive root must contain the numbered directories directly. Return the full
relay, not a delta.

## State after Round 019

Set according to adjudication. Preserve the wider Rounds 3–10 HOLD and every
external blocker.

## Integrity generation order

1. Hash every new Round 019 file except its own `SHA256SUMS.txt`.
2. Generate `INPUT_SHA256SUMS.txt` over all files immutable to the next actor.
3. Generate `FILE_INVENTORY.json` using its declared exclusions.
4. Generate `CURRENT_SHA256SUMS.txt` last over every file except itself.
5. Build and reopen the ZIP.
6. Report the outer ZIP SHA-256 out of band.

Return one ZIP only.
