# Execute Round 020 — Controlling Phase 0A Specification and Gate Repair

Use this complete relay as the only supplied corpus.

You are the controlling Phase 0A specification engineer. You are not the independent
reviewer and not the application builder.

Round 019 adjudication is `HOLD_FOR_FURTHER_PHASE0A_SPEC_REPAIR`.

## Read first

Read the original builder handoff completely:

`01_ORIGINAL_ARTIFACTS/Pioneer-Alignment-Phase-0A-Builder-Handoff-v1.md`

Then read, in order:

- `03_EXCHANGE/ROUND_019_INDEPENDENT_PHASE0A_SPEC_REREVIEW/RETURN_SUMMARY.md`
- `03_EXCHANGE/ROUND_019_INDEPENDENT_PHASE0A_SPEC_REREVIEW/REVIEW.md`
- `03_EXCHANGE/ROUND_019_INDEPENDENT_PHASE0A_SPEC_REREVIEW/FINDING_CLOSURE.json`
- `03_EXCHANGE/ROUND_019_INDEPENDENT_PHASE0A_SPEC_REREVIEW/EXECUTION_RECEIPT.json`
- `03_EXCHANGE/ROUND_019_INDEPENDENT_PHASE0A_SPEC_REREVIEW/r19_probes.py`
- `03_EXCHANGE/ROUND_018_CONTROLLING_PHASE0A_REPAIR/REPAIR_SUMMARY.md`

## Environment note

Run every tool with `PYTHONDONTWRITEBYTECODE=1` until finding `R19-F06` is repaired.
The shipped `__pycache__` bytes are hash-pinned and are rewritten on import, which
makes the documented validator command fail on a clean unpack.

## Preserve these Round 018 closures unchanged

Round 019 independently confirmed four genuine closures. Do not regress them:

1. HOLD is terminal — exactly two review traces are admitted out of 36 combinations.
2. `n80_identity_check` prevents release of non-reviewed bytes.
3. Export identity formulas reproduce the golden ZIP byte-for-byte.
4. Mutation receipts are deterministic across `PYTHONHASHSEED` values.

The fake Relay schemas and algorithm, the web-security vectors, the authority
declarations and the handoff requirement registry are also sound and should be
carried forward.

## Required repairs (Round 020)

1. **R19-F01 (critical)** — Make the independent oracle decide every case it counts.
   Eliminate the reflexive comparison in `result()`. Give `CANDIDATE_OBSERVE`,
   `PROVENANCE_SCENARIO`, `VERIFY_EXPORT_GOLDEN` and `VERIFY_EXPORT_HASHES` cases
   real inputs and real evaluators, or exclude them from the reported pass total
   under an explicit `DEFERRED_TO_CANDIDATE_EXECUTION` label. Today 60 of 89 cases
   pass with garbage input and 42 echo an arbitrary invented expectation.
2. **R19-F02 (critical)** — Use `AUTHORITY_REJECT_SUBSTRINGS`, which is currently
   defined and never referenced. Extend it to the full prohibited vocabulary already
   present in `CURRENT_STATE.json` and `PHASE0A_PRECEDENCE_AND_SUPERSESSION.v2.json`
   (GitHub, push, publish, deploy, Cloudflare, DNS, credential, tunnel, remote), and
   scan every string field of every normative file rather than only DAG
   `required_checks`.
3. **R19-F03 (critical)** — Bind raw-HTML enforcement to fixture payloads instead of
   case-ID substrings. Any case whose input body matches `RAW_HTML_PATTERNS` must be
   routed to `VALIDATE_RAW_HTML` and required to expect `REJECT` /
   `RAW_HTML_REJECTED`, whatever the case is named.
4. **R19-F04 (high)** — Resolve every `evidence_path` and compare the byte hash
   against the declared `evidence_sha256`. Add `evidence_fixtures/` to
   `PHASE0A_NORMATIVE_MANIFEST.v1.json` and stop excluding it from checksum
   regeneration in `run_round18_mutations.py`.
5. **R19-F05 (high)** — Assert exact equality between the note schema's slug pattern
   and reserved list and the oracle constants in `lib_phase0a.py`, and test the
   pattern behaviourally against a fixed hostile-slug corpus including `..`, `...`,
   `a..b` and `.env`.
6. **R19-F06 (high)** — Remove `__pycache__` from the archive and from all three
   manifests, or set `sys.dont_write_bytecode = True` at the top of every entry
   point, so the documented commands are reproducible on a clean unpack.
7. **R19-F07 (medium)** — Replace declared-example iteration with exhaustive
   derivation or an exact-ID minimum forbidden set.
8. **General rule** — Adopt and test the invariant that **no gate may be keyed on an
   identifier, a declared list length, or any value the mutation itself can rewrite**.
   All seven Round 019 false-greens exploit some form of that single mistake.
9. **Registry** — Add all eight Round 019 probe classes to the mandatory mutation
   registry with exact expected reason codes, and re-run the full suite under at
   least two `PYTHONHASHSEED` values. `r19_probes.py` contains executable definitions
   you may adapt directly.

## Required output directory

Write only under:

`03_EXCHANGE/ROUND_020_CONTROLLING_PHASE0A_REPAIR/`

Include at minimum `START_HERE.md`, `REPAIR_SUMMARY.md`,
`REQUEST_FOR_INDEPENDENT_REREVIEW.md`, the repaired normative files and tools,
`MUTATION_RECEIPTS.json`, `MUTATION_RECEIPTS.md` and `SHA256SUMS.txt`.

## Required adjudication

Choose exactly one:

- `ROUND020_REPAIR_COMPLETE_AWAITING_INDEPENDENT_REREVIEW`
- `HOLD_INSUFFICIENT_REPAIR`
- `INSUFFICIENT_EVIDENCE`

## Prohibitions

Do not build or modify application code; initialise or mutate a Git repository;
create a branch or commit; push or create a GitHub repository; request or use
credentials; connect a provider; deploy; change DNS, Cloudflare, hosting, domain or
production; create public accounts, NEX, LEX, federation, governance or real
identities; spend money; approve operator decisions; promote provisional wider
architecture; fabricate missing canon source bytes; or alter any prior round or
original artifact.

Preserve all seven external blockers. Do not manufacture host or application closure.

## Return protocol

Update only the Round 020 directory and the exact control/tool/manifest paths
authorised by `CURRENT_STATE.json`.

Return one complete:

`Pioneer-Alignment-Single-Relay-v11.zip`

Report the detached outer ZIP SHA-256 beside the archive. Return no loose files.
