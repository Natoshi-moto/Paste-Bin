# START HERE — Pioneer Alignment Single-ZIP Relay v10

**Current state:** `HOLD_FOR_FURTHER_PHASE0A_SPEC_REPAIR`
**Current actor:** Controlling Phase 0A specification/gate repairer
**Authority:** Bounded Round 020 specification and gate repair only

This ZIP is the full evolving relay. Do not ask the operator to combine loose
files or reconstruct prior context.

## Round 019 result

```text
Adjudication:                HOLD_FOR_FURTHER_PHASE0A_SPEC_REPAIR
Archive integrity:           PASS (SHA-256 match, 365 immutable files)
Round 018 suite reproduced:  31 rejected / 0 false-green / receipts byte-identical
Round 017 adversarial:       20/20 still reject for intended reasons
Round 019 new probes:        8 attempted / 7 FALSE-GREEN / 1 rejected
Round 017 findings closed:   4 of 10
New findings:                3 critical, 3 high, 1 medium
Application candidate:       NONE
Application tests:           NOT RUN
Host preflight:              NOT RUN
Repository mutation:         NONE
GitHub or remote action:     NONE
```

Round 018 made real progress. HOLD is genuinely terminal, N80 genuinely cannot
release non-reviewed bytes, export identity is complete and reproducible, and the
mutation receipts are deterministic. Those four closures should be carried forward
unchanged.

The gate is nevertheless still false-green on material mutations outside its own
registry. Seven of eight independent Round 019 probes passed every documented tool.
Phase 0A is **not** released to a builder.

The wider Rounds 3–10 architecture remains a separate HOLD.

## Read first

1. `00_CONTROL/CURRENT_STATE.json`
2. `00_CONTROL/PROMPT_TO_EXECUTE.md`
3. `03_EXCHANGE/ROUND_019_INDEPENDENT_PHASE0A_SPEC_REREVIEW/RETURN_SUMMARY.md`
4. `03_EXCHANGE/ROUND_019_INDEPENDENT_PHASE0A_SPEC_REREVIEW/REVIEW.md`
5. `03_EXCHANGE/ROUND_019_INDEPENDENT_PHASE0A_SPEC_REREVIEW/FINDING_CLOSURE.json`
6. `03_EXCHANGE/ROUND_019_INDEPENDENT_PHASE0A_SPEC_REREVIEW/EXECUTION_RECEIPT.json`
7. `03_EXCHANGE/ROUND_018_CONTROLLING_PHASE0A_REPAIR/REPAIR_SUMMARY.md`

## Known relay defect — read before running anything

The documented command `python3 -S meta_validate_round18.py` returns **exit 1** on a
clean unpack, reporting
`CHECKSUM_MISMATCH:__pycache__/lib_phase0a.cpython-314.pyc`.

The relay ships `__pycache__/*.pyc` and hash-pins those bytes in all three manifests.
Importing `lib_phase0a` makes CPython rewrite the cache file, so the checksum pass
compares against a now-stale pin. The `-S` flag does not prevent this. Running the
tools also creates new unlisted `.pyc` files, after which
`verify_input_manifest.py` reports `IMMUTABLE_PATH_UNLISTED`.

Until this is repaired, run every tool with:

```text
PYTHONDONTWRITEBYTECODE=1
```

and verify the input manifest on a **fresh unpack** before running anything else.
See finding `R19-F06`.

## Required action

Perform the bounded Round 020 controlling repair exactly as specified in
`PROMPT_TO_EXECUTE.md`.

Return one complete:

`Pioneer-Alignment-Single-Relay-v11.zip`

Do not build the application, mutate a repository, create a branch or commit,
push to GitHub, deploy, request credentials, connect a provider, create public
state, or claim that the host path or an application candidate has been verified.
