# One-ZIP Policy

Only one complete evolving relay ZIP moves between the controlling and
independent ChatGPT chats.

The receiver must:

- preserve the entire corpus and every prior exchange round;
- write only to the current authorised exchange directory and listed
  control/manifest paths;
- return the complete updated relay, never a loose delta;
- never require the operator to combine files;
- report inner integrity and the detached returned ZIP SHA-256;
- preserve the separation between the narrow Phase 0A lane and the wider
  Rounds 3–10 HOLD.

Current required return:

`Pioneer-Alignment-Single-Relay-v10.zip`
