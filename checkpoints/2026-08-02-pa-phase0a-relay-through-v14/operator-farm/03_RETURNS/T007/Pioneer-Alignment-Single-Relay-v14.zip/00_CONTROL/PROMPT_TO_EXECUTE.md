# Round 024 controlling Phase 0A specification and gate repair

Act as the controlling repair engineer, not the independent reviewer and not the
application builder. Verify the v14 immutable-input manifest before running any
other tool. Use `PYTHONDONTWRITEBYTECODE=1 python3 -S` for every Python
invocation.

Scope: `BOUNDED_PHASE0A_SPECIFICATION_AND_EXECUTABLE_GATE_REPAIR_ONLY`. Do not
build an application, mutate a repository, perform host preflight, use
credentials, connect providers, deploy, or take any external action. Do not
self-adjudicate release; an independent Round 025 re-review is mandatory.

Preserve everything Round 022 got right. Its suite reproduces byte-for-byte and
must continue to: 1240 immutable inputs, both validation modes valid, oracle
54 decided / 35 deferred / ineligible, 66 registry classes rejecting for their
intended reason, 43 closure negatives, 11 findings closed, seed-1/seed-2
byte-identical receipts, and 17/17 full receipt replay.

Close these, each with permanent negative registry evidence:

- **R23-F01** — normalize every authority leaf through a confusable skeleton
  (Unicode TR39 or an explicit map) and reject any leaf mixing Latin with
  another script. Add one registry class per script family.
- **R23-F02** — match a whole-document normalized projection in addition to
  per-leaf matching, so phrases fragmented across adjacent array elements, table
  cells and sibling leaves are caught. Reject non-foldable string-composition
  expressions in the validator source outright rather than trying to fold every
  form.
- **R23-F03** — extend the authority scan to the whole relay, explicitly
  including `00_CONTROL/**`, `04_TOOLS/**`, `05_MANIFESTS/**` and the incoming
  round directory; or declare those paths out of gate scope in `AUTHORITY.md`
  and pin them by another stated mechanism.
- **R23-F04** — reject unknown top-level keys in the acceptance contract and add
  release/deferral-override vocabulary to the authority reject set.
- **R23-F05** — add review-bypass vocabulary to the authority reject set:
  clearing a HOLD, proceeding without a further independent review, proceeding
  directly to N80, treating a HOLD as advisory.
- **R21-F01** and residual **R19-F02** — these close only when R23-F01, R23-F02
  and R23-F03 all close.
- **R23-F06** — no code repair; record explicitly that receipt freshness is an
  anti-staleness control and must not be cited as adversarial evidence.

Adopt all 14 Round 023 probe classes from
`03_EXCHANGE/ROUND_023_INDEPENDENT_PHASE0A_SPEC_REREVIEW/r23_probes.py` into the
permanent registry, keeping their coherent-rebind discipline including
security-constant repin, validator library relock and operational-receipt
recoherence. A probe that dies on an unconverged rebind has not been rejected.

Note the structural limit honestly in your summary: the validator cannot
exact-hash lock itself, so its own bytes are pinned only by the relay-level
immutable input manifest. Say so rather than implying a self-verifying anchor.

Preserve `NO_IMPLEMENTATION_CANDIDATE`, all four external blockers, the terminal
HOLD, N80 reviewed-byte identity, honest deferral, deterministic export identity
and the separate Rounds 3–10 architecture HOLD.

Return exactly one complete `Pioneer-Alignment-Single-Relay-v15.zip`, one
detached outer SHA-256, and exactly one adjudication.
