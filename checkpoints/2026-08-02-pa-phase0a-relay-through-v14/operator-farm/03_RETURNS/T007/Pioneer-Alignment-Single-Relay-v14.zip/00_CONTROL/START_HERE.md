# START HERE — Pioneer Alignment Single-ZIP Relay v14

Current state: `AWAITING_CONTROLLING_PHASE0A_REPAIR`

Current actor: controlling Round 024 Phase 0A specification/gate repair engineer.

Round 023 adjudicated `HOLD_FOR_FURTHER_PHASE0A_SPEC_REPAIR`.

Round 022's own suite reproduces exactly, byte-for-byte: 1240 immutable inputs
PASS, both validation modes `SPEC_CONTRACT_VALID`, oracle 54 decided / 35
deferred / ineligible, 66 of 66 mutations rejected with zero false greens, 43 of
43 closure negatives rejected for their intended reason, 11 of 11 tracked
findings closed, receipts byte-identical under hash seeds 1 and 2, receipt
replay 9/9 quick and 17/17 full. Round 022's arithmetic is honest and must be
preserved.

Release was withheld because 14 independently invented probes produced 9 false
greens, 8 of them materially exploitable, all outside the 66-class registry and
all after a full coherent rebind. Round 022 widened authority scan *coverage*
but did not harden the *matcher*: Unicode confusables that NFKC does not fold,
phrases fragmented across adjacent JSON leaves, and a non-foldable
generator-expression composition inside the one Python member that cannot
hash-lock itself all ship prohibited authority green. The scan is also rooted at
the round directory, so `00_CONTROL/**` ships unscanned.

`R21-F02`, `R21-F03`, `R21-F04` and residual `R19-F05` are confirmed closed
under maximal coherent rebind. `R21-F01` and residual `R19-F02` remain OPEN.

Read in order:

1. `00_CONTROL/CURRENT_STATE.json`
2. `00_CONTROL/AUTHORITY.md`
3. `00_CONTROL/PROMPT_TO_EXECUTE.md`
4. `03_EXCHANGE/ROUND_023_INDEPENDENT_PHASE0A_SPEC_REREVIEW/RETURN_SUMMARY.md`
5. `03_EXCHANGE/ROUND_023_INDEPENDENT_PHASE0A_SPEC_REREVIEW/REVIEW.md`
6. `03_EXCHANGE/ROUND_023_INDEPENDENT_PHASE0A_SPEC_REREVIEW/FINDING_CLOSURE.json`
7. `03_EXCHANGE/ROUND_023_INDEPENDENT_PHASE0A_SPEC_REREVIEW/EXECUTION_RECEIPT.json`
8. `03_EXCHANGE/ROUND_023_INDEPENDENT_PHASE0A_SPEC_REREVIEW/receipts/r23_probes.json`

First command on a fresh unpack:

```text
PYTHONDONTWRITEBYTECODE=1 python3 -S 04_TOOLS/verify_input_manifest.py
```

Then reproduce the Round 022 suite, then re-run
`03_EXCHANGE/ROUND_023_INDEPENDENT_PHASE0A_SPEC_REREVIEW/r23_probes.py` and
close every material false green. An import crash, a digest mismatch or an
unconverged receipt rebind is a harness failure, never an intended semantic
rejection.

All Python entry points must use `PYTHONDONTWRITEBYTECODE=1 python3 -S`.

Return one full relay named `Pioneer-Alignment-Single-Relay-v15.zip`.
Do not build the application or expand authority.
