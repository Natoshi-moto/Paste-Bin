# Single-ZIP Relay Protocol — Round 024 controlling repair

## Immutable areas

The next actor must not modify:

- `01_ORIGINAL_ARTIFACTS/**`;
- `02_EXTRACTED_CORPUS/**`;
- `00_CONTROL/AUTHORITY.md`;
- every exchange directory through
  `03_EXCHANGE/ROUND_023_INDEPENDENT_PHASE0A_SPEC_REREVIEW/**`.

Round 021's and Round 023's probe harnesses and every Round 022 gate/receipt
byte are immutable evidence. Round 024 must copy what it needs into its own
directory rather than editing prior rounds. Tests and mutations must use
disposable complete copies beneath `/tmp`.

## Writable areas

- `03_EXCHANGE/ROUND_024_CONTROLLING_PHASE0A_REPAIR/**`;
- only the exact control/tool/manifest paths listed in
  `00_CONTROL/CURRENT_STATE.json`.

## Required return archive

Return the complete relay as `Pioneer-Alignment-Single-Relay-v15.zip`, with the
numbered directories directly at archive root. Return no delta and no loose
companion files. Report the outer ZIP SHA-256 detached from the archive.

## Integrity order

1. Finish the Round 024 repair outputs and operational receipts.
2. Hash the new Round 024 files except their self-referential checksum file.
3. Transition state and `allowed_mutations` to the next actor.
4. Run the relay builder once to generate, in order, the next immutable-input
   manifest, cycle-free inventory, current manifest, and ZIP.
5. Exclude every `__pycache__/**` and `*.pyc`; reject every symlink.
6. Reopen and verify the built ZIP, then validate a fresh extraction read-only.
7. Make no byte edit after the final builder run; rebuild if any byte changes.
8. Report the detached outer hash out of band.

## Scoring discipline

A mutation counts as rejected only when the documented tools fail on the
intended semantic reason code. An import crash, a
`SECURITY_CONSTANTS_DIGEST_MISMATCH`, an unrefreshed exact-hash lock or an
unconverged operational-receipt rebind is a harness failure, not a control.
Coherent rebind means: normative manifest, evidence envelope, round checksum
manifest, `SECURITY_CONSTANTS_SHA256` repin, the validator's exact-hash lock on
`lib_phase0a.py`, and full operational-receipt recoherence.

Round 024 repairs; it does not adjudicate release. An independent Round 025
re-review is mandatory.
