# One-ZIP policy — relay v14 to v15

The only return artifact is one complete
`Pioneer-Alignment-Single-Relay-v15.zip`. It must contain all numbered relay
directories at archive root and no wrapper directory.

Do not return a delta, loose receipt, second archive, cache, bytecode, database,
dependency directory, credential, or temporary file. `__pycache__/**` and
`*.pyc` are excluded from every checksum/inventory walk and from the ZIP.
Symlinks are prohibited in the archive.

Note that this exclusion is also a blind spot: Round 023 probe
`R23-P14-BYTECODE-NAMED-AUTHORITY-MEMBER` showed that a text file named
`*.pyc`, or any file beneath `__pycache__/`, is invisible to every checksum and
authority walk. It is harmless only because the builder likewise refuses to
package it — verified by rebuild, zero such entries. Do not weaken the builder
exclusion without first closing the scan blind spot.

The outer ZIP SHA-256 is detached and reported out of band because an archive
cannot contain its own hash without self-reference.
