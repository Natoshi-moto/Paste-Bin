# START HERE — Pioneer Alignment Single-ZIP Relay v12

Current state: `AWAITING_CONTROLLING_PHASE0A_SPEC_REPAIR`

Current actor: controlling Round 022 Phase 0A specification/gate repair engineer.

Round 021 independently re-reviewed Round 020 and returned
`HOLD_FOR_FURTHER_PHASE0A_SPEC_REPAIR`. The Phase 0A specification is **not**
released to a bounded local builder. No application candidate exists and 35
candidate-required cases remain deferred.

Round 020's own evidence reproduces honestly — all six tools green, 46 registry
classes rejected with zero false greens, receipts byte-identical across hash seeds
1 and 2. The HOLD comes from three false greens among twelve mutation classes
invented outside that registry, one of which is an authority-widening green path.

Read in order:

1. `00_CONTROL/CURRENT_STATE.json`
2. `00_CONTROL/AUTHORITY.md`
3. `00_CONTROL/PROMPT_TO_EXECUTE.md`
4. `03_EXCHANGE/ROUND_021_INDEPENDENT_PHASE0A_SPEC_REREVIEW/RETURN_SUMMARY.md`
5. `03_EXCHANGE/ROUND_021_INDEPENDENT_PHASE0A_SPEC_REREVIEW/REVIEW.md`
6. `03_EXCHANGE/ROUND_021_INDEPENDENT_PHASE0A_SPEC_REREVIEW/FINDING_CLOSURE.json`
7. `03_EXCHANGE/ROUND_021_INDEPENDENT_PHASE0A_SPEC_REREVIEW/EXECUTION_RECEIPT.json`

First command on a fresh unpack:

```text
PYTHONDONTWRITEBYTECODE=1 python3 -S 04_TOOLS/verify_input_manifest.py
```

Then reproduce the Round 021 probes before repairing:

```text
cd 03_EXCHANGE/ROUND_021_INDEPENDENT_PHASE0A_SPEC_REREVIEW
PYTHONDONTWRITEBYTECODE=1 python3 -S r21_probes.py --relay-root ../.. --output-json /tmp/r21.json
PYTHONDONTWRITEBYTECODE=1 python3 -S r21_authority_surface.py --relay-root ../.. --output-json /tmp/r21-auth.json
```

Both must false-green today. Both must reject after your repair.

Must close: **R21-F01** (critical), **R21-F02**, **R21-F03**, **R21-F04**.

Warning carried forward from Round 021: `lib_phase0a.py` pins the SHA-256 of
`PHASE0A_SECURITY_CONSTANTS.v1.json`. A probe that edits that file without
repinning crashes every tool at import with `SECURITY_CONSTANTS_DIGEST_MISMATCH`
before any semantic check runs. Never score such a crash as a rejection.

All Python entry points must use `PYTHONDONTWRITEBYTECODE=1 python3 -S`.

Return one full relay named `Pioneer-Alignment-Single-Relay-v13.zip`.
Do not build the application or expand authority.
