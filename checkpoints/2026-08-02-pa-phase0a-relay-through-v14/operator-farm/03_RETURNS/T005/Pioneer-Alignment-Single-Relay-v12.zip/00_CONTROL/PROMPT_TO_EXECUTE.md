# Round 022 controlling Phase 0A specification and gate repair

Act as the controlling repair engineer, not the independent reviewer and not the
application builder. Verify the v12 input manifest before running any other tool.
Use `PYTHONDONTWRITEBYTECODE=1 python3 -S` for every Python invocation.

Scope: `BOUNDED_PHASE0A_SPECIFICATION_AND_EXECUTABLE_GATE_REPAIR_ONLY`. Do not
build an application, mutate a repository, perform host preflight, or take any
external action.

Read the Round 021 review, closure map and receipts, then reproduce both Round 021
probe harnesses so you observe the three false greens yourself before repairing.

## Required closures

1. **R21-F01 (CRITICAL).** Authority-scan coverage is bounded by
   `PHASE0A_NORMATIVE_MANIFEST.v1.json` membership while package membership is
   defined by the larger round `SHA256SUMS.txt`. Files in the gap ship inside the
   package, are checksum-covered, and are never scanned; 8 of 8 tested locations
   and extensions accept verbatim `reject_substrings` and green every tool.
   Require every checksum-covered file to be either a declared normative member or
   a member of an explicit hash-pinned non-normative allowlist, authority-scan the
   union, and fail closed with a specific code on any file in neither set.
2. **R21-F02 (HIGH).** `slug.max_length` is cross-checked only for
   schema/constants agreement, not against an independent floor, and
   `slug.hostile_corpus` contains no over-length entry. Pin the value to an exact
   independently anchored constant and add over-length hostile entries.
3. **R21-F03 (MEDIUM).** The declared export identity domains in
   `PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v3.json` are enforced nowhere. Assert they
   equal `DOMAIN_EXPORT_ID`, `DOMAIN_CONTENT_SET` and `DOMAIN_RECEIPT`.
4. **R21-F04 (MEDIUM).** Shipped operational receipts are stale:
   `authority_strings_scanned` reads 15590, 15597 and 15600 across the closure
   receipt, the spec receipts and a live run. Regenerate every operational receipt
   as the final build step, after the last manifest regeneration.

## Registry expansion

Adopt all twelve `r21_probes.py` classes and all eight `r21_authority_surface.py`
variants as permanent registry classes. Preserve the existing 46 classes and the
23 closure negatives; all must continue to reject for their intended reasons.

Adopt the constants-repin discipline: a probe that edits
`PHASE0A_SECURITY_CONSTANTS.v1.json` must refresh the SHA-256 pin in
`lib_phase0a.py`, otherwise every tool crashes at import with
`SECURITY_CONSTANTS_DIGEST_MISMATCH` and the class is scored as a rejection it did
not earn.

## Preserve

These held under Round 021 attack and must not regress: terminal HOLD including
against renamed HOLD-origin vocabulary; N80 reviewed-byte identity; honest
DEFERRED with 35 candidate-required cases blocking candidate PASS; payload-semantic
raw-HTML and active-content rejection; evidence symlink, path and fixture-set
integrity; deterministic export identity and hash-seed receipt identity.

Return exactly one complete `Pioneer-Alignment-Single-Relay-v13.zip` and a request
for Round 023 independent re-review. Report the outer ZIP SHA-256 out of band.
