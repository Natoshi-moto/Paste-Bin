# One-ZIP policy — relay v12 to v13

The only return artifact is one complete
`Pioneer-Alignment-Single-Relay-v13.zip`. It must contain all numbered relay
directories at archive root and no wrapper directory.

Do not return a delta, loose receipt, second archive, cache, bytecode, database,
dependency directory, credential, or temporary file. `__pycache__/**` and
`*.pyc` are excluded from every checksum/inventory walk and from the ZIP.
Symlinks are prohibited in the archive.

The outer ZIP SHA-256 is detached and reported out of band because an archive
cannot contain its own hash without self-reference.
