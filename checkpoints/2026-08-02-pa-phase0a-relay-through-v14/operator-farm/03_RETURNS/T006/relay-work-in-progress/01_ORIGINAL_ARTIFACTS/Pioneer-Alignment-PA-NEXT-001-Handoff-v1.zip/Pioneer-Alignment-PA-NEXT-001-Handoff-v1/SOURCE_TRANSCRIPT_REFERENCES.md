# Source Transcript References

The complete session transcripts were used to derive the durable evidence,
but are intentionally excluded from this portable ZIP because full session
files may contain unrelated context or secret-like material.

## Fable full session JSONL (excluded)

- SHA-256: `6b92d1a25ee2fc4aa89efbd2afdd08a038f2c3c2c2e800078528cbf6b3d12ead`
- Bytes: `607620`
- Handling: Excluded from portable handoff because full session transcripts may contain unrelated context or secret-like material.

## Claude execution session JSONL (excluded)

- SHA-256: `32787120dbdb4b4e719be585699ea7294337b0d2f768f852430919afce1be497`
- Bytes: `732666`
- Handling: Excluded from portable handoff because full session transcripts may contain unrelated context or secret-like material.

## Fable terminal paste (included)

- SHA-256: `15d62ff3a92acd820c843322a4a5d342578afb48e0d4e976d738f89b3de30fa2`
- Bytes: `31785`
- Handling: Included as the bounded report text used for adjudication.

## Claude match report (included)

- SHA-256: `c317e10242cd189c84d09f35a734a7f0fe226fe6d54a6b20dcd4136675c04e6d`
- Bytes: `1894`
- Handling: Included to bind the selected execution transcript identity.

## Execution ledger reconciliation (included)

- SHA-256: `42a9d2cbf84f5cf5514eec1d3e24f372b31108ac78e5a4d60dbefe00169b32fc`
- Bytes: `17854`
- Handling: Included as the durable transcript-derived reconciliation.

Known original Claude execution transcript location:

```text
/home/anon/.claude/projects/-home-anon/e6f746a3-e426-4565-8258-d800e8af8c05.jsonl
```

Do not ask the operator to upload or redistribute a full raw session transcript
unless it has first been reviewed and redacted for unrelated credentials or
secret-bearing context.
