# Fable Findings and Final Disposition

Fable's classification:

```text
SAFE BUT INCOMPLETE
```

Accepted load-bearing findings:

1. Reading a split index can freshen the modification time of
   `.git/sharedindex.<oid>` even when optional locks are disabled.
2. `GIT_CONFIG_NOSYSTEM=1` does not disable the separate system attributes
   source; `GIT_ATTR_NOSYSTEM=1` is needed for that bound.
3. The ordinary index lock and persistence path can be disabled while the
   in-memory refresh still runs.
4. `--untracked-files=no`, `--ignore-submodules=all`, `--no-renames` and
   `--no-ahead-behind` materially narrow the status operation.
5. Newline-framed porcelain-v2 output was preferable in this lane because the
   prior NUL-framed capture failed and its output was lost.

Corrections made after Fable:

- direct type checks were added for `.git/index` and relevant parent
  directories;
- broad directory listings were replaced with targeted control-name checks;
- empty stdout was rejected as a clean result because `--branch` requires branch
  headers;
- the evidence ceiling was narrowed explicitly to non-submodule tracked state.

Historical result:

The revised operation passed and its transcript ledger has now been reconciled.

The raw Fable full-session JSONL is deliberately excluded from this portable
handoff. The bounded terminal report is included under `EVIDENCE/`.
