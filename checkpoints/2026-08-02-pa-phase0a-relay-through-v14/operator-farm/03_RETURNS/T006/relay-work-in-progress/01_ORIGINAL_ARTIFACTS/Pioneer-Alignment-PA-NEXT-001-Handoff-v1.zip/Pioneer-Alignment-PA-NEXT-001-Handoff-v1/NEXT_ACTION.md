# Next Action

## Decision to adjudicate

Determine whether this objective is necessary and whether a minimally revealing,
non-mutating index-mode query can be approved:

> Detect whether the candidate index contains any gitlink entries with object
> mode `160000`.

The previously suggested basis was:

```text
git ls-files --sparse --format='%(objectmode)'
```

That text is **not approved**.

## Required adjudication questions

The receiving chat must independently verify, against current official Git
documentation and upstream Git source:

1. Whether `git ls-files --sparse --format='%(objectmode)'` can write, lock,
   refresh, expand, collapse or otherwise persistently alter the index.
2. Whether reading a split index can still touch a shared-index mtime and whether
   the freshly established absence of `sharedindex.*` is enough.
3. Whether `--sparse` actually prevents sparse-index expansion for the relevant
   Git version and what additional output modes may occur.
4. Whether the command reads worktree files, attributes, grafts, alternates,
   objects, config values, hooks, fsmonitor state, submodules, filters, helpers,
   pagers, credentials or network resources.
5. Whether `%(objectmode)` can expose only modes or whether any quoting,
   localisation, diagnostics, or repository state can widen output.
6. Whether a lower-level non-Git read would be safer or would merely create a
   larger parsing and provenance surface.
7. Whether this evidence gap needs closing now at all.
8. Exact prerequisites, stop conditions, evidence ceiling and output parser if
   approval is recommended.

## Authority

The receiving chat has adjudication authority only.

It does not have authority to:

- execute a command;
- touch the candidate;
- inspect untracked files or submodules;
- use credentials or network access against the repository/provider;
- create a repository-side receipt;
- repair anything;
- mark any gate PASS;
- lift BLOCKED or HOLD.
