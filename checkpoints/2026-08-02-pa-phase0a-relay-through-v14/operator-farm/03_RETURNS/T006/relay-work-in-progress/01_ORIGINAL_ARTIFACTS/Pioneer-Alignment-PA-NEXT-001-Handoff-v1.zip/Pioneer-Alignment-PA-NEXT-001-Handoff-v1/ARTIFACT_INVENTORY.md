# Artifact Inventory

Included:

- `START_HERE.md`
- `CURRENT_STATE.md`
- `FABLE_FINDINGS_AND_DISPOSITION.md`
- `NEXT_ACTION.md`
- `SOURCE_TRANSCRIPT_REFERENCES.md`
- `PROMPT_TO_PASTE.md`
- `EVIDENCE/PA-NEXT-001-Execution-Ledger-Reconciliation-v1.md`
- `EVIDENCE/RECONCILIATION_SHA256SUMS.txt`
- `EVIDENCE/FABLE_ADJUDICATION_TERMINAL_PASTE.txt`
- `EVIDENCE/CLAUDE_EXECUTION_TRANSCRIPT_MATCH_REPORT.txt`
- `SHA256SUMS.txt`

Excluded intentionally:

- complete Fable and Claude raw full-session transcripts;
- unrelated Cloudflare and research-launch artifacts;
- secrets, credentials and temporary scratch captures;
- candidate repository content.

The omitted raw transcripts are identified by hash in
`SOURCE_TRANSCRIPT_REFERENCES.md`.
