# Repository Recovery and Artifact Authenticity Specification

Status: architecture requirement; no repository action authorised.

Before any implementation sweep mutates a repository:

1. Record exact path, branch, HEAD, tree, status, remotes and worktree list.
2. Create `git bundle create <name>.bundle --all`.
3. Store the bundle outside the writable worktree.
4. Hash the bundle and inventory all refs.
5. Create a disposable clone from the bundle with network disabled.
6. Delete the disposable clone's working tree and restore it again from the bundle.
7. Verify all refs, HEAD/tree, tags and required branches.
8. Freeze source inputs, toolchain versions, package-manager version, lockfiles and
   dependency allowlist.
9. Generate an SBOM.
10. Run two clean builds in separate network-disabled directories.
11. Require identical source-tree hash, generated-schema hash, state-vector hash and
    artifact hash. Nondeterministic artifacts must be explicitly excluded and explained.
12. Label every local artifact `UNSIGNED_LOCAL_ARTIFACT` until a separately adopted
    release-signing policy and independent authenticity receipt exist.

## Dependency policy

- Lockfile required.
- No unpinned Git dependency.
- No install script or dynamic download without explicit reviewed allowlist.
- No dependency may silently widen network, filesystem, credential or code-execution authority.
- Record licence, source and integrity hash.
- High-authority clients prohibit dynamic remote code.

## Restore drill evidence

A valid receipt binds:

- original commit/tree;
- bundle SHA-256;
- ref inventory SHA-256;
- restored commit/tree;
- toolchain manifest SHA-256;
- dependency lock SHA-256;
- SBOM SHA-256;
- clean-build A/B hashes;
- network-disabled evidence;
- actor and administrative domain.

A missing or failed restore drill blocks the sweep.
