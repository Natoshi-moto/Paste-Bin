# Phase 0A Host-Path Blocker

The architecture corpus declares the intended local repository path as:

`/home/anon/Projects/Pioneer-Alignment-App`

and the intended branch as:

`phase-0a/local-vertical-slice`

This relay does not contain a verified filesystem snapshot, Git identity, commit,
tree, status or worktree lock for that path.

Therefore:

- the path is `DECLARED_UNVERIFIED`;
- no repository write is authorised;
- PRE-S01 must inspect and receipt the exact path before any mutation;
- any mismatch, active writer, dirty state, missing recovery bundle or different
  repository identity creates a HOLD;
- the operator is not asked for credentials or destructive cleanup.
