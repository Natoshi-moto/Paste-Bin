#!/usr/bin/env python3
from pathlib import Path
import json, hashlib, sys
root=Path(__file__).resolve().parent
expected=json.loads((root/"GENESIS_EXPECTED.json").read_text())
checks={
"inputs_sha256":hashlib.sha256((root/"GENESIS_INPUTS.json").read_bytes()).hexdigest(),
"canonical_profile_sha256":hashlib.sha256((root/"CANONICAL_PROFILE.json").read_bytes()).hexdigest(),
"algorithm_registry_sha256":hashlib.sha256((root/"ALGORITHM_REGISTRY.json").read_bytes()).hexdigest(),
"keys_sha256":hashlib.sha256((root/"SYNTHETIC_KEYS.json").read_bytes()).hexdigest(),
"genesis_event_body_sha256":hashlib.sha256((root/"GENESIS_EVENT.canonical.bin").read_bytes()).hexdigest(),
"genesis_event_file_sha256":hashlib.sha256((root/"GENESIS_EVENT.json").read_bytes()).hexdigest(),
"genesis_state_sha256":hashlib.sha256((root/"GENESIS_STATE.canonical.bin").read_bytes()).hexdigest(),
"checkpoint_file_sha256":hashlib.sha256((root/"GENESIS_CHECKPOINT.json").read_bytes()).hexdigest(),
}
bad=[f"{k}: {v} != {expected.get(k)}" for k,v in checks.items() if v!=expected.get(k)]
if bad:
 print("\n".join(bad)); sys.exit(1)
print("PASS synthetic genesis fixed-file hashes")
