# Round 014 Controlling Machine-Spec Repair

Status: `REPAIR_PACKAGE_READY_FOR_INDEPENDENT_REVIEW`

This round is architecture repair only. No repository, GitHub, provider, deployment,
DNS, identity, balance, federation or production state was changed.

## Fourteen amendments supplied

1. Exact canon snapshots remain an explicit external blocker; no source bytes were fabricated.
2. Deterministic graph and gate generators include lossless canonical JSON and `--check`.
3. DAG dependencies are structured and reject dangling nodes/outputs.
4. Cross-domain gates moved to integration; every enabled adapter enters review/adjudication.
5. `pa.gate_evidence.v1` and a frozen named corpus are defined.
6. The original Phase 0A acceptance floor, exact note/event schema and export format are restored.
7. Synthetic genesis is self-contained with deterministic public fixture keys, exact bytes, checkpoint and hashes.
8. A legacy supersession map and machine-readable membrane reducer are supplied.
9. Anonymous ballots and confidential payloads use distinct envelope types; golden vectors freeze encoding.
10. Parameter, finding and public-blocker registries are populated.
11. Federation threat bounds and Noted no-reroll/abort rules are defined; adapters default disabled.
12. Repository bundle recovery, restore drill, SBOM, dependency and reproducible-build requirements are defined.
13. GitHub is a no-standing-authority policy requiring a fresh exact single-use approval and recursive archive inspection.
14. Control files and inventory are versioned for the next actor.

## Open external blockers

- exact byte snapshots of binding canon documents;
- no current private GitHub backup approval;
- exact Phase 0A host repository state and active-writer lock not verified;
- no implementation evidence exists, by design.

## Requested adjudication

Round 015 must test the specs and validator. It must not treat architecture documents as
implementation evidence or close the canon-source blocker.
