# Generated Authority Graph v2

> Generated from `NORMATIVE_AUTHORITY_GRAPH.v2.json`. Do not edit.

## Metadata

- Schema: `pa.normative_authority_graph.v2`
- Status: `ROUND14_SYNTHETIC_ARCHITECTURE_NORMATIVE_WITHIN_PROVISIONAL_PACKAGE`

## Nodes

| ID | Label | Class |
|---|---|---|
| `GENESIS` | Synthetic genesis manifest | `authority_root` |
| `CONST` | Constitution / accepted canon | `authority` |
| `OP` | Bootstrap operator / later constitutional roles | `authority` |
| `ID` | Identity + key registry | `foundation` |
| `MATURITY` | Mature-human credential state | `foundation` |
| `ROLE` | Role and capability grants | `authority` |
| `CLOCK` | Injected deterministic clock/events | `foundation` |
| `EVT` | Canonical signed-event kernel | `foundation` |
| `HEAD` | Head checkpoints | `foundation` |
| `REC` | LOOM RECORD store | `evidence` |
| `ROUTE` | LOOM ROUTE indexes | `derived` |
| `CLAIM` | LOOM CLAIM registry | `claim` |
| `SOCIAL` | Social events + projections | `event_domain` |
| `MOD` | Moderation / appeal / resolution | `institutional_action` |
| `TASK` | Task publication | `work_market` |
| `BID` | Bids | `work_market` |
| `CONTRACT` | Accepted contract | `work_market` |
| `EXEC` | Agent/human execution | `work_market` |
| `RECEIPT` | Execution receipt | `evidence` |
| `VERIFY` | Independent verification | `finding` |
| `ADJ` | Adjudication | `institutional_action` |
| `WORK_REP` | Work reputation projection | `derived` |
| `COMPETENCE` | Role-specific competence projection | `derived` |
| `NEX` | NEX event ledger + epoch balances | `accounting` |
| `LEX` | LEX event ledger + epoch balances | `accounting` |
| `GOV` | Governance proposals / ballots | `institutional_action` |
| `ENACT` | Rule enactment | `institutional_action` |
| `AI` | Native social AI / Relay | `derived_intelligence` |
| `ATP` | AT Protocol adapter | `transport_adapter` |
| `NOSTR` | Nostr adapter | `transport_adapter` |
| `NOTED` | Noted deterministic game adapter | `optional_game_domain` |
| `PUB` | Static public publication | `published_position` |

## Edges

| ID | From | To | Relation |
|---|---|---|---|
| `E-001` | `GENESIS` | `CONST` | `declares_synthetic_root` |
| `E-002` | `GENESIS` | `OP` | `declares_test_operator` |
| `E-003` | `GENESIS` | `ID` | `declares_test_identities` |
| `E-004` | `GENESIS` | `ROLE` | `declares_root_capabilities` |
| `E-005` | `GENESIS` | `CLOCK` | `declares_clock_source` |
| `E-006` | `CONST` | `ROLE` | `defines_roles` |
| `E-007` | `OP` | `ROLE` | `exercises_only_declared_bootstrap_grants` |
| `E-008` | `ID` | `ROLE` | `subjects_receive_grants` |
| `E-009` | `ROLE` | `EVT` | `authorises_event_types` |
| `E-010` | `ID` | `EVT` | `signs_events` |
| `E-011` | `CLOCK` | `EVT` | `supplies_deterministic_time_events` |
| `E-012` | `EVT` | `HEAD` | `creates_checkpoints` |
| `E-013` | `EVT` | `REC` | `ingests_exact_accepted_bytes` |
| `E-014` | `REC` | `ROUTE` | `indexes_replaceably` |
| `E-015` | `REC` | `CLAIM` | `supports_or_contradicts` |
| `E-016` | `ROUTE` | `AI` | `locates_records_without_authority` |
| `E-017` | `REC` | `AI` | `authorised_context` |
| `E-018` | `AI` | `CLAIM` | `drafts_claim_candidate` |
| `E-019` | `EVT` | `SOCIAL` | `projects_social_state` |
| `E-020` | `SOCIAL` | `MOD` | `subject_of_actions` |
| `E-021` | `MOD` | `EVT` | `appends_actions_appeals_resolutions` |
| `E-022` | `ROLE` | `TASK` | `authorises_task_publication` |
| `E-023` | `TASK` | `BID` | `accepts_bids` |
| `E-024` | `BID` | `CONTRACT` | `award_gate` |
| `E-025` | `CONTRACT` | `EXEC` | `authorises_execution` |
| `E-026` | `EXEC` | `RECEIPT` | `produces_receipt` |
| `E-027` | `RECEIPT` | `VERIFY` | `is_reproduced` |
| `E-028` | `VERIFY` | `ADJ` | `supplies_finding` |
| `E-029` | `ADJ` | `NEX` | `orders_defined_settlement` |
| `E-030` | `ADJ` | `WORK_REP` | `updates_evidence_projection` |
| `E-031` | `EVT` | `WORK_REP` | `projects_work_history` |
| `E-032` | `WORK_REP` | `COMPETENCE` | `bounded_role_specific_input` |
| `E-033` | `COMPETENCE` | `ROLE` | `bounded_pool_eligibility_only` |
| `E-034` | `EVT` | `NEX` | `applies_valid_nex_events` |
| `E-035` | `EVT` | `LEX` | `applies_valid_lex_events` |
| `E-036` | `ID` | `MATURITY` | `identity_evidence_only` |
| `E-037` | `MATURITY` | `GOV` | `one_human_credential_input` |
| `E-038` | `LEX` | `GOV` | `source_eligible_ballot_expenditure` |
| `E-039` | `GOV` | `ENACT` | `authorises_separate_enactment` |
| `E-040` | `ENACT` | `ROLE` | `changes_future_role_rules` |
| `E-041` | `ENACT` | `EVT` | `changes_future_validation_rules` |
| `E-042` | `SOCIAL` | `ATP` | `bounded_export` |
| `E-043` | `ATP` | `SOCIAL` | `quarantined_import` |
| `E-044` | `SOCIAL` | `NOSTR` | `bounded_export` |
| `E-045` | `NOSTR` | `SOCIAL` | `quarantined_import` |
| `E-046` | `VERIFY` | `NOTED` | `eligible_milestone_reference_only` |
| `E-047` | `NOTED` | `SOCIAL` | `game_event_or_announcement` |
| `E-048` | `CLAIM` | `PUB` | `deliberate_promotion_only` |
| `E-049` | `REC` | `PUB` | `source_evidence` |

## Invariants

- **INV-001 `route_non_authority`:** No CLAIM may cite a ROUTE as evidence.
- **INV-002 `signature_not_truth`:** A valid signature proves authorship/control, not factual correctness.
- **INV-003 `projection_non_authority`:** Feeds, reputation, AI summaries, popularity and search rank are derived.
- **INV-004 `no_self_settlement`:** Related identities cannot span publisher, worker, sole verifier, adjudicator and ledger authority.
- **INV-005 `no_nex_from_engagement`:** Social engagement cannot mint NEX.
- **INV-006 `no_nex_political_power`:** NEX, NEX-domain work, work reputation and NEX-funded activity cannot affect maturity, civic LEX, proposal throughput, ballot eligibility or weight, moderation, visibility, reputation outside explicitly labelled work projections, evidence authority, truth status, or institutional role selection that can yield binding governance power.
- **INV-007 `no_lex_intelligence_purchase`:** LEX cannot buy reasoning, compute, NEX work or NEX settlement.
- **INV-008 `no_unit_conversion`:** No direct or indirect NEX–LEX conversion or functional substitute.
- **INV-009 `no_external_value_rail`:** No official external price, redemption, purchase, sale, deposit, withdrawal, exchange, bridge, market, debt, equity, payment, collateral or external-value claim.
- **INV-010 `append_only_correction`:** Accepted events and accounting are repaired by new events.
- **INV-011 `explicit_epoch_continuity`:** Every balance epoch has declared closure and transition rules.
- **INV-012 `moderation_purge_split`:** Visibility, retraction, deletion request and verified purge are distinct.
- **INV-013 `ai_deny_by_default`:** Content and model output cannot grant tool or state authority.
- **INV-014 `adapter_non_sovereignty`:** External protocol state requires separate accepted Pioneer events.
- **INV-015 `noted_isolation`:** Noted history cannot affect institutional eligibility, economics, truth, moderation or research assessment.
- **INV-016 `publication_isolation`:** Static publication consumes reviewed promotion artifacts only.
- **INV-017 `narrow_freeze`:** Failures freeze the narrowest affected scope.
- **INV-018 `operator_receipt`:** Exceptional operator actions require explicit start, expiry, scope, reason, affected state, effect, reviewer, review deadline and termination receipt.
- **INV-019 `one_compensation_domain`:** One deliverable lineage may settle in exactly one compensation domain.
- **INV-020 `secret_ballot_model`:** Binding ballot choices are not publicly linkable or transferable as proof.
- **INV-021 `civic_source_only`:** Only equal current-cycle civic LEX may fund binding ballot conviction; governance/social/transferred/service LEX is non-voting.
- **INV-022 `proposal_throughput_equality`:** Accepted proposal throughput is identity-capped and cannot be increased by NEX, LEX transfer, service role, popularity, Noted status or external protocol reach.
- **INV-023 `private_root_non_export`:** Private human-root and pseudonym-link data cannot enter public federation, public LOOM, public fork bundles or public ballot records.
- **INV-024 `anonymous_ballot_union`:** Anonymous ballot envelopes omit actor identity and use scoped nullifiers/proofs; they are not coerced into the actor-bound social envelope.
- **INV-025 `enabled_adapter_review`:** Every enabled adapter is included in the exact integrated candidate reviewed, repaired and adjudicated before S07.
- **INV-026 `multi_epoch_trajectory`:** NEX epoch opening cannot reset cumulative issuance trajectory or evade a higher-class variance review.
- **INV-027 `critical_projection_reproducibility`:** Critical views expose source events, projection version and deterministic reference output; UI cannot alter canonical outcomes.
- **INV-028 `noted_no_institutional_prestige`:** Noted state cannot affect identity maturity, task access, reputation, moderation, LEX issuance, proposal access, ballots or research assessment.

## Forbidden edges

| From | To |
|---|---|
| `WORK_REP` | `MATURITY` |
| `NEX` | `MATURITY` |
| `NEX` | `GOV` |
| `NOTED` | `WORK_REP` |
| `ATP` | `ID` |
| `NOSTR` | `ID` |
| `NEX` | `MOD` |
| `NEX` | `SOCIAL_VISIBILITY` |
| `NEX` | `EVIDENCE` |
| `NEX` | `CLAIM_TRUTH` |
| `WORK_REP` | `ROLE_GOVERNANCE_POWER` |
| `NOTED` | `MATURITY` |
| `NOTED` | `TASK_ELIGIBILITY` |
| `FEDERATION` | `GOVERNANCE_IDENTITY` |

## Lossless canonical JSON

```json
{"edges":[{"from":"GENESIS","id":"E-001","relation":"declares_synthetic_root","to":"CONST"},{"from":"GENESIS","id":"E-002","relation":"declares_test_operator","to":"OP"},{"from":"GENESIS","id":"E-003","relation":"declares_test_identities","to":"ID"},{"from":"GENESIS","id":"E-004","relation":"declares_root_capabilities","to":"ROLE"},{"from":"GENESIS","id":"E-005","relation":"declares_clock_source","to":"CLOCK"},{"from":"CONST","id":"E-006","relation":"defines_roles","to":"ROLE"},{"from":"OP","id":"E-007","relation":"exercises_only_declared_bootstrap_grants","to":"ROLE"},{"from":"ID","id":"E-008","relation":"subjects_receive_grants","to":"ROLE"},{"from":"ROLE","id":"E-009","relation":"authorises_event_types","to":"EVT"},{"from":"ID","id":"E-010","relation":"signs_events","to":"EVT"},{"from":"CLOCK","id":"E-011","relation":"supplies_deterministic_time_events","to":"EVT"},{"from":"EVT","id":"E-012","relation":"creates_checkpoints","to":"HEAD"},{"from":"EVT","id":"E-013","relation":"ingests_exact_accepted_bytes","to":"REC"},{"from":"REC","id":"E-014","relation":"indexes_replaceably","to":"ROUTE"},{"from":"REC","id":"E-015","relation":"supports_or_contradicts","to":"CLAIM"},{"from":"ROUTE","id":"E-016","relation":"locates_records_without_authority","to":"AI"},{"from":"REC","id":"E-017","relation":"authorised_context","to":"AI"},{"from":"AI","id":"E-018","relation":"drafts_claim_candidate","to":"CLAIM"},{"from":"EVT","id":"E-019","relation":"projects_social_state","to":"SOCIAL"},{"from":"SOCIAL","id":"E-020","relation":"subject_of_actions","to":"MOD"},{"from":"MOD","id":"E-021","relation":"appends_actions_appeals_resolutions","to":"EVT"},{"from":"ROLE","id":"E-022","relation":"authorises_task_publication","to":"TASK"},{"from":"TASK","id":"E-023","relation":"accepts_bids","to":"BID"},{"from":"BID","id":"E-024","relation":"award_gate","to":"CONTRACT"},{"from":"CONTRACT","id":"E-025","relation":"authorises_execution","to":"EXEC"},{"from":"EXEC","id":"E-026","relation":"produces_receipt","to":"RECEIPT"},{"from":"RECEIPT","id":"E-027","relation":"is_reproduced","to":"VERIFY"},{"from":"VERIFY","id":"E-028","relation":"supplies_finding","to":"ADJ"},{"from":"ADJ","id":"E-029","relation":"orders_defined_settlement","to":"NEX"},{"from":"ADJ","id":"E-030","relation":"updates_evidence_projection","to":"WORK_REP"},{"from":"EVT","id":"E-031","relation":"projects_work_history","to":"WORK_REP"},{"from":"WORK_REP","id":"E-032","relation":"bounded_role_specific_input","to":"COMPETENCE"},{"from":"COMPETENCE","id":"E-033","relation":"bounded_pool_eligibility_only","to":"ROLE"},{"from":"EVT","id":"E-034","relation":"applies_valid_nex_events","to":"NEX"},{"from":"EVT","id":"E-035","relation":"applies_valid_lex_events","to":"LEX"},{"from":"ID","id":"E-036","relation":"identity_evidence_only","to":"MATURITY"},{"from":"MATURITY","id":"E-037","relation":"one_human_credential_input","to":"GOV"},{"from":"LEX","id":"E-038","relation":"source_eligible_ballot_expenditure","to":"GOV"},{"from":"GOV","id":"E-039","relation":"authorises_separate_enactment","to":"ENACT"},{"from":"ENACT","id":"E-040","relation":"changes_future_role_rules","to":"ROLE"},{"from":"ENACT","id":"E-041","relation":"changes_future_validation_rules","to":"EVT"},{"from":"SOCIAL","id":"E-042","relation":"bounded_export","to":"ATP"},{"from":"ATP","id":"E-043","relation":"quarantined_import","to":"SOCIAL"},{"from":"SOCIAL","id":"E-044","relation":"bounded_export","to":"NOSTR"},{"from":"NOSTR","id":"E-045","relation":"quarantined_import","to":"SOCIAL"},{"from":"VERIFY","id":"E-046","relation":"eligible_milestone_reference_only","to":"NOTED"},{"from":"NOTED","id":"E-047","relation":"game_event_or_announcement","to":"SOCIAL"},{"from":"CLAIM","id":"E-048","relation":"deliberate_promotion_only","to":"PUB"},{"from":"REC","id":"E-049","relation":"source_evidence","to":"PUB"}],"forbidden_edges":[{"from":"WORK_REP","to":"MATURITY"},{"from":"NEX","to":"MATURITY"},{"from":"NEX","to":"GOV"},{"from":"NOTED","to":"WORK_REP"},{"from":"ATP","to":"ID"},{"from":"NOSTR","to":"ID"},{"from":"NEX","to":"MOD"},{"from":"NEX","to":"SOCIAL_VISIBILITY"},{"from":"NEX","to":"EVIDENCE"},{"from":"NEX","to":"CLAIM_TRUTH"},{"from":"WORK_REP","to":"ROLE_GOVERNANCE_POWER"},{"from":"NOTED","to":"MATURITY"},{"from":"NOTED","to":"TASK_ELIGIBILITY"},{"from":"FEDERATION","to":"GOVERNANCE_IDENTITY"}],"invariants":[{"id":"INV-001","name":"route_non_authority","text":"No CLAIM may cite a ROUTE as evidence."},{"id":"INV-002","name":"signature_not_truth","text":"A valid signature proves authorship/control, not factual correctness."},{"id":"INV-003","name":"projection_non_authority","text":"Feeds, reputation, AI summaries, popularity and search rank are derived."},{"id":"INV-004","name":"no_self_settlement","text":"Related identities cannot span publisher, worker, sole verifier, adjudicator and ledger authority."},{"id":"INV-005","name":"no_nex_from_engagement","text":"Social engagement cannot mint NEX."},{"id":"INV-006","name":"no_nex_political_power","text":"NEX, NEX-domain work, work reputation and NEX-funded activity cannot affect maturity, civic LEX, proposal throughput, ballot eligibility or weight, moderation, visibility, reputation outside explicitly labelled work projections, evidence authority, truth status, or institutional role selection that can yield binding governance power."},{"id":"INV-007","name":"no_lex_intelligence_purchase","text":"LEX cannot buy reasoning, compute, NEX work or NEX settlement."},{"id":"INV-008","name":"no_unit_conversion","text":"No direct or indirect NEX–LEX conversion or functional substitute."},{"id":"INV-009","name":"no_external_value_rail","text":"No official external price, redemption, purchase, sale, deposit, withdrawal, exchange, bridge, market, debt, equity, payment, collateral or external-value claim."},{"id":"INV-010","name":"append_only_correction","text":"Accepted events and accounting are repaired by new events."},{"id":"INV-011","name":"explicit_epoch_continuity","text":"Every balance epoch has declared closure and transition rules."},{"id":"INV-012","name":"moderation_purge_split","text":"Visibility, retraction, deletion request and verified purge are distinct."},{"id":"INV-013","name":"ai_deny_by_default","text":"Content and model output cannot grant tool or state authority."},{"id":"INV-014","name":"adapter_non_sovereignty","text":"External protocol state requires separate accepted Pioneer events."},{"id":"INV-015","name":"noted_isolation","text":"Noted history cannot affect institutional eligibility, economics, truth, moderation or research assessment."},{"id":"INV-016","name":"publication_isolation","text":"Static publication consumes reviewed promotion artifacts only."},{"id":"INV-017","name":"narrow_freeze","text":"Failures freeze the narrowest affected scope."},{"id":"INV-018","name":"operator_receipt","text":"Exceptional operator actions require explicit start, expiry, scope, reason, affected state, effect, reviewer, review deadline and termination receipt."},{"id":"INV-019","name":"one_compensation_domain","text":"One deliverable lineage may settle in exactly one compensation domain."},{"id":"INV-020","name":"secret_ballot_model","text":"Binding ballot choices are not publicly linkable or transferable as proof."},{"id":"INV-021","name":"civic_source_only","text":"Only equal current-cycle civic LEX may fund binding ballot conviction; governance/social/transferred/service LEX is non-voting."},{"id":"INV-022","name":"proposal_throughput_equality","text":"Accepted proposal throughput is identity-capped and cannot be increased by NEX, LEX transfer, service role, popularity, Noted status or external protocol reach."},{"id":"INV-023","name":"private_root_non_export","text":"Private human-root and pseudonym-link data cannot enter public federation, public LOOM, public fork bundles or public ballot records."},{"id":"INV-024","name":"anonymous_ballot_union","text":"Anonymous ballot envelopes omit actor identity and use scoped nullifiers/proofs; they are not coerced into the actor-bound social envelope."},{"id":"INV-025","name":"enabled_adapter_review","text":"Every enabled adapter is included in the exact integrated candidate reviewed, repaired and adjudicated before S07."},{"id":"INV-026","name":"multi_epoch_trajectory","text":"NEX epoch opening cannot reset cumulative issuance trajectory or evade a higher-class variance review."},{"id":"INV-027","name":"critical_projection_reproducibility","text":"Critical views expose source events, projection version and deterministic reference output; UI cannot alter canonical outcomes."},{"id":"INV-028","name":"noted_no_institutional_prestige","text":"Noted state cannot affect identity maturity, task access, reputation, moderation, LEX issuance, proposal access, ballots or research assessment."}],"nodes":[{"class":"authority_root","id":"GENESIS","label":"Synthetic genesis manifest"},{"class":"authority","id":"CONST","label":"Constitution / accepted canon"},{"class":"authority","id":"OP","label":"Bootstrap operator / later constitutional roles"},{"class":"foundation","id":"ID","label":"Identity + key registry"},{"class":"foundation","id":"MATURITY","label":"Mature-human credential state"},{"class":"authority","id":"ROLE","label":"Role and capability grants"},{"class":"foundation","id":"CLOCK","label":"Injected deterministic clock/events"},{"class":"foundation","id":"EVT","label":"Canonical signed-event kernel"},{"class":"foundation","id":"HEAD","label":"Head checkpoints"},{"class":"evidence","id":"REC","label":"LOOM RECORD store"},{"class":"derived","id":"ROUTE","label":"LOOM ROUTE indexes"},{"class":"claim","id":"CLAIM","label":"LOOM CLAIM registry"},{"class":"event_domain","id":"SOCIAL","label":"Social events + projections"},{"class":"institutional_action","id":"MOD","label":"Moderation / appeal / resolution"},{"class":"work_market","id":"TASK","label":"Task publication"},{"class":"work_market","id":"BID","label":"Bids"},{"class":"work_market","id":"CONTRACT","label":"Accepted contract"},{"class":"work_market","id":"EXEC","label":"Agent/human execution"},{"class":"evidence","id":"RECEIPT","label":"Execution receipt"},{"class":"finding","id":"VERIFY","label":"Independent verification"},{"class":"institutional_action","id":"ADJ","label":"Adjudication"},{"class":"derived","id":"WORK_REP","label":"Work reputation projection"},{"class":"derived","id":"COMPETENCE","label":"Role-specific competence projection"},{"class":"accounting","id":"NEX","label":"NEX event ledger + epoch balances"},{"class":"accounting","id":"LEX","label":"LEX event ledger + epoch balances"},{"class":"institutional_action","id":"GOV","label":"Governance proposals / ballots"},{"class":"institutional_action","id":"ENACT","label":"Rule enactment"},{"class":"derived_intelligence","id":"AI","label":"Native social AI / Relay"},{"class":"transport_adapter","id":"ATP","label":"AT Protocol adapter"},{"class":"transport_adapter","id":"NOSTR","label":"Nostr adapter"},{"class":"optional_game_domain","id":"NOTED","label":"Noted deterministic game adapter"},{"class":"published_position","id":"PUB","label":"Static public publication"}],"representation_rule":{"check_command":"python3 generate_round14_views.py --check","generated_view":"AUTHORITY_GRAPH_GENERATED.v2.md","generator":"generate_round14_views.py","lossless":true,"mutation_detection":"every normative field is embedded as canonical JSON; any field mutation changes the generated view","normative_source":"NORMATIVE_AUTHORITY_GRAPH.v2.json","projection_schema":"AUTHORITY_GRAPH_PROJECTION_SCHEMA.v1.json"},"schema_version":"pa.normative_authority_graph.v2","status":"ROUND14_SYNTHETIC_ARCHITECTURE_NORMATIVE_WITHIN_PROVISIONAL_PACKAGE"}
```
