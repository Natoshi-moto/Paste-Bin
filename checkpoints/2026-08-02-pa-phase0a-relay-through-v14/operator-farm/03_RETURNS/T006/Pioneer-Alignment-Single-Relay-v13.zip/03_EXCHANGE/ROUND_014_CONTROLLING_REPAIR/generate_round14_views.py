#!/usr/bin/env python3
from pathlib import Path
import json, sys

ROOT=Path(__file__).resolve().parent

def canon(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",",":"))

def graph_view(g):
    lines=["# Generated Authority Graph v2","","> Generated from `NORMATIVE_AUTHORITY_GRAPH.v2.json`. Do not edit.",""]
    lines += ["## Metadata","",f"- Schema: `{g['schema_version']}`",f"- Status: `{g['status']}`",""]
    lines += ["## Nodes","","| ID | Label | Class |","|---|---|---|"]
    for n in g["nodes"]: lines.append(f"| `{n['id']}` | {n['label']} | `{n['class']}` |")
    lines += ["","## Edges","","| ID | From | To | Relation |","|---|---|---|---|"]
    for e in g["edges"]: lines.append(f"| `{e['id']}` | `{e['from']}` | `{e['to']}` | `{e['relation']}` |")
    lines += ["","## Invariants",""]
    for i in g["invariants"]: lines.append(f"- **{i['id']} `{i['name']}`:** {i['text']}")
    lines += ["","## Forbidden edges","","| From | To |","|---|---|"]
    for e in g["forbidden_edges"]: lines.append(f"| `{e['from']}` | `{e['to']}` |")
    lines += ["","## Lossless canonical JSON","","```json",canon(g),"```",""]
    return "\n".join(lines)

def gate_view(r):
    lines=["# Generated Gate Registry v3","","> Generated from `GATE_REGISTRY.v3.json`. Do not edit.","",
           f"Corpus: `{r['corpus']['path']}` — `{r['corpus']['sha256']}`","",
           "| Gate | Sweep | Cases | Assertions | Mutants | Independent |","|---|---|---:|---:|---:|---|"]
    for g in r["gates"]:
        lines.append(f"| `{g['gate_id']}` | `{g['sweep']}` | {len(g['required_case_ids'])} | {len(g['required_assertion_ids'])} | {len(g['required_mutant_ids'])} | {str(g['independent_implementation_required']).lower()} |")
    lines += ["","## Lossless canonical JSON","","```json",canon(r),"```",""]
    return "\n".join(lines)

pairs=[
("NORMATIVE_AUTHORITY_GRAPH.v2.json","AUTHORITY_GRAPH_GENERATED.v2.md",graph_view),
("GATE_REGISTRY.v3.json","GATE_REGISTRY_GENERATED.v3.md",gate_view),
]
check="--check" in sys.argv
bad=[]
for src_name,out_name,fn in pairs:
    obj=json.loads((ROOT/src_name).read_text(encoding="utf-8"))
    rendered=fn(obj)
    out=ROOT/out_name
    if check:
        if not out.exists() or out.read_text(encoding="utf-8") != rendered:
            bad.append(out_name)
    else:
        out.write_text(rendered,encoding="utf-8")
if bad:
    print("MISMATCH: "+", ".join(bad)); sys.exit(1)
print("PASS generated views" if check else "GENERATED views")
