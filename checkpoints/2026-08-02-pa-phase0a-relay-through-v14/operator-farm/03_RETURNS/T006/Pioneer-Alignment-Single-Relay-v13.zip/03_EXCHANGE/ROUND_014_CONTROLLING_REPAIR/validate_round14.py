#!/usr/bin/env python3
from pathlib import Path
import json, hashlib, subprocess, sys, copy, re

R=Path(__file__).resolve().parent
fail=[]

def load(name): return json.loads((R/name).read_text(encoding="utf-8"))
def ok(cond,msg):
    if not cond: fail.append(msg)

# Generated-view check
p=subprocess.run([sys.executable,str(R/"generate_round14_views.py"),"--check"],capture_output=True,text=True)
ok(p.returncode==0,"generated view --check failed: "+p.stdout+p.stderr)

# Lossless graph projection
graph=load("NORMATIVE_AUTHORITY_GRAPH.v2.json")
md=(R/"AUTHORITY_GRAPH_GENERATED.v2.md").read_text()
m=re.search(r"```json\n(.*)\n```\n?$",md,re.S)
ok(bool(m),"graph canonical JSON block missing")
if m:
    ok(json.loads(m.group(1))==graph,"graph view not lossless")

# Graph mutation must alter view
mut=copy.deepcopy(graph); mut["invariants"][0]["text"]+=" MUTATION"
def canon(o): return json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(",",":"))
ok(canon(mut)!=canon(graph),"graph mutation not detected")

# DAG strict references
dag=load("BUILD_DAG.v3.json")
ids={n["id"] for n in dag["nodes"]}
outs={n["id"]:{o["output_id"] for o in n["outputs"]} for n in dag["nodes"]}
for n in dag["nodes"]:
    for d in n["dependencies"]:
        ok(d["node_id"] in ids,f"dangling DAG node {d}")
        if d["node_id"] in outs: ok(d["output_id"] in outs[d["node_id"]],f"dangling DAG output {d}")
        ok(isinstance(d.get("condition"),str) and d["condition"],f"missing dependency condition {d}")
# planted dangling dependency must fail strict checker
bad=copy.deepcopy(dag); bad["nodes"][1]["dependencies"].append({"node_id":"MISSING","output_id":"X","interface_sha256_source":"x","condition":"always"})
bad_ids={n["id"] for n in bad["nodes"]}
ok(any(d["node_id"] not in bad_ids for n in bad["nodes"] for d in n["dependencies"]),"planted DAG defect escaped")

# enabled adapter path
for aid in ["S03A-AT","S03A-NOSTR","S03A-NOTED"]:
    n=next(x for x in dag["nodes"] if x["id"]==aid)
    ok(n["review_path"]=="S06R-ADAPTERS",f"{aid} review path wrong")
s05a=next(x for x in dag["nodes"] if x["id"]=="S05-ADAPTERS")
ok(any(d["node_id"]=="S03A-AT" for d in s05a["dependencies"]),"AT absent from integration")

# Gate registry/corpus binding
reg=load("GATE_REGISTRY.v3.json"); corpus=load("GATE_CORPUS.v1.json")
ok(hashlib.sha256((R/"GATE_CORPUS.v1.json").read_bytes()).hexdigest()==reg["corpus"]["sha256"],"gate corpus hash mismatch")
gateids={g["gate_id"] for g in reg["gates"]}
for n in dag["nodes"]:
    for gid in n["required_gates"]: ok(gid in gateids,f"unknown gate {gid} on {n['id']}")
for g in reg["gates"]:
    c=corpus["gates"].get(g["gate_id"])
    ok(c is not None,f"missing corpus {g['gate_id']}")
    if c:
        caseids=[x["case_id"] for x in c["cases"]]
        ok(len(caseids)==len(set(caseids)),"duplicate gate cases "+g["gate_id"])
        ok(set(g["required_case_ids"])==set(caseids),"gate case binding mismatch "+g["gate_id"])
        ok(len(g["required_assertion_ids"])>0,"zero assertions "+g["gate_id"])
        ok(len(g["required_mutant_ids"])>0,"zero mutants "+g["gate_id"])
# planted duplicate/zero assertion detected
gmut=copy.deepcopy(reg["gates"][0]); gmut["required_case_ids"].append(gmut["required_case_ids"][0]); gmut["required_assertion_ids"]=[]
ok(len(gmut["required_case_ids"])!=len(set(gmut["required_case_ids"])) and len(gmut["required_assertion_ids"])==0,"planted gate defect escaped")

# Phase 0A original floor
floor=load("PHASE0A_ACCEPTANCE_FLOOR.v2.json")
required={"G-P0A-SCHEMA","G-P0A-MIGRATION","G-P0A-SLUG","G-P0A-CHAIN","G-P0A-RAWHTML","G-P0A-FAKE-RELAY","G-P0A-SECRETS","G-P0A-DEPS","G-P0A-TRAVERSAL","G-P0A-WRITE-BOUNDARY","G-P0A-WEB","G-P0A-EXPORT"}
ok(required=={x["id"] for x in floor["gates"]},"Phase0A gate floor incomplete")

# Genesis fixed hashes
ep=load("SYNTHETIC_GENESIS/GENESIS_EXPECTED.json")
for key,name in [("inputs_sha256","GENESIS_INPUTS.json"),("canonical_profile_sha256","CANONICAL_PROFILE.json"),("algorithm_registry_sha256","ALGORITHM_REGISTRY.json"),("keys_sha256","SYNTHETIC_KEYS.json"),("genesis_event_file_sha256","GENESIS_EVENT.json"),("checkpoint_file_sha256","GENESIS_CHECKPOINT.json")]:
    actual=hashlib.sha256((R/"SYNTHETIC_GENESIS"/name).read_bytes()).hexdigest()
    ok(actual==ep[key],f"genesis hash mismatch {name}")
# planted genesis mutation detected
raw=(R/"SYNTHETIC_GENESIS/GENESIS_INPUTS.json").read_bytes()
ok(hashlib.sha256(raw+b"X").hexdigest()!=ep["inputs_sha256"],"planted genesis mutation escaped")

# Membrane source allowlist and legacy supersession
mem=load("MEMBRANE_REDUCER_CONTRACT.v1.json")
for forbidden in ["nex_balance","nex_work_receipt","work_reputation","social_reputation","noted_state"]:
    ok(forbidden in mem["maturity"]["forbidden_inputs"],"maturity forbidden input missing "+forbidden)
for cls in ["GOVERNANCE_SERVICE","SOCIAL_SERVICE","TRANSFERRED"]:
    ok(mem["lex_classes"][cls]["binding_vote_eligible"] is False,cls+" incorrectly vote eligible")
ok(mem["lex_classes"]["CIVIC_CURRENT_CYCLE"]["binding_vote_eligible"] is True,"civic LEX not vote eligible")
ok(mem["proposal_throughput"]["base_slots_per_cycle"]==1,"proposal quota not equal")
sup=load("LEGACY_SUPERSESSION_MAP.v1.json")
ok(len(sup["entries"])>=9,"legacy supersession incomplete")

# Privacy/event contradiction
spec=(R/"CANONICAL_ENCODING_TIME_PRIVACY_SPEC.v2.md").read_text()
ok("ANONYMOUS_ACTION_V1" in spec and "CONFIDENTIAL_RECORD_V1" in spec,"event union missing")
ok("no raw payload, unsalted payload hash, deterministic" in spec,"private public-commitment prohibition missing")
# planted private commitment must be rejected by architecture rule
bad_private={"type":"CONFIDENTIAL_RECORD_V1","payload_hash":"0"*64}
ok("payload_hash" in bad_private and "payload_hash" not in ["type","schema","record_handle","policy_id"],"planted privacy defect escaped")

# Parameters and blockers populated
params=load("PARAMETER_DECISION_REGISTRY.v2.json")
ok(len(params["decisions"])>=10,"parameter registry unpopulated")
blocks=load("PUBLIC_BLOCKER_REGISTRY.v3.json")
ok(all(b["required_evidence_artifact"] and b["closure_predicate"] for b in blocks["blockers"]),"public blockers unexecutable")
ns=load("FINDING_NAMESPACE_MAP.v2.json")
ok(any(m["legacy"]=="PB-001" and m["canonical"]=="R9-B001" for m in ns["mappings"]),"finding mapping absent")

# GitHub no authority
gh=load("GITHUB_BACKUP_POLICY.v2.json")
ok(gh["standing_push_authority"] is False and gh["current_push_authority"] is False,"GitHub authority accidentally granted")
ok(gh["per_backup_approval"]["single_use"] is True,"backup approval not single use")
ok(gh["preflight"]["recursive_archive_inspection"] is True,"opaque archive policy missing")

# Canon blocker remains honest
cb=load("CANON_SNAPSHOT_BLOCKER.v2.json")
ok(all(x["present"] is False and x["sha256"] is None for x in cb["required_snapshots"]),"canon snapshots falsely claimed")

if fail:
    print("ROUND14 VALIDATION FAIL")
    print("\n".join("- "+x for x in fail))
    sys.exit(1)
print("ROUND14 VALIDATION PASS")
print("Planted defect classes detected: graph, DAG, gate, genesis, privacy")
