# Canonical Encoding, Event Union, Time, Finality and Privacy — v2

Status: provisional synthetic architecture; not public finality or canon.

## 1. Canonical JSON profile `PA-CANON-JSON-v2`

- UTF-8 only; no byte-order mark and no trailing newline in canonical bytes.
- Objects use string keys only.
- Keys and string values are normalised to Unicode NFC before validation.
- Post-NFC duplicate keys are rejected.
- Object keys sort by Unicode scalar-value order.
- Arrays preserve supplied order.
- Integers only. Floats, NaN, infinity and implementation-dependent number forms are rejected.
- `true`, `false` and `null` use JSON tokens.
- Control characters use JSON escapes; non-ASCII characters remain UTF-8.
- Parsers reject duplicate keys, invalid UTF-8, lone surrogates and unrecognised fields where a schema is closed.
- Domain separation is prepended outside JSON as ASCII bytes plus `0x00`.

## 2. Envelope union

The kernel accepts exactly one of three closed envelope types.

### `ACTOR_EVENT_V2`

For attributable social, ledger, administrative and service events.

Required public fields:

`type`, `schema`, `event_kind`, `actor_id`, `capability_id`,
`logical_tick`, `accepted_parent`, `payload_mode`, `payload_descriptor`,
`nonce`, `signature_suite`, `signature`.

### `ANONYMOUS_ACTION_V1`

For secret governance ballots and other explicitly authorised anonymous actions.

It omits `actor_id`. It contains:

`type`, `schema`, `action_scope`, `epoch_id`, `proposal_id`,
`credential_policy_hash`, `scoped_nullifier`, `eligibility_proof`,
`encrypted_choice`, `logical_tick`, `confirmed_head`, `signature_suite`,
`proof_signature`.

The nullifier is proposal-scoped. Public data cannot link it across proposals,
pseudonyms, epochs or federation identities. The proof binds exactly one eligible
credential, one proposal and one final ballot state. Revocation and duplicate checks
occur inside the governance reducer.

### `CONFIDENTIAL_RECORD_V1`

For private/restricted payload state.

The public envelope contains no raw payload, unsalted payload hash, deterministic
content commitment, private-root link or external identity link. It contains an
opaque random record handle and policy identifier only.

Integrity for the confidential payload is recorded in an access-controlled sidecar:

`record_handle`, `ciphertext_digest`, `policy_hash`, `key_epoch`,
`authorised_subject_commitment`, `sidecar_signature`.

The sidecar is not public LOOM or public fork material.

After verified purge, controlled stores retain only a non-reversible purge receipt
that does not contain the plaintext hash or a guessable content commitment.

## 3. Event IDs and signatures

- `body_bytes = DOMAIN || 0x00 || canonical_json(unsigned_body)`
- `event_id = SHA-256("PA-EVENT-ID-v2" || 0x00 || body_bytes)`
- Signatures cover `body_bytes`, never a rendered view.
- Hybrid signatures, when required, cover identical `body_bytes`.
- Signature framing includes suite ID and exact byte length.
- Any mismatched body, suite, field or canonicalisation profile rejects.

## 4. Logical time and ordering

- `CLOCK_TICK_V1` may be signed only by the synthetic clock capability.
- Ticks are monotonically increasing integers.
- The local synthetic sequencer assigns a monotonic `accepted_seq`.
- Same-tick order is `accepted_seq`; ties are invalid.
- Capability, revocation and role checks evaluate at acceptance sequence, not claimed wall time.
- High-authority events require the exact current confirmed head.
- Delayed high-authority events signed before revocation but accepted after revocation reject.
- Commutative low-authority offline social events may reference a stale confirmed head only when their event kind explicitly allows merge; conflict projection remains deterministic.

A confirmed head is:

`{checkpoint_id, state_hash, accepted_seq, logical_tick, event_count}`

## 5. Finality boundary

The local synthetic kernel provides one-writer checkpoint finality only.

It makes no public multi-writer, consensus, witness, availability or fork-choice claim.
Public finality remains blocker `PB-003`.

## 6. Golden vectors

`GOLDEN_VECTORS.v1.json` is normative for the synthetic profile. Independent
implementations must match every accepted/rejected outcome and byte hash.
