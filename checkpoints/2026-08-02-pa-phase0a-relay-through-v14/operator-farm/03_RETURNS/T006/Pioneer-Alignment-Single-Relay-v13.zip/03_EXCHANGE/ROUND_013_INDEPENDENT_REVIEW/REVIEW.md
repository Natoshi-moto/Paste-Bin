# Pioneer Alignment — Round 013 Independent Review

Version: v1  
Date: 2026-08-01  
Actor: independent high-reasoning architecture critic  
Posture: review and adjudication only

## 1. Authority understood

I was authorised to verify the supplied relay, review Round 012 against all 31 Round 011 findings, identify false-green repairs and authority leaks, and return one complete relay containing this review.

I was not authorised to write application code, mutate or create a repository, create a branch or commit, push to GitHub, deploy, request credentials, connect a provider, alter production, DNS or Cloudflare, spend money, approve an operator decision, or promote provisional architecture into binding canon.

The operator clarified during Round 013 that GitHub is intended as a private project backup/pastebin and is to be used only with the operator's authorisation. This resolves the purpose ambiguity. It is not approval of the proposed manifest and is not authority for a current or standing push.

## 2. Relay and manifest verification

Received archive:

- filename: `Pioneer-Alignment-Single-Relay-v3.zip`;
- outer SHA-256: `7afeaefbe60d9a083a330f727fea8ea0adfb6a0335e2b6251fa729fee69c8536`;
- entries: 127;
- archive test: passed;
- unsafe absolute/traversal paths: none;
- duplicate paths: none;
- symlinks: none;
- wrapper directory: none.

Integrity checks:

- immutable input manifest: 123/123 passed;
- current manifest: 126/126 passed and correctly excluded itself;
- Round 012 checksum manifest: all 23 listed files passed;
- supplied `validate_round12.py`: passed its own checks.

An independent current-snapshot comparison found that the node labels, edge triples and invariant rows shown in `AUTHORITY_GRAPH_GENERATED.md` match the corresponding JSON fields, and that the rows shown in `GATE_REGISTRY_GENERATED.md` match the selected gate fields. This proves present content agreement only. No generator or `--check` mechanism is supplied, and the Round 012 validator never reads either Markdown view.

`05_MANIFESTS/FILE_INVENTORY.json` is stale: it identifies relay v1 and 93 pre-manifest files, while the received relay is v3 with 127 entries. It is integrity-protected historical metadata, not a current inventory.

## 3. Executive adjudication

`HOLD_FOR_ADDITIONAL_ARCHITECTURE_REPAIR`

Round 012 is directionally useful, but it is not ready for final reconciliation or implementation. It records several correct policies while leaving their machine representations, precedence, parameters, evidence schemas or dependency wiring unresolved. The supplied validator can report green while dangling dependencies, missing gate evidence, stale generated views and cross-domain authority paths remain.

Disposition counts:

| Disposition | Critical | High | Medium | Total |
|---|---:|---:|---:|---:|
| `CLOSED` | 0 | 1 | 1 | 2 |
| `PARTIALLY_CLOSED` | 13 | 10 | 2 | 25 |
| `OPEN` | 0 | 2 | 1 | 3 |
| `SUPERSEDED_BY_STRONGER_REPAIR` | 0 | 0 | 0 | 0 |
| `INSUFFICIENT_EVIDENCE` | 1 | 0 | 0 | 1 |
| **Total** | **14** | **13** | **4** | **31** |

This is not a rejection of the narrow Phase 0A aim. It is a veto on building against an acceptance specification that can still pass without exercising the original Phase 0A floor.

## 4. Finding-by-finding closure table for all 31 Round 011 findings

`R12/` below means `03_EXCHANGE/ROUND_012_CONTROLLING_RECONCILIATION/`.

| ID | Severity | Disposition | Evidence and adjudication | Objective closure test |
|---|---|---|---|---|
| R11-001 | Critical | `INSUFFICIENT_EVIDENCE` | `R12/CANON_INDEX.json` is explicitly incomplete; all ten source entries have `sha256: null`. `R12/SOURCE_SNAPSHOT_REQUEST.md` honestly preserves the blocker. | Every binding invariant resolves to one present, hash-pinned clause with status and supersession; no unresolved authority reference remains. |
| R11-002 | Critical | `PARTIALLY_CLOSED` | `R12/NORMATIVE_AUTHORITY_GRAPH.json` and its current Markdown view agree on displayed fields, but no generator exists, the view is lossy, the validator does not compare them, and three original invariants are weakened. | A deterministic generator reproduces every declared projection; parity covers every normative field or an explicit projection schema; field mutations fail. |
| R11-003 | Critical | `PARTIALLY_CLOSED` | `R12/SYNTHETIC_GENESIS.json` declares a synthetic root and order, but lacks exact test keys/key hashes, algorithm-registry bytes/hash, genesis event/checkpoint bytes, expected state hash and a hash-pinned clock fixture. | Two clean implementations derive the same genesis event, checkpoint and state hash from the self-contained manifest; every root/key/grant/order/profile mutation rejects. |
| R11-004 | Critical | `PARTIALLY_CLOSED` | M2, graph INV-006 and direct forbidden edges state zero NEX/work effect, but legacy Round 8 still consumes work/service history and the graph retains `WORK_REP -> COMPETENCE -> ROLE -> EVT -> LEX -> GOV` without a role allowlist or supersession map. | With allowlisted identity evidence fixed, arbitrary NEX/work/reputation/social/Noted changes leave maturity, civic issuance, proposal quota and ballot capacity byte-identical; forbidden transitive paths fail lint. |
| R11-005 | Critical | `PARTIALLY_CLOSED` | `R12/BUILD_DAG.json` fixes the obvious S04/S03 relationship, but dependencies use ad-hoc suffixes, the validator discards qualifier semantics and unknown bases, gates can precede required subsystems, and enabled adapters bypass the S06 path. | Structured dependencies reject every dangling node/output; exact input/output hashes and accepted bases are present; every optional configuration topologically validates and enters review. |
| R11-006 | Critical | `PARTIALLY_CLOSED` | One gate registry now exists with nonzero minima and fail labels, but `pa.gate_evidence.v1` is undefined and all 29 gates lack frozen corpus hashes, seeds, named cases, expected transitions, mutant IDs and exact candidate binding. | A real runner fails empty/skipped/killed/zero-assertion runs, proves named case coverage, and turns every relevant gate red under a seeded violation. |
| R11-007 | Critical | `PARTIALLY_CLOSED` | `R12/INDEPENDENT_REPLAY_SPEC.md` defines a credible clean-room boundary, but no frozen unambiguous wire vectors, adversarial corpus, separately authored verifier package or mutation receipt exists. | A separately authored implementation imports no primary canonicaliser/reducer/generated code and matches valid/rejected corpus results while killing named semantic mutants. |
| R11-008 | Critical | `PARTIALLY_CLOSED` | `R12/REVIEW_REPAIR_ADJUDICATION_SPLIT.md` correctly separates roles and blocks open material findings, but no machine actor/candidate/disabled-feature receipt schema binds the exact merge commit. | Machine evidence proves distinct reviewer, repairer and adjudicator identities; adjudication binds the repaired merge commit; S07 rejects every open material invariant or enabled deferred feature. |
| R11-009 | High | `PARTIALLY_CLOSED` | `R12/PHASE_0A_REPAIR_ADDENDUM.md` adds version, state hash, prior hash, transaction ID and atomic append, but does not define exact canonical note fields, domain separation, create sentinel or version transition. | Row tampering, missing/reordered events and half-transactions fail against one frozen canonical note/event schema. |
| R11-010 | High | `PARTIALLY_CLOSED` | The payload-manifest-receipt graph is acyclic and export events are excluded, but the subject/global provenance cut, verification-event treatment, manifest encoding/order/newlines, export parameter schema and deterministic container metadata remain unspecified. | Two fresh-process exports of the same frozen cut are byte-identical; every payload or parameter mutation fails; the receipt graph is acyclic and complete. |
| R11-011 | High | `CLOSED` | Tracked status now uses `final_commit: DETACHED_RECEIPT_REQUIRED`; the actual HEAD is bound after commit in a detached receipt. | Final tree is clean and the detached receipt equals `git rev-parse HEAD`; no tracked object claims its containing commit. |
| R11-012 | High | `PARTIALLY_CLOSED` | Payload/envelope separation and purge stores are introduced, but the universal envelope requires `payload_hash` while private hashes are said to exist only in restricted metadata. Envelope visibility and purge-safe commitment semantics conflict. | Purge defeats recovery and low-entropy guessing across every controlled store/export while a minimal replayable public envelope reveals no content commitment or root link. |
| R11-013 | High | `PARTIALLY_CLOSED` | Logical ticks, acceptance-time authority checks, stale high-authority rejection and the public-finality blocker are improvements. CLOCK_TICK authority/progression, same-tick order, confirmed-head format, merge rules and executable fixtures are missing. | Independent skew, rollback, delayed submission, revocation-before-sync and partition fixtures produce identical accepted/rejected states. |
| R11-014 | High | `OPEN` | `R12/GITHUB_CONTINUITY_AUTHORITY_MANIFEST_PROPOSAL.json` is explicitly unapproved. The operator's backup/pastebin clarification requires a single-use authorisation for each exact backup, which the proposal does not encode. | No write occurs without one expiring approval naming exact private repo, visibility, branch, operation, actor, commit/tree and artifact inventory; opaque archives are recursively inspected or excluded. |
| R11-015 | High | `PARTIALLY_CLOSED` | Core and optional adapters are split, but `S06R` depends on `S05`, not conditionally on `S05-ADAPTERS`; an enabled adapter candidate can escape review. | Disabled adapters leave core hashes identical; every enabled adapter passes its preflight/gates and enters the exact-candidate S06R/F/A path. |
| R11-016 | High | `PARTIALLY_CLOSED` | `R12/PARAMETER_DECISION_REGISTRY.json` defines useful classes but contains no populated decisions, approvals or executable lint. Several blocked proposals self-label normative without an acceptance receipt. | Every authority-sensitive value resolves to an approved decision; any unregistered seed, threshold, time window, encoding or emergency cap fails closed. |
| R11-017 | High | `OPEN` | Round 012 adds no `git bundle --all`, destructive restore drill, frozen toolchain/source snapshot, dependency/SBOM policy, network-disabled double build or `UNSIGNED_LOCAL_ARTIFACT` rule. | Destroy a disposable clone, restore all refs from an independently stored bundle, and reproduce tree/state hashes in network-disabled double builds. |
| R11-018 | High | `PARTIALLY_CLOSED` | The Phase 0A addendum states loopback, socket, Host, Origin, CSRF and body controls, but G-P0A-003 omits several controls and the exact Host/Origin/null-Origin policy; original raw-HTML and traversal gates are not preserved. | Runtime bind override, hostile Host/Origin, null Origin, missing/invalid CSRF, oversized/wrong-content bodies, raw HTML and traversal all fail; socket is exactly `127.0.0.1`. |
| R11-019 | High | `PARTIALLY_CLOSED` | `R12/PUBLIC_BLOCKER_REGISTRY.json` materially expands the set and keeps all open, but every `required_evidence_artifact` is null and no candidate-bound closure predicate exists. | Every blocker names exact expected evidence, subject and independent receipt; count-only or mismatched evidence cannot close it. |
| R11-020 | Medium | `PARTIALLY_CLOSED` | PA-NEXT is correctly downgraded to selected-transcript reference evidence and made non-blocking for Phase 0A, but repository/tree/observed-at/gate fields and a reproducible parser remain absent. | An independent parser reproduces bounded counts and the gate engine refuses any wider or Phase 0A application. |
| R11-021 | Medium | `OPEN` | `R12/FINDING_NAMESPACE_MAP.json` contains prefix rules rather than actual mappings; its own legacy note says mapping remains pending, while public blockers use `PB-*` despite the stated `R9-B###` rule. | Every prose/CSV/JSON/amendment/blocker row maps to one stable ID with no collision, orphan, alias or count-only record. |
| R11-022 | Medium | `CLOSED` | The current manifest excludes itself and the outer ZIP digest is reported out of band. Both layers were independently verified. | Inner manifest verifies all covered entries; detached outer digest verifies received ZIP bytes; neither covers itself. |
| R11-023 | Medium | `PARTIALLY_CLOSED` | Static evidence is correctly labelled reference-only, but no defined evidence schema or gate runner enforces repository/commit/candidate/scope matching. | Gate tooling rejects every evidence package whose subject tuple differs from the requested gate subject. |
| R11-024 | Critical | `PARTIALLY_CLOSED` | M1, INV-019 and G-S02-002 state one compensation domain, but no lineage schema, atomic cross-ledger reservation or concurrent first-claim rule exists; the gate is scheduled before LEX/S04. | One global registry rejects NEX/LEX races, copies, rewrites, splits and declared derivatives; semantic overlap outside provable lineage is explicitly residual/adjudicable. |
| R11-025 | Critical | `PARTIALLY_CLOSED` | M3 states equal proposal access, but quota window/consumption, withdrawal/retry, clones, sponsorship, concurrency and legacy transferred-LEX bond supersession are unspecified. | Varying transferred LEX from zero to maximum never changes accepted proposal slots across every direct/sponsor/withdraw/retry/concurrent path. |
| R11-026 | Critical | `PARTIALLY_CLOSED` | M4 chooses the stronger non-binding service-LEX rule, but legacy Round 7 remains contradictory, graph E-038 is generic `LEX -> GOV`, and no civic-only transition or gate exists. | Governance-service LEX adds exactly zero binding capacity after maturation, transfer, pooling, remediation and epoch transition. |
| R11-027 | Critical | `PARTIALLY_CLOSED` | M5 selects a secret model, but the universal event envelope still requires `actor_id`, `capability_grant_id` and signature. No anonymous ballot/nullifier/delegation/recovery state machine resolves duplicate voting or linkability. | Duplicate nullifiers fail; delegation plus override yields one ballot; private conflicts enforce; unrelated ballots remain unlinkable; inclusion is provable without transferable choice proof. |
| R11-028 | Critical | `PARTIALLY_CLOSED` | M6 expands relatedness factors, but supplies no canonical domain schema, transitive collapse algorithm, evidence/unknown posture, privacy/appeal policy or recovery/nullifier continuity. | Controller, organisation, funding and infrastructure relations collapse as specified; issuer/guardian/appeal domains are disjoint; recovery cannot enable a second vote. |
| R11-029 | Critical | `PARTIALLY_CLOSED` | M7 names cumulative limits, but no fingerprint algorithm, equivalence rule, logical-tick window/cap, escalation thresholds or post-cap transition is selected; the gate checks only non-reset. | One hundred altered hold/end/restart events across an outage hit a fixed deterministic hard stop no declarer or panel can extend. |
| R11-030 | High | `PARTIALLY_CLOSED` | M8 adds pairwise IDs and root exclusions, but there is no attacker model, correlation metric/bound, exact mapping schema or deletion transition; legacy detailed mappings remain unsuperseded. | Against a named observer with public records/content/timing, measured root-link recovery remains below a named bound and deletion enters one deterministic retention state. |
| R11-031 | High | `PARTIALLY_CLOSED` | M9 adds precommit/isolation, but the allocator can still search seeds, methods or candidate commitments before committing; no unbiasable seed, deadline, abort consumption or metric exists. | Varying slots, seeds, receipt metadata, aborts and disclosure timing yields no selection advantage; Noted-only changes leave all institutional projections byte-identical. |

## 5. New material findings introduced by Round 012

### R13-001 — Generated and validator false-green

- Severity: CRITICAL
- `validate_round12.py` never reads either generated Markdown view and no generator is supplied. It checks only a small subset of graph, DAG and gate semantics, yet prints a broad internal-consistency pass.

### R13-002 — DAG dependency erasure and unsafe ordering

- Severity: CRITICAL
- The validator strips `:` qualifiers and `?`, silently drops unknown dependency bases, and cannot prove required interface existence. Nodes do not bind required gates, input/output hashes or accepted commits. G-S02-002 and G-S02-003 require later LEX/maturity/governance state, and enabled adapters are outside the S06 review path.

### R13-003 — Gate evidence and Phase 0A coverage gap

- Severity: CRITICAL
- `pa.gate_evidence.v1` does not exist. Counts are unbound to named fixtures and can be satisfied by duplicates. Phase 0A sealing names only three composite gates and omits the original explicit migration, slug, chain, raw-HTML, fake-Relay, secrets, dependency-audit, traversal and write-boundary requirements.

### R13-004 — Synthetic genesis is not independently derivable

- Severity: CRITICAL
- The manifest references profiles and validation steps without exact keys, registry bytes/hashes, event/checkpoint bytes, expected state hash or external expected manifest digest. Root capability retirement is incomplete and fixture reset remains broad.

### R13-005 — Membrane and secret ballot are not machine-wired

- Severity: CRITICAL
- Legacy clauses are not explicitly superseded; LEX sources, competence roles, compensation lineage, proposal quota, anonymous ballot/nullifier state, domain independence and emergency fingerprints have no shared reducer schemas. The universal actor-bound event envelope contradicts anonymous ballots.

### R13-006 — Canonical event privacy and encoding contradiction

- Severity: HIGH
- Mandatory `payload_hash` conflicts with restricted-only private hashes and purge-safe tombstones. Post-NFC key collisions, escape choices, signature framing, same-tick ordering and head/checkpoint types are not fully specified, so clean implementations may diverge or leak guessable content commitments.

### R13-007 — Original authority invariants were weakened

- Severity: HIGH
- Graph INV-006 omits NEX effects on moderation, visibility, reputation, evidence and truth; INV-009 omits deposit, withdrawal and exchange; INV-018 replaces explicit start and expiry with ambiguous “time.”

### R13-008 — Blocker and finding registries are not executable

- Severity: HIGH
- All 22 public blockers have null evidence-artifact fields and no closure predicates. The finding namespace file contains no mappings and conflicts with the blocker's `PB-*` identifiers.

### R13-009 — Phase 0A canonical input and export format remain undefined

- Severity: HIGH
- The note-state hash lacks an exact field/domain/version schema, and deterministic export lacks exact provenance cuts, manifest encoding, file ordering, newline and archive metadata rules.

### R13-010 — Private GitHub backup policy is incomplete

- Severity: HIGH
- The proposal is unapproved, uses generic writer/branch fields, lacks single-use expiry and does not require recursive inspection or exclusion of nested opaque archives. Policy approval must not become standing push authority.

### R13-011 — Relay metadata and next-actor instructions can go stale

- Severity: MEDIUM
- `FILE_INVENTORY.json` still describes v1. The current round is forbidden to update `START_HERE.md`, `PROMPT_TO_EXECUTE.md` and `RELAY_PROTOCOL.md`, so v4 necessarily contains previous-actor instructions alongside the updated current state. The current state must be authoritative until Round 014 repairs the control protocol.

## 6. Normative graph, DAG and gate parity review

The present graph and gate Markdown rows match the JSON fields they display. That is a useful observation, not generation proof. The views omit normative fields, there is no projection schema, and no supplied command can regenerate or check them.

The DAG is not machine-safe because dependency strings combine node IDs, output selectors and optional markers in one unchecked string. The validator removes precisely the information that must be validated. It also fails to link nodes to gates or artifacts and fails to enumerate optional-adapter candidate paths.

The gate registry improves on Round 10 by using immutable IDs, positive/negative minima and fail labels. It remains false-green because the evidence object is undefined and no gate binds its claimed counts to a frozen corpus, seed, expected transition, mutant, implementation identity or exact candidate commit/tree.

## 7. NEX/LEX, identity and governance membrane review

M1–M9 generally point in the right direction. They do not yet constitute a coherent executable membrane.

- Mature-human inputs need an explicit identity-only allowlist and a clause supersession map.
- Competence must be limited to enumerated non-civic role pools; generic `ROLE` is too broad.
- Compensation lineage needs an atomic registry and an honest boundary around semantic derivatives.
- Civic, governance-service and transferred LEX must be distinct machine types; only civic LEX may bind ballots.
- Proposal quotas need exact periods, consumption and sponsor/retry semantics.
- Secret ballots need an anonymous envelope plus nullifier/delegation/recovery transitions.
- Administrative-domain relatedness needs evidence, privacy, unknown-state, appeal and transitive-collapse rules; household data must not become an unbounded relationship registry.
- Emergency limits need exact logical-tick parameters and deterministic post-cap state.
- Federation needs a threat model and measurable bound.
- Noted needs an unbiasable commitment source, attempt identity and abort consumption.

## 8. Event, privacy and replay review

The local logical-clock and acceptance-time model is a substantial improvement, and public admission/finality is honestly left blocked. The canonical wire profile is not complete enough for clean-room agreement: canonical JSON edge cases, tick-event authority, head/checkpoint types and same-tick order remain unresolved.

The private payload model contains a direct representation conflict. `payload_hash` is mandatory in the canonical envelope, while private hashes are said to stay in restricted metadata and public tombstones must avoid guessable hashes. The design must choose explicit envelope visibility classes or a purge-safe commitment construction rather than asserting both.

The independent replay separation rules are credible, but the actual frozen vectors, clean-room package and dependency proof are absent. Replay cannot be used to validate an ambiguous wire specification.

## 9. Phase 0A boundary review

Phase 0A remains local-only, fake-provider-only and without live authority. The repairs for note-version binding, detached final-commit receipts and loopback hardening are useful.

It is not yet safe to seal because:

- three composite gates replace rather than preserve the original minimum test floor;
- the canonical note-state hash is undefined;
- deterministic export container details are undefined;
- the later signed-event kernel is being partially imported without a clean boundary from the simpler Phase 0A LOOM-style chain;
- the exact writable host path remains external to this relay.

Phase 0A should remain a small vertical slice. It must not inherit the constitutional machinery merely to fix its local hash chain.

## 10. GitHub continuity-manifest review

The operator's clarified intent is:

- private project backup/pastebin;
- explicit operator authorisation;
- no mutation of `Natoshi-moto/pioneer-alignment-public` or production.

The proposed repository `Natoshi-moto/pioneer-alignment-app` remains only a proposal. The phrase `APPROVE PRIVATE GITHUB MANIFEST` has not been supplied and, even if supplied later, should approve policy only. Every actual backup must require a fresh single-use authorisation naming the exact repository, visibility, branch, operation, actor, commit/tree and artifact inventory. That authority expires after the one backup.

Nested ZIPs must be recursively scanned or excluded. A tracked-file scan over the outer archive is not evidence about its contents.

No GitHub action occurred in Round 013.

## 11. Remaining evidence blockers

1. Exact byte snapshots and hashes for the controlling canon bundle.
2. Invariant-to-clause traceability and accepted supersession receipts.
3. Operator approval of an amended private-backup policy; later, separate approval for each actual backup.
4. Self-contained synthetic genesis inputs and golden state.
5. Frozen event/wire vectors and a separately authored replay package.
6. Defined gate evidence schema, frozen corpora and mutation receipts.
7. Exact administrative, ballot, emergency, federation and Noted policy decisions.
8. Repository recovery/authenticity and toolchain evidence.
9. Exact writable Phase 0A host path.

## 12. Minimal required amendments

1. Add the exact canon snapshots in a new superseding round and bind every invariant to a hash-pinned clause; do not modify the now-immutable Round 012 directory.
2. Supply deterministic graph/gate view generators with `--check`, lossless projection schemas and mutation tests.
3. Replace DAG dependency strings with structured node/output/hash/condition objects; reject every dangling reference; bind each node to gates, inputs, outputs and exact commits.
4. Move cross-domain gates to integration, and route every enabled adapter through the same S06 review/adjudication path.
5. Define `pa.gate_evidence.v1` with exact candidate, implementation, corpus, seed, case, transition, mutant, subprocess and assertion fields.
6. Restore every original Phase 0A gate; add exact note/event and deterministic-export schemas.
7. Make synthetic genesis self-contained and hash-pinned, including keys, registries, fixtures, genesis bytes, checkpoint and expected state hash.
8. Add an explicit legacy-clause supersession map and a machine-readable membrane reducer contract for maturity, role pools, LEX classes, lineage, proposal quotas, ballots, domains and emergencies.
9. Resolve anonymous ballot/event-envelope and private payload/hash contradictions; freeze golden vectors.
10. Populate the parameter, finding and public-blocker registries with actual decisions/mappings/evidence predicates.
11. Define federation threat bounds and Noted unbiasable precommit/abort rules, or keep those adapters disabled.
12. Add git-bundle recovery, restore drill, toolchain/source freeze, dependency allowlist, SBOM, network-disabled double build and unsigned-local-artifact posture.
13. Amend GitHub policy with `standing_push_authority: false`, single-use per-backup approval and recursive opaque-archive handling.
14. Version the current file inventory and repair the cross-round control protocol so the next actor never receives stale executable instructions.

## 13. Final posture and exact next action

`HOLD_FOR_ADDITIONAL_ARCHITECTURE_REPAIR`

Exact next action:

The controlling ChatGPT should perform Round 014 as a narrow machine-spec repair, not a build. It should apply the fourteen amendments above in a new `03_EXCHANGE/ROUND_014_CONTROLLING_REPAIR/` directory, preserve the exact canon and GitHub approvals as open external blockers, include a validator that fails planted graph/DAG/gate/privacy defects, and return the complete relay as `Pioneer-Alignment-Single-Relay-v5.zip` for another independent review.

No repository or production mutation is authorised. Phase 0A construction remains held until its original acceptance floor and exact canonical inputs are restored.
