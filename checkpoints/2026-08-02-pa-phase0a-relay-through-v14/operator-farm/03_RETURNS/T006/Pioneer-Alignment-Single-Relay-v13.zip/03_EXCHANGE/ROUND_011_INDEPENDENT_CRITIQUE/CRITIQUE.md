# Pioneer Alignment — Round 011 Independent Architecture Critique

Version: v1  
Date: 2026-08-01  
Actor: independent architecture critic  
Posture: architecture critique only  
Evidence vocabulary: OBSERVATION, INFERENCE, ASSUMPTION, ALLEGATION, UNKNOWN

### 1. Authority understood

I am authorised to inspect the supplied relay, verify its manifests, identify contradictions, omissions, unsafe defaults, false-green gates and authority leaks, and return an amended relay containing this critique.

I am not authorised to write application code, mutate any repository, create a branch or commit, push to GitHub, deploy, access credentials, connect providers, create public accounts or balances, alter DNS or Cloudflare, spend money, promote provisional architecture into canon, delete evidence, or touch the public production repository.

The operator's accompanying direction says that project-relevant work should ultimately be preserved on GitHub and gives this critic veto authority while retaining the operator's power to reverse decisions. That direction is relevant but not sufficiently scoped to authorise a repository write: it does not identify a safe repository, visibility, branch, artifact policy or push operation. The supplied Phase 0A handoff still says no remote and no push, and the relay authority prohibits repository mutation. The only matching GitHub repository observed during read-only orientation was the expressly frozen public repository Natoshi-moto/pioneer-alignment-public. No GitHub mutation was made.

Veto means I may reject an unsafe or incoherent implementation posture. It does not grant me authority to invent canon, credentials, public policy or irreversible operator decisions.

### 2. Corpus inventory

The outer relay Pioneer-Alignment-Single-Relay-v1.zip was opened successfully and had SHA-256:

208a4fc422d28542042c8a5f8fc584a0a527ef651d37d9543b62a41f8c2da1be

The archive contained 96 entries. The immutable input manifest contains 92 files and has SHA-256:

310a3a2fb5003172e41e1c9ee7ae2f456e6bfb8f161d74baa1ca48f49903dd93

All 92 immutable files passed independent SHA-256 verification. The complete per-file path and hash inventory remains in 05_MANIFESTS/INPUT_SHA256SUMS.txt and is incorporated here by reference. Duplicate original and extracted copies were compared by hash; a logical artifact was not counted as two independent sources merely because it appeared twice.

Artifacts actually reviewed:

| Artifact | Supplied SHA-256 |
|---|---|
| 00_CONTROL/AUTHORITY.md | 9857d7170428ed2e0af7fbdf8c38db19e9cdb930ec825bc1a547d1cb910f4923 |
| 00_CONTROL/PROMPT_TO_EXECUTE.md | 4440cf9c8c4f4a623ca2d7b651db177827d0b8f977530dad44f3b26714052c4e |
| 00_CONTROL/RELAY_PROTOCOL.md | 7b59cad908cbfebf6922f17a86e106ecff09eb83727b487af124b1bce65ce1c0 |
| 00_CONTROL/START_HERE.md | 4f8bda503fea48c3b6006419b7916be71b4db007d5a74ede142ed3a81fcfbe4f |
| Founder Canon Voice Interview scaffold | f264767444b1bafcd24a70efa0784127c0227e3d503cf64ab145451414da9a5b |
| PA-NEXT-001 handoff ZIP and extracted evidence | 713dd7bbf35c6a5450ab0f497ecce7c7eb82f23d38c550d4daf68a9981c1847c |
| Phase 0A Builder Handoff | b5b4c0825b47b12935962ead4c66e546f949dd28f60b1bc3dbc301d3d448b360 |
| Phase 0A Canon Steering Addendum | 9f5740b5e7e9ea7aaa322bbc000ad0124203cd6b9133c78e4bc4f68d412c9b7a |
| Round 3 Canon Reconciliation | f3f865e8405beb6b397d644441aa4bada69c4fce91bbe7dbadc67d9c6a80bc4b |
| Round 4 Authority Graph package and extracted Markdown/JSON | 3ea7510f8e80b6e0a32f645e9c33d28bf7e718c183b5b366db9bc5bf585c669b |
| Round 5 NEX Economy package and simulation data | 9ec9248b2cf317d31bdbd26571ee5f70de97779b2da3813b6c60fe9f5894eb6f |
| Round 6 Social/LOOM/Federation/Noted package and matrices | eb21676f8b676bb2927e0cf1e27d5e9be8bb3d1dadf05f4235bb6e57b7cef134 |
| Round 7 LEX/Governance package and simulation data | 1e64717310176ec7a3680c38fe01965d1cdeee36af6185cfb90889de43878773 |
| Round 8 Identity/Custody/Agent/PQ package and matrices | 2c087b2da65b6712d2e3c5154c1d74dce5753a0da6ec9da8db5b3a926b78fad3 |
| Round 9 Integrated Threat package and risk register | 0da6c256009fff07afc7b9457bf07a3598f5d4ba67bbbc3a993d063fa8fad84b |
| Round 10 Build Sweep package, JSON, CSV and control structure | 20177de424e73de1d27e2d258c90da2c8a52d0070c90e751b6794eb8e03ec271 |
| Rounds 3–10 Architecture Corpus bundle | db4174142e81c291dc837ae5a960fdea57a0b4cc12ef0eb29ba7929e2b85b819 |
| Static Release Candidate Evidence package | 09e977a8c3419d3843921eba745874e8fe57bf18ff6e95e2b8b4c42539568002 |
| Relay verification and repackaging tools | 617b40421ee6c876f229fb5404edd02ebbd8c3de0b11489d99b7079c50747882 and 1c306bb7fb409e60cad56ba272240d1b74a19a4297924866693125ec9580c0ee |
| File inventory | 8e7bb74a40928613f0744ef24895781e9d1639d6f38852d4eee880ec6e95ab79 |

The supplied inner checksum manifests were also reviewed. Integrity succeeded. Integrity does not resolve semantic contradictions between authentic files.

### 3. Executive adjudication

HOLD_FOR_ARCHITECTURE_REPAIR

The complete Rounds 3–10 system is not ready for bounded implementation. The hold is caused by repairable architecture defects, not by a belief that every public-epoch question must be solved before local work.

The narrower Application Foundation 0A vertical slice is separately viable after the Phase 0A amendments in findings R11-009 through R11-013 and after its exact local path is available. It must be sealed and accepted as Phase 0A; it must not silently expand into the Rounds 3–10 system.

No implementation is authorised by Round 10 itself. No GitHub push is authorised by this adjudication.

### 4. Material findings

#### R11-001 — Missing binding source-of-truth bundle

- Severity: CRITICAL
- Epistemic basis: OBSERVATION
- Exact claim: The review cannot verify fidelity to the authority hierarchy because the higher-authority artifacts named by that hierarchy are absent.
- Supporting artifacts: Round 3, Authority order; Round 4 header, Inputs; Round 10 critic prompt, Source-of-truth order. The Founder Canon Voice Interview file is an unanswered scaffold, while Round 3 §2 attributes eighteen founder directions to a voice session.
- Failure sequence: a provisional round asserts a rule is binding; later rounds inherit it; a builder implements it; no reviewer can trace it to an accepted Decision Register entry, NEX/LEX Canon clause, Charter clause or exact operator decision.
- Affected invariant: provisional work cannot manufacture canon.
- Class: omission and unsupported claim.
- Required amendment: add a hash-pinned CANON_INDEX.json and exact snapshots of every controlling Decision Register, NEX/LEX Canon, Charter, domain canon/status document and load-bearing operator decision. Record status, effective date and supersession links. Either add a bounded source transcript/decision receipt for the founder directions or label each direction unsupported/exploratory.
- Objective closure test: every claimed binding invariant resolves to one present hash-verified clause; zero higher-authority references remain unresolved; an independent traceability tool reproduces the same authority order.

#### R11-002 — Round 4 prose and machine authority graphs disagree

- Severity: CRITICAL
- Epistemic basis: OBSERVATION
- Exact claim: The Markdown graph and JSON graph encode materially different systems.
- Supporting artifacts: Round 4 §2 depicts 28 nodes and 39 edges. Pioneer-Alignment-Round-4-Authority-Graph-v1.json contains 22 nodes and 29 edges, omitting operator, role, head, bid, execution and enactment. The JSON shortcuts task to contract, contract to receipt and governance to constitution. Only 8 of 29 JSON edges state authority_transfer, and the JSON invariant set omits prose §6 protections.
- Failure sequence: a builder or test generator consumes the JSON; bid, execution or enactment gates disappear; tests pass against the reduced graph while the prose architecture appears stricter.
- Affected invariant: no authority path may be removed or shortened by representation choice.
- Class: contradiction and false-green risk.
- Required amendment: designate one normative graph source and generate every Markdown, JSON and test view from it. Restore all nodes, edges, gates and all eighteen prose invariants.
- Objective closure test: schema and parity tests prove exact node, edge, gate and invariant identity; negative fixtures show no settlement without bid/execution and no constitutional mutation without valid enactment.

#### R11-003 — Bootstrap authority is circular and has no synthetic genesis

- Severity: CRITICAL
- Epistemic basis: OBSERVATION plus INFERENCE
- Exact claim: The first valid constitution, operator, identity, role grant, capability and event cannot be derived from the stated rules without an undeclared trusted root.
- Supporting artifacts: Round 4 §§4.1, 4.2, 4.4 and 4.18. Constitution needs operator/enactment; identity needs admission/role checks; the event kernel needs identity/capability; governance needs constitution, identity and LEX before it can enact.
- Failure sequence: the builder invents a first operator or bypass rule; that implementation detail becomes de facto constitutional authority; later replay reproduces the hidden assumption and mistakes consistency for legitimacy.
- Affected invariant: authority must have an explicit origin and bounded transition.
- Class: circular trust and omitted dependency.
- Required amendment: define a hash-pinned synthetic genesis manifest, exact validation order, declared trusted local sequencer, test-only keys, root capabilities, prohibited powers and transition/retirement conditions. Label it synthetic and non-public.
- Objective closure test: an independent implementation derives identical genesis state from only the manifest; changing any root hash, key, capability or order is rejected.

#### R11-004 — NEX work can still change governance eligibility

- Severity: CRITICAL
- Epistemic basis: OBSERVATION
- Exact claim: The combined architecture contains an indirect NEX-domain work to reputation to governance-maturity path.
- Supporting artifacts: Round 4 §2 links adjudication to reputation and reputation to governance; Round 4 §5 permits reputation to contribute to a maturity gate; Round 5 creates work-relevant reputation from NEX-domain contracts; Round 8 §4.3 requires independently accepted work or service receipts for synthetic maturation. Round 3 §1.2 and Round 9 F01 prohibit indirect NEX political effects.
- Failure sequence: an actor obtains or funds NEX-domain work; accepted receipts increase work reputation; reputation or those receipts help satisfy maturity; maturity yields civic LEX and governance eligibility.
- Affected invariant: NEX, reputation, identity maturity and governance remain separate.
- Class: contradiction and hidden authority transfer.
- Required amendment: remove general work reputation and all NEX-domain receipts from mature-human credential eligibility. Namespace work, competence, social, identity and governance-service signals. Governance consumes only the mature-human credential; competence affects named role pools, never civic status or ballot weight.
- Objective closure test: holding identity evidence constant while arbitrarily changing NEX balances, NEX work, participant-funded work and every work-reputation projection leaves maturity, civic LEX, proposal rights and ballot weight unchanged.

#### R11-005 — Sweep dependency graph contains implicit and contradictory edges

- Severity: CRITICAL
- Epistemic basis: OBSERVATION
- Exact claim: Round 10 cannot be executed from its declared branch dependencies.
- Supporting artifacts: Round 4 §9 orders social, moderation and reputation before NEX and LEX. Round 10 S02 depends only on S01 while requiring operator-level independence and governance-effect controls supplied later. S04 declares S01 as its dependency while consuming frozen S03 interfaces. The machine JSON repeats dependencies S02→S01, S03→S01 and S04→S01 plus a non-dependency frozen_interfaces_from field.
- Failure sequence: branches begin from S01; S04 either imports unaccepted S03 work, duplicates schemas, or cannot compile; S02 marks downstream governance/Noted effects zero because those systems are absent.
- Affected invariant: each sweep consumes only accepted, hash-frozen inputs.
- Class: contradiction, missing dependency and false-green test.
- Required amendment: create a machine-checked DAG. Add an accepted cross-domain contract checkpoint for identity/operator relatedness, retention/export classes and authority-effect types. Make S04 depend on an accepted S03 interface commit or place it sequentially after accepted S03. Reclassify downstream-isolation gates as integration gates until the downstream subsystem exists.
- Objective closure test: every branch records an exact accepted base and hashed interface package; topological validation finds no implicit edge; removing an undeclared branch makes no accepted sweep fail.

#### R11-006 — Three gate representations disagree and zero-count gates are vacuous

- Severity: CRITICAL
- Epistemic basis: OBSERVATION
- Exact claim: Prose, JSON and CSV provide different gate sets, and many gates can pass with no exercised attack case.
- Supporting artifacts: Round 10 §4.4 lists eight S01 conditions; Build-Sweeps JSON lists four; Sweep-Gates CSV lists three. Similar reductions occur through S05. S07 has no JSON hard_gate and only a label check in CSV. Numerous gates require zero violations without a denominator, minimum accepted/rejected corpus or transition coverage.
- Failure sequence: the builder selects the smallest gate view or runs empty fixtures; every violation count is zero; the sweep is labelled accepted without the threatened path being executed.
- Affected invariant: no success claim from an unexercised or selectively omitted gate.
- Class: contradiction and false-green test.
- Required amendment: create one authoritative gate registry with immutable IDs. Generate prose, JSON and CSV from it. Each predicate must define evidence schema, required positive/negative case counts, corpus hash, seed, expected transitions, minimum assertions and blocking severity.
- Objective closure test: parity lint fails on any missing/extra gate; empty, skipped, killed and zero-assertion runs fail; one seeded violation makes the relevant gate red.

#### R11-007 — Independent replay is not independent

- Severity: CRITICAL
- Epistemic basis: OBSERVATION plus INFERENCE
- Exact claim: A second reducer path in the same implementation does not satisfy the architecture's cross-implementation claim.
- Supporting artifacts: Round 10 objective requires another implementation to reconstruct state; S01.3 only forbids calling the primary reducer. Round 5 §21.3, Round 7 §19 and Round 8 §16 require cross-implementation agreement.
- Failure sequence: both paths share parser, schema, canonicaliser, hashing code or author assumption; the same semantic bug produces matching hashes; a green equality check validates common-mode error.
- Affected invariant: independent reconstruction detects implementation-specific authority bugs.
- Class: ambiguous boundary and false-green test.
- Required amendment: require a separately authored verifier/replay package that imports neither the primary reducer nor primary canonicaliser and consumes only a frozen wire specification and public vectors.
- Objective closure test: both implementations accept/reject the same adversarial corpus and match valid state hashes; seeded semantic mutations in either implementation are caught.

#### R11-008 — S06 and S07 permit release with unresolved material defects

- Severity: CRITICAL
- Epistemic basis: OBSERVATION
- Exact claim: A finding merely needs a disposition, not closure, before S07.
- Supporting artifacts: Build-Sweeps JSON S06 gates zero material findings without disposition, then S07 depends only on S06. Round 10 uses one repair branch and allows the original builder to repair.
- Failure sequence: a Critical finding is marked accepted-risk or deferred; S06 is green; S07 receives a candidate label and sealed package despite a live invariant breach.
- Affected invariant: declared candidate properties cannot coexist with unresolved material violations.
- Class: unsafe default and reviewer-independence failure.
- Required amendment: split immutable review, per-finding repair and independent adjudication identities. Block S07 on every unresolved Critical/High finding affecting a declared invariant. A deferred finding may pass only if the feature is disabled and confinement is independently tested.
- Objective closure test: release tooling refuses any open blocker; an independent reviewer reproduces each repair from a clean checkout and signs the exact reviewed commit.

#### R11-009 — Phase 0A events do not bind the note version they provenance

- Severity: HIGH
- Epistemic basis: OBSERVATION plus INFERENCE
- Exact claim: A valid event chain can coexist with tampered mutable note state.
- Supporting artifacts: Phase 0A handoff §2 mutates note rows; §4 requires action and subject identifier but not canonical subject bytes/hash, version, prior-version hash or transaction identity. The steering addendum asks only to document the boundary.
- Failure sequence: a note row is changed directly; the append-only chain remains internally valid; preview/export uses the changed row; provenance incorrectly appears intact.
- Affected invariant: provenance must bind the exact subject state.
- Class: omission and implementation risk.
- Required amendment: bind every create/edit/preview/export event to canonical note-state hash, subject version, prior-version hash and transaction ID; commit the note update and event append atomically.
- Objective closure test: row tampering, missing event, reordered version or half-transaction causes chain/export verification to fail.

#### R11-010 — Deterministic export identity is underspecified and partly circular

- Severity: HIGH
- Epistemic basis: OBSERVATION
- Exact claim: Repeated export events alter the provenance input, and a receipt/checksum can accidentally cover itself.
- Supporting artifacts: Phase 0A handoff §§4–5 requires export and verification events, a provenance excerpt, SHA256SUMS.txt, an export receipt and identical hashes for identical canonical input.
- Failure sequence: export one appends an event; export two includes a different provenance tail and produces a different payload. Alternatively the receipt or checksum attempts to cover itself and cannot stabilise.
- Affected invariant: identical canonical input produces identical export bytes.
- Class: contradiction and ambiguous completion criterion.
- Required amendment: define an immutable note-version cut and included-event boundary. Use an acyclic receipt graph: payload files, then payload manifest, then receipt. Neither manifest nor receipt covers itself. Operational export events are outside payload identity.
- Objective closure test: two fresh-process exports of the same note cut are byte-identical; any payload mutation fails verification; the receipt dependency graph is acyclic and complete.

#### R11-011 — Tracked STATUS.json cannot contain its own final commit

- Severity: HIGH
- Epistemic basis: OBSERVATION
- Exact claim: A tracked file cannot stably contain the SHA of the commit that contains it.
- Supporting artifacts: Phase 0A Required repository files demands STATUS.json.current commit; Git discipline demands a clean final tree.
- Failure sequence: write commit A into STATUS; committing that change creates commit B; updating to B creates C indefinitely.
- Affected invariant: exact truthful status with a clean tree.
- Class: impossible completion criterion.
- Required amendment: tracked status stores source parent/version or a generated placeholder. Bind the actual final commit in a detached handoff receipt, signed tag or external report.
- Objective closure test: final tree is clean; detached receipt equals git rev-parse HEAD; no tracked object claims its own containing commit.

#### R11-012 — Append-only history and verified purge lack payload separation

- Severity: HIGH
- Epistemic basis: OBSERVATION plus INFERENCE
- Exact claim: Sensitive canonical bytes cannot both remain immutable and be genuinely purged.
- Supporting artifacts: Round 4 §§4.4–4.5 makes exact accepted bytes and RECORD bytes authoritative; Round 6 §§4–5 requires retention classes and verified purge; Round 8 §1 excludes private keys/documents from public logs.
- Failure sequence: private content or a guessable content hash enters the canonical envelope; a deletion request removes a database row but leaves plaintext, ciphertext key, reversible hash or backup copy; the chain still enables recovery or correlation.
- Affected invariant: privacy-classed payloads can be purged without forging canonical history.
- Class: contradiction and privacy risk.
- Required amendment: separate canonical envelope from retention-classed payload. Use non-guessable references or ciphertext, scoped key destruction, minimal tombstones, backup/cache/export policy and explicit external-copy unknowns.
- Objective closure test: purge makes plaintext unrecoverable from database, cache, export, backup fixture and ROUTE while canonical minimal metadata still replays.

#### R11-013 — Finality, witness and time semantics remain unresolved

- Severity: HIGH
- Epistemic basis: OBSERVATION
- Exact claim: The architecture uses expiry, hours, days, current capability and confirmed head without a normative time/freshness or admission-order model.
- Supporting artifacts: Round 4 §10 explicitly leaves exact event finality and witness model open. Round 6 §3.2 says wall-clock time is metadata and §12 exposes head uncertainty. Round 7 §14.3 uses 24-hour, 72-hour and seven-day emergency limits. Round 10 S01 expects parent/head and checkpoints.
- Failure sequence: two implementations disagree whether an offline event was signed or accepted before expiry; a local clock rollback prolongs an emergency; a stale client uses a revoked capability; deterministic replay diverges.
- Affected invariant: authority expiry and replay have one deterministic meaning.
- Class: omitted dependency and ambiguous boundary.
- Required amendment: for the local synthetic system, define one injected deterministic clock/event source, acceptance-time semantics, stale-head handling and explicit rejection of high-authority offline actions after current-state uncertainty. Treat wall time as an input event, not an unstated oracle. Add public admission/order/finality/availability as a separate blocker.
- Objective closure test: clock skew, rollback, delayed offline submission, revocation-before-sync and partition fixtures produce identical results across implementations.

#### R11-014 — GitHub continuity instruction lacks a safe target and supersession record

- Severity: HIGH
- Epistemic basis: OBSERVATION
- Exact claim: The desire for durable GitHub continuity conflicts with the current no-remote/no-push rules and cannot safely target the only observed Pioneer repository.
- Supporting artifacts: Phase 0A Git discipline; Round 10 §13; 00_CONTROL/AUTHORITY.md; accompanying operator instruction; GITHUB_CONTINUITY_BOUNDARY.md in this exchange.
- Failure sequence: an agent interprets “everything goes to GitHub” broadly, adds the frozen public repo as remote, uploads architecture/private evidence or triggers deployment.
- Affected invariant: repository and production authority remain explicit and least-privileged.
- Class: authority conflict.
- Required amendment: operator-approved GitHub authority manifest naming exact private repo, visibility, branch, allowed push actor/actions, artifact include/exclude policy and explicit prohibition on public repo/deployment changes.
- Objective closure test: no write occurs with an incomplete manifest; undeclared remote, public visibility, Actions/Pages/deployment or excluded artifact fails closed.

#### R11-015 — Large sweeps make optional adapters a core blast-radius dependency

- Severity: HIGH
- Epistemic basis: OBSERVATION plus INFERENCE
- Exact claim: S03 and S04 combine too many independently failing domains while milestone checkpoints remain merely recommended.
- Supporting artifacts: Round 9 F19; Round 10 §3.3 and S03/S04 scope. Round 3 §9 and Round 6 §§11.8 and 13 require canonical Noted source/provenance/licensing inspection, which is absent.
- Failure sequence: S03 core social/LOOM is built, then Noted provenance or AT/Nostr source fails; the whole sweep remains unmergeable or an agent weakens the source gate to preserve progress.
- Affected invariant: optional adapter failure cannot contaminate or block accepted core state.
- Class: unnecessary blast radius and missing source.
- Required amendment: mandatory milestone commits and receipts. Split social/LOOM/privacy core from AT, Nostr and Noted adapters. Make Noted source/provenance/licensing a preflight gate for that adapter only.
- Objective closure test: removing every optional adapter produces identical canonical core state; each adapter can fail/disable without changing core hashes.

#### R11-016 — Builder autonomy includes authority-sensitive choices

- Severity: HIGH
- Epistemic basis: OBSERVATION
- Exact claim: Seeds, thresholds, schema fields, pagination and performance choices are not always ordinary implementation details.
- Supporting artifacts: Round 10 §12 permits these choices; Round 9 C5 shows filters, presentation and projection defaults create de facto authority; Rounds 5 §23, 7 §21 and 8 §19 mark many values provisional.
- Failure sequence: the builder chooses a seed, cap, default filter or canonical field/encoding that changes eligibility, visibility, tally or test outcomes; the choice is later treated as accepted architecture because code exists.
- Affected invariant: provisional parameters and presentation cannot silently become constitutional authority.
- Class: authority leak and unsafe default.
- Required amendment: create a parameter/decision registry classifying canonical, simulation-only, security-sensitive and ordinary reversible choices. Exclude canonical encoding, critical ordering/filtering, threat corpus, pass thresholds, retention/export semantics and authority-bearing UI from unilateral choice.
- Objective closure test: decision lint rejects an unapproved authority-sensitive choice; every autonomous decision maps to a reversible non-canonical category.

#### R11-017 — Repository recovery and release authenticity are not durable enough

- Severity: HIGH
- Epistemic basis: OBSERVATION
- Exact claim: A tag or local commit is not a recovery artifact if the only repository is lost, and a co-packaged hash manifest does not authenticate origin.
- Supporting artifacts: Round 10 §§2–3 and §15; Round 9 F20; static candidate Known Limitations on same-toolchain reproducibility.
- Failure sequence: shared worktree metadata or object database is corrupted; tag and commit vanish with it; a replacement ZIP and its manifest are both modified; no out-of-band identity detects substitution.
- Affected invariant: accepted state remains recoverable and its evidence ceiling is honest.
- Class: supply-chain and repository-operation risk.
- Required amendment: name one integration writer; serialize ref/config/gc operations; require verified git bundle --all stored separately and a restore drill. Freeze toolchain/source snapshots, dependency allowlist, lifecycle policy and SBOM. Use an out-of-band digest/signature or label artifacts UNSIGNED_LOCAL_ARTIFACT.
- Objective closure test: destroy a disposable clone, restore all accepted refs from the bundle and reproduce tree/state hashes; clean network-disabled double builds match.

#### R11-018 — Localhost binding alone does not secure a local operator app

- Severity: HIGH
- Epistemic basis: OBSERVATION plus INFERENCE
- Exact claim: A hostile web page can target loopback, and a default-only test can miss a runtime bind override.
- Supporting artifacts: Phase 0A New workspace and §7 require 127.0.0.1 but do not require Host/Origin validation, CSRF protection, body limits or actual socket assertion.
- Failure sequence: operator visits a malicious page; it submits a form to loopback; the local app accepts it. Or an environment override binds 0.0.0.0 while the unit test only inspects the default constant.
- Affected invariant: local-only means no ambient browser or LAN authority.
- Class: unsafe default.
- Required amendment: fixed loopback bind guard, actual socket assertion, Host and Origin checks, CSRF tokens, method/content-type/body limits and rejection of host overrides.
- Objective closure test: 0.0.0.0, ::, LAN address, hostile Host/Origin and missing/invalid CSRF all fail; the listening socket reports exactly 127.0.0.1.

#### R11-019 — Public blockers omit adoption, public ordering and release governance

- Severity: HIGH
- Epistemic basis: OBSERVATION
- Exact claim: Round 9 B1–B15 do not include every condition required by the architecture's own later claims.
- Supporting artifacts: Round 4 §10 leaves finality/witness open; Round 5 §23 and Round 7 §21 require explicit adoption/replacement of provisional parameters; Round 9 F17/F20 requires publication supersession and release provenance.
- Failure sequence: a locally deterministic single-sequencer system is described as public governance-ready after B1; provisional economics becomes public because it was implemented; stale publication remains institutional truth; client/release compromise changes perceived outcomes.
- Affected invariant: public authority cannot be inferred from local replay.
- Class: omission and wrongly scoped blocker.
- Required amendment: add blockers for accepted canon/parameter ratification; public event admission/order/finality/availability; production repository/release governance; LOOM-to-publication supersession; public incident/rollback drills; provider/private-data policy. Make Noted licensing conditional on shipping Noted, not a blocker for a core that excludes it.
- Objective closure test: every blocker has immutable ID, named evidence artifact and independent receipt; none closes through a count-only assertion.

#### R11-020 — PA-NEXT evidence and HOLD scope are overstated

- Severity: MEDIUM
- Epistemic basis: OBSERVATION
- Exact claim: The portable package proves calls observed in one selected transcript, not complete global activity, and its public-release HOLD can be misapplied to Phase 0A.
- Supporting artifacts: PA-NEXT Execution Ledger Reconciliation, Source Transcript References, Claude match report, CURRENT_STATE and START_HERE. The raw transcript is excluded; the match report selected a best match; repository identity/tree/gate scope are incomplete.
- Failure sequence: downstream agents treat “uncertainty resolved completely” as global proof or propagate a Cloudflare/public-candidate HOLD to the separate local app.
- Affected invariant: evidence claims remain bounded to exact source, repository, time and gate.
- Class: unsupported claim and ambiguous boundary.
- Required amendment: downgrade the claim to the selected transcript unless a redacted tool-event transcript is included. Add repository ID, remote identity, HEAD tree, observed-at, applicable gate and explicit does_not_block.
- Objective closure test: independent parser reproduces the bounded counts; gate engine cannot apply PA-NEXT to Phase 0A.

#### R11-021 — Finding identifiers collide across Round 9 representations

- Severity: MEDIUM
- Epistemic basis: OBSERVATION
- Exact claim: C1 means different things in prose and CSV, so findings cannot be reliably reconciled.
- Supporting artifacts: Round 9 prose uses C1–C7, F01–F24 and B1–B15; the CSV renames thirty rows C1–C30; JSON stores counts rather than a complete identity map.
- Failure sequence: S06 closes or repairs the wrong C1; a risk disappears because its representation cannot be joined.
- Affected invariant: every finding has stable identity and disposition history.
- Class: implementation risk.
- Required amendment: immutable namespaces such as R9-C01, R9-F01 and R9-B01 plus explicit mapping.
- Objective closure test: schema test finds no collision, orphan or count-only finding; every amendment, campaign, gate and closure receipt resolves to exactly one ID.

#### R11-022 — Relay ZIP hash requirement is self-referential

- Severity: MEDIUM
- Epistemic basis: OBSERVATION
- Exact claim: RETURN_SUMMARY.md cannot honestly contain the SHA-256 of the ZIP that contains RETURN_SUMMARY.md.
- Supporting artifacts: 00_CONTROL/RELAY_PROTOCOL.md, Required output and Repackaging.
- Failure sequence: compute ZIP hash; write it into summary; rebuild ZIP; hash changes. Repeating does not produce a guaranteed fixed point.
- Affected invariant: receipts must bind claims without circularity.
- Class: impossible completion criterion.
- Required amendment: put a deterministic content-tree or manifest hash inside the archive and report the outer ZIP hash out-of-band in the delivering message or a detached sibling receipt.
- Objective closure test: inner manifest verifies every included file except itself; outer digest verifies received ZIP bytes; neither claims to cover itself.

#### R11-023 — Static release evidence is reference-only, not sweep evidence

- Severity: MEDIUM
- Epistemic basis: OBSERVATION
- Exact claim: The static evidence proves bounded properties of commit 7c77c63… and cannot satisfy application sweep gates.
- Supporting artifacts: Static Security Assertions, Test Results and Known Limitations explicitly exclude live/provider/browser and application runtime claims.
- Failure sequence: a gate engine sees green tests and reuses them for S01–S07 despite different repository, commit, candidate ID and scope.
- Affected invariant: evidence applies only to its identified subject and claim.
- Class: scope ambiguity.
- Required amendment: label the package REFERENCE_ONLY_NOT_SWEEP_EVIDENCE and require candidate/repository/commit/scope matching.
- Objective closure test: gate tooling rejects evidence with a different candidate ID, repository, commit or scope.

#### R11-024 — One deliverable can apparently earn both NEX and governance-eligible LEX

- Severity: CRITICAL
- Epistemic basis: OBSERVATION
- Exact claim: The two ledgers have no normative receipt-consumption or derivative-lineage rule preventing double compensation.
- Supporting artifacts: Round 5 §7.2 rewards audits, research, documentation and provenance; Round 7 §4.1 rewards governance audits and public-process documentation; Round 7 §4.2 says completing NEX work is non-earning but does not define how the same or derived receipt is detected.
- Failure sequence: deliverable R settles for NEX; the actor copies, wraps or splits R into R-prime; a LEX programme accepts it as governance service; one act crosses the economic membrane through two reward events.
- Affected invariant: one economic-domain act cannot manufacture influence in the other domain.
- Class: omission and hidden conversion.
- Required amendment: every receipt receives one immutable compensation domain. Copies and derived/split receipts inherit the exclusion unless an independently scoped second deliverable with distinct acceptance evidence is proven.
- Objective closure test: after R settles in NEX, attempts to issue LEX from R, a byte-copy, metadata rewrite or derived R-prime all fail.

#### R11-025 — Transferred LEX can buy agenda bandwidth

- Severity: CRITICAL
- Epistemic basis: OBSERVATION
- Exact claim: Transferred LEX is denied ballot weight but permitted to fund binding-proposal bonds, which is still governance influence.
- Supporting artifacts: Round 7 §§2.2 and 9.2; attack matrices cover laundering and wealth gates but not proposal-volume advantage.
- Failure sequence: a wealthy actor acquires transferred LEX or receives it through a side deal; funds many binding proposals; consumes civic attention and sets the agenda despite having no extra ballot weight.
- Affected invariant: transferable wealth does not buy governance authority.
- Class: contradiction and omitted attack.
- Required amendment: cap accepted binding submissions per mature credential equally. Use civic capacity or independent sponsors for access. Transferred LEX may be refundable anti-spam collateral but cannot increase proposal throughput.
- Objective closure test: one million transferred LEX gives no more accepted proposal slots than an otherwise identical zero-balance mature participant.

#### R11-026 — Governance-service LEX creates a lawful incumbent aristocracy

- Severity: CRITICAL
- Epistemic basis: OBSERVATION plus INFERENCE
- Exact claim: Matured governance-service LEX remains vote-eligible and its budget materially exceeds civic LEX, allowing incumbents to accumulate lawful influence without violating per-ballot identity rules.
- Supporting artifacts: Round 7 §§2.2, 3.3 and 7.3; Round 9 C1/A1 adds a per-proposal service cap but does not bound cumulative influence across many proposals.
- Failure sequence: incumbents occupy service roles; earn governance-service LEX; spend capped amounts across many proposals; influence the rules selecting and rewarding future incumbents.
- Affected invariant: equal civic standing remains dominant and service does not become a political class.
- Class: circular capture.
- Required amendment: safest default is that service LEX never receives binding-vote eligibility. If retained for simulation, define a fixed per-human per-cycle cumulative ceiling independent of proposal count, same-body delay and non-incumbent entry quotas.
- Objective closure test: over an arbitrary proposal schedule, the maximum-service incumbent's total binding capacity stays within one explicit fixed bound over a civic-only participant.

#### R11-027 — Ballot privacy, conflict enforcement, delegation and export are mutually unresolved

- Severity: CRITICAL
- Epistemic basis: OBSERVATION
- Exact claim: The design implies cross-context unlinkability while also requiring identity-visible tally/conflict logic and exportable ballot receipts, without choosing a coherent privacy model.
- Supporting artifacts: Round 8 §§2.7 and 5.3; Round 7 §§8.1, 11.1 and 16.2.
- Failure sequence: identity-visible tally or exported receipts link ballots across contexts or enable vote-sale proof; hiding identity prevents private conflict enforcement and delegation override from being verified.
- Affected invariant: one person/one action, conflict enforcement and privacy claims must be simultaneously implementable.
- Class: contradiction and unresolved operator-value decision.
- Required amendment: explicitly choose a ballot privacy model. A secret model needs anonymous eligibility/conflict proofs, delegation tokens and receipt-free choice evidence. A public model must withdraw unlinkability and coercion-resistance implications.
- Objective closure test: enforce a real private conflict and delegated override without linking unrelated ballots; if receipt-freeness is claimed, the voter cannot produce transferable proof of vote choice.

#### R11-028 — Issuer and guardian independence is nominal, not machine-defined

- Severity: CRITICAL
- Epistemic basis: OBSERVATION plus INFERENCE
- Exact claim: Three-of-five thresholds do not provide three independent domains when controller, funding, organisation and infrastructure relatedness are not normative.
- Supporting artifacts: Round 8 §§5.4 and 8.2; Round 9 F06; identity attack matrices test nominal counts but not controller collapse.
- Failure sequence: one controller operates three nominal issuers and overlapping guardians; creates a mature human, later recovers it, and influences appeals while every numeric threshold passes.
- Affected invariant: no single administrative domain can mint or recover governance identity.
- Class: false independence and circular trust.
- Required amendment: state safety as conditional on fewer than threshold corrupt independent administrative domains. Formalise ultimate-controller, organisation, funding and infrastructure relatedness, plus issuer/guardian/appeal disjointness.
- Objective closure test: collapsing nominal actors by ultimate controller makes three issuers under one controller count as one; recovery preserves original epoch and proposal nullifier state.

#### R11-029 — Emergency hold chains can remain permanent while each hold expires

- Severity: CRITICAL
- Epistemic basis: OBSERVATION
- Exact claim: Repeated end/restart or seven-day extension sequences can evade the non-expiring-emergency test.
- Supporting artifacts: Round 7 §14.3 permits repeated panel extensions and conditions participant ratification on the participant system remaining functional; Round 9 F14/A8 recognises repeated emergencies but Round 10 lacks an executable cumulative rule.
- Failure sequence: issue a scoped hold; expire it; immediately restart substantially identical scope or extend during a claimed governance outage; each individual event expires while the effective emergency never ends.
- Affected invariant: emergency power cannot become de facto ordinary governance.
- Class: unsafe default and false-green test.
- Required amendment: define scope/root-cause fingerprint, cumulative rolling-window duration, increasing independent threshold, mandatory ordinary review and a rule that restart never resets accumulated duration.
- Objective closure test: one hundred substantially identical hold/end/restart events during simulated governance outage hit a hard stop that the declarer and emergency panel cannot self-authorise past.

#### R11-030 — Federation receipts can become a surveillance join table

- Severity: HIGH
- Epistemic basis: OBSERVATION plus INFERENCE
- Exact claim: Detailed AT/Nostr mappings plus LOOM timing can correlate pseudonyms and preserve imported material after external deletion.
- Supporting artifacts: Round 6 §9.4 binds Pioneer event ID, AT DID, PDS, URI and hashes; Round 8 §§10.2–10.4 adds bidirectional bindings.
- Failure sequence: an observer joins public mapping receipts, event timing and governance activity; recovers supposedly private pseudonym relations; an imported external post remains locally archived after its author deletes it.
- Affected invariant: purpose-specific bindings do not create a universal identity graph.
- Class: privacy leak and retention ambiguity.
- Required amendment: pairwise adapter identifiers, separately access-controlled mapping receipts, timing minimisation, no root/credential identifiers and explicit retention/legal-basis transitions for imported third-party content.
- Objective closure test: an observer with all public federation/governance records cannot recover private root links above a declared bound; external deletion invokes the declared import-retention transition.

#### R11-031 — Noted slot allocation can be ground and prestige can leak indirectly

- Severity: HIGH
- Epistemic basis: OBSERVATION plus INFERENCE
- Exact claim: Deterministic output does not prevent an allocator from searching candidate milestone/slot combinations, and Noted history can still influence reputation or competence projections.
- Supporting artifacts: Round 6 §§11.3–11.7; Round 8 §§4.2 and 13; Round 9 F11/A10.
- Failure sequence: allocator withholds or fragments milestones, retries eligible slot choices and selects rare output; prestige then affects maturation, panel competence, social visibility or research assessment despite no direct ledger edge.
- Affected invariant: Noted creates no institutional, economic, identity or research authority.
- Class: omission and indirect authority leak.
- Required amendment: precommit deterministic slot assignment before milestone outcome; forbid every Noted-derived feature from identity maturity, reputation, task/panel eligibility, moderation and research assessment.
- Objective closure test: many milestones, candidate slots and abort opportunities cannot improve rarity distribution; changing only Noted history leaves every institutional eligibility projection byte-identical.

### 5. Sweep-order review

The current S01–S07 order is not executable as written.

| Sweep | Adjudication | Required order repair |
|---|---|---|
| Phase 0A | Separately viable with findings R11-009–R11-013 and R11-018 | Complete, test, seal and accept as Application Foundation 0A. Do not call it S01 or the social kernel. |
| Pre-S01 | Missing | Freeze canon index, synthetic genesis, normative graph, event/wire/canonicalisation/time spec, gate registry and GitHub authority policy. |
| S01 | HOLD | Build canonical kernel plus minimal synthetic identity/operator/capability contracts from the pre-S01 artifacts. |
| S02 | REORDER/RE-SCOPE | May build NEX mechanics after S01, but downstream governance/Noted isolation remains pending until integration. It must consume the operator-relatedness contract. |
| S03-core | AFTER S01 | Build social/LOOM/privacy core and freeze its schemas. |
| S03-adapters | OPTIONAL SUB-SWEEPS | AT, Nostr and Noted each receive separate source/provenance gates and removable branches. |
| S04 | AFTER ACCEPTED S03 INTERFACE | Consume exact S03 schema commit. Identity maturity must not consume NEX work reputation. |
| S05 | AFTER ACCEPTED S01–S04 | Integrate exact accepted commits and run non-vacuous cross-domain campaigns. |
| S06 | SPLIT | Immutable review, isolated repairs and independent adjudication must have distinct provenance. |
| S07 | BLOCKING GATE | Refuse release on open Critical/High invariant findings; otherwise label only LOCAL SYNTHETIC CANDIDATE. |

Only one integration writer may merge accepted sweep commits. The exact post-conflict-resolution merge commit is the object reviewed, not merely its parents.

### 6. Autonomous-authority review

The lead builder may safely decide and record:

- local language/framework and package layout within a frozen dependency budget;
- internal module names that do not enter canonical bytes;
- database plumbing and migration mechanics;
- local UI arrangement that does not change critical ordering, filtering, proposal meaning or tally;
- error messages, test harness implementation and non-authority-bearing fixture presentation;
- performance improvements proven not to change canonical state.

The lead builder must stop and produce a proposal, not a binding implementation decision, for:

- canon, source precedence or constitutional meaning;
- synthetic genesis roots and transition powers until explicitly accepted;
- canonical serialisation, hash/signature suite, finality, witness or time semantics;
- identity/uniqueness policy, maturity inputs or governance eligibility;
- NEX/LEX conversion boundaries, issuance policy or public continuity;
- critical seeds, thresholds, gate corpus or acceptance meaning;
- privacy retention, purge commitments or fork-export policy;
- public GitHub repository identity/visibility/push authority;
- public federation, providers, credentials, deployments or production;
- Noted licensing/provenance;
- permanent founder/emergency authority.

### 7. Public-blocker review

Round 9 B1–B15 remain useful but require these changes:

- Split B1 into local deterministic kernel and public multi-writer admission/order/finality/availability. Local replay is not public canonicality.
- Add accepted canon/Decision Register bundle and explicit adoption of every provisional public parameter.
- Add production repository, client, release and artifact-provenance governance.
- Add LOOM-to-static-publication correction/supersession authority and tested update/rollback.
- Add deterministic/public time and expiry semantics.
- Add real moderation, appeals, incident-response and operational staffing evidence.
- Add provider retention/training/subprocessor/private-data policy before real model routing.
- Keep privacy/purge, federation deletion and fork privacy as separate but linked blockers.
- Make Noted source/licensing a blocker only if public Noted ships; it must not block a core that excludes the adapter.
- Communications and continuity disclosure must precede, not follow, any real balance-bearing epoch.
- Operational custody must precede any claim that constitutional governance controls production.

### 8. Test adequacy review

Missing or false-green test classes:

1. Empty-suite and zero-assertion failure.
2. Positive/negative corpus minimums for every zero-count gate.
3. Mutation tests proving each invariant can fail red.
4. Cross-implementation replay without shared canonicaliser/reducer.
5. Synthetic-genesis alteration and root-authority escalation.
6. NEX work/reputation variation with governance eligibility held invariant.
7. Clock skew, rollback, stale head, delayed offline action and revocation-before-sync.
8. Atomic note-row/event commit crash cases.
9. Private-payload dictionary attack, backup/cache recovery and fork-export re-identification.
10. Concurrent head acceptance, transaction isolation and crash/restart.
11. Adapter removal proving identical core state.
12. Malformed external protocol versions and unknown-kind quarantine.
13. Host/Origin/CSRF/body-limit and actual listening-socket checks.
14. Supply-chain failure on unapproved dependency, lifecycle script or changed source snapshot.
15. Evidence-scope rejection for wrong repository, commit, candidate or gate.
16. Test-runner failure propagation; skipped/killed subprocesses must not report green.
17. Cross-ledger receipt copy, split and derivative-lineage replay.
18. Transferred-LEX proposal-volume and cumulative service-LEX influence.
19. Secret/public ballot, delegation, conflict and receipt-freeness interoperability.
20. Issuer/guardian threshold collapse by ultimate controller.
21. Repeated emergency hold/end/restart chains across a governance outage.
22. Federation correlation and external-deletion retention transitions.
23. Noted slot grinding, abort opportunities and prestige-isolation checks.

### 9. Minimal amendment set

The smallest coherent repair set is:

1. Add CANON_INDEX.json plus exact controlling sources and decision receipts.
2. Add SYNTHETIC_GENESIS.json and a deterministic bootstrap/transition spec.
3. Make one normative authority graph and generate all other views.
4. Remove work/NEX reputation from mature-human and governance eligibility.
5. Replace the sweep plan with one explicit machine-checked dependency DAG.
6. Create one authoritative non-vacuous gate registry and stable finding namespaces.
7. Add a normative canonicalisation, event, finality, time/freshness and privacy-payload spec with golden vectors.
8. Require a genuinely independent replay/tally implementation.
9. Bind Phase 0A provenance to immutable note versions; make update/event append atomic.
10. Define acyclic export, repository-status and relay-receipt graphs.
11. Split optional adapters and require Noted source/licence preflight only for Noted.
12. Split S06 review/repair/adjudication and block S07 on open material invariants.
13. Add a GitHub continuity authority manifest before any remote write.
14. Add the missing public blockers and explicit evidence-scope checks.
15. Add one normative R5–R8 membrane amendment covering receipt compensation domain, agenda access, service-LEX cumulative limits, ballot privacy, related administrative domains, emergency chaining, federation privacy and Noted grinding.

These amendments repair architecture. They do not promote any provisional economic, identity, cryptographic or constitutional choice into canon.

### 10. Residual unknowns

- Exact accepted Charter, Decision Register and domain canon contents.
- The bounded source evidence for the eighteen founder directions in Round 3.
- The operator's exact private GitHub repository, visibility and push policy.
- Final public identity/uniqueness mechanism and its inclusion costs.
- Final anonymous credential/nullifier scheme.
- Final cryptographic parameter sets and independently audited implementations.
- Public multi-writer admission, ordering, witness, finality and availability.
- Public time/expiry authority.
- Noted canonical source, licence and original naming/assets.
- AT Protocol and Nostr versions/source commits to freeze.
- Jurisdiction, legal structure, data-controller duties and external representations.
- Private bribery, coercion, grey markets, collusion and cultural capture.
- Production custody, incident staffing, moderation capacity and recovery.
- The exact writable build path in the execution environment.

### 11. Final posture

HOLD_FOR_ARCHITECTURE_REPAIR

Exact next action:

The controlling ChatGPT should ingest this Round 011 critique and produce a Round 012 Architecture Repair package that applies the fourteen minimal amendments, includes the missing hash-pinned source-of-truth bundle, and presents one explicit GitHub continuity authority decision for the operator. It must not build the full Rounds 3–10 system or mutate any repository during reconciliation.

The separate Phase 0A local vertical slice may resume only after its exact writable path is authorised and findings R11-009, R11-010, R11-011, R11-013 and R11-018 are inserted into its controlling handoff. It remains local-only, fake-provider-only and without live authority.
