# Round 011 Request

Actor: Independent architecture critic  
Input: Entire relay corpus  
Required posture: Architecture critique only  
Return state: `AWAITING_CONTROLLING_CHATGPT_RECONCILIATION`

Read `00_CONTROL/PROMPT_TO_EXECUTE.md` and follow it in full.
