# GitHub Continuity Boundary — Decision Required

Date: 2026-08-01  
Status: PROPOSAL ONLY — NO REPOSITORY WRITE AUTHORISED  
Applies to: Pioneer Alignment architecture relays and the future separate application repository

## Latest operator intent recorded

The operator wants project-relevant work preserved on GitHub so progress, plans and evidence survive model-credit or session loss. The critic has veto authority over unsafe implementation decisions; the operator may reverse those decisions.

This establishes the continuity objective. It does not safely identify a repository mutation.

## Read-only facts observed

- Authenticated GitHub identity: Natoshi-moto.
- A read-only search for pioneer-alignment returned only Natoshi-moto/pioneer-alignment-public.
- That repository is public and is explicitly frozen/reference-only at accepted checkpoint 7c77c63c1f5648d0ee5001e22be7afab7dbd7d9a.
- No separate private Pioneer Alignment application repository was identified.
- No GitHub write, repository creation, branch change, commit, push, workflow change or deployment occurred.

## Current authority conflict

The Phase 0A Builder Handoff says:

- create a separate local repository;
- configure no remote;
- do not push;
- do not create a public GitHub repository;
- do not mutate pioneer-alignment-public.

The current relay says repository mutation is prohibited.

Therefore the continuity objective needs one narrow superseding decision. It must amend only the new application/architecture continuity policy. It must not amend the frozen public repository or production boundary.

## Recommended bounded policy

The controlling ChatGPT should ask the operator to approve one complete manifest with all fields resolved:

| Field | Recommended value |
|---|---|
| repository_full_name | Natoshi-moto/operator-selected-private-name |
| visibility | private |
| public repository exclusion | Natoshi-moto/pioneer-alignment-public remains prohibited |
| production/deployment | none |
| Pages/Actions deployment | disabled/not configured |
| secrets/environments | none |
| default branch | main, integration-only |
| development branch | phase-0a/local-vertical-slice, then explicitly named sweep branches |
| push actor | one named writer for the active branch |
| integration actor | one named integration writer |
| force push/history rewrite | prohibited |
| first push | exact inventory, commit and branch reported before execution or covered by an explicit standing bounded grant |
| relay storage | text outputs and manifests committed; complete safe relay ZIP may also be committed while small |

The operator may choose a different private name. The name must be explicit before creation or push.

## “Everything” means project-relevant and safe

Include:

- source code;
- tests and fixtures containing synthetic data only;
- architecture, decisions, plans, threat models and status;
- failure receipts and test reports safe for repository storage;
- exchange critique/reconciliation text;
- manifests, hashes and clean handoff packages;
- exact known limitations and unresolved findings.

Exclude:

- credentials, tokens, cookies, recovery codes and secrets;
- databases and real operator-entered note content unless separately reviewed;
- node_modules, caches, temporary files and generated private state;
- raw full-session transcripts;
- unrelated personal context;
- real identity documents or private pseudonym mappings;
- provider requests/responses containing private material;
- private or restricted security evidence whose disclosure policy is unresolved;
- production configuration or deployment authority not already public and explicitly in scope.

Exclusion is not evidence deletion. Excluded material receives a bounded identity/hash and safe location policy where appropriate; secret material is not hashed publicly if the hash itself could aid guessing or correlation.

## Required fail-closed checks

Before any push:

1. repository name and visibility equal the approved manifest;
2. remote is not pioneer-alignment-public;
3. branch is approved;
4. tracked-file secret and private-data scan passes;
5. no database, cache, dependency tree or raw session is tracked;
6. no workflow, Pages, environment, webhook or deployment configuration is introduced;
7. exact commit and safe artifact inventory are recorded;
8. public production remains untouched.

## Veto interpretation

The critic or lead engineer may stop or reject a proposed action that violates canon, safety, evidence or authority boundaries. Veto does not permit the agent to:

- invent the private repository name;
- choose public visibility;
- create credentials;
- grant itself push authority;
- publish restricted evidence;
- mutate production;
- promote provisional architecture into canon.

## Closure condition

This boundary closes only when the operator approves an exact private repository manifest or names an already-existing private repository and grants the bounded push scope. Until then, GitHub remains read-only and the relay ZIP is the durable inter-chat handoff.
