# Request for independent Phase 0A specification re-review

Please independently re-review the Round 020 package. Do not treat the shipped
positive evidence vector as application evidence: it is explicitly synthetic and
35 candidate-required cases remain deferred.

From a fresh unpack, first verify relay input integrity, then run:

```text
PYTHONDONTWRITEBYTECODE=1 python3 -S 04_TOOLS/verify_input_manifest.py
cd 03_EXCHANGE/ROUND_020_CONTROLLING_PHASE0A_REPAIR
PYTHONDONTWRITEBYTECODE=1 python3 -S meta_validate_round20.py --semantic-only
PYTHONDONTWRITEBYTECODE=1 python3 -S meta_validate_round20.py
PYTHONDONTWRITEBYTECODE=1 python3 -S independent_oracle.py
PYTHONDONTWRITEBYTECODE=1 python3 -S transition_evaluator.py
PYTHONDONTWRITEBYTECODE=1 python3 -S export_generator.py
PYTHONDONTWRITEBYTECODE=1 python3 -S export_verifier.py
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=1 python3 -S run_round20_closure_probes.py --output-json /tmp/r20-closure-seed1.json
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=2 python3 -S run_round20_closure_probes.py --output-json /tmp/r20-closure-seed2.json
cmp /tmp/r20-closure-seed1.json /tmp/r20-closure-seed2.json
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=1 python3 -S run_round20_mutations.py --full --output-json /tmp/r20-seed1.json --output-md /tmp/r20-seed1.md
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=2 python3 -S run_round20_mutations.py --full --output-json /tmp/r20-seed2.json --output-md /tmp/r20-seed2.md
cmp /tmp/r20-seed1.json /tmp/r20-seed2.json
cmp /tmp/r20-seed1.md /tmp/r20-seed2.md
```

Please also attempt novel, coherently rebound mutations, particularly complete
behavior removal/replacement, authority text in non-JSON normative members,
deferred candidate expectation rewrites, evidence path/symlink escapes, N80 final
node/producer bypasses, operational-receipt substitution, and manifest/cache
pollution.

The requested next return archive is `Pioneer-Alignment-Single-Relay-v12.zip`.
