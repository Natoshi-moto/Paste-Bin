#!/usr/bin/env python3
from __future__ import annotations
import sys
from pathlib import Path
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from lib_phase0a import *

def main():
    root = Path(__file__).resolve().parent
    members = {name: (root / "fixtures" / name).read_bytes() for name in EXPORT_MEMBERS}
    errors = verify_export_bundle(members)
    gold = load_json(root / "PHASE0A_EXPORT_GOLDEN_VECTOR.v2.json")
    if sha256_file(root / "fixtures/selected-note-golden.zip") != gold["zip_sha256"]:
        errors.append("ZIP_GOLDEN_MISMATCH")
    print(dumps_pretty({"errors": errors, "ok": not errors}), end="")
    return 0 if not errors else 1

if __name__ == "__main__":
    raise SystemExit(main())
