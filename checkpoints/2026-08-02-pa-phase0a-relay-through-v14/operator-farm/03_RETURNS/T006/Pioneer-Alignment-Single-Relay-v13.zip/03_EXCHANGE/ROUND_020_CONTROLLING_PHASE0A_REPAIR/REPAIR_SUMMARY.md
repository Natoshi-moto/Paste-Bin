# Round 020 Phase 0A repair summary

Adjudication: `ROUND020_REPAIR_COMPLETE_AWAITING_INDEPENDENT_REREVIEW`

Round 020 closes R19-F01 through R19-F07 at the specification/gate level while
preserving terminal HOLD, N80 reviewed-byte identity, deterministic export, and
the prior adversarial registry. No application or host claim is made.

Key repairs:

- The v2 independent oracle derives complete observables from closed input
  shapes. It counts 54 independently decided cases and explicitly defers 35;
  deferred or malformed fixtures never enter pass totals.
- A rename-invariant semantic-corpus lock rejects empty, partial, duplicated, or
  coherently removed behavior sets. Deferred candidate expectations are locked
  and cross-checked against transition/reason assertions.
- Authority scanning uses independently anchored minimum vocabulary plus shared
  locked constants on every string leaf/literal/body in every anchored normative
  JSON, JSONL, Python, Markdown, HTML, and text member. Negative controls are
  permitted only in structurally declared policy containers.
- Raw HTML is detected from payload text, independent of case/test identifiers;
  ordinary tags, comments, SVG, declarations, scripts, handlers, URLs, and
  embedded-object forms are all rejected while safe Markdown remains accepted.
- All 356 evidence references resolve to safe regular files beneath the declared
  synthetic root; the 356 result fixtures plus payload manifest are normative
  members whose exact bytes are hashed.
- Slug schema, validator, and oracle load one locked constants file and execute
  safe, hostile, and reserved behavioral corpora.
- Bytecode caches are excluded from every checksum walk, manifest, copy, and ZIP;
  every documented Python command sets `PYTHONDONTWRITEBYTECODE=1`.
- All 36 N50/N60/N70 traces are derived by the evaluator: exactly two are
  eligible, 34 are forbidden, and all 12 HOLD-origin traces remain terminal.
- N80 is the unique final semantic node and consumes reviewed binding, tree,
  source manifest, and evidence from N70. Its executable checker independently
  rejects those four identity mismatches plus remotes, non-loopback bind,
  provider adapters, and forbidden untracked files.
- Contract test/case/assertion/mutant ownership and evidence summaries are
  derived relationally, not accepted from list totals or rewritable identifiers.
- Operational receipts are content-validated and cross-hashed. The exact
  46-class mutation registry/semantics, 23 closure negatives, two distinct seed
  command templates, command outputs, and execution scope cannot be replaced by
  empty or self-invented receipt values.

Verification artifacts are `SPEC_VALIDATION_RECEIPT*.json`,
`ORACLE_RECEIPT.json`, `TRANSITION_EVAL_RECEIPT.json`, export receipts,
`CLOSURE_PROBE_RECEIPT.json`, `MUTATION_RECEIPTS.{json,md}`,
`MUTATION_DETERMINISM_RECEIPT.json`, and `EXECUTION_RECEIPT.json`.
