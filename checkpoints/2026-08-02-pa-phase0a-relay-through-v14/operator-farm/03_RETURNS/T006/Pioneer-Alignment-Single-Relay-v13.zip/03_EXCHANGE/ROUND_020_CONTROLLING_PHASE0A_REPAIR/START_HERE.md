# Round 020 controlling Phase 0A repair

Adjudication: `ROUND020_REPAIR_COMPLETE_AWAITING_INDEPENDENT_REREVIEW`

This directory supersedes the Round 018 executable Phase 0A gate. It is a
specification/gate package only. There is no application candidate, host
preflight, provider connection, repository mutation, deployment, or release.

Run from this directory, always with bytecode writes disabled:

```text
PYTHONDONTWRITEBYTECODE=1 python3 -S meta_validate_round20.py --semantic-only
PYTHONDONTWRITEBYTECODE=1 python3 -S meta_validate_round20.py
PYTHONDONTWRITEBYTECODE=1 python3 -S independent_oracle.py
PYTHONDONTWRITEBYTECODE=1 python3 -S transition_evaluator.py
PYTHONDONTWRITEBYTECODE=1 python3 -S export_generator.py
PYTHONDONTWRITEBYTECODE=1 python3 -S export_verifier.py
PYTHONDONTWRITEBYTECODE=1 python3 -S run_round20_closure_probes.py
PYTHONDONTWRITEBYTECODE=1 python3 -S run_round20_mutations.py --full --output-json /tmp/R20_MUTATIONS.json --output-md /tmp/R20_MUTATIONS.md
```

The independent reviewer should reproduce all commands from a fresh unpack,
compare the mutation receipts under `PYTHONHASHSEED=1` and `2`, and run novel
mutations. Deferred candidate cases are excluded from the spec pass denominator
and make candidate PASS ineligible until a real candidate executes them.
