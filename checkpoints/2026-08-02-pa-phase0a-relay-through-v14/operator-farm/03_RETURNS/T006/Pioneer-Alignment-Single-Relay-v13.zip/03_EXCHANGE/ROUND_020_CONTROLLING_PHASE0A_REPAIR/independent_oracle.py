#!/usr/bin/env python3
"""Round 020 independent, non-reflexive oracle for pure Phase 0A fixtures."""
from __future__ import annotations

import hashlib
import json
import sys
sys.dont_write_bytecode = True

from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
from lib_phase0a import *


ORACLE_ID = "pa.phase0a.independent_oracle.v2"
EXPECTED_CONTRACT_SEMANTIC_CORPUS_SHA256 = SECURITY_CONSTANTS["oracle"]["contract_semantic_corpus_sha256"]


def _exact_keys(value: Any, required: set[str]) -> bool:
    return isinstance(value, dict) and set(value) == required


def _valid_hash_map(value: Any, names: set[str] | None = None) -> bool:
    if not isinstance(value, dict) or (names is not None and set(value) != names):
        return False
    return all(isinstance(v, str) and HEX64.fullmatch(v) for v in value.values())


NOTE_KEYS = {
    "schema_version", "note_id", "version", "title", "slug", "summary",
    "body_markdown", "status", "created_at", "updated_at",
    "previous_state_hash", "state_hash",
}
EVENT_KEYS = {
    "schema_version", "event_id", "timestamp", "actor", "action", "subject",
    "previous_event_hash", "note_id", "note_version", "note_state_hash",
    "details", "event_hash",
}
REQUEST_KEYS = {
    "schema_version", "request_id", "provider", "model", "prompt",
    "temperature", "max_tokens", "timeout_ms",
}
RECEIPT_KEYS = {
    "schema_version", "export_id", "note_id", "note_version",
    "note_state_hash", "frozen_cut_event_id", "frozen_cut_event_hash",
    "renderer_version", "canonical_profile", "manifest_sha256",
    "content_set_sha256", "receipt_hash",
}


def _plain_int(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def _valid_note_shape(note: Any) -> bool:
    if not _exact_keys(note, NOTE_KEYS):
        return False
    string_fields = NOTE_KEYS - {"version"}
    return _plain_int(note["version"]) and all(isinstance(note[key], str) for key in string_fields)


def _valid_event_shape(event: Any) -> bool:
    if not _exact_keys(event, EVENT_KEYS):
        return False
    string_fields = EVENT_KEYS - {"note_version", "subject", "details"}
    return (
        _plain_int(event["note_version"])
        and all(isinstance(event[key], str) for key in string_fields)
        and _exact_keys(event["subject"], {"kind", "id"})
        and all(isinstance(event["subject"][key], str) for key in ("kind", "id"))
        and isinstance(event["details"], dict)
    )


def _valid_request_shape(request: Any) -> bool:
    if not _exact_keys(request, REQUEST_KEYS):
        return False
    string_fields = {"schema_version", "request_id", "provider", "model", "prompt"}
    return (
        all(isinstance(request[key], str) for key in string_fields)
        and isinstance(request["temperature"], (int, float))
        and not isinstance(request["temperature"], bool)
        and _plain_int(request["max_tokens"])
        and _plain_int(request["timeout_ms"])
    )


def _valid_receipt_shape(receipt: Any) -> bool:
    if not _exact_keys(receipt, RECEIPT_KEYS):
        return False
    return (
        _plain_int(receipt["note_version"])
        and all(isinstance(receipt[key], str) for key in RECEIPT_KEYS - {"note_version"})
    )


def contract_semantic_corpus_sha256(contract: Any) -> str:
    """Fingerprint behaviors without case IDs or counted-case expected outputs."""
    rows = []
    if isinstance(contract, dict) and isinstance(contract.get("cases"), list):
        for case in contract["cases"]:
            case = case if isinstance(case, dict) else {}
            fixture = case.get("fixture_inline")
            fixture = fixture if isinstance(fixture, dict) else {}
            rows.append({
                "execution_policy": case.get("execution_policy"),
                "oracle_disposition": case.get("oracle_disposition"),
                "immutable": case.get("immutable"),
                "fixture_immutable": fixture.get("immutable"),
                "operation": fixture.get("operation"),
                "input": fixture.get("input"),
                "candidate_operation": fixture.get("candidate_operation"),
                "candidate_input": fixture.get("candidate_input"),
                "candidate_expected_observable": (
                    fixture.get("candidate_expected_observable")
                    if case.get("execution_policy") != "RUN"
                    else None
                ),
            })
    serialized_rows = sorted(
        json.dumps(row, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        for row in rows
    )
    canonical = json.dumps(
        serialized_rows, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


def validate_operation_input(kind: str, inp: Any) -> bool:
    """Reject malformed fixtures before policy evaluation.

    This deliberately prevents garbage from matching an ordinary negative case.
    """
    if kind == "VALIDATE_NOTE_STATE":
        return _exact_keys(inp, {"note"}) and _valid_note_shape(inp["note"])
    if kind == "VALIDATE_VERSION_INCREMENT":
        return (
            _exact_keys(inp, {"prior", "next"})
            and _valid_note_shape(inp["prior"])
            and _valid_note_shape(inp["next"])
        )
    if kind == "VALIDATE_SLUG":
        return (
            _exact_keys(inp, {"slug", "existing_slugs"})
            and isinstance(inp["slug"], str)
            and isinstance(inp["existing_slugs"], list)
            and all(isinstance(x, str) for x in inp["existing_slugs"])
        )
    if kind == "VALIDATE_RAW_HTML":
        return _exact_keys(inp, {"body_markdown"}) and isinstance(inp["body_markdown"], str)
    if kind == "FAKE_RELAY_COMPLETE":
        return _exact_keys(inp, {"request"}) and _valid_request_shape(inp["request"])
    if kind == "CHECK_NO_NETWORK_ADAPTER":
        return (
            _exact_keys(inp, {"declared_adapters", "network_adapters"})
            and isinstance(inp["declared_adapters"], list)
            and isinstance(inp["network_adapters"], list)
            and all(isinstance(value, str) for value in inp["declared_adapters"])
            and all(isinstance(value, str) for value in inp["network_adapters"])
        )
    if kind == "CHECK_WRITE_BOUNDARY":
        return (
            _exact_keys(inp, {"attempted_path", "allowed_write_roots"})
            and isinstance(inp["attempted_path"], str)
            and isinstance(inp["allowed_write_roots"], list)
            and bool(inp["allowed_write_roots"])
            and all(isinstance(value, str) for value in inp["allowed_write_roots"])
        )
    if kind == "CHECK_BIND":
        return _exact_keys(inp, {"bind_address"}) and isinstance(inp["bind_address"], str)
    if kind == "CHECK_HOST":
        return _exact_keys(inp, {"host"}) and isinstance(inp["host"], str)
    if kind == "CHECK_ORIGIN":
        return _exact_keys(inp, {"origin"}) and isinstance(inp["origin"], str)
    if kind == "CHECK_CSRF":
        return _exact_keys(inp, {"csrf"}) and (inp["csrf"] is None or isinstance(inp["csrf"], str))
    if kind == "CHECK_CONTENT_TYPE":
        return _exact_keys(inp, {"content_type"}) and isinstance(inp["content_type"], str)
    if kind == "CHECK_BODY_LIMIT":
        return (
            _exact_keys(inp, {"body_bytes"})
            and isinstance(inp["body_bytes"], int)
            and not isinstance(inp["body_bytes"], bool)
            and inp["body_bytes"] >= 0
        )
    if kind == "CHECK_METHOD_POLICY":
        return (
            _exact_keys(inp, {"method", "mutates"})
            and isinstance(inp["method"], str)
            and isinstance(inp["mutates"], bool)
        )
    if kind == "CHECK_PATH_TRAVERSAL":
        return (
            isinstance(inp, dict)
            and set(inp) in ({"path"}, {"path", "is_symlink_escape"})
            and isinstance(inp["path"], str)
            and ("is_symlink_escape" not in inp or isinstance(inp["is_symlink_escape"], bool))
        )
    if kind == "VALIDATE_EVENT":
        return _exact_keys(inp, {"event"}) and _valid_event_shape(inp["event"])
    if kind == "VALIDATE_EVENT_CHAIN":
        return (
            _exact_keys(inp, {"event", "prior_event_hash"})
            and _valid_event_shape(inp["event"])
            and isinstance(inp["prior_event_hash"], str)
            and bool(HEX64.fullmatch(inp["prior_event_hash"]))
        )
    if kind == "VERIFY_EXPORT_GOLDEN":
        return (
            _exact_keys(inp, {"member_sha256", "zip_sha256", "receipt"})
            and _valid_hash_map(inp["member_sha256"], set(EXPORT_MEMBERS))
            and isinstance(inp["zip_sha256"], str)
            and bool(HEX64.fullmatch(inp["zip_sha256"]))
            and _valid_receipt_shape(inp["receipt"])
        )
    if kind == "VERIFY_EXPORT_HASHES":
        return _exact_keys(inp, {"members"}) and _valid_hash_map(inp["members"], set(EXPORT_MEMBERS))
    return False


def _export_truth(root: Path) -> tuple[dict[str, str], str, dict]:
    member_hashes = {name: sha256_file(root / "fixtures" / name) for name in EXPORT_MEMBERS}
    zip_hash = sha256_file(root / "fixtures" / "selected-note-golden.zip")
    receipt = load_json(root / "PHASE0A_EXPORT_GOLDEN_VECTOR.v2.json")["receipt"]
    return member_hashes, zip_hash, receipt


def evaluate_case(case: dict, root: Path | None = None) -> dict:
    root = (root or Path(__file__).resolve().parent).resolve()
    case_id = case.get("case_id", "<missing-case-id>")
    try:
        fx = case["fixture_inline"]
        op = fx["operation"]
        inp = fx["input"]
        kind = op["kind"]
        expected = fx["expected_observable"]
    except Exception as exc:
        return {
            "oracle_id": ORACLE_ID,
            "case_id": case_id,
            "disposition": "INVALID",
            "pass": False,
            "failure_code": "INVALID_FIXTURE_STRUCTURE",
            "detail": type(exc).__name__,
        }

    if kind == DEFERRED_OPERATION_KIND:
        correct = (
            case.get("oracle_disposition") == "DEFERRED_TO_CANDIDATE_EXECUTION"
            and case.get("execution_policy") == "DEFERRED_TO_CANDIDATE_EXECUTION"
            and expected == {"transition": "DEFERRED", "reason_code": DEFERRED_REASON_CODE}
            and case.get("expected_transition") == "DEFERRED"
            and case.get("expected_reason_code") == DEFERRED_REASON_CODE
        )
        if not correct:
            return {
                "oracle_id": ORACLE_ID,
                "case_id": case_id,
                "disposition": "INVALID",
                "pass": False,
                "failure_code": "DEFERRED_EXPECTATION_INVALID",
            }
        return {
            "oracle_id": ORACLE_ID,
            "case_id": case_id,
            "disposition": "DEFERRED",
            "transition": "DEFERRED",
            "reason_code": DEFERRED_REASON_CODE,
            "pass": None,
            "counted_in_pass_total": False,
        }

    if kind in FORBIDDEN_REFLEXIVE_OPERATION_KINDS:
        return {
            "oracle_id": ORACLE_ID,
            "case_id": case_id,
            "disposition": "INVALID",
            "pass": False,
            "failure_code": "REFLEXIVE_OPERATION_FORBIDDEN",
        }

    if case.get("oracle_disposition") != "DECIDED_NON_REFLEXIVELY":
        return {
            "oracle_id": ORACLE_ID,
            "case_id": case_id,
            "disposition": "INVALID",
            "pass": False,
            "failure_code": "ORACLE_DISPOSITION_INVALID",
        }

    def result(transition: str, reason_code: str, **extra) -> dict:
        observable = {"transition": transition, "reason_code": reason_code, **extra}
        ok = (
            isinstance(expected, dict)
            and observable == expected
            and transition == case.get("expected_transition")
            and reason_code == case.get("expected_reason_code")
        )
        return {
            "oracle_id": ORACLE_ID,
            "case_id": case_id,
            "disposition": "DECIDED",
            "transition": transition,
            "reason_code": reason_code,
            "observable": observable,
            "pass": ok,
            "counted_in_pass_total": True,
            **({} if ok else {"failure_code": "ORACLE_EXPECTATION_MISMATCH"}),
            **extra,
        }

    if not validate_operation_input(kind, inp):
        return {
            "oracle_id": ORACLE_ID,
            "case_id": case_id,
            "disposition": "INVALID_FIXTURE",
            "transition": "INVALID",
            "reason_code": "INVALID_FIXTURE_INPUT",
            "pass": False,
            "counted_in_pass_total": False,
            "failure_code": "INVALID_FIXTURE_INPUT",
        }

    try:
        if kind == "VALIDATE_NOTE_STATE":
            errors = validate_note_state(inp["note"], op.get("mode", "any"))
            return result("REJECT", errors[0].split(":")[0], errors=errors) if errors else result("ACCEPT", "OK", errors=[])

        if kind == "VALIDATE_VERSION_INCREMENT":
            if inp["next"].get("version") != inp["prior"].get("version", 0) + 1:
                return result("REJECT", "NOTE_VERSION_NON_SEQUENTIAL")
            return result("ACCEPT", "OK")

        if kind == "VALIDATE_SLUG":
            slug_error = validate_slug(inp["slug"])
            if slug_error:
                return result("REJECT", slug_error)
            if inp["slug"] in set(inp["existing_slugs"]):
                return result("REJECT", "DUPLICATE_SLUG")
            return result("ACCEPT", "OK")

        if kind == "VALIDATE_RAW_HTML":
            raw_error = detect_raw_html(inp["body_markdown"])
            return result("REJECT", raw_error) if raw_error else result("ACCEPT", "OK")

        if kind == "FAKE_RELAY_COMPLETE":
            output = fake_relay_complete(inp["request"])
            return result("ACCEPT", "OK", result=output) if output["ok"] else result("REJECT", output["reason_code"], result=output)

        if kind == "CHECK_NO_NETWORK_ADAPTER":
            if inp["network_adapters"]:
                return result("REJECT", "NETWORK_ADAPTER_PRESENT")
            return result("ACCEPT", "OK")

        if kind == "CHECK_WRITE_BOUNDARY":
            attempted = Path(inp["attempted_path"]).resolve(strict=False)
            allowed_roots = [Path(value).resolve(strict=False) for value in inp["allowed_write_roots"]]
            inside = any(attempted == allowed or allowed in attempted.parents for allowed in allowed_roots)
            return result("ACCEPT", "OK") if inside else result("REJECT", "WRITE_BOUNDARY_VIOLATION")

        if kind == "VERIFY_EXPORT_GOLDEN":
            members, zip_hash, receipt = _export_truth(root)
            if inp["member_sha256"] != members or inp["zip_sha256"] != zip_hash or inp["receipt"] != receipt:
                return result("REJECT", "EXPORT_GOLDEN_MISMATCH")
            return result("ACCEPT", "OK")

        if kind == "VERIFY_EXPORT_HASHES":
            members, _, _ = _export_truth(root)
            if inp["members"] != members:
                return result("REJECT", "EXPORT_HASH_MISMATCH")
            return result("ACCEPT", "OK")

        if kind == "CHECK_BIND":
            return result("ACCEPT", "OK") if inp["bind_address"] == BIND else result("REJECT", "BIND_OVERRIDE_REJECTED")

        if kind == "CHECK_HOST":
            allowed = {"127.0.0.1:8787", "localhost:8787"}
            return result("ACCEPT", "OK") if inp["host"] in allowed else result("REJECT", "HOST_REJECTED")

        if kind == "CHECK_ORIGIN":
            allowed = {"http://127.0.0.1:8787", "http://localhost:8787"}
            return result("ACCEPT", "OK") if inp["origin"] in allowed else result("REJECT", "ORIGIN_REJECTED")

        if kind == "CHECK_CSRF":
            if inp["csrf"] is None:
                return result("REJECT", "CSRF_MISSING")
            if inp["csrf"] != "valid-token":
                return result("REJECT", "CSRF_INVALID")
            return result("ACCEPT", "OK")

        if kind == "CHECK_CONTENT_TYPE":
            return result("ACCEPT", "OK") if inp["content_type"] == "application/json" else result("REJECT", "CONTENT_TYPE_REJECTED")

        if kind == "CHECK_BODY_LIMIT":
            return result("REJECT", "BODY_LIMIT") if inp["body_bytes"] > 1_000_000 else result("ACCEPT", "OK")

        if kind == "CHECK_METHOD_POLICY":
            if inp["method"] == "GET" and inp["mutates"]:
                return result("REJECT", "METHOD_POLICY")
            return result("ACCEPT", "OK")

        if kind == "CHECK_PATH_TRAVERSAL":
            path = inp["path"]
            if inp.get("is_symlink_escape", False):
                return result("REJECT", "SYMLINK_ESCAPE_REJECTED")
            if "\x00" in path:
                return result("REJECT", "NULL_BYTE_PATH_REJECTED")
            if path.startswith(("/", "\\")):
                return result("REJECT", "ABSOLUTE_PATH_REJECTED")
            lowered = path.casefold()
            if "%2f" in lowered or "%5c" in lowered:
                return result("REJECT", "ENCODED_PATH_ESCAPE_REJECTED")
            if ".." in path.replace("\\", "/").split("/"):
                return result("REJECT", "PATH_ESCAPE_REJECTED")
            return result("ACCEPT", "OK")

        if kind == "VALIDATE_EVENT":
            errors = validate_event(inp["event"])
            return result("REJECT", errors[0].split(":")[0]) if errors else result("ACCEPT", "OK")

        if kind == "VALIDATE_EVENT_CHAIN":
            errors = validate_event(inp["event"], inp["prior_event_hash"])
            return result("REJECT", errors[0].split(":")[0]) if errors else result("ACCEPT", "OK")

        return {
            "oracle_id": ORACLE_ID,
            "case_id": case_id,
            "disposition": "INVALID",
            "pass": False,
            "failure_code": "UNKNOWN_OPERATION",
        }
    except Exception as exc:
        return {
            "oracle_id": ORACLE_ID,
            "case_id": case_id,
            "disposition": "INVALID_FIXTURE",
            "transition": "INVALID",
            "reason_code": "ORACLE_EVALUATION_ERROR",
            "pass": False,
            "counted_in_pass_total": False,
            "failure_code": "ORACLE_EVALUATION_ERROR",
            "detail": type(exc).__name__,
        }


def evaluate_contract(contract: dict, root: Path | None = None) -> dict:
    results = [evaluate_case(case, root) for case in contract.get("cases", [])]
    decided = [r for r in results if r.get("disposition") == "DECIDED"]
    deferred = [r for r in results if r.get("disposition") == "DEFERRED"]
    invalid = [r for r in results if r.get("disposition") not in {"DECIDED", "DEFERRED"}]
    failed_decided = [r for r in decided if r.get("pass") is False]
    corpus_hash = contract_semantic_corpus_sha256(contract)
    corpus_valid = corpus_hash == EXPECTED_CONTRACT_SEMANTIC_CORPUS_SHA256
    coverage_failures = [] if corpus_valid else [{
        "failure_code": "CONTRACT_SEMANTIC_CORPUS_MISMATCH",
        "actual_sha256": corpus_hash,
        "expected_sha256": EXPECTED_CONTRACT_SEMANTIC_CORPUS_SHA256,
    }]
    failures = failed_decided + invalid + coverage_failures
    passed = [r for r in decided if r.get("pass") is True]
    return {
        "oracle_id": ORACLE_ID,
        "control": "OUTSIDE_CANDIDATE",
        "total_cases": len(results),
        "decided_cases": len(decided),
        "pass_denominator": len(decided),
        "passed": len(passed),
        "failed": len(failed_decided),
        "deferred": len(deferred),
        "invalid_cases": len(invalid),
        "semantic_corpus_sha256": corpus_hash,
        "semantic_corpus_valid": corpus_valid,
        "aggregate_invariants_ok": (
            len(results) == len(decided) + len(deferred) + len(invalid)
            and len(passed) + len(failed_decided) == len(decided)
        ),
        "deferred_excluded_from_pass_totals": True,
        "spec_oracle_valid": not failures,
        "candidate_pass_eligible": not failures and not deferred,
        "candidate_pass_blocker": None if not failures and not deferred else (
            "ORACLE_FAILURE" if failures else "DEFERRED_REQUIRED_CASES"
        ),
        "failures": failures[:40],
    }


def main() -> int:
    root = Path(__file__).resolve().parent
    contract_path = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else root / "PHASE0A_ACCEPTANCE_CONTRACT.v4.json"
    try:
        contract = load_json(contract_path)
    except Exception as exc:
        print(dumps_pretty({
            "oracle_id": ORACLE_ID,
            "spec_oracle_valid": False,
            "candidate_pass_eligible": False,
            "failed": 1,
            "failures": [{"failure_code": str(exc)}],
        }), end="")
        return 1
    output = evaluate_contract(contract, contract_path.parent)
    print(dumps_pretty(output), end="")
    return 0 if output["spec_oracle_valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
