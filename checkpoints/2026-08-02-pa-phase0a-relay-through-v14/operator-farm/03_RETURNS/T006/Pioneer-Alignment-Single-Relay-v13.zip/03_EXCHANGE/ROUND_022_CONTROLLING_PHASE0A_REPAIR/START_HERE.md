# Round 022 controlling Phase 0A repair

Adjudication: `ROUND022_REPAIR_COMPLETE_AWAITING_INDEPENDENT_REREVIEW`

This directory supersedes Round 020 for the bounded executable Phase 0A gate.
It contains specifications, synthetic fixtures, validators, mutation tests and
receipts only. No application candidate exists; host preflight and application
tests remain unrun.

Run from this directory with bytecode writes disabled:

```text
PYTHONDONTWRITEBYTECODE=1 python3 -S meta_validate_round22.py --semantic-only
PYTHONDONTWRITEBYTECODE=1 python3 -S meta_validate_round22.py
PYTHONDONTWRITEBYTECODE=1 python3 -S independent_oracle.py
PYTHONDONTWRITEBYTECODE=1 python3 -S transition_evaluator.py
PYTHONDONTWRITEBYTECODE=1 python3 -S export_generator.py
PYTHONDONTWRITEBYTECODE=1 python3 -S export_verifier.py
PYTHONDONTWRITEBYTECODE=1 python3 -S verify_round22_receipts.py
```

The permanent mutation registry contains 66 classes: all 46 Round 020 classes,
all 12 Round 021 probes, and all eight Round 021 authority-surface variants.
For the complete deterministic replay, run `verify_round22_receipts.py --full`.

Candidate PASS remains ineligible because 35 cases require execution against a
future reviewed implementation. The terminal HOLD and N80 reviewed-byte
identity controls remain binding.
