#!/usr/bin/env python3
"""Round 022 deterministic mutation registry.

The runner never mutates its source relay.  Each registered class is applied to a
fresh disposable copy of the *full* relay, dependent hashes are rebound in an
acyclic order, and the Round 022 semantic/full gates are executed there.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
sys.dont_write_bytecode = True

SOURCE = Path(__file__).resolve().parent
RELAY_ROOT = SOURCE.parents[1]
ROUND_RELATIVE = SOURCE.relative_to(RELAY_ROOT)
CONTRACT = "PHASE0A_ACCEPTANCE_CONTRACT.v4.json"
VECTORS = "PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json"
NORMATIVE_MANIFEST = "PHASE0A_NORMATIVE_MANIFEST.v1.json"
ROUND_CHECKSUMS = "SHA256SUMS.txt"
SECURITY_CONSTANTS = "PHASE0A_SECURITY_CONSTANTS.v1.json"


def load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


AUTHORITY_PROBE_PAYLOADS = tuple(
    load(SOURCE / SECURITY_CONSTANTS)["authority"]["probe_payloads"]
)


def save(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def ignored_bytecode(path: Path) -> bool:
    return "__pycache__" in path.parts or path.suffix == ".pyc"


def copy_ignore(_directory: str, names: list[str]) -> set[str]:
    return {name for name in names if name == "__pycache__" or name.endswith(".pyc")}


def round_tree_sha256(round_dir: Path) -> str:
    rows = []
    for path in sorted(round_dir.rglob("*"), key=lambda item: item.relative_to(round_dir).as_posix()):
        if ignored_bytecode(path):
            continue
        relative = path.relative_to(round_dir).as_posix()
        if path.is_symlink():
            target = os.readlink(path)
            content_hash = sha256_file(path) if path.is_file() else "BROKEN"
            rows.append(f"SYMLINK {target} {content_hash}  {relative}\n")
        elif path.is_file():
            rows.append(f"FILE {sha256_file(path)}  {relative}\n")
    return sha256_bytes("".join(rows).encode("utf-8"))


def regenerate_round_checksums(round_dir: Path) -> None:
    manifest = round_dir / ROUND_CHECKSUMS
    files = sorted(
        (
            path for path in round_dir.rglob("*")
            if path.is_file() and path != manifest and not ignored_bytecode(path)
        ),
        key=lambda item: item.relative_to(round_dir).as_posix(),
    )
    manifest.write_text(
        "".join(
            f"{sha256_file(path)}  {path.relative_to(round_dir).as_posix()}\n"
            for path in files
        ),
        encoding="utf-8",
    )


def rebind_acyclic(round_dir: Path) -> None:
    """Rebind leaf -> normative manifest -> binding -> evidence -> round checksum.

    The evidence vector embeds normative_manifest_sha256 and therefore must stay
    outside the normative manifest.  Evidence-integrity mutators deliberately do
    not update their targeted evidence declaration or payload manifest.
    """
    nm_path = round_dir / NORMATIVE_MANIFEST
    manifest = load(nm_path)
    members = manifest.get("members") or []
    member_paths = {member.get("path") for member in members}
    if NORMATIVE_MANIFEST in member_paths:
        raise RuntimeError("NORMATIVE_MANIFEST_SELF_LISTED")
    if VECTORS in member_paths:
        raise RuntimeError("NORMATIVE_EVIDENCE_ENVELOPE_CYCLE")
    for member in members:
        relative = member.get("path")
        if not isinstance(relative, str):
            continue
        target = round_dir / relative
        if target.is_file():
            member["sha256"] = sha256_file(target)
    manifest["member_count"] = len(members)
    save(nm_path, manifest)

    vector_path = round_dir / VECTORS
    if vector_path.is_file():
        vectors = load(vector_path)
        positive = vectors.get("positive_fixture") or {}
        binding = positive.get("candidate_binding") or {}
        evidence = positive.get("candidate_evidence") or {}
        contract_path = round_dir / CONTRACT
        if contract_path.is_file():
            contract_hash = sha256_file(contract_path)
            binding["contract_sha256"] = contract_hash
            evidence["contract_sha256"] = contract_hash
        normative_hash = sha256_file(nm_path)
        binding["normative_manifest_sha256"] = normative_hash
        evidence["normative_manifest_sha256"] = normative_hash
        evidence["candidate_binding_sha256"] = sha256_bytes(canonical(binding))
        save(vector_path, vectors)

    regenerate_round_checksums(round_dir)


def mutate_json(round_dir: Path, filename: str, edit: Callable[[Any], None]) -> None:
    path = round_dir / filename
    value = load(path)
    edit(value)
    save(path, value)


def replace_json(round_dir: Path, filename: str, value: Any) -> None:
    save(round_dir / filename, value)


def repin_constants(round_dir: Path) -> None:
    """Refresh the library pin so constants probes reach semantic controls."""
    new_digest = sha256_file(round_dir / SECURITY_CONSTANTS)
    library_path = round_dir / "lib_phase0a.py"
    text = library_path.read_text(encoding="utf-8")
    text, count = re.subn(
        r'(?m)^SECURITY_CONSTANTS_SHA256 = "[a-f0-9]{64}"$',
        f'SECURITY_CONSTANTS_SHA256 = "{new_digest}"',
        text,
    )
    if count != 1:
        raise RuntimeError("security constants digest pin not found exactly once")
    library_path.write_text(text, encoding="utf-8")


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def resync_corpus_lock(round_dir: Path) -> None:
    contract = load(round_dir / CONTRACT)
    oracle = load_module(round_dir / "independent_oracle.py", "r22_mutation_oracle")
    constants = load(round_dir / SECURITY_CONSTANTS)
    constants["oracle"]["contract_semantic_corpus_sha256"] = (
        oracle.contract_semantic_corpus_sha256(contract)
    )
    save(round_dir / SECURITY_CONSTANTS, constants)
    repin_constants(round_dir)


# R17/R18 registry ---------------------------------------------------------


def m_empty_binding_schema(d: Path) -> None:
    replace_json(d, "PHASE0A_CANDIDATE_BINDING.schema.json", {})


def m_empty_evidence_schema(d: Path) -> None:
    replace_json(d, "PHASE0A_CANDIDATE_EVIDENCE.schema.json", {})


def m_empty_gate_schema(d: Path) -> None:
    replace_json(d, "PHASE0A_GATE_CASE_EVIDENCE.schema.json", {})


def m_empty_dag_schema(d: Path) -> None:
    replace_json(d, "PHASE0A_DAG_SCHEMA.v2.json", {})


def m_vacuous_fixtures(d: Path) -> None:
    mutate_json(d, CONTRACT, lambda value: [case.__setitem__("fixture_inline", {}) for case in value["cases"]])


def m_noop_mutants(d: Path) -> None:
    def edit(value: dict) -> None:
        for mutant in value["mutants"]:
            mutant["mutation_operator"] = {
                "id": "NO_OP", "kind": "NO_OP", "executable": False,
                "control": "CANDIDATE", "transform": "NO_OP",
            }
    mutate_json(d, CONTRACT, edit)


def m_final_condition_true(d: Path) -> None:
    def edit(value: dict) -> None:
        for index, condition in enumerate(value["conditions"]):
            if condition["condition_id"] == "N80_ELIGIBLE":
                value["conditions"][index] = {
                    "condition_id": "N80_ELIGIBLE", "type": "constant", "value": True,
                }
    mutate_json(d, "PHASE0A_CONDITION_REGISTRY.v2.json", edit)


def m_rereview_checks_removed(d: Path) -> None:
    def edit(value: dict) -> None:
        node = next(item for item in value["nodes"] if item["node_id"] == "P0A-N70-INDEPENDENT-REREVIEW")
        node["kind"] = "noop"
        node["required_checks"] = []
    mutate_json(d, "PHASE0A_BUILD_DAG.v2.json", edit)


def m_initial_review_removed(d: Path) -> None:
    def edit(value: dict) -> None:
        node = next(item for item in value["nodes"] if item["node_id"] == "P0A-N50-INDEPENDENT-REVIEW")
        node["required_checks"] = ["do not execute candidate acceptance tests"]
    mutate_json(d, "PHASE0A_BUILD_DAG.v2.json", edit)


def m_slug_traversal(d: Path) -> None:
    def edit(value: dict) -> None:
        value["properties"]["slug"]["pattern"] = "^.*$"
        value["x-phase0a-slug-reserved"] = []
    mutate_json(d, "PHASE0A_NOTE_STATE.schema.json", edit)


def m_published_status(d: Path) -> None:
    mutate_json(
        d, "PHASE0A_NOTE_STATE.schema.json",
        lambda value: value["properties"]["status"]["enum"].append("published"),
    )


def m_action_detail_removed(d: Path) -> None:
    mutate_json(d, "PHASE0A_PROVENANCE_EVENT.schema.json", lambda value: value.__setitem__("x-phase0a-action-detail-branch", {}))


def m_hash_domains(d: Path) -> None:
    def edit(value: dict) -> None:
        value["hashes"]["note_state"]["domain_prefix_utf8_then_nul"] = "BROKEN-NOTE-DOMAIN"
        value["hashes"]["provenance_event"]["domain_prefix_utf8_then_nul"] = "BROKEN-EVENT-DOMAIN"
        value["hashes"]["export_receipt"]["domain_prefix_utf8_then_nul"] = "BROKEN-RECEIPT-DOMAIN"
    mutate_json(d, "PHASE0A_CANONICAL_RULES.v2.json", edit)


def m_export_write_widen(d: Path) -> None:
    def edit(value: dict) -> None:
        value["write_boundary"]["public_repository"] = True
        value["write_boundary"]["outside_workspace"] = True
    mutate_json(d, "PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v3.json", edit)


def m_export_self_hash(d: Path) -> None:
    mutate_json(
        d, "PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v3.json",
        lambda value: value["members"]["export-receipt.json"].__setitem__("receipt_hash_excludes_field", None),
    )


def m_runner_bypass(d: Path) -> None:
    def edit(value: dict) -> None:
        value["command"] = ["true"]
        value["final_evidence"] = {"status_logic": {"CANDIDATE_TESTS_PASS": "runner says PASS"}}
        value["oracle"] = {
            "module": "candidate_oracle.py", "control": "CANDIDATE",
            "candidate_may_not_supply_oracle": False,
        }
    mutate_json(d, "PHASE0A_RUNNER_INTERFACE.v2.json", edit)


def m_fictitious_evidence(d: Path) -> None:
    def edit(value: dict) -> None:
        evidence = value["positive_fixture"]["candidate_evidence"]
        for group in ("case_results", "assertion_results", "mutant_results"):
            for result in evidence[group]:
                result["evidence_sha256"] = "0" * 64
        evidence["payload_manifest_sha256"] = "0" * 64
        value["positive_fixture"]["payload_manifest_sha256"] = "0" * 64
    mutate_json(d, VECTORS, edit)


def m_hidden_provider(d: Path) -> None:
    def edit(value: dict) -> None:
        node = next(item for item in value["nodes"] if item["node_id"] == "P0A-N40-BUILD-CANDIDATE")
        node["required_checks"].append(AUTHORITY_PROBE_PAYLOADS[0])
    mutate_json(d, "PHASE0A_BUILD_DAG.v2.json", edit)


def m_impl_claim(d: Path) -> None:
    def edit(value: dict) -> None:
        value["application_implemented"] = True
        value["candidate_pass_target"] = "CANDIDATE_TESTS_PASS_ALREADY_ACHIEVED"
    mutate_json(d, "NO_IMPLEMENTATION_CANDIDATE.json", edit)


def m_remove_dashboard(d: Path) -> None:
    contract = load(d / CONTRACT)
    test_id = "T-G-P0A-DASHBOARD-EXPORT-STATUS"
    test = next(item for item in contract["tests"] if item["test_id"] == test_id)
    case_ids = set(test["case_ids"])
    assertion_ids = set(test["assertion_ids"])
    mutant_ids = set(test["mutant_ids"])
    for gate in contract["gates"]:
        gate["test_ids"] = [item for item in gate["test_ids"] if item != test_id]
    contract["tests"] = [item for item in contract["tests"] if item["test_id"] != test_id]
    contract["cases"] = [item for item in contract["cases"] if item["case_id"] not in case_ids]
    contract["assertions"] = [item for item in contract["assertions"] if item["assertion_id"] not in assertion_ids]
    contract["mutants"] = [item for item in contract["mutants"] if item["mutant_id"] not in mutant_ids]
    contract["counts"]["total_tests"] = len(contract["tests"])
    contract["counts"]["total_cases"] = len(contract["cases"])
    contract["counts"]["total_assertions"] = len(contract["assertions"])
    contract["counts"]["total_mutants"] = len(contract["mutants"])
    save(d / CONTRACT, contract)

    runner = load(d / "PHASE0A_RUNNER_INTERFACE.v2.json")
    runner["required_runner_methods"] = [
        item for item in runner["required_runner_methods"] if item != test["runner_method"]
    ]
    save(d / "PHASE0A_RUNNER_INTERFACE.v2.json", runner)

    vectors = load(d / VECTORS)
    evidence = vectors["positive_fixture"]["candidate_evidence"]
    evidence["case_results"] = [item for item in evidence["case_results"] if item["case_id"] not in case_ids]
    evidence["assertion_results"] = [item for item in evidence["assertion_results"] if item["assertion_id"] not in assertion_ids]
    evidence["mutant_results"] = [item for item in evidence["mutant_results"] if item["mutant_id"] not in mutant_ids]
    save(d / VECTORS, vectors)


def m_weak_note_schema(d: Path) -> None:
    replace_json(d, "PHASE0A_NOTE_STATE.schema.json", {"type": "object"})


def m_binding_main_branch_const(d: Path) -> None:
    mutate_json(d, "PHASE0A_CANDIDATE_BINDING.schema.json", lambda value: value["properties"]["branch"].__setitem__("const", "main"))


def m_binding_zero_bind(d: Path) -> None:
    mutate_json(d, "PHASE0A_CANDIDATE_BINDING.schema.json", lambda value: value["properties"]["server_bind"].__setitem__("const", "0.0.0.0"))


def m_hold_not_terminal(d: Path) -> None:
    mutate_json(d, "PHASE0A_CONDITION_REGISTRY.v2.json", lambda value: value["rules"].__setitem__("HOLD_is_terminal", False))


def m_extra_allowed_trace(d: Path) -> None:
    mutate_json(
        d, "PHASE0A_TRANSITION_TABLE.v1.json",
        lambda value: value["allowed_traces"].append({
            "n50": "HOLD", "n60": "NOT_REQUIRED", "n70": "INITIAL_PASS_CONFIRMED", "n80": "ELIGIBLE",
        }),
    )


def m_n80_always(d: Path) -> None:
    def edit(value: dict) -> None:
        node = next(item for item in value["nodes"] if item["node_id"] == "P0A-N80-FINAL-HANDOFF")
        node["condition_ids"] = ["ALWAYS"]
        node["consumes"] = ["output:P0A-N70-INDEPENDENT-REREVIEW/O-REREVIEW-RECEIPT"]
    mutate_json(d, "PHASE0A_BUILD_DAG.v2.json", edit)


def m_raw_html_accept(d: Path) -> None:
    mutate_json(d, "PHASE0A_CANONICAL_RULES.v2.json", lambda value: value["raw_html_policy"].__setitem__("on_persist", "ACCEPT_WITH_ESCAPING"))


def m_remove_requirement(d: Path) -> None:
    mutate_json(
        d, "PHASE0A_HANDOFF_REQUIREMENT_REGISTRY.v1.json",
        lambda value: value.__setitem__("requirements", [
            item for item in value["requirements"] if item["requirement_id"] != "HR-DASHBOARD"
        ]),
    )


def m_echo_oracle(d: Path) -> None:
    mutate_json(
        d, CONTRACT,
        lambda value: value.__setitem__("oracle", {
            "id": "candidate-echo", "control": "CANDIDATE", "echo_runner_rejected": False,
        }),
    )


def m_reversed_times(d: Path) -> None:
    def edit(value: dict) -> None:
        evidence = value["positive_fixture"]["candidate_evidence"]
        evidence["started_at"] = "2026-08-01T10:00:00Z"
        evidence["finished_at"] = "2026-08-01T09:00:00Z"
    mutate_json(d, VECTORS, edit)


def m_authority_true(d: Path) -> None:
    mutate_json(
        d, "PHASE0A_PRECEDENCE_AND_SUPERSESSION.v2.json",
        lambda value: value["authority_granted"].__setitem__("external_provider", True),
    )


# R19 exact probes ---------------------------------------------------------


def p01_echo_expectation_flip(d: Path) -> None:
    def edit(value: dict) -> None:
        case = next(item for item in value["cases"] if item["case_id"] == "C-G-P0A-WRITE-BOUNDARY-NO-HOME-WIDE-WRITE-001")
        case["fixture_inline"]["expected_observable"] = {"transition": "ACCEPT", "reason_code": "OK"}
        case["expected_transition"] = "ACCEPT"
        case["expected_reason_code"] = "OK"
    mutate_json(d, CONTRACT, edit)


def p02_slug_subtle_weaken(d: Path) -> None:
    mutate_json(d, "PHASE0A_NOTE_STATE.schema.json", lambda value: value["properties"]["slug"].__setitem__("pattern", "^[a-z0-9.\\-]{1,64}$"))


def p03_public_github_push(d: Path) -> None:
    def edit(value: dict) -> None:
        node = next(item for item in value["nodes"] if item["node_id"] == "P0A-N40-BUILD-CANDIDATE")
        node["required_checks"].append(AUTHORITY_PROBE_PAYLOADS[1])
    mutate_json(d, "PHASE0A_BUILD_DAG.v2.json", edit)


def first_evidence_target(d: Path) -> tuple[Path, dict]:
    vectors = load(d / VECTORS)
    evidence = vectors["positive_fixture"]["candidate_evidence"]
    results = sorted(
        evidence["case_results"] + evidence["assertion_results"] + evidence["mutant_results"],
        key=lambda item: item["evidence_path"],
    )
    result = results[0]
    protocol = load(d / "PHASE0A_EVIDENCE_PROTOCOL.v1.json")
    return d / protocol["synthetic_fixture_root"] / result["evidence_path"], result


def p04_evidence_fixture_tamper(d: Path) -> None:
    target, _ = first_evidence_target(d)
    if not target.is_file():
        raise RuntimeError(f"evidence target missing: {target.relative_to(d)}")
    target.write_bytes(target.read_bytes() + b"\ntampered\n")


def p05_forbidden_examples_removed(d: Path) -> None:
    mutate_json(d, "PHASE0A_TRANSITION_TABLE.v1.json", lambda value: value.__setitem__("forbidden_examples", []))


def p06_reserved_slugs_trimmed(d: Path) -> None:
    mutate_json(d, "PHASE0A_NOTE_STATE.schema.json", lambda value: value.__setitem__("x-phase0a-slug-reserved", ["admin"]))


def p07_raw_html_case_evasion(d: Path) -> None:
    for filename in (CONTRACT, "PHASE0A_RUNNER_INTERFACE.v2.json", "PHASE0A_HANDOFF_REQUIREMENT_REGISTRY.v1.json"):
        path = d / filename
        path.write_text(path.read_text(encoding="utf-8").replace("SCRIPT-TAG", "BOLD-TAG"), encoding="utf-8")
    contract = load(d / CONTRACT)
    case = next(item for item in contract["cases"] if "BOLD-TAG" in item["case_id"])
    case["fixture_inline"]["operation"]["kind"] = "CANDIDATE_OBSERVE"
    case["fixture_inline"]["expected_observable"] = {"transition": "ACCEPT", "reason_code": "OK"}
    case["expected_transition"] = "ACCEPT"
    case["expected_reason_code"] = "OK"
    save(d / CONTRACT, contract)


def p08_duplicate_json_key(d: Path) -> None:
    path = d / "PHASE0A_CANONICAL_RULES.v2.json"
    value = load(path)
    text = path.read_text(encoding="utf-8")
    index = text.rfind("}")
    if index < 0:
        raise RuntimeError("canonical rules has no closing object")
    prefix = text[:index].rstrip()
    injected = prefix + ",\n  \"schema_version\": " + json.dumps(value["schema_version"]) + "\n}\n"
    path.write_text(injected, encoding="utf-8")


# R20 closure classes ------------------------------------------------------


def c01_oracle_nonreflexive_matrix(d: Path) -> None:
    contract = load(d / CONTRACT)
    decided = sorted(
        (case for case in contract["cases"] if case.get("oracle_disposition") == "DECIDED_NON_REFLEXIVELY"),
        key=lambda item: item["case_id"],
    )
    if len(decided) < 2:
        raise RuntimeError("need at least two decided cases")
    # A single real disk mutant contains both attack classes.  The exhaustive
    # per-case matrix is run by run_round20_closure_probes.py.
    for index, case in enumerate(decided):
        if index % 2 == 0:
            case["fixture_inline"]["input"] = {"__garbage__": True}
        else:
            expected = case["fixture_inline"]["expected_observable"]
            flipped = "REJECT" if expected.get("transition") == "ACCEPT" else "ACCEPT"
            case["fixture_inline"]["expected_observable"] = {
                "transition": flipped, "reason_code": "R20_INVENTED_REASON",
            }
            case["expected_transition"] = flipped
            case["expected_reason_code"] = "R20_INVENTED_REASON"
    save(d / CONTRACT, contract)


def c02_authority_other_normative_file(d: Path) -> None:
    mutate_json(
        d, "PHASE0A_CANONICAL_RULES.v2.json",
        lambda value: value.__setitem__("x-round20-authority-probe", AUTHORITY_PROBE_PAYLOADS[3]),
    )


def c03_raw_html_payload_semantics(d: Path) -> None:
    contract = load(d / CONTRACT)
    case = next(
        item for item in sorted(contract["cases"], key=lambda row: row["case_id"])
        if item.get("oracle_disposition") == "DECIDED_NON_REFLEXIVELY"
        and "RAWHTML" not in item["case_id"]
    )
    case["fixture_inline"]["operation"] = {"kind": "CANDIDATE_OBSERVE_V2"}
    case["fixture_inline"]["input"] = {"body_markdown": "safe prefix <iframe src='x'></iframe>"}
    case["fixture_inline"]["expected_observable"] = {"transition": "ACCEPT", "reason_code": "OK"}
    case["expected_transition"] = "ACCEPT"
    case["expected_reason_code"] = "OK"
    save(d / CONTRACT, contract)


def c04_hash_without_matching_bytes(d: Path) -> None:
    vectors = load(d / VECTORS)
    evidence = vectors["positive_fixture"]["candidate_evidence"]
    result = min(
        evidence["case_results"] + evidence["assertion_results"] + evidence["mutant_results"],
        key=lambda item: item["evidence_path"],
    )
    result["evidence_sha256"] = "f" * 64 if result["evidence_sha256"] != "f" * 64 else "e" * 64
    save(d / VECTORS, vectors)


def c05_coherent_slug_weaken(d: Path) -> None:
    constants = load(d / SECURITY_CONSTANTS)
    constants["slug"]["pattern"] = "^[a-z0-9.\\-]{1,64}$"
    constants["slug"]["reserved"] = []
    save(d / SECURITY_CONSTANTS, constants)
    new_digest = sha256_file(d / SECURITY_CONSTANTS)

    library_path = d / "lib_phase0a.py"
    text = library_path.read_text(encoding="utf-8")
    text, count = re.subn(
        r'(?m)^SECURITY_CONSTANTS_SHA256 = "[a-f0-9]{64}"$',
        f'SECURITY_CONSTANTS_SHA256 = "{new_digest}"',
        text,
    )
    if count != 1:
        raise RuntimeError("security constants digest pin not found exactly once")
    library_path.write_text(text, encoding="utf-8")

    schema = load(d / "PHASE0A_NOTE_STATE.schema.json")
    schema["properties"]["slug"]["pattern"] = constants["slug"]["pattern"]
    schema["properties"]["slug"]["maxLength"] = constants["slug"]["max_length"]
    schema["x-phase0a-slug-reserved"] = []
    save(d / "PHASE0A_NOTE_STATE.schema.json", schema)


def c06_bytecode_manifest_pollution(d: Path) -> None:
    target = d / "__pycache__" / "round20_negative_control.pyc"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(b"ROUND020-NOT-A-REAL-PYC\n")
    manifest = load(d / NORMATIVE_MANIFEST)
    manifest["members"].append({
        "path": "__pycache__/round20_negative_control.pyc",
        "role": "negative_control",
        "sha256": sha256_file(target),
    })
    manifest["member_count"] = len(manifest["members"])
    save(d / NORMATIVE_MANIFEST, manifest)


def c07_forbidden_derived_coherent_rewrite(d: Path) -> None:
    table = load(d / "PHASE0A_TRANSITION_TABLE.v1.json")
    hold = {
        "n50": "HOLD", "n60": "NOT_REQUIRED", "n70": "INITIAL_PASS_CONFIRMED", "n80": "ELIGIBLE",
    }
    table["allowed_traces"].append(hold)
    table["forbidden_examples"] = [
        item for item in table["forbidden_examples"]
        if not (
            item.get("n50") == hold["n50"]
            and item.get("n60") == hold["n60"]
            and item.get("n70") == hold["n70"]
        )
    ]
    save(d / "PHASE0A_TRANSITION_TABLE.v1.json", table)


# R21 registry adoption ---------------------------------------------------


def deferred_cases(contract: dict) -> list[dict]:
    return [
        case for case in contract["cases"]
        if case.get("oracle_disposition") == "DEFERRED_TO_CANDIDATE_EXECUTION"
    ]


def decided_cases(contract: dict) -> list[dict]:
    return [
        case for case in contract["cases"]
        if case.get("oracle_disposition") == "DECIDED_NON_REFLEXIVELY"
    ]


def r21_p01_runner_method_reassign(d: Path) -> None:
    contract = load(d / CONTRACT)
    first, second = deferred_cases(contract)[:2]
    first["runner_method"], second["runner_method"] = (
        second["runner_method"], first["runner_method"]
    )
    save(d / CONTRACT, contract)


def r21_p02_slug_maxlength_widen(d: Path) -> None:
    constants = load(d / SECURITY_CONSTANTS)
    constants["slug"]["max_length"] = 100000
    save(d / SECURITY_CONSTANTS, constants)
    repin_constants(d)
    note = load(d / "PHASE0A_NOTE_STATE.schema.json")
    note["properties"]["slug"]["maxLength"] = 100000
    save(d / "PHASE0A_NOTE_STATE.schema.json", note)


def r21_p03_authority_zero_width(d: Path) -> None:
    dag = load(d / "PHASE0A_BUILD_DAG.v2.json")
    payloads = [
        AUTHORITY_PROBE_PAYLOADS[2].replace("public GitHub", "public\u200bGitHub"),
        AUTHORITY_PROBE_PAYLOADS[3].replace(" ", "\u00a0"),
        AUTHORITY_PROBE_PAYLOADS[0].replace("DeepSeek", "DeepSe\u0435k"),
        "p\u200dush " + AUTHORITY_PROBE_PAYLOADS[2].split("push ", 1)[1],
    ]
    nodes = dag.get("nodes") or []
    for index, payload in enumerate(payloads):
        instructions = nodes[index % len(nodes)].setdefault("instructions", [])
        instructions.append(payload)
    save(d / "PHASE0A_BUILD_DAG.v2.json", dag)


def r21_p04_markdown_datauri_active_content(d: Path) -> None:
    payload = base64.b64encode(b"<script>alert(1)</script>").decode("ascii")
    contract = load(d / CONTRACT)
    for case in decided_cases(contract):
        note = case.get("fixture_inline", {}).get("input", {}).get("note")
        if isinstance(note, dict) and "body_markdown" in note:
            note["body_markdown"] = (
                "# Synthetic Local Note\n\n"
                f"[click](data:text/html;base64,{payload})\n\n"
                "[go](java\tscript:alert(1))\n\n"
                "[img]: &#106;avascript:alert(1)\n"
            )
            break
    save(d / CONTRACT, contract)
    resync_corpus_lock(d)


def r21_p05_evidence_extra_unlisted_file(d: Path) -> None:
    target = d / "evidence_fixtures/synthetic_positive/extra_unlisted_result.json"
    save(target, {"status": "PASS", "note": "unreferenced smuggled fixture"})


def r21_p06_hold_rename_vocab_extension(d: Path) -> None:
    constants = load(d / SECURITY_CONSTANTS)
    transition = constants["transition"]
    transition["n50_outcomes"].append("HOLD_CLEARED")
    transition["allowed_traces"].append(
        ["HOLD_CLEARED", "REPAIRED", "PASS_AFTER_REPAIR"]
    )
    save(d / SECURITY_CONSTANTS, constants)
    repin_constants(d)
    table = load(d / "PHASE0A_TRANSITION_TABLE.v1.json")
    for key in ("n50_outcomes", "n50", "outcomes"):
        value = table.get(key)
        if isinstance(value, list) and "HOLD" in value:
            value.append("HOLD_CLEARED")
    save(d / "PHASE0A_TRANSITION_TABLE.v1.json", table)


def r21_p07_deferred_counted_in_pass_total(d: Path) -> None:
    contract = load(d / CONTRACT)
    deferred_ids = {case["case_id"] for case in deferred_cases(contract)}
    for test in contract["tests"]:
        if set(test.get("case_ids") or []) & deferred_ids:
            test["counted_in_spec_oracle_pass_total"] = True
            test["execution_policy"] = "RUN"
    for assertion in contract["assertions"]:
        if assertion.get("case_id") in deferred_ids:
            assertion["counted_in_spec_oracle_pass_total"] = True
            assertion["execution_policy"] = "RUN"
    contract["counts"]["oracle_decided_cases"] = 89
    contract["counts"]["oracle_deferred_cases"] = 0
    contract["counts"]["oracle_pass_denominator"] = 89
    contract["oracle"]["candidate_pass_requires_zero_deferred"] = False
    contract["oracle"]["deferred_excluded_from_pass_totals"] = False
    contract["candidate_pass_eligible_at_spec_stage"] = True
    contract["candidate_pass_blocker"] = None
    save(d / CONTRACT, contract)


def r21_p08_export_domain_coherent_rebind(d: Path) -> None:
    export_spec = load(d / "PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v3.json")
    export_spec["identity"]["export_id"]["domain"] = "PA-P0A-EXPORT-ID-V2"
    save(d / "PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v3.json", export_spec)


def r21_p09_new_reflexive_operation_name(d: Path) -> None:
    contract = load(d / CONTRACT)
    case = decided_cases(contract)[0]
    fixture = case["fixture_inline"]
    fixture["operation"] = {"kind": "REPLAY_DECLARED_OBSERVABLE"}
    fixture["input"] = {"declared": fixture["expected_observable"]}
    save(d / CONTRACT, contract)
    resync_corpus_lock(d)


def authority_payload() -> str:
    return " ".join(AUTHORITY_PROBE_PAYLOADS[2:7])


def r21_p10_authority_in_subdirectory_file(d: Path) -> None:
    for subdirectory in ("goldens", "fixtures"):
        target = d / subdirectory / "OPERATOR_NOTES.md"
        target.write_text("# Operator notes\n\n" + authority_payload() + "\n", encoding="utf-8")


def r21_p11_evidence_symlink_escape(d: Path) -> None:
    root = d / "evidence_fixtures/synthetic_positive"
    targets = sorted(
        path for path in root.rglob("*")
        if path.is_file() and path.name != "payload_manifest.txt"
    )
    victim = targets[0]
    external = d.parents[1] / "r22_external_evidence.bin"
    external.write_bytes(victim.read_bytes())
    victim.unlink()
    victim.symlink_to(external)


def r21_p12_assertion_ownership_reassign(d: Path) -> None:
    contract = load(d / CONTRACT)
    floor = [test for test in contract["tests"] if test.get("handoff_floor")]
    donor, receiver = floor[:2]
    moved = list(donor.get("assertion_ids") or [])
    donor["assertion_ids"] = []
    receiver["assertion_ids"] = list(receiver.get("assertion_ids") or []) + moved
    donor_cases = set(donor.get("case_ids") or [])
    receiver_case = (receiver.get("case_ids") or [None])[0]
    for assertion in contract["assertions"]:
        if assertion.get("case_id") in donor_cases and assertion["assertion_id"] in moved:
            assertion["case_id"] = receiver_case
    save(d / CONTRACT, contract)


def write_authority_surface_file(target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = authority_payload()
    if target.suffix == ".json":
        save(target, {"required_action": payload})
    elif target.suffix == ".jsonl":
        target.write_text(json.dumps({"required_action": payload}) + "\n", encoding="utf-8")
    elif target.suffix == ".py":
        target.write_text(f"OPERATOR_STEP = {payload!r}\n", encoding="utf-8")
    else:
        target.write_text("# Operator notes\n\n" + payload + "\n", encoding="utf-8")


def authority_surface_mutator(relative: str) -> Callable[[Path], None]:
    def mutate(d: Path) -> None:
        write_authority_surface_file(d / relative)
    return mutate


@dataclass(frozen=True)
class Mutation:
    mutation_id: str
    expected_codes: tuple[str, ...]
    mutator: Callable[[Path], None]
    required_rejectors: tuple[str, ...] = ("semantic_validator", "full_validator")
    require_all_codes: bool = True


MUTATIONS = (
    Mutation("R17-M01-EMPTY-CANDIDATE-BINDING-SCHEMA", ("SCHEMA_NOT_SUBSTANTIVE",), m_empty_binding_schema),
    Mutation("R17-M02-EMPTY-CANDIDATE-EVIDENCE-SCHEMA", ("SCHEMA_NOT_SUBSTANTIVE",), m_empty_evidence_schema),
    Mutation("R17-M03-EMPTY-GATE-CASE-SCHEMA", ("SCHEMA_NOT_SUBSTANTIVE",), m_empty_gate_schema),
    Mutation("R17-M04-EMPTY-DAG-SCHEMA", ("SCHEMA_NOT_SUBSTANTIVE",), m_empty_dag_schema),
    Mutation("R17-M05-VACUOUS-INLINE-FIXTURES", ("SYMBOLIC_CASE",), m_vacuous_fixtures),
    Mutation("R17-M06-NOOP-MUTATION-OPERATORS", ("NOOP_MUTANT",), m_noop_mutants),
    Mutation("R17-M07-FINAL-CONDITION-CONSTANT-TRUE", ("FINAL_CONDITION_CONSTANT",), m_final_condition_true),
    Mutation("R17-M08-REREVIEW-CHECKS-REMOVED", ("REREVIEW_NOOP",), m_rereview_checks_removed),
    Mutation("R17-M09-INITIAL-REVIEW-TEST-EXECUTION-REMOVED", ("INITIAL_REVIEW_TEST_EXECUTION_REMOVED",), m_initial_review_removed),
    Mutation("R17-M10-SLUG-TRAVERSAL-ALLOWED", ("SLUG_PATTERN_SOURCE_MISMATCH",), m_slug_traversal),
    Mutation("R17-M11-PUBLISHED-STATUS-ADDED", ("NOTE_STATUS_PUBLISHED_FORBIDDEN",), m_published_status),
    Mutation("R17-M12-ACTION-DETAIL-MAPPING-REMOVED", ("ACTION_DETAIL_MAPPING_INCOMPLETE",), m_action_detail_removed),
    Mutation("R17-M13-CANONICAL-HASH-DOMAINS-CHANGED", ("CANONICAL_NOTE_DOMAIN", "CANONICAL_EVENT_DOMAIN", "CANONICAL_RECEIPT_DOMAIN"), m_hash_domains),
    Mutation("R17-M14-EXPORT-WRITE-BOUNDARY-WIDENED", ("EXPORT_WRITE_BOUNDARY_WIDENED",), m_export_write_widen),
    Mutation("R17-M15-EXPORT-RECEIPT-SELF-HASH-ENABLED", ("EXPORT_RECEIPT_SELF_HASH",), m_export_self_hash),
    Mutation("R17-M16-RUNNER-EVIDENCE-BYPASS", ("RUNNER_EVIDENCE_BYPASS",), m_runner_bypass),
    Mutation("R17-M17-FICTITIOUS-EVIDENCE-HASHES", ("FICTITIOUS_EVIDENCE_HASH",), m_fictitious_evidence),
    Mutation("R17-M18-HIDDEN-PROVIDER-AUTHORITY-IN-DAG", ("AUTHORITY_PROHIBITED_TEXT",), m_hidden_provider),
    Mutation("R17-M19-UNSUPPORTED-IMPLEMENTATION-CLAIM", ("UNSUPPORTED_IMPLEMENTATION_CLAIM",), m_impl_claim),
    Mutation("R17-M20-REQUIRED-DASHBOARD-TEST-REMOVED-COHERENTLY", ("CONTRACT_SEMANTIC_CORPUS_MISMATCH",), m_remove_dashboard),
    Mutation("R18-M21-WEAK-NOTE-SCHEMA", ("SCHEMA_NOT_SUBSTANTIVE",), m_weak_note_schema),
    Mutation("R18-M22-BINDING-MAIN-BRANCH", ("BINDING_INSTANCE",), m_binding_main_branch_const),
    Mutation("R18-M23-BINDING-0.0.0.0", ("BINDING_INSTANCE",), m_binding_zero_bind),
    Mutation("R18-M24-HOLD-NOT-TERMINAL", ("HOLD_NOT_TERMINAL",), m_hold_not_terminal),
    Mutation("R18-M25-EXTRA-ALLOWED-HOLD-TRACE", ("TRANSITION_ALLOWED_SET_MISMATCH",), m_extra_allowed_trace),
    Mutation("R18-M26-N80-ALWAYS", ("N80_CONDITION_ALWAYS",), m_n80_always),
    Mutation("R18-M27-RAW-HTML-ACCEPT", ("RAW_HTML_MUST_REJECT",), m_raw_html_accept),
    Mutation("R18-M28-REMOVE-DASHBOARD-REQUIREMENT", ("REQUIREMENT_REMOVED",), m_remove_requirement),
    Mutation("R18-M29-ECHO-ORACLE", ("ORACLE_NOT_INDEPENDENT",), m_echo_oracle),
    Mutation("R18-M30-REVERSED-EVIDENCE-TIMES", ("EVIDENCE_TIME_REVERSED",), m_reversed_times),
    Mutation("R18-M31-AUTHORITY-GRANTED-TRUE", ("AUTHORITY_GRANTED_NOT_FALSE",), m_authority_true),
    Mutation("R19-P01-ECHO-CASE-EXPECTATION-FLIP", ("ORACLE_EXPECTATION_MISMATCH",), p01_echo_expectation_flip, ("semantic_validator", "full_validator", "independent_oracle")),
    Mutation("R19-P02-SLUG-PATTERN-SUBTLE-WEAKEN", ("SLUG_PATTERN_SOURCE_MISMATCH",), p02_slug_subtle_weaken),
    Mutation("R19-P03-DAG-PUBLIC-GITHUB-PUSH", ("AUTHORITY_PROHIBITED_TEXT",), p03_public_github_push),
    Mutation("R19-P04-EVIDENCE-FIXTURE-TAMPER", ("EVIDENCE_BYTES_HASH_MISMATCH",), p04_evidence_fixture_tamper),
    Mutation("R19-P05-FORBIDDEN-EXAMPLES-REMOVED", ("FORBIDDEN_EXAMPLES_DERIVATION_MISMATCH",), p05_forbidden_examples_removed),
    Mutation("R19-P06-RESERVED-SLUGS-TRIMMED", ("SLUG_RESERVED_SOURCE_MISMATCH",), p06_reserved_slugs_trimmed),
    Mutation("R19-P07-RAW-HTML-CASE-EVASION", ("RAW_HTML_EXPECTATION_MISMATCH", "RAW_HTML_ROUTE_REQUIRED"), p07_raw_html_case_evasion, ("semantic_validator", "full_validator", "independent_oracle")),
    Mutation("R19-P08-DUPLICATE-JSON-KEY", ("DUPLICATE_JSON_KEY",), p08_duplicate_json_key),
    Mutation("R20-C01-ORACLE-NONREFLEXIVE-MATRIX", ("INVALID_FIXTURE_INPUT", "ORACLE_EXPECTATION_MISMATCH"), c01_oracle_nonreflexive_matrix, ("semantic_validator", "full_validator", "independent_oracle")),
    Mutation("R20-C02-AUTHORITY-ALL-NORMATIVE-MATRIX", ("AUTHORITY_PROHIBITED_TEXT",), c02_authority_other_normative_file),
    Mutation("R20-C03-RAWHTML-PAYLOAD-SEMANTICS-MATRIX", ("RAW_HTML_EXPECTATION_MISMATCH", "RAW_HTML_ROUTE_REQUIRED"), c03_raw_html_payload_semantics, ("semantic_validator", "full_validator", "independent_oracle")),
    Mutation("R20-C04-EVIDENCE-HASH-BYTES-MATRIX", ("EVIDENCE_BYTES_HASH_MISMATCH",), c04_hash_without_matching_bytes),
    Mutation("R20-C05-SLUG-SOURCE-COHERENT-WEAKEN-MATRIX", ("SLUG_HOSTILE_ACCEPTED",), c05_coherent_slug_weaken),
    Mutation("R20-C06-BYTECODE-MANIFEST-POLLUTION", ("FORBIDDEN_BYTECODE_MANIFEST_ENTRY",), c06_bytecode_manifest_pollution),
    Mutation("R20-C07-FORBIDDEN-DERIVED-MATRIX", ("TRANSITION_ALLOWED_SET_MISMATCH", "FORBIDDEN_EXAMPLES_DERIVATION_MISMATCH"), c07_forbidden_derived_coherent_rewrite),
    Mutation("R21-P01-RUNNER-METHOD-REASSIGN", ("TEST_CASE_SEMANTIC_BINDING_MISMATCH",), r21_p01_runner_method_reassign),
    Mutation("R21-P02-SLUG-MAXLENGTH-WIDEN", ("SLUG_MAX_LENGTH_ABSOLUTE_MISMATCH",), r21_p02_slug_maxlength_widen),
    Mutation("R21-P03-AUTHORITY-ZERO-WIDTH-HOMOGLYPH", ("AUTHORITY_PROHIBITED_TEXT",), r21_p03_authority_zero_width),
    Mutation("R21-P04-MARKDOWN-DATAURI-ACTIVE-CONTENT", ("ORACLE_EXPECTATION_MISMATCH",), r21_p04_markdown_datauri_active_content, ("semantic_validator", "full_validator", "independent_oracle")),
    Mutation("R21-P05-EVIDENCE-EXTRA-UNLISTED-FILE", ("EVIDENCE_FIXTURE_SET_MISMATCH",), r21_p05_evidence_extra_unlisted_file),
    Mutation("R21-P06-HOLD-RENAME-VOCAB-EXTENSION", ("TRANSITION_N50_INDEPENDENT_ANCHOR_MISMATCH",), r21_p06_hold_rename_vocab_extension),
    Mutation("R21-P07-DEFERRED-COUNTED-IN-PASS-TOTAL", ("DEFERRED_SPEC_PASS_CLAIM",), r21_p07_deferred_counted_in_pass_total),
    Mutation("R21-P08-EXPORT-DOMAIN-COHERENT-REBIND", ("EXPORT_SPEC_DOMAIN_MISMATCH",), r21_p08_export_domain_coherent_rebind),
    Mutation("R21-P09-NEW-REFLEXIVE-OPERATION-NAME", ("CASE_NOT_ORACLE_DECIDABLE",), r21_p09_new_reflexive_operation_name, ("semantic_validator", "full_validator", "independent_oracle")),
    Mutation("R21-P10-AUTHORITY-IN-SUBDIRECTORY-FILE", ("AUTHORITY_PROHIBITED_TEXT",), r21_p10_authority_in_subdirectory_file),
    Mutation("R21-P11-EVIDENCE-SYMLINK-ESCAPE", ("NORMATIVE_MEMBER_SYMLINK",), r21_p11_evidence_symlink_escape),
    Mutation("R21-P12-ASSERTION-OWNERSHIP-REASSIGN", ("CASE_ASSERTION_SEMANTIC_SET_MISMATCH",), r21_p12_assertion_ownership_reassign),
    Mutation("R21-AS01-TOPLEVEL-MD", ("AUTHORITY_PROHIBITED_TEXT",), authority_surface_mutator("OPERATOR_NOTES.md")),
    Mutation("R21-AS02-TOPLEVEL-JSON", ("AUTHORITY_PROHIBITED_TEXT",), authority_surface_mutator("OPERATOR_PLAN.json")),
    Mutation("R21-AS03-TOPLEVEL-PY", ("AUTHORITY_PROHIBITED_TEXT",), authority_surface_mutator("operator_helper.py")),
    Mutation("R21-AS04-TOPLEVEL-TXT", ("AUTHORITY_PROHIBITED_TEXT",), authority_surface_mutator("operator.txt")),
    Mutation("R21-AS05-TOPLEVEL-JSONL", ("AUTHORITY_PROHIBITED_TEXT",), authority_surface_mutator("operator.jsonl")),
    Mutation("R21-AS06-SUBDIR-GOLDENS-MD", ("AUTHORITY_PROHIBITED_TEXT",), authority_surface_mutator("goldens/OPERATOR_NOTES.md")),
    Mutation("R21-AS07-SUBDIR-FIXTURES-MD", ("AUTHORITY_PROHIBITED_TEXT",), authority_surface_mutator("fixtures/OPERATOR_NOTES.md")),
    Mutation("R21-AS08-EVIDENCE-ROOT-MD", ("AUTHORITY_PROHIBITED_TEXT",), authority_surface_mutator("evidence_fixtures/OPERATOR_NOTES.md")),
)


REQUIRED_REGISTRY = (
    "R17-M01-EMPTY-CANDIDATE-BINDING-SCHEMA",
    "R17-M02-EMPTY-CANDIDATE-EVIDENCE-SCHEMA",
    "R17-M03-EMPTY-GATE-CASE-SCHEMA",
    "R17-M04-EMPTY-DAG-SCHEMA",
    "R17-M05-VACUOUS-INLINE-FIXTURES",
    "R17-M06-NOOP-MUTATION-OPERATORS",
    "R17-M07-FINAL-CONDITION-CONSTANT-TRUE",
    "R17-M08-REREVIEW-CHECKS-REMOVED",
    "R17-M09-INITIAL-REVIEW-TEST-EXECUTION-REMOVED",
    "R17-M10-SLUG-TRAVERSAL-ALLOWED",
    "R17-M11-PUBLISHED-STATUS-ADDED",
    "R17-M12-ACTION-DETAIL-MAPPING-REMOVED",
    "R17-M13-CANONICAL-HASH-DOMAINS-CHANGED",
    "R17-M14-EXPORT-WRITE-BOUNDARY-WIDENED",
    "R17-M15-EXPORT-RECEIPT-SELF-HASH-ENABLED",
    "R17-M16-RUNNER-EVIDENCE-BYPASS",
    "R17-M17-FICTITIOUS-EVIDENCE-HASHES",
    "R17-M18-HIDDEN-PROVIDER-AUTHORITY-IN-DAG",
    "R17-M19-UNSUPPORTED-IMPLEMENTATION-CLAIM",
    "R17-M20-REQUIRED-DASHBOARD-TEST-REMOVED-COHERENTLY",
    "R18-M21-WEAK-NOTE-SCHEMA",
    "R18-M22-BINDING-MAIN-BRANCH",
    "R18-M23-BINDING-0.0.0.0",
    "R18-M24-HOLD-NOT-TERMINAL",
    "R18-M25-EXTRA-ALLOWED-HOLD-TRACE",
    "R18-M26-N80-ALWAYS",
    "R18-M27-RAW-HTML-ACCEPT",
    "R18-M28-REMOVE-DASHBOARD-REQUIREMENT",
    "R18-M29-ECHO-ORACLE",
    "R18-M30-REVERSED-EVIDENCE-TIMES",
    "R18-M31-AUTHORITY-GRANTED-TRUE",
    "R19-P01-ECHO-CASE-EXPECTATION-FLIP",
    "R19-P02-SLUG-PATTERN-SUBTLE-WEAKEN",
    "R19-P03-DAG-PUBLIC-GITHUB-PUSH",
    "R19-P04-EVIDENCE-FIXTURE-TAMPER",
    "R19-P05-FORBIDDEN-EXAMPLES-REMOVED",
    "R19-P06-RESERVED-SLUGS-TRIMMED",
    "R19-P07-RAW-HTML-CASE-EVASION",
    "R19-P08-DUPLICATE-JSON-KEY",
    "R20-C01-ORACLE-NONREFLEXIVE-MATRIX",
    "R20-C02-AUTHORITY-ALL-NORMATIVE-MATRIX",
    "R20-C03-RAWHTML-PAYLOAD-SEMANTICS-MATRIX",
    "R20-C04-EVIDENCE-HASH-BYTES-MATRIX",
    "R20-C05-SLUG-SOURCE-COHERENT-WEAKEN-MATRIX",
    "R20-C06-BYTECODE-MANIFEST-POLLUTION",
    "R20-C07-FORBIDDEN-DERIVED-MATRIX",
    "R21-P01-RUNNER-METHOD-REASSIGN",
    "R21-P02-SLUG-MAXLENGTH-WIDEN",
    "R21-P03-AUTHORITY-ZERO-WIDTH-HOMOGLYPH",
    "R21-P04-MARKDOWN-DATAURI-ACTIVE-CONTENT",
    "R21-P05-EVIDENCE-EXTRA-UNLISTED-FILE",
    "R21-P06-HOLD-RENAME-VOCAB-EXTENSION",
    "R21-P07-DEFERRED-COUNTED-IN-PASS-TOTAL",
    "R21-P08-EXPORT-DOMAIN-COHERENT-REBIND",
    "R21-P09-NEW-REFLEXIVE-OPERATION-NAME",
    "R21-P10-AUTHORITY-IN-SUBDIRECTORY-FILE",
    "R21-P11-EVIDENCE-SYMLINK-ESCAPE",
    "R21-P12-ASSERTION-OWNERSHIP-REASSIGN",
    "R21-AS01-TOPLEVEL-MD",
    "R21-AS02-TOPLEVEL-JSON",
    "R21-AS03-TOPLEVEL-PY",
    "R21-AS04-TOPLEVEL-TXT",
    "R21-AS05-TOPLEVEL-JSONL",
    "R21-AS06-SUBDIR-GOLDENS-MD",
    "R21-AS07-SUBDIR-FIXTURES-MD",
    "R21-AS08-EVIDENCE-ROOT-MD",
)
actual_registry = tuple(mutation.mutation_id for mutation in MUTATIONS)
if (
    len(actual_registry) != len(set(actual_registry))
    or set(actual_registry) != set(REQUIRED_REGISTRY)
):
    missing = sorted(set(REQUIRED_REGISTRY) - set(actual_registry))
    extra = sorted(set(actual_registry) - set(REQUIRED_REGISTRY))
    raise RuntimeError(f"Round 022 registry mismatch: missing={missing}, extra={extra}")
EXPECTED_REGISTRY = tuple(sorted(REQUIRED_REGISTRY))


TOOL_COMMAND_TEMPLATES = {
    "semantic_validator": ["env", "PYTHONDONTWRITEBYTECODE=1", "python3", "-S", "meta_validate_round22.py", "--root", "<ROUND_ROOT>", "--semantic-only"],
    "full_validator": ["env", "PYTHONDONTWRITEBYTECODE=1", "python3", "-S", "meta_validate_round22.py", "--root", "<ROUND_ROOT>"],
    "independent_oracle": ["env", "PYTHONDONTWRITEBYTECODE=1", "python3", "-S", "independent_oracle.py", "PHASE0A_ACCEPTANCE_CONTRACT.v4.json"],
    "transition_evaluator": ["env", "PYTHONDONTWRITEBYTECODE=1", "python3", "-S", "transition_evaluator.py"],
    "export_generator": ["env", "PYTHONDONTWRITEBYTECODE=1", "python3", "-S", "export_generator.py"],
    "export_verifier": ["env", "PYTHONDONTWRITEBYTECODE=1", "python3", "-S", "export_verifier.py"],
}


def actual_command(round_dir: Path, tool: str) -> list[str]:
    if tool == "semantic_validator":
        return ["python3", "-S", str(round_dir / "meta_validate_round22.py"), "--root", str(round_dir), "--semantic-only"]
    if tool == "full_validator":
        return ["python3", "-S", str(round_dir / "meta_validate_round22.py"), "--root", str(round_dir)]
    if tool == "independent_oracle":
        return ["python3", "-S", str(round_dir / "independent_oracle.py"), str(round_dir / CONTRACT)]
    return ["python3", "-S", str(round_dir / f"{tool}.py")]


def run_tool(round_dir: Path, tool: str) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env.setdefault("LC_ALL", "C")
    env.setdefault("TZ", "UTC")
    return subprocess.run(
        actual_command(round_dir, tool), cwd=round_dir, env=env,
        capture_output=True, text=True, check=False,
    )


CODE_RE = re.compile(r"^[A-Z][A-Z0-9_]{2,}$")


def normalize_text(value: str, round_dir: Path) -> str:
    return value.replace(str(round_dir), "<ROUND_ROOT>").replace(str(round_dir.parents[1]), "<RELAY_ROOT>")


def normalized_output_hash(value: str, round_dir: Path) -> str:
    normalized = normalize_text(value or "", round_dir)
    try:
        parsed = json.loads(normalized)
        normalized = json.dumps(parsed, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    except Exception:
        pass
    return sha256_bytes(normalized.encode("utf-8"))


def reason_codes(processes: dict[str, subprocess.CompletedProcess[str]], round_dir: Path) -> list[str]:
    """Extract only structured reason-code fields, never attacker-controlled detail."""
    codes: set[str] = set()
    for process in processes.values():
        try:
            payload = json.loads(process.stdout)
            for error in payload.get("errors", []) if isinstance(payload, dict) else []:
                if isinstance(error, str):
                    code = error.split(":", 1)[0]
                    if CODE_RE.fullmatch(code):
                        codes.add(code)
            for failure in payload.get("failures", []) if isinstance(payload, dict) else []:
                if isinstance(failure, dict) and isinstance(failure.get("failure_code"), str):
                    code = failure["failure_code"]
                    if CODE_RE.fullmatch(code):
                        codes.add(code)
            for field in ("failure_code", "error_code"):
                code = payload.get(field) if isinstance(payload, dict) else None
                if isinstance(code, str) and CODE_RE.fullmatch(code):
                    codes.add(code)
        except Exception:
            pass
    return sorted(codes)


def process_receipt(process: subprocess.CompletedProcess[str], round_dir: Path) -> dict[str, Any]:
    return {
        "exit_code": process.returncode,
        "stdout_sha256": normalized_output_hash(process.stdout, round_dir),
        "stderr_sha256": normalized_output_hash(process.stderr, round_dir),
    }


def run_selected_tools(round_dir: Path, tools: set[str]) -> dict[str, subprocess.CompletedProcess[str]]:
    return {tool: run_tool(round_dir, tool) for tool in sorted(tools)}


def baseline_tools() -> set[str]:
    return set(TOOL_COMMAND_TEMPLATES)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-json", type=Path)
    parser.add_argument("--output-md", type=Path)
    parser.add_argument("--full", action="store_true", help="run all six documented tools for every mutation")
    parser.add_argument("--only", action="append", default=[], help="run only the named mutation (repeatable; diagnostic use)")
    parser.add_argument("--list", action="store_true", help="print the exact registry and exit")
    args = parser.parse_args()

    if args.list:
        print("\n".join(EXPECTED_REGISTRY))
        return 0
    if args.output_json is None or args.output_md is None:
        parser.error("--output-json and --output-md are required unless --list is used")

    selected_ids = set(args.only) if args.only else set(EXPECTED_REGISTRY)
    unknown = selected_ids - set(EXPECTED_REGISTRY)
    if unknown:
        raise SystemExit("unknown mutation IDs: " + ", ".join(sorted(unknown)))
    selected = sorted((mutation for mutation in MUTATIONS if mutation.mutation_id in selected_ids), key=lambda item: item.mutation_id)

    baseline_processes = run_selected_tools(SOURCE, baseline_tools())
    baseline = {
        "ok": all(process.returncode == 0 for process in baseline_processes.values()),
        "tools": {
            tool: process_receipt(process, SOURCE)
            for tool, process in sorted(baseline_processes.items())
        },
    }

    results = []
    if baseline["ok"]:
        for mutation in selected:
            with tempfile.TemporaryDirectory(prefix="pa-r022-mut-") as tmp:
                relay_copy = Path(tmp) / "relay"
                shutil.copytree(RELAY_ROOT, relay_copy, ignore=copy_ignore)
                round_dir = relay_copy / ROUND_RELATIVE
                before = round_tree_sha256(round_dir)
                mutation.mutator(round_dir)
                after_mutator = round_tree_sha256(round_dir)
                mutation_changed_tree = before != after_mutator
                rebind_acyclic(round_dir)
                after_rebind = round_tree_sha256(round_dir)

                tools = {"semantic_validator", "full_validator"}
                tools.update(mutation.required_rejectors)
                if args.full:
                    tools.update(TOOL_COMMAND_TEMPLATES)
                processes = run_selected_tools(round_dir, tools)
                codes = reason_codes(processes, round_dir)
                rejectors_rejected = all(processes[name].returncode != 0 for name in mutation.required_rejectors)
                codes_matched = (
                    all(code in codes for code in mutation.expected_codes)
                    if mutation.require_all_codes
                    else any(code in codes for code in mutation.expected_codes)
                )
                if not mutation_changed_tree or not rejectors_rejected:
                    observed = "FALSE_GREEN"
                elif not codes_matched:
                    observed = "REJECTED_WRONG_REASON"
                else:
                    observed = "REJECTED"

                results.append({
                    "mutation_id": mutation.mutation_id,
                    "expected": "REJECT",
                    "expected_reason_codes": list(mutation.expected_codes),
                    "required_rejectors": list(mutation.required_rejectors),
                    "observed": observed,
                    "mutation_changed_tree": mutation_changed_tree,
                    "mutation_present_after_rebind": after_rebind != before,
                    "reason_codes_matched": codes_matched,
                    "observed_reason_codes": codes,
                    "tools": {
                        tool: process_receipt(process, round_dir)
                        for tool, process in sorted(processes.items())
                    },
                })

    results.sort(key=lambda item: item["mutation_id"])
    rejected = sum(item["observed"] == "REJECTED" for item in results)
    false_green = sum(item["observed"] == "FALSE_GREEN" for item in results)
    wrong_reason = sum(item["observed"] == "REJECTED_WRONG_REASON" for item in results)
    complete_registry_run = selected_ids == set(EXPECTED_REGISTRY)
    status = (
        "PASS" if baseline["ok"] and complete_registry_run
        and rejected == len(EXPECTED_REGISTRY)
        and false_green == 0 and wrong_reason == 0 else "FAIL"
    )
    receipt = {
        "schema_version": "pa.phase0a.round22_mutation_receipt.v1",
        "round": "ROUND_022_CONTROLLING_PHASE0A_REPAIR",
        "status": status,
        "source_tree_modified": False,
        "execution_boundary": "disposable /tmp copies of the full relay only",
        "python_invocation": "PYTHONDONTWRITEBYTECODE=1 python3 -S",
        "pythonhashseed_note": "seed is intentionally not recorded; canonical receipt bytes must match for seeds 1 and 2",
        "tool_command_templates": TOOL_COMMAND_TEMPLATES,
        "toolchain_mode": "all_documented_tools_per_mutation" if args.full else "designated_rejectors",
        "baseline": baseline,
        "registry_exact": list(EXPECTED_REGISTRY),
        "registry_count": len(EXPECTED_REGISTRY),
        "selected_count": len(selected),
        "complete_registry_run": complete_registry_run,
        "summary": {
            "mutation_classes": len(results),
            "rejected": rejected,
            "false_green": false_green,
            "rejected_wrong_reason": wrong_reason,
        },
        "results": results,
    }
    text = json.dumps(receipt, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_md.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(text, encoding="utf-8")

    lines = [
        "# Round 022 Mutation Receipt", "", f"Status: `{status}`", "",
        f"Registry classes: {len(EXPECTED_REGISTRY)}", f"Selected: {len(selected)}",
        f"Rejected for intended reason: {rejected}", f"False green: {false_green}",
        f"Rejected for wrong reason: {wrong_reason}", "",
        "| ID | Observed | Intended reason |", "|---|---|---|",
    ]
    for result in results:
        lines.append(
            f"| `{result['mutation_id']}` | {result['observed']} | "
            f"`{', '.join(result['expected_reason_codes'])}` |"
        )
    args.output_md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(receipt["summary"], sort_keys=True))
    print(f"receipt_sha256={sha256_bytes(text.encode('utf-8'))}")
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
