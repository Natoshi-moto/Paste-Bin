#!/usr/bin/env python3
from __future__ import annotations

import sys
sys.dont_write_bytecode = True

from itertools import product
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from lib_phase0a import *


def main() -> int:
    rows = []
    for n50, n60, n70 in product(N50_OUTCOMES, N60_OUTCOMES, N70_OUTCOMES):
        rows.append({"n50": n50, "n60": n60, "n70": n70, **evaluate_review_trace(n50, n60, n70)})
    allowed = [row for row in rows if row["allowed"]]
    actual_allowed = {(row["n50"], row["n60"], row["n70"]) for row in allowed}
    expected_allowed = set(ALLOWED_TRACES)
    hold_rows = [row for row in rows if row["n50"] == "HOLD"]
    invalid_rows = [row for row in rows if row["n50"] != "HOLD" and not row["allowed"]]

    base = ("binding", "tree", "source", "evidence")
    def n80(*, handoff=base, remotes=None, bind=BIND, providers=None, untracked=None):
        return n80_identity_check(
            *base, *handoff,
            [] if remotes is None else remotes,
            bind,
            [] if providers is None else providers,
            [] if untracked is None else untracked,
        )

    n80_checks = {
        "matching_identity_accepts": n80() == [],
        "binding_mismatch_rejects": "N80_BINDING_MISMATCH" in n80(handoff=("other", *base[1:])),
        "tree_mismatch_rejects": "N80_TREE_MISMATCH" in n80(handoff=(base[0], "other", *base[2:])),
        "source_manifest_mismatch_rejects": "N80_SOURCE_MANIFEST_MISMATCH" in n80(handoff=(*base[:2], "other", base[3])),
        "evidence_mismatch_rejects": "N80_EVIDENCE_MISMATCH" in n80(handoff=(*base[:3], "other")),
        "remote_rejects": "N80_REMOTES_PRESENT" in n80(remotes=["origin"]),
        "non_loopback_bind_rejects": "N80_BIND_INVALID" in n80(bind="0.0.0.0"),
        "provider_adapter_rejects": "N80_PROVIDER_ADAPTER_PRESENT" in n80(providers=["external"]),
        "forbidden_untracked_rejects": "N80_UNTRACKED_FORBIDDEN" in n80(untracked=["secret.env"]),
    }
    out = {
        "schema_version": "pa.phase0a.round22_transition_eval_receipt.v1",
        "matrix_source": "shared locked evaluator vocabularies",
        "total": len(rows),
        "allowed_count": len(allowed),
        "forbidden_count": len(rows) - len(allowed),
        "allowed": allowed,
        "hold_origin_count": len(hold_rows),
        "hold_terminal_ok": all(
            not row["allowed"]
            and not row["n80_eligible"]
            and row["reason_code"] == "HOLD_TERMINAL"
            for row in hold_rows
        ),
        "other_forbidden_ok": all(
            not row["n80_eligible"] and row["reason_code"] == "INVALID_REVIEW_TRACE"
            for row in invalid_rows
        ),
        "allowed_set_matches_evaluator_constants": actual_allowed == expected_allowed,
        "n80_checks": n80_checks,
    }
    ok = (
        len(rows) == 36
        and len(allowed) == 2
        and out["forbidden_count"] == 34
        and out["hold_origin_count"] == 12
        and out["hold_terminal_ok"]
        and out["other_forbidden_ok"]
        and out["allowed_set_matches_evaluator_constants"]
        and all(n80_checks.values())
    )
    out["ok"] = ok
    print(dumps_pretty(out), end="")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
