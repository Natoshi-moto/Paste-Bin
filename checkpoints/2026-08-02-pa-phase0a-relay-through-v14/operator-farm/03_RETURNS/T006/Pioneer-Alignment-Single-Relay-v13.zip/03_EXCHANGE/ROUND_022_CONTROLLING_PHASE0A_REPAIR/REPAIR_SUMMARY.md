# Round 022 Phase 0A repair summary

Adjudication: `ROUND022_REPAIR_COMPLETE_AWAITING_INDEPENDENT_REREVIEW`

Round 022 closes R21-F01 through R21-F04 at the specification/gate level and
closes residual R19-F02 and R19-F05 through their successor controls. Release is
not self-adjudicated: independent Round 023 re-review remains mandatory.

## Exact closure map

| Finding | Repair | Permanent negative evidence |
|---|---|---|
| R21-F01 / R19-F02 | `meta_validate_round22.py` derives coverage from every shipped package file, checks SHA membership, strips default-ignorable format characters before authority matching, scans JSON keys/values, JSONL, Python string/bytes/static-composition literals, comments, paths and text bodies, recursively scans the sole fixed-hash ZIP fixture, admits executable Python only from a closed path set, and exact-hash locks every non-validator Python member. Negative contexts are exact context/value anchors. | `R21-P10`; `R21-AS01` through `R21-AS08`; undeclared/disguised/context probes; balanced bytes/f-string probes; allowlisted Add/format/percent/join probes; exact-lock `__add__`, name and `format_map` probes; zero-width Markdown probe |
| R21-F02 / R19-F05 | Exact slug maximum 80 is independently anchored across runtime, constants and schema. The hostile corpus contains an 81-character boundary vector and the validator checks length plus pattern semantics. | `R21-P02`; `R22-F02-SLUG-MAXLENGTH-COHERENT-WIDEN`; `R22-F02-SLUG-OVERLENGTH-CORPUS-REMOVED` |
| R21-F03 | All three selected-export domains are checked between the normative export spec, runtime constants and fixed absolute values. | `R21-P08`; spec-only, runtime-only and coherent dual-rebind closure probes |
| R21-F04 | Shipped validator and closure counters must equal the live package-wide scan count. `verify_round22_receipts.py` replays leaf receipts and, in full mode, both seed suites byte-for-byte. | two stale-counter closure probes plus final live replay |

## Preserved controls

- The independent oracle still decides 54 cases non-reflexively and honestly
  defers 35 candidate-required cases; deferred work cannot enter PASS totals.
- All 36 review traces remain exhaustively derived: two allowed, 34 forbidden,
  and all 12 HOLD-origin traces terminal.
- N80 still binds reviewed binding, tree, source-manifest and evidence identity
  and rejects unsafe environment dimensions.
- Active-content checks remain payload-semantic; evidence path, symlink and
  fixture-set controls remain closed.
- Export identity and golden ZIP bytes remain deterministic.
- All prior 23 closure negatives and all Round 019 probes remain present.

No app, host, repository, credential, network-provider, production, domain,
wallet, on-chain or public-state claim is made.
