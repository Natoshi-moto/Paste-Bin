#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ast
import io
import json
import re
import sys
import tokenize
import unicodedata
import zipfile
from itertools import product
from pathlib import Path, PurePosixPath

sys.dont_write_bytecode = True

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from lib_phase0a import *
from independent_oracle import evaluate_case, evaluate_contract, validate_operation_input

RELAY = ROOT.parents[1]

REQUIRED_FILES = [
    "PHASE0A_NORMATIVE_MANIFEST.v1.json",
    "PHASE0A_PRECEDENCE_AND_SUPERSESSION.v2.json",
    "PHASE0A_CANONICAL_RULES.v2.json",
    "PHASE0A_HANDOFF_REQUIREMENT_REGISTRY.v1.json",
    "PHASE0A_NOTE_STATE.schema.json",
    "PHASE0A_PROVENANCE_EVENT.schema.json",
    "PHASE0A_EXPORT_RECEIPT.schema.json",
    "PHASE0A_EXPORT_METADATA.schema.json",
    "PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v3.json",
    "PHASE0A_PROVENANCE_EXCERPT_POLICY.v1.json",
    "PHASE0A_RELAY_REQUEST.schema.json",
    "PHASE0A_RELAY_RESPONSE.schema.json",
    "PHASE0A_RELAY_ERROR.schema.json",
    "PHASE0A_FAKE_RELAY_ALGORITHM.v1.json",
    "PHASE0A_RELAY_GOLDEN_VECTORS.v1.json",
    "PHASE0A_WEB_SECURITY_VECTORS.v1.json",
    "PHASE0A_NOTE_EVENT_GOLDEN_VECTORS.v2.json",
    "PHASE0A_EXPORT_GOLDEN_VECTOR.v2.json",
    "PHASE0A_GATE_CASE_EVIDENCE.schema.json",
    "PHASE0A_CANDIDATE_BINDING.schema.json",
    "PHASE0A_CANDIDATE_EVIDENCE.schema.json",
    "PHASE0A_EVIDENCE_PROTOCOL.v1.json",
    "PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json",
    "PHASE0A_ACCEPTANCE_CONTRACT.v4.json",
    "PHASE0A_RUNNER_INTERFACE.v2.json",
    "PHASE0A_CONDITION_REGISTRY.v2.json",
    "PHASE0A_DAG_SCHEMA.v2.json",
    "PHASE0A_BUILD_DAG.v2.json",
    "PHASE0A_TRANSITION_TABLE.v1.json",
    "PHASE0A_RECEIPT_SCHEMAS.v1.json",
    "PHASE0A_HOST_PREFLIGHT_MATRIX.v1.json",
    "PHASE0A_REPOSITORY_FILE_REGISTRY.v1.json",
    "NO_IMPLEMENTATION_CANDIDATE.json",
    "PHASE0A_SECURITY_CONSTANTS.v1.json",
    "lib_phase0a.py",
    "independent_oracle.py",
    "transition_evaluator.py",
    "export_generator.py",
    "export_verifier.py",
    "meta_validate_round22.py",
    "run_round22_mutations.py",
    "run_round22_closure_probes.py",
    "verify_round22_receipts.py",
    "START_HERE.md",
    "REPAIR_SUMMARY.md",
    "REQUEST_FOR_INDEPENDENT_REREVIEW.md",
    "RETURN_SUMMARY.md",
    "FINDING_CLOSURE.json",
    "SPEC_VALIDATION_RECEIPT.semantic.json",
    "SPEC_VALIDATION_RECEIPT.json",
    "ORACLE_RECEIPT.json",
    "TRANSITION_EVAL_RECEIPT.json",
    "EXPORT_GENERATOR_RECEIPT.json",
    "EXPORT_VERIFIER_RECEIPT.json",
    "CLOSURE_PROBE_RECEIPT.json",
    "MUTATION_RECEIPTS.json",
    "MUTATION_RECEIPTS.md",
    "MUTATION_DETERMINISM_RECEIPT.json",
    "EXECUTION_RECEIPT.json",
    "fixtures/index.html",
    "fixtures/source.md",
    "fixtures/metadata.json",
    "fixtures/provenance.jsonl",
    "fixtures/SHA256SUMS.txt",
    "fixtures/export-receipt.json",
    "fixtures/selected-note-golden.zip",
    "goldens/interleaved_provenance_excerpt.json",
]

# This path-to-role anchor is independent of the manifest it validates.  Dynamic
# evidence members are anchored separately from the evidence protocol below.
REQUIRED_NORMATIVE_MEMBER_ROLES = {
    "NO_IMPLEMENTATION_CANDIDATE.json": "claims",
    "PHASE0A_ACCEPTANCE_CONTRACT.v4.json": "acceptance_contract",
    "PHASE0A_BUILD_DAG.v2.json": "dag",
    "PHASE0A_CANDIDATE_BINDING.schema.json": "schema",
    "PHASE0A_CANDIDATE_EVIDENCE.schema.json": "schema",
    "PHASE0A_CANONICAL_RULES.v2.json": "canonical_rules",
    "PHASE0A_CONDITION_REGISTRY.v2.json": "conditions",
    "PHASE0A_DAG_SCHEMA.v2.json": "schema",
    "PHASE0A_EVIDENCE_PROTOCOL.v1.json": "evidence_protocol",
    "PHASE0A_EXPORT_GOLDEN_VECTOR.v2.json": "golden",
    "PHASE0A_EXPORT_METADATA.schema.json": "schema",
    "PHASE0A_EXPORT_RECEIPT.schema.json": "schema",
    "PHASE0A_FAKE_RELAY_ALGORITHM.v1.json": "normative_spec",
    "PHASE0A_GATE_CASE_EVIDENCE.schema.json": "schema",
    "PHASE0A_HANDOFF_REQUIREMENT_REGISTRY.v1.json": "handoff_registry",
    "PHASE0A_HOST_PREFLIGHT_MATRIX.v1.json": "host_matrix",
    "PHASE0A_NOTE_EVENT_GOLDEN_VECTORS.v2.json": "golden",
    "PHASE0A_NOTE_STATE.schema.json": "schema",
    "PHASE0A_PRECEDENCE_AND_SUPERSESSION.v2.json": "precedence",
    "PHASE0A_PROVENANCE_EVENT.schema.json": "schema",
    "PHASE0A_PROVENANCE_EXCERPT_POLICY.v1.json": "export_spec",
    "PHASE0A_RECEIPT_SCHEMAS.v1.json": "receipt_schemas",
    "PHASE0A_RELAY_ERROR.schema.json": "schema",
    "PHASE0A_RELAY_GOLDEN_VECTORS.v1.json": "golden",
    "PHASE0A_RELAY_REQUEST.schema.json": "schema",
    "PHASE0A_RELAY_RESPONSE.schema.json": "schema",
    "PHASE0A_REPOSITORY_FILE_REGISTRY.v1.json": "repo_registry",
    "PHASE0A_RUNNER_INTERFACE.v2.json": "runner",
    "PHASE0A_SECURITY_CONSTANTS.v1.json": "security_constants",
    "PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v3.json": "export_spec",
    "PHASE0A_TRANSITION_TABLE.v1.json": "transition_table",
    "PHASE0A_WEB_SECURITY_VECTORS.v1.json": "security_vectors",
    "export_generator.py": "export_tool",
    "export_verifier.py": "export_tool",
    "fixtures/SHA256SUMS.txt": "fixture",
    "fixtures/export-receipt.json": "fixture",
    "fixtures/index.html": "fixture",
    "fixtures/metadata.json": "fixture",
    "fixtures/provenance.jsonl": "fixture",
    "fixtures/selected-note-golden.zip": "fixture",
    "fixtures/source.md": "fixture",
    "goldens/interleaved_provenance_excerpt.json": "golden",
    "independent_oracle.py": "oracle",
    "lib_phase0a.py": "library",
    "meta_validate_round22.py": "validator",
    "run_round22_closure_probes.py": "closure_probe",
    "run_round22_mutations.py": "mutation_runner",
    "verify_round22_receipts.py": "receipt_verifier",
    "transition_evaluator.py": "transition_evaluator",
}

# Independent minimums: these do not derive from the mutable shared constants.
REQUIRED_AUTHORITY_VOCABULARY_TERMS = (
    "github", "push", "deploy", "cloudflare", "dns", "public repository",
    "credentials", "provider", "0.0.0.0", "deepseek",
)
REQUIRED_AUTHORITY_PROHIBITED_PAYLOADS = (
    "push to public GitHub repository",
    "push the candidate tree to a public GitHub repository",
    "deploy to Cloudflare",
    "change DNS using provider credentials",
    "bind to 0.0.0.0",
    "connect DeepSeek as provider",
)
ABSOLUTE_AUTHORITY_REJECT_SUBSTRINGS = (
    "push to public github repository",
    "push the candidate tree to a public github repository",
    "public github repository",
    "public github push",
    "deploy to cloudflare",
    "deploy on cloudflare",
    "change dns",
    "configure dns",
    "cloudflare changes",
    "connect deepseek",
    "deepseek with operator credentials",
    "operator credentials",
    "provider credentials",
    "connect provider",
    "connect an external provider",
    "create a public repository",
    "create a public github repository",
    "configure a remote",
    "remote push",
    "public tunnel",
    "bind to 0.0.0.0",
    "0.0.0.0 bind",
    "npm publish",
)
ABSOLUTE_AUTHORITY_PROBE_PAYLOADS = (
    "connect DeepSeek with operator credentials",
    "push the candidate tree to a public GitHub repository for backup",
    "push the candidate tree to a public GitHub repository",
    "deploy to Cloudflare",
    "change DNS using provider credentials",
    "bind to 0.0.0.0",
    "connect DeepSeek as provider",
)
ABSOLUTE_AUTHORITY_CONTEXTS_SHA256 = "8eb5de6d375ca98bd7a28b9775dc926477b11ed09a646cbda09ca2ab89abfa56"
REQUIRED_N50_OUTCOMES = ("PASS", "REPAIR_REQUIRED", "HOLD")
REQUIRED_N60_OUTCOMES = ("NOT_REQUIRED", "REPAIRED", "BLOCKED")
REQUIRED_N70_OUTCOMES = ("INITIAL_PASS_CONFIRMED", "PASS_AFTER_REPAIR", "FAIL", "BLOCKED")
REQUIRED_ALLOWED_TRACES = {
    ("PASS", "NOT_REQUIRED", "INITIAL_PASS_CONFIRMED"),
    ("REPAIR_REQUIRED", "REPAIRED", "PASS_AFTER_REPAIR"),
}
REQUIRED_RAW_HTML_BEHAVIORAL_PAYLOADS = (
    "<script>alert(1)</script>",
    "<img src=x onclick=alert(1)>",
    "[x](javascript:alert(1))",
    "<iframe src=x></iframe>",
    "<object data=x></object>",
    "<embed src=x>",
    "<link rel=import href=x>",
    "<div>ordinary raw HTML</div>",
    "<b>bold raw HTML</b>",
    "<!-- raw HTML comment -->",
    "<svg><circle /></svg>",
    "<!DOCTYPE html>",
)
REQUIRED_RAW_HTML_SAFE_MARKDOWN = (
    "plain **md** only",
    "[safe link](https://example.test)",
    "<https://example.test>",
)
ABSOLUTE_SLUG_MAX_LENGTH = 80
ABSOLUTE_EXPORT_DOMAINS = {
    "content_set_sha256": "PA-P0A-CONTENT-SET-V1",
    "export_id": "PA-P0A-EXPORT-ID-V1",
    "receipt_hash": "PA-P0A-EXPORT-RECEIPT-V2",
}
REQUIRED_MUTATION_REGISTRY_SHA256 = "f5930f2b18f2010cbd38defcb0e6b8ab6b611c59235ee0f6a81f81b349e91e2c"
REQUIRED_MUTATION_SEMANTICS_SHA256 = "b7015dbb9972538c3ea530a39e472fbc1d8b4d47eebfa73c02558976a080363c"
REQUIRED_MUTATION_COUNT = 66
REQUIRED_CLOSURE_NEGATIVE_COUNT = 43
REQUIRED_CLOSURE_SEMANTICS_SHA256 = "f045722d59fb52638a48aca3caf7ab74aafe13402ef33d410d89b77c79c0cbd1"
EMPTY_SHA256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
NORMATIVE_TEXTUAL_SUFFIXES = {".json", ".jsonl", ".py", ".md", ".html", ".txt"}
ALLOWED_NORMATIVE_BINARY_MEMBERS = {"fixtures/selected-note-golden.zip"}
ALLOWED_PACKAGE_BINARY_MEMBERS = {
    "fixtures/selected-note-golden.zip":
        "9fbe23d06c8e99e48fc65270a93501041ab39840c54b28ac6760b6a446933bd9",
}
ALLOWED_PACKAGE_PYTHON_MEMBERS = {
    "export_generator.py",
    "export_verifier.py",
    "independent_oracle.py",
    "lib_phase0a.py",
    "meta_validate_round22.py",
    "run_round22_closure_probes.py",
    "run_round22_mutations.py",
    "transition_evaluator.py",
    "verify_round22_receipts.py",
}
ABSOLUTE_PACKAGE_PYTHON_SHA256 = {
    "export_generator.py": "9d6390a3266a09adbb6d8a84dcfab6d48e006a1e3ea801f9ea86f6dd2828b5fa",
    "export_verifier.py": "48937a951d40d83ae0622070b8f7267eed6d7ba79b40c3f1b1e3ca8e95fef24a",
    "independent_oracle.py": "ebdba92ac9e824dbeaf98e019e7ad9ce5798a5c4f85cff2a87e5e02f8a8cdca9",
    "lib_phase0a.py": "73cbbc8f55b73216dd17b54b056d4d288a58a627c118f4ccb04e0f87dfaecfdd",
    "run_round22_closure_probes.py": "d38607494d60acd76c2c30d898ff0eeba49e1aa55c545aae57007077ebba099b",
    "run_round22_mutations.py": "7129bb716ec3948e697ff9ae6326f0b2d727ff7e8f7643c5b16e36e2940adb16",
    "transition_evaluator.py": "cf3ebcb17ef7ab04edd426cfe0f203973930e1f2ecdd930c308c8cb5b9d2d5be",
    "verify_round22_receipts.py": "30e76d0ec4c525ee4cfb25540d2dbe948aa9e806f3e625d78a890087b8259216",
}

SCHEMA_FILES = [
    "PHASE0A_NOTE_STATE.schema.json",
    "PHASE0A_PROVENANCE_EVENT.schema.json",
    "PHASE0A_EXPORT_RECEIPT.schema.json",
    "PHASE0A_EXPORT_METADATA.schema.json",
    "PHASE0A_RELAY_REQUEST.schema.json",
    "PHASE0A_RELAY_RESPONSE.schema.json",
    "PHASE0A_RELAY_ERROR.schema.json",
    "PHASE0A_GATE_CASE_EVIDENCE.schema.json",
    "PHASE0A_CANDIDATE_BINDING.schema.json",
    "PHASE0A_CANDIDATE_EVIDENCE.schema.json",
    "PHASE0A_DAG_SCHEMA.v2.json",
]

def err(errors, code, detail=""):
    errors.append(f"{code}" + (f":{detail}" if detail else ""))


def string_leaves(value, pointer="$"):
    if isinstance(value, str):
        yield pointer, value
    elif isinstance(value, dict):
        for key in sorted(value):
            escaped = str(key).replace("~", "~0").replace("/", "~1")
            yield from string_leaves(value[key], f"{pointer}/{escaped}")
    elif isinstance(value, list):
        for index, item in enumerate(value):
            yield from string_leaves(item, f"{pointer}/{index}")


def string_fields(value, pointer="$"):
    """Yield every JSON string key and value with an unambiguous pointer."""
    if isinstance(value, str):
        yield pointer, value
    elif isinstance(value, dict):
        for key in sorted(value, key=lambda item: str(item)):
            escaped = str(key).replace("~", "~0").replace("/", "~1")
            if isinstance(key, str):
                yield f"{pointer}/$key/{escaped}", key
            yield from string_fields(value[key], f"{pointer}/{escaped}")
    elif isinstance(value, list):
        for index, item in enumerate(value):
            yield from string_fields(item, f"{pointer}/{index}")


def normalized_text(value: str) -> str:
    normalized = unicodedata.normalize("NFKC", value)
    visible = "".join(
        character for character in normalized
        if unicodedata.category(character) != "Cf"
        and not (0xFE00 <= ord(character) <= 0xFE0F)
        and not (0xE0100 <= ord(character) <= 0xE01EF)
    )
    return " ".join(visible.casefold().split())


def ignored_bytecode_path(path: Path) -> bool:
    return "__pycache__" in path.parts or path.suffix == ".pyc"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--semantic-only", action="store_true")
    parser.add_argument("--receipt", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    relay = root.parents[1]
    errors: list[str] = []

    # presence
    for rel in REQUIRED_FILES:
        if not (root / rel).is_file():
            err(errors, "REQUIRED_FILE_MISSING", rel)

    if errors and not args.semantic_only:
        # still continue semantic if possible
        pass

    def load(name):
        try:
            return load_json(root / name)
        except Exception as e:
            message = str(e)
            if message.startswith("DUPLICATE_JSON_KEY:"):
                err(errors, "DUPLICATE_JSON_KEY", f"{name}:{message.split(':', 1)[1]}")
            else:
                err(errors, "JSON_LOAD", f"{name}:{message}")
            return None

    # schemas substantive + applied
    schemas = {}
    for sf in SCHEMA_FILES:
        sc = load(sf)
        schemas[sf] = sc
        if sc is None:
            continue
        for e in schema_is_substantive(sc):
            err(errors, "SCHEMA_NOT_SUBSTANTIVE", f"{sf}:{e}")
        # metaschema-ish: must have $schema and $id for schema files
        if not sc.get("$schema") or not sc.get("$id"):
            err(errors, "SCHEMA_META_MISSING", sf)

    note_schema = schemas.get("PHASE0A_NOTE_STATE.schema.json") or {}
    event_schema = schemas.get("PHASE0A_PROVENANCE_EVENT.schema.json") or {}
    binding_schema = schemas.get("PHASE0A_CANDIDATE_BINDING.schema.json") or {}
    evidence_schema = schemas.get("PHASE0A_CANDIDATE_EVIDENCE.schema.json") or {}
    dag_schema = schemas.get("PHASE0A_DAG_SCHEMA.v2.json") or {}
    gate_schema = schemas.get("PHASE0A_GATE_CASE_EVIDENCE.schema.json") or {}

    # note schema invariants
    if note_schema:
        slug = note_schema.get("properties", {}).get("slug", {})
        if SLUG_MAX_LENGTH != ABSOLUTE_SLUG_MAX_LENGTH:
            err(errors, "SLUG_MAX_LENGTH_ABSOLUTE_MISMATCH", str(SLUG_MAX_LENGTH))
        if SECURITY_CONSTANTS.get("slug", {}).get("max_length") != ABSOLUTE_SLUG_MAX_LENGTH:
            err(errors, "SLUG_MAX_LENGTH_ABSOLUTE_MISMATCH", "security_constants")
        if slug.get("pattern") != SLUG_PATTERN:
            err(errors, "SLUG_PATTERN_SOURCE_MISMATCH")
        if slug.get("maxLength") != SLUG_MAX_LENGTH:
            err(errors, "SLUG_MAX_LENGTH_SOURCE_MISMATCH")
        if slug.get("maxLength") != ABSOLUTE_SLUG_MAX_LENGTH:
            err(errors, "SLUG_MAX_LENGTH_ABSOLUTE_MISMATCH", "note_schema")
        if "published" in (note_schema.get("properties", {}).get("status", {}).get("enum") or []):
            err(errors, "NOTE_STATUS_PUBLISHED_FORBIDDEN")
        reserved = note_schema.get("x-phase0a-slug-reserved")
        if reserved != SECURITY_CONSTANTS["slug"]["reserved"]:
            err(errors, "SLUG_RESERVED_SOURCE_MISMATCH")
        try:
            schema_slug_re = re.compile(slug.get("pattern", ""))
            overlength_hostiles = []
            for hostile in SECURITY_CONSTANTS["slug"]["hostile_corpus"]:
                schema_accepts = (
                    isinstance(hostile, str)
                    and len(hostile) <= slug.get("maxLength", -1)
                    and schema_slug_re.fullmatch(hostile) is not None
                )
                library_result = validate_slug(hostile)
                if schema_accepts or library_result is None:
                    err(errors, "SLUG_HOSTILE_ACCEPTED", repr(hostile))
                if isinstance(hostile, str) and len(hostile) > ABSOLUTE_SLUG_MAX_LENGTH:
                    overlength_hostiles.append(hostile)
                    if library_result != "SLUG_TOO_LONG" or schema_accepts:
                        err(errors, "SLUG_HOSTILE_LENGTH_GUARD_MISSING", repr(hostile))
            if not overlength_hostiles:
                err(errors, "SLUG_OVERLENGTH_HOSTILE_CORPUS_MISSING")
            if not any(len(value) == ABSOLUTE_SLUG_MAX_LENGTH + 1 for value in overlength_hostiles):
                err(errors, "SLUG_BOUNDARY_PLUS_ONE_HOSTILE_MISSING")
            for safe in SECURITY_CONSTANTS["slug"]["safe_corpus"]:
                if (
                    len(safe) > slug.get("maxLength", -1)
                    or not schema_slug_re.fullmatch(safe)
                    or validate_slug(safe) is not None
                ):
                    err(errors, "SLUG_SAFE_REJECTED", safe)
            for required_reserved in SECURITY_CONSTANTS["slug"]["reserved"]:
                if validate_slug(required_reserved) != "RESERVED_SLUG":
                    err(errors, "SLUG_REQUIRED_RESERVED_MISSING", required_reserved)
        except re.error as exc:
            err(errors, "SLUG_PATTERN_INVALID", str(exc))
        if note_schema.get("x-phase0a-state-hash-domain") != DOMAIN_NOTE:
            err(errors, "NOTE_HASH_DOMAIN_CHANGED")
        if note_schema.get("x-phase0a-raw-html") != "REJECT_BEFORE_PERSIST":
            err(errors, "RAW_HTML_POLICY_MISSING")

    if event_schema:
        branch = event_schema.get("x-phase0a-action-detail-branch") or {}
        if set(branch.keys()) != set(ACTIONS):
            err(errors, "ACTION_DETAIL_MAPPING_INCOMPLETE")
        if event_schema.get("x-phase0a-event-hash-domain") != DOMAIN_EVENT:
            err(errors, "EVENT_HASH_DOMAIN_CHANGED")
        if set(event_schema.get("x-phase0a-required-actions") or []) != set(ACTIONS):
            err(errors, "REQUIRED_ACTIONS_CHANGED")

    # canonical rules domains
    rules = load("PHASE0A_CANONICAL_RULES.v2.json") or {}
    hashes = rules.get("hashes", {})
    if hashes.get("note_state", {}).get("domain_prefix_utf8_then_nul") != DOMAIN_NOTE:
        err(errors, "CANONICAL_NOTE_DOMAIN")
    if hashes.get("provenance_event", {}).get("domain_prefix_utf8_then_nul") != DOMAIN_EVENT:
        err(errors, "CANONICAL_EVENT_DOMAIN")
    if hashes.get("export_receipt", {}).get("domain_prefix_utf8_then_nul") != DOMAIN_RECEIPT:
        err(errors, "CANONICAL_RECEIPT_DOMAIN")
    if hashes.get("content_set", {}).get("domain_prefix_utf8_then_nul") != DOMAIN_CONTENT_SET:
        err(errors, "CANONICAL_CONTENT_SET_DOMAIN")
    if hashes.get("export_id", {}).get("domain_prefix_utf8_then_nul") != DOMAIN_EXPORT_ID:
        err(errors, "CANONICAL_EXPORT_ID_DOMAIN")
    if rules.get("raw_html_policy", {}).get("on_persist") != "REJECT":
        err(errors, "RAW_HTML_MUST_REJECT")
    for payload in REQUIRED_RAW_HTML_BEHAVIORAL_PAYLOADS:
        if detect_raw_html(payload) != "RAW_HTML_REJECTED":
            err(errors, "RAW_HTML_BEHAVIORAL_CLASS_ACCEPTED", payload)
    for payload in REQUIRED_RAW_HTML_SAFE_MARKDOWN:
        if detect_raw_html(payload) is not None:
            err(errors, "RAW_HTML_SAFE_MARKDOWN_REJECTED", payload)
    web_vectors = load("PHASE0A_WEB_SECURITY_VECTORS.v1.json") or {}
    raw_html_vectors = web_vectors.get("raw_html_bodies") or []
    if not raw_html_vectors:
        err(errors, "RAW_HTML_VECTOR_CORPUS_EMPTY")
    for index, vector in enumerate(raw_html_vectors):
        if (
            not isinstance(vector, dict)
            or detect_raw_html(vector.get("body_markdown", "")) != "RAW_HTML_REJECTED"
            or vector.get("reason_code") != "RAW_HTML_REJECTED"
        ):
            err(errors, "RAW_HTML_VECTOR_INVALID", str(index))

    # export spec
    export_spec = load("PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v3.json") or {}
    wb = export_spec.get("write_boundary", {})
    if wb.get("public_repository") is not False or wb.get("outside_workspace") is not False:
        err(errors, "EXPORT_WRITE_BOUNDARY_WIDENED")
    if export_spec.get("members", {}).get("export-receipt.json", {}).get("receipt_hash_excludes_field") != "receipt_hash":
        err(errors, "EXPORT_RECEIPT_SELF_HASH")
    if not export_spec.get("identity", {}).get("content_set_sha256"):
        err(errors, "EXPORT_CONTENT_SET_FORMULA_MISSING")
    if not export_spec.get("identity", {}).get("export_id"):
        err(errors, "EXPORT_ID_FORMULA_MISSING")
    declared_export_domains = {
        name: (export_spec.get("identity", {}).get(name) or {}).get("domain")
        for name in ABSOLUTE_EXPORT_DOMAINS
    }
    runtime_export_domains = {
        "content_set_sha256": DOMAIN_CONTENT_SET,
        "export_id": DOMAIN_EXPORT_ID,
        "receipt_hash": DOMAIN_RECEIPT,
    }
    for name, absolute_domain in ABSOLUTE_EXPORT_DOMAINS.items():
        if declared_export_domains.get(name) != runtime_export_domains.get(name):
            err(errors, "EXPORT_SPEC_DOMAIN_MISMATCH", name)
        if declared_export_domains.get(name) != absolute_domain:
            err(errors, "EXPORT_SPEC_DOMAIN_ABSOLUTE_MISMATCH", name)
        if runtime_export_domains.get(name) != absolute_domain:
            err(errors, "EXPORT_RUNTIME_DOMAIN_ABSOLUTE_MISMATCH", name)
    pep = export_spec.get("provenance_excerpt_policy", {})
    if pep.get("self_verifying_global_chain") is not False:
        err(errors, "PROVENANCE_EXCERPT_MUST_DECLARE_NON_SELF_VERIFYING")

    # precedence / authority
    prec = load("PHASE0A_PRECEDENCE_AND_SUPERSESSION.v2.json") or {}
    ag = prec.get("authority_granted") or {}
    for k in PROHIBITED_AUTHORITY_KEYS:
        if ag.get(k) is not False:
            err(errors, "AUTHORITY_GRANTED_NOT_FALSE", k)
    if set(prec.get("prohibited_actions") or []) < set(PROHIBITED_AUTHORITY_KEYS):
        err(errors, "PROHIBITED_ACTIONS_INCOMPLETE")
    claims = prec.get("claims") or {}
    if claims.get("application_implemented") is not False:
        err(errors, "FALSE_IMPLEMENTATION_CLAIM")
    if claims.get("host_path_verified") is not False:
        err(errors, "FALSE_HOST_CLAIM")
    cs = prec.get("controlling_source") or {}
    handoff = relay / "01_ORIGINAL_ARTIFACTS/Pioneer-Alignment-Phase-0A-Builder-Handoff-v1.md"
    if handoff.is_file():
        if cs.get("sha256") != sha256_file(handoff):
            err(errors, "HANDOFF_HASH_MISMATCH")

    # no implementation
    nic = load("NO_IMPLEMENTATION_CANDIDATE.json") or {}
    if nic.get("application_implemented") is not False:
        err(errors, "UNSUPPORTED_IMPLEMENTATION_CLAIM")
    if nic.get("application_tests_run") is not False:
        err(errors, "UNSUPPORTED_TESTS_CLAIM")
    if nic.get("host_preflight_run") is not False:
        err(errors, "UNSUPPORTED_HOST_CLAIM")

    # contract
    contract = load("PHASE0A_ACCEPTANCE_CONTRACT.v4.json") or {}
    tests = []
    cases = []
    assertions = []
    mutants = []
    decided_cases = []
    deferred_cases = []
    if not contract:
        err(errors, "CONTRACT_MISSING")
    else:
        counts = contract.get("counts") or {}
        tests = contract.get("tests") or []
        cases = contract.get("cases") or []
        assertions = contract.get("assertions") or []
        mutants = contract.get("mutants") or []
        # Counts are reported, never used as an acceptance oracle. Structural
        # completeness is enforced through referential closure and semantic checks.
        collections_by_count = {
            "total_tests": tests,
            "total_cases": cases,
            "total_assertions": assertions,
            "total_mutants": mutants,
        }
        for field, collection in collections_by_count.items():
            if counts.get(field) != len(collection):
                err(errors, "DECLARED_COUNT_MISMATCH", field)
        # Every counted case is input-derived; all other cases are explicit deferrals.
        for case in cases:
            fx = case.get("fixture_inline") or {}
            op = fx.get("operation") or {}
            kind = op.get("kind")
            if "input" not in fx:
                err(errors, "VACUOUS_FIXTURE", case.get("case_id"))
            if not op or kind in (None, ""):
                err(errors, "SYMBOLIC_CASE", case.get("case_id"))
            if not isinstance(fx.get("expected_observable"), dict):
                err(errors, "CASE_NO_OBSERVABLE", case.get("case_id"))
            if not case.get("immutable"):
                err(errors, "CASE_NOT_IMMUTABLE", case.get("case_id"))
            if fx.get("immutable") is not True:
                err(errors, "FIXTURE_NOT_IMMUTABLE", case.get("case_id"))
            if kind in FORBIDDEN_REFLEXIVE_OPERATION_KINDS:
                err(errors, "REFLEXIVE_OPERATION_FORBIDDEN", str(kind))
            if kind == DEFERRED_OPERATION_KIND:
                deferred_cases.append(case)
                expected_deferred = {"transition": "DEFERRED", "reason_code": DEFERRED_REASON_CODE}
                if (
                    case.get("oracle_disposition") != "DEFERRED_TO_CANDIDATE_EXECUTION"
                    or case.get("execution_policy") != "DEFERRED_TO_CANDIDATE_EXECUTION"
                    or fx.get("expected_observable") != expected_deferred
                    or case.get("expected_transition") != "DEFERRED"
                    or case.get("expected_reason_code") != DEFERRED_REASON_CODE
                ):
                    err(errors, "DEFERRED_EXPECTATION_INVALID", case.get("case_id"))
                candidate_operation = fx.get("candidate_operation")
                candidate_expected = fx.get("candidate_expected_observable")
                if not isinstance(candidate_operation, dict) or not candidate_operation.get("kind"):
                    err(errors, "DEFERRED_CANDIDATE_OPERATION_MISSING", case.get("case_id"))
                if (
                    not isinstance(candidate_expected, dict)
                    or set(candidate_expected) != {"transition", "reason_code"}
                    or candidate_expected.get("transition") not in {"ACCEPT", "REJECT"}
                    or not isinstance(candidate_expected.get("reason_code"), str)
                    or not candidate_expected.get("reason_code")
                ):
                    err(errors, "DEFERRED_CANDIDATE_EXPECTATION_INVALID", case.get("case_id"))
            else:
                decided_cases.append(case)
                if case.get("oracle_disposition") != "DECIDED_NON_REFLEXIVELY":
                    err(errors, "ORACLE_DISPOSITION_INVALID", case.get("case_id"))
                if not validate_operation_input(str(kind), fx.get("input")):
                    err(errors, "CASE_NOT_ORACLE_DECIDABLE", case.get("case_id"))
                result = evaluate_case(case, root)
                if result.get("pass") is not True:
                    err(errors, result.get("failure_code", "ORACLE_CASE_FAILURE"), case.get("case_id"))

            # Payload semantics, never case/test identifiers, govern raw-HTML safety.
            raw_payload = any(detect_raw_html(value) for _, value in string_leaves(fx.get("input")))
            if raw_payload:
                if kind != "VALIDATE_RAW_HTML":
                    err(errors, "RAW_HTML_ROUTE_REQUIRED", case.get("case_id"))
                expected = fx.get("expected_observable") or {}
                if (
                    expected != {"transition": "REJECT", "reason_code": "RAW_HTML_REJECTED"}
                    or case.get("expected_transition") != "REJECT"
                    or case.get("expected_reason_code") != "RAW_HTML_REJECTED"
                ):
                    err(errors, "RAW_HTML_EXPECTATION_MISMATCH", case.get("case_id"))

        if counts.get("oracle_decided_cases") != len(decided_cases):
            err(errors, "ORACLE_DECIDED_COUNT_MISMATCH")
        if counts.get("oracle_deferred_cases") != len(deferred_cases):
            err(errors, "ORACLE_DEFERRED_COUNT_MISMATCH")
        if counts.get("oracle_pass_denominator") != len(decided_cases):
            err(errors, "ORACLE_PASS_DENOMINATOR_MISMATCH")
        contract_eval = evaluate_contract(contract, root)
        if contract_eval["failed"] or contract_eval["invalid_cases"] or not contract_eval["spec_oracle_valid"]:
            err(
                errors,
                "ORACLE_CONTRACT_FAILURE",
                f"failed={contract_eval['failed']},invalid={contract_eval['invalid_cases']}",
            )
            for failure in contract_eval.get("failures") or []:
                if isinstance(failure, dict) and failure.get("failure_code"):
                    err(errors, str(failure["failure_code"]))
        if deferred_cases and contract_eval["candidate_pass_eligible"]:
            err(errors, "DEFERRED_CANDIDATE_PASS_ELIGIBLE")
        if deferred_cases and contract.get("candidate_pass_eligible_at_spec_stage") is not False:
            err(errors, "DEFERRED_SPEC_PASS_CLAIM")
        # mutants executable
        for m in mutants:
            mop = m.get("mutation_operator")
            if not isinstance(mop, dict) or not mop.get("executable"):
                err(errors, "MUTANT_NOT_EXECUTABLE", m.get("mutant_id"))
            if mop.get("kind") == "NO_OP" or mop.get("id") == "NO_OP" or mop.get("transform") == "NO_OP":
                err(errors, "NOOP_MUTANT", m.get("mutant_id"))
            if mop.get("control") != "OUTSIDE_CANDIDATE":
                err(errors, "MUTANT_CANDIDATE_CONTROLLED", m.get("mutant_id"))
        # oracle outside candidate
        oracle = contract.get("oracle") or {}
        if oracle.get("control") != "OUTSIDE_CANDIDATE":
            err(errors, "ORACLE_NOT_INDEPENDENT")
        if not oracle.get("echo_runner_rejected"):
            err(errors, "ECHO_RUNNER_NOT_REJECTED")
        if oracle.get("id") != "pa.phase0a.independent_oracle.v2":
            err(errors, "ORACLE_ID_MISMATCH")
        if oracle.get("candidate_pass_requires_zero_deferred") is not True:
            err(errors, "ORACLE_DEFERRED_PASS_RULE_MISSING")
        # unique ids
        for collection, key, code in [
            (tests, "test_id", "DUP_TEST"),
            (cases, "case_id", "DUP_CASE"),
            (assertions, "assertion_id", "DUP_ASSERTION"),
            (mutants, "mutant_id", "DUP_MUTANT"),
        ]:
            seen = set()
            for item in collection:
                v = item.get(key)
                if v in seen:
                    err(errors, code, v)
                seen.add(v)

        case_ids = {item.get("case_id") for item in cases}
        assertion_ids = {item.get("assertion_id") for item in assertions}
        mutant_ids = {item.get("mutant_id") for item in mutants}
        referenced_cases: set[str] = set()
        referenced_assertions: set[str] = set()
        referenced_mutants: set[str] = set()
        case_reference_counts: dict[str, int] = {}
        assertion_reference_counts: dict[str, int] = {}
        mutant_reference_counts: dict[str, int] = {}
        case_by_id = {item.get("case_id"): item for item in cases}
        assertion_by_id = {item.get("assertion_id"): item for item in assertions}
        mutant_by_id = {item.get("mutant_id"): item for item in mutants}
        for test in tests:
            for field, available, collected in (
                ("case_ids", case_ids, referenced_cases),
                ("assertion_ids", assertion_ids, referenced_assertions),
                ("mutant_ids", mutant_ids, referenced_mutants),
            ):
                for reference in test.get(field) or []:
                    collected.add(reference)
                    counter = {
                        "case_ids": case_reference_counts,
                        "assertion_ids": assertion_reference_counts,
                        "mutant_ids": mutant_reference_counts,
                    }[field]
                    counter[reference] = counter.get(reference, 0) + 1
                    if reference not in available:
                        err(errors, "CONTRACT_DANGLING_REFERENCE", f"{field}:{reference}")
            owned_cases = [case_by_id.get(value) for value in test.get("case_ids") or []]
            owned_cases = [value for value in owned_cases if value is not None]
            if not owned_cases:
                err(errors, "TEST_HAS_NO_SEMANTIC_CASE", test.get("test_id"))
            for owned_case in owned_cases:
                if (
                    owned_case.get("runner_method") != test.get("runner_method")
                    or owned_case.get("execution_policy") != test.get("execution_policy")
                    or test.get("counted_in_spec_oracle_pass_total")
                    is not (owned_case.get("execution_policy") == "RUN")
                ):
                    err(errors, "TEST_CASE_SEMANTIC_BINDING_MISMATCH", test.get("test_id"))
            expected_assertion_ids = {
                assertion.get("assertion_id")
                for assertion in assertions
                if assertion.get("case_id") in set(test.get("case_ids") or [])
            }
            if set(test.get("assertion_ids") or []) != expected_assertion_ids:
                err(errors, "TEST_ASSERTION_SET_MISMATCH", test.get("test_id"))
            owned_mutants = [mutant_by_id.get(value) for value in test.get("mutant_ids") or []]
            owned_mutants = [value for value in owned_mutants if value is not None]
            if not owned_mutants:
                err(errors, "TEST_HAS_NO_EXECUTABLE_MUTANT", test.get("test_id"))
            for owned_mutant in owned_mutants:
                if (
                    owned_mutant.get("test_id") != test.get("test_id")
                    or owned_mutant.get("execution_policy") != test.get("execution_policy")
                    or owned_mutant.get("required_killed") is not True
                ):
                    err(errors, "TEST_MUTANT_SEMANTIC_BINDING_MISMATCH", test.get("test_id"))
        for label, available, referenced in (
            ("case", case_ids, referenced_cases),
            ("assertion", assertion_ids, referenced_assertions),
            ("mutant", mutant_ids, referenced_mutants),
        ):
            for orphan in sorted(available - referenced):
                err(errors, "CONTRACT_ORPHAN_RECORD", f"{label}:{orphan}")
        for label, available, reference_counts in (
            ("case", case_ids, case_reference_counts),
            ("assertion", assertion_ids, assertion_reference_counts),
            ("mutant", mutant_ids, mutant_reference_counts),
        ):
            for reference in sorted(available):
                if reference_counts.get(reference) != 1:
                    err(errors, "CONTRACT_RECORD_OWNERSHIP_MISMATCH", f"{label}:{reference}")

        test_ids = {item.get("test_id") for item in tests}
        gate_test_reference_counts: dict[str, int] = {}
        for gate in contract.get("gates") or []:
            for test_id in gate.get("test_ids") or []:
                gate_test_reference_counts[test_id] = gate_test_reference_counts.get(test_id, 0) + 1
                test = next((item for item in tests if item.get("test_id") == test_id), None)
                if test is None:
                    err(errors, "GATE_DANGLING_TEST_REFERENCE", str(test_id))
                elif test.get("gate_id") != gate.get("gate_id"):
                    err(errors, "GATE_TEST_SEMANTIC_BINDING_MISMATCH", str(test_id))
        for test_id in sorted(test_ids):
            if gate_test_reference_counts.get(test_id) != 1:
                err(errors, "GATE_TEST_OWNERSHIP_MISMATCH", str(test_id))

        assertions_by_case: dict[str, dict[str, list[dict]]] = {}
        for assertion in assertions:
            assertions_by_case.setdefault(assertion.get("case_id"), {}).setdefault(
                assertion.get("kind"), []
            ).append(assertion)
        for case in cases:
            case_id = case.get("case_id")
            fixture = case.get("fixture_inline") or {}
            deferred = case.get("execution_policy") == "DEFERRED_TO_CANDIDATE_EXECUTION"
            if deferred:
                target = fixture.get("candidate_expected_observable") or {}
            else:
                observed = evaluate_case(case, root)
                target = {
                    "transition": observed.get("transition"),
                    "reason_code": observed.get("reason_code"),
                }
            expected_assertions = {
                "TRANSITION_EQUALS": target.get("transition"),
                "REASON_CODE_EQUALS": target.get("reason_code"),
            }
            grouped = assertions_by_case.get(case_id, {})
            for kind, expected_value in expected_assertions.items():
                matches = grouped.get(kind) or []
                if len(matches) != 1:
                    err(errors, "CASE_ASSERTION_SEMANTIC_SET_MISMATCH", f"{case_id}:{kind}")
                    continue
                assertion = matches[0]
                if (
                    assertion.get("expected") != expected_value
                    or assertion.get("execution_policy") != case.get("execution_policy")
                    or assertion.get("counted_in_spec_oracle_pass_total") is not (not deferred)
                ):
                    err(errors, "CASE_ASSERTION_EXPECTATION_MISMATCH", f"{case_id}:{kind}")

    # requirement registry binds tests
    reg = load("PHASE0A_HANDOFF_REQUIREMENT_REGISTRY.v1.json") or {}
    if reg:
        requirement_texts = [
            normalized_text(str(item.get("text", "")))
            for item in reg.get("requirements") or []
        ]
        required_semantic_topics = {
            "dashboard": ("dashboard", "export status"),
            "note workflow": ("create", "preview", "notes"),
            "persistence": ("embedded db", "migrations"),
            "provenance": ("provenance", "hash-linked"),
            "export": ("deterministic export", "receipts"),
            "relay": ("fake/offline relay", "no network"),
            "raw html": ("raw html rejected", "persistence"),
            "localhost": ("127.0.0.1", "csrf"),
            "repository files": ("repository files",),
            "status": ("status.json",),
            "git": ("local git", "no remote"),
            "failure preservation": ("failing outputs", "before repair"),
            "final report": ("final report", "zip exclusions"),
            "security scans": ("secrets scan", "path traversal"),
        }
        for topic, needles in sorted(required_semantic_topics.items()):
            if not any(all(needle in text for needle in needles) for text in requirement_texts):
                err(errors, "REQUIREMENT_REMOVED", topic)
        all_req_tests = set()
        for r in reg.get("requirements") or []:
            if r.get("removable") is not False:
                err(errors, "REQUIREMENT_MARKED_REMOVABLE", r.get("requirement_id"))
            for tid in r.get("mandatory_test_ids") or []:
                all_req_tests.add(tid)
        test_ids = {t["test_id"] for t in (contract.get("tests") or [])}
        for tid in all_req_tests:
            if tid not in test_ids:
                err(errors, "REQUIREMENT_TEST_MISSING", tid)

    # runner
    runner = load("PHASE0A_RUNNER_INTERFACE.v2.json") or {}
    if runner:
        cmd = runner.get("command") or []
        if cmd == ["true"] or (isinstance(cmd, list) and len(cmd) == 1 and cmd[0] in ("true", ":", "echo")):
            err(errors, "RUNNER_EVIDENCE_BYPASS")
        if "PYTHONDONTWRITEBYTECODE=1" not in cmd or "-S" not in cmd:
            err(errors, "RUNNER_BYTECODE_GUARD_MISSING")
        if "independent_oracle.py" not in json.dumps(runner):
            err(errors, "RUNNER_MISSING_ORACLE")
        fe = runner.get("final_evidence") or {}
        if not fe.get("protocol"):
            err(errors, "RUNNER_EVIDENCE_PROTOCOL_MISSING")
        if runner.get("oracle", {}).get("candidate_may_not_supply_oracle") is not True:
            err(errors, "CANDIDATE_ORACLE_ALLOWED")
        if runner.get("oracle", {}).get("candidate_pass_requires_zero_deferred") is not True:
            err(errors, "RUNNER_DEFERRED_PASS_RULE_MISSING")
        eligibility = fe.get("candidate_pass_eligibility") or {}
        if eligibility.get("requires_zero_deferred") is not True:
            err(errors, "RUNNER_DEFERRED_PASS_RULE_MISSING")
        if eligibility.get("spec_fixture_candidate_pass_eligible") is not False:
            err(errors, "RUNNER_FALSE_SPEC_PASS_CLAIM")
        # all methods present
        methods = set(runner.get("required_runner_methods") or [])
        for t in contract.get("tests") or []:
            if t["runner_method"] not in methods:
                err(errors, "RUNNER_METHOD_MISSING", t["runner_method"])

    # DAG
    dag = load("PHASE0A_BUILD_DAG.v2.json") or {}
    if dag_schema and dag:
        for e in validate_against_schema(dag, dag_schema):
            err(errors, "DAG_SCHEMA_FAIL", e)
    if dag:
        nodes = dag.get("nodes") or []
        by_id = {n["node_id"]: n for n in nodes}
        by_kind = {n.get("kind"): n for n in nodes}
        required_node_kinds = {
            "verification", "runtime_preflight", "recovery_preparation",
            "architecture_freeze", "implementation", "independent_review",
            "repair_or_noop", "independent_rereview", "local_handoff",
        }
        for kind in sorted(required_node_kinds - set(by_kind)):
            err(errors, "DAG_SEMANTIC_NODE_MISSING", kind)
        for kind in sorted(required_node_kinds):
            if sum(node.get("kind") == kind for node in nodes) != 1:
                err(errors, "DAG_SEMANTIC_NODE_OWNERSHIP_MISMATCH", kind)
        # N70 checks
        if any(
            node.get("kind") == "noop"
            and any("REREVIEW" in str(value) or "REVIEWED" in str(value) for value in node.get("outputs") or [])
            for node in nodes
        ):
            err(errors, "REREVIEW_NOOP")
        n70 = by_kind.get("independent_rereview") or {}
        if n70.get("kind") == "noop":
            err(errors, "REREVIEW_NOOP")
        if not n70.get("required_checks"):
            err(errors, "REREVIEW_CHECKS_REMOVED")
        n50 = by_kind.get("independent_review") or {}
        checks50 = " ".join(n50.get("required_checks") or []).lower()
        if "acceptance" not in checks50 and "contract" not in checks50 and "oracle" not in checks50:
            err(errors, "INITIAL_REVIEW_TEST_EXECUTION_REMOVED")
        if any("do not execute" in c.lower() for c in (n50.get("required_checks") or [])):
            err(errors, "INITIAL_REVIEW_TEST_EXECUTION_REMOVED")
        n80 = by_kind.get("local_handoff") or {}
        if dag.get("final_node") != n80.get("node_id"):
            err(errors, "DAG_FINAL_NODE_NOT_LOCAL_HANDOFF")
        if n70.get("node_id") not in set(n80.get("depends_on") or []):
            err(errors, "DAG_FINAL_NODE_REREVIEW_DEPENDENCY_MISSING")
        required_final_outputs = {"O-FINAL-HANDOFF-RECEIPT", "O-LOCAL-ZIP"}
        if not required_final_outputs <= set(n80.get("outputs") or []):
            err(errors, "DAG_FINAL_OUTPUTS_MISSING")
        consumes = n80.get("consumes") or []
        reviewed_identity_artifacts = {
            "O-REVIEWED-BINDING",
            "O-REVIEWED-TREE",
            "O-REVIEWED-SOURCE-MANIFEST",
            "O-REVIEWED-EVIDENCE",
        }
        n70_outputs = set(n70.get("outputs") or [])
        n80_consumed_outputs = {
            str(value).rsplit("/", 1)[-1] for value in consumes
        }
        for artifact in sorted(reviewed_identity_artifacts - n70_outputs):
            err(errors, "N70_REVIEWED_IDENTITY_ARTIFACT_MISSING", artifact)
        expected_n80_identity_consumes = {
            f"output:{n70.get('node_id')}/{artifact}"
            for artifact in reviewed_identity_artifacts
        }
        for artifact in sorted(reviewed_identity_artifacts - n80_consumed_outputs):
            code = {
                "O-REVIEWED-BINDING": "N80_NOT_BOUND_TO_REVIEWED",
                "O-REVIEWED-TREE": "N80_TREE_NOT_CONSUMED",
                "O-REVIEWED-SOURCE-MANIFEST": "N80_SOURCE_MANIFEST_NOT_CONSUMED",
                "O-REVIEWED-EVIDENCE": "N80_EVIDENCE_NOT_CONSUMED",
            }[artifact]
            err(errors, code, artifact)
        for reference in sorted(expected_n80_identity_consumes - set(consumes)):
            err(errors, "N80_REVIEWED_IDENTITY_PRODUCER_MISMATCH", reference)
        declared_n80_identity = dag.get("n80_identity_check") or {}
        required_identity_dimensions = {
            "reviewed_binding_identity",
            "reviewed_tree_identity",
            "reviewed_source_manifest_identity",
            "reviewed_evidence_identity",
            "git_remotes_empty",
            "server_bind_loopback",
            "provider_adapters_absent",
            "forbidden_untracked_absent",
        }
        if set(declared_n80_identity.get("reviewed_artifacts") or []) != reviewed_identity_artifacts:
            err(errors, "N80_REVIEWED_ARTIFACT_DECLARATION_MISMATCH")
        if set(declared_n80_identity.get("required_dimensions") or []) != required_identity_dimensions:
            err(errors, "N80_IDENTITY_DIMENSION_SET_MISMATCH")
        if (
            declared_n80_identity.get("producer_kind") != "independent_rereview"
            or declared_n80_identity.get("consumer_kind") != "local_handoff"
            or declared_n80_identity.get("evaluator") != "lib_phase0a.n80_identity_check"
        ):
            err(errors, "N80_IDENTITY_EVALUATOR_BINDING_MISMATCH")
        identity_base = ("binding", "tree", "source", "evidence")
        def execute_n80(*, handoff=identity_base, remotes=None, bind=BIND, providers=None, untracked=None):
            return n80_identity_check(
                *identity_base,
                *handoff,
                [] if remotes is None else remotes,
                bind,
                [] if providers is None else providers,
                [] if untracked is None else untracked,
            )
        executable_n80_dimensions = {
            "reviewed_binding_identity": "N80_BINDING_MISMATCH" in execute_n80(handoff=("other", *identity_base[1:])),
            "reviewed_tree_identity": "N80_TREE_MISMATCH" in execute_n80(handoff=(identity_base[0], "other", *identity_base[2:])),
            "reviewed_source_manifest_identity": "N80_SOURCE_MANIFEST_MISMATCH" in execute_n80(handoff=(*identity_base[:2], "other", identity_base[3])),
            "reviewed_evidence_identity": "N80_EVIDENCE_MISMATCH" in execute_n80(handoff=(*identity_base[:3], "other")),
            "git_remotes_empty": "N80_REMOTES_PRESENT" in execute_n80(remotes=["origin"]),
            "server_bind_loopback": "N80_BIND_INVALID" in execute_n80(bind="0.0.0.0"),
            "provider_adapters_absent": "N80_PROVIDER_ADAPTER_PRESENT" in execute_n80(providers=["external"]),
            "forbidden_untracked_absent": "N80_UNTRACKED_FORBIDDEN" in execute_n80(untracked=["secret.env"]),
        }
        if execute_n80():
            err(errors, "N80_MATCHING_IDENTITY_REJECTED")
        for dimension, passed in sorted(executable_n80_dimensions.items()):
            if not passed:
                err(errors, "N80_EXECUTABLE_DIMENSION_FAILURE", dimension)
        authority_decl = dag.get("authority_scan") or {}
        if authority_decl.get("reject_substrings") != list(AUTHORITY_REJECT_SUBSTRINGS):
            err(errors, "AUTHORITY_SCAN_SOURCE_MISMATCH")
        if tuple(AUTHORITY_REJECT_SUBSTRINGS) != ABSOLUTE_AUTHORITY_REJECT_SUBSTRINGS:
            err(errors, "AUTHORITY_REJECT_ABSOLUTE_MISMATCH")
        if tuple(SECURITY_CONSTANTS["authority"].get("probe_payloads") or []) != ABSOLUTE_AUTHORITY_PROBE_PAYLOADS:
            err(errors, "AUTHORITY_PROBE_PAYLOADS_ABSOLUTE_MISMATCH")
        authority_contexts = {
            "REQUIRED_AUTHORITY_PROHIBITED_PAYLOADS": list(REQUIRED_AUTHORITY_PROHIBITED_PAYLOADS),
            "ABSOLUTE_AUTHORITY_REJECT_SUBSTRINGS": list(ABSOLUTE_AUTHORITY_REJECT_SUBSTRINGS),
            "ABSOLUTE_AUTHORITY_PROBE_PAYLOADS": list(ABSOLUTE_AUTHORITY_PROBE_PAYLOADS),
        }
        if sha256_bytes(canonical_json_bytes(authority_contexts)) != ABSOLUTE_AUTHORITY_CONTEXTS_SHA256:
            err(errors, "AUTHORITY_NEGATIVE_CONTEXT_ANCHOR_MISMATCH")
        normalized_vocabulary = {
            normalized_text(value) for value in AUTHORITY_VOCABULARY
        }
        for required_term in REQUIRED_AUTHORITY_VOCABULARY_TERMS:
            if normalized_text(required_term) not in normalized_vocabulary:
                err(errors, "AUTHORITY_VOCABULARY_MINIMUM_MISSING", required_term)
        normalized_rejects = {
            normalized_text(value) for value in AUTHORITY_REJECT_SUBSTRINGS
        }
        for required_payload in REQUIRED_AUTHORITY_PROHIBITED_PAYLOADS:
            normalized_payload = normalized_text(required_payload)
            if not any(reject in normalized_payload for reject in normalized_rejects):
                err(errors, "AUTHORITY_REJECT_MINIMUM_MISSING", required_payload)
        if authority_decl.get("scan_scope") != "every string key, value, literal, comment, path, or text body of every shipped package member; recursively scan closed binary containers":
            err(errors, "AUTHORITY_SCAN_SCOPE_INCOMPLETE")
        # N80 condition not ALWAYS alone without eligibility
        condition_by_id = {
            item.get("condition_id"): item
            for item in (load("PHASE0A_CONDITION_REGISTRY.v2.json") or {}).get("conditions", [])
        }
        n80_conditions = [condition_by_id.get(value, {}) for value in n80.get("condition_ids") or []]
        if not n80_conditions or all(item.get("type") == "constant" for item in n80_conditions):
            err(errors, "N80_CONDITION_ALWAYS")
        if not any(
            item.get("type") == "transition_evaluator"
            and item.get("allows") == [list(trace) for trace in ALLOWED_TRACES]
            for item in n80_conditions
        ):
            err(errors, "N80_ELIGIBILITY_MISSING")
        # topo + refs
        seen = set()
        for n in nodes:
            for d in n.get("depends_on") or []:
                if d not in by_id:
                    err(errors, "DAG_DANGLING_DEP", d)
            for consumed in n.get("consumes") or []:
                if not isinstance(consumed, str) or not consumed.startswith("output:"):
                    continue
                try:
                    producer_id, artifact = consumed[len("output:"):].split("/", 1)
                except ValueError:
                    err(errors, "DAG_OUTPUT_REFERENCE_MALFORMED", str(consumed))
                    continue
                producer = by_id.get(producer_id)
                if producer is None or artifact not in set(producer.get("outputs") or []):
                    err(errors, "DAG_OUTPUT_REFERENCE_UNRESOLVED", consumed)
            nid = n["node_id"]
            if nid in seen:
                err(errors, "DAG_DUP_NODE", nid)
            seen.add(nid)
        # conditions used
        cond_reg = load("PHASE0A_CONDITION_REGISTRY.v2.json") or {}
        cond_ids = {c["condition_id"] for c in cond_reg.get("conditions") or []}
        used = set()
        for n in nodes:
            for cid in n.get("condition_ids") or []:
                used.add(cid)
                if cid not in cond_ids:
                    err(errors, "DAG_UNKNOWN_CONDITION", cid)
        # final condition must not be constant true
        for c in cond_reg.get("conditions") or []:
            if c["condition_id"] == "N80_ELIGIBLE" and c.get("type") == "constant":
                err(errors, "FINAL_CONDITION_CONSTANT")
            if c["condition_id"] in ("REREVIEW_PASS_OR_INITIAL_PASS_CONFIRMED",) and c.get("type") == "constant":
                err(errors, "FINAL_CONDITION_CONSTANT_TRUE")
        if cond_reg.get("rules", {}).get("HOLD_is_terminal") is not True:
            err(errors, "HOLD_NOT_TERMINAL")

        receipt_schemas = load("PHASE0A_RECEIPT_SCHEMAS.v1.json") or {}
        receipt_definitions = receipt_schemas.get("receipts") or {}
        reviewed_receipt_identity_fields = {
            "candidate_binding_sha256",
            "tree_sha",
            "source_manifest_sha256",
            "evidence_envelope_sha256",
        }
        for receipt_name in ("independent_review", "independent_rereview", "final_handoff"):
            required_fields = set(
                (receipt_definitions.get(receipt_name) or {}).get("required") or []
            )
            for field in sorted(reviewed_receipt_identity_fields - required_fields):
                err(errors, "REVIEWED_RECEIPT_IDENTITY_FIELD_MISSING", f"{receipt_name}:{field}")

    # transition table
    tt = load("PHASE0A_TRANSITION_TABLE.v1.json") or {}
    if tt:
        if N50_OUTCOMES != REQUIRED_N50_OUTCOMES:
            err(errors, "TRANSITION_N50_INDEPENDENT_ANCHOR_MISMATCH")
        if N60_OUTCOMES != REQUIRED_N60_OUTCOMES:
            err(errors, "TRANSITION_N60_INDEPENDENT_ANCHOR_MISMATCH")
        if N70_OUTCOMES != REQUIRED_N70_OUTCOMES:
            err(errors, "TRANSITION_N70_INDEPENDENT_ANCHOR_MISMATCH")
        if set(ALLOWED_TRACES) != REQUIRED_ALLOWED_TRACES:
            err(errors, "TRANSITION_ALLOWED_INDEPENDENT_ANCHOR_MISMATCH")
        if tuple(tt.get("n50_outcomes") or []) != N50_OUTCOMES:
            err(errors, "TRANSITION_N50_VOCABULARY_MISMATCH")
        if tuple(tt.get("n60_outcomes") or []) != N60_OUTCOMES:
            err(errors, "TRANSITION_N60_VOCABULARY_MISMATCH")
        if tuple(tt.get("n70_outcomes") or []) != N70_OUTCOMES:
            err(errors, "TRANSITION_N70_VOCABULARY_MISMATCH")

        derived_allowed = set()
        derived_forbidden = set()
        for n50, n60, n70 in product(N50_OUTCOMES, N60_OUTCOMES, N70_OUTCOMES):
            observed = evaluate_review_trace(n50, n60, n70)
            row = (n50, n60, n70)
            if observed["allowed"]:
                if not observed["n80_eligible"] or observed["reason_code"] != "OK":
                    err(errors, "TRANSITION_EVALUATOR_INCONSISTENT", str(row))
                derived_allowed.add((*row, "ELIGIBLE"))
            else:
                expected_reason = "HOLD_TERMINAL" if n50 == "HOLD" else "INVALID_REVIEW_TRACE"
                if observed["n80_eligible"] or observed["reason_code"] != expected_reason:
                    err(errors, "TRANSITION_EVALUATOR_INCONSISTENT", str(row))
                derived_forbidden.add((*row, "INELIGIBLE", expected_reason))
        declared_allowed = {
            (item.get("n50"), item.get("n60"), item.get("n70"), item.get("n80"))
            for item in (tt.get("allowed_traces") or []) if isinstance(item, dict)
        }
        declared_forbidden = {
            (
                item.get("n50"), item.get("n60"), item.get("n70"),
                item.get("n80"), item.get("reason_code")
            )
            for item in (tt.get("forbidden_examples") or []) if isinstance(item, dict)
        }
        if (
            len(derived_allowed) != 2
            or len(derived_forbidden) != 34
            or sum(1 for row in product(N50_OUTCOMES, N60_OUTCOMES, N70_OUTCOMES) if row[0] == "HOLD") != 12
        ):
            err(errors, "TRANSITION_EXHAUSTIVE_CARDINALITY_MISMATCH")
        if declared_allowed != derived_allowed:
            err(errors, "TRANSITION_ALLOWED_SET_MISMATCH")
        if declared_forbidden != derived_forbidden:
            err(errors, "FORBIDDEN_EXAMPLES_DERIVATION_MISMATCH")

    # apply schemas to goldens
    note_gold = load("PHASE0A_NOTE_EVENT_GOLDEN_VECTORS.v2.json") or {}
    if note_gold and note_schema:
        n = note_gold.get("note")
        for e in validate_against_schema(n, note_schema):
            err(errors, "NOTE_GOLDEN_SCHEMA", e)
        for e in validate_note_state(n, "create"):
            err(errors, "NOTE_GOLDEN_SEMANTIC", e)
        events = note_gold.get("events") or {}
        if set(events.keys()) != set(ACTIONS):
            err(errors, "NOTE_GOLDEN_ACTIONS_INCOMPLETE", str(sorted(events.keys())))
        prev = ZERO64
        # chain create -> edit is separate branch; create -> preview for export
        for action in ["NOTE_CREATED", "PREVIEW_GENERATED", "EXPORT_GENERATED", "EXPORT_VERIFICATION_PASSED"]:
            ev = events.get(action)
            if not ev:
                err(errors, "NOTE_GOLDEN_EVENT_MISSING", action)
                continue
            if event_schema:
                for e in validate_against_schema(ev, event_schema):
                    err(errors, "EVENT_GOLDEN_SCHEMA", f"{action}:{e}")
            # chain validation with appropriate prior
            if action == "NOTE_CREATED":
                prior = ZERO64
            elif action == "PREVIEW_GENERATED":
                prior = events["NOTE_CREATED"]["event_hash"]
            elif action == "EXPORT_GENERATED":
                prior = events["PREVIEW_GENERATED"]["event_hash"]
            else:
                prior = events["EXPORT_GENERATED"]["event_hash"]
            for e in validate_event(ev, prior):
                err(errors, "EVENT_GOLDEN_SEMANTIC", f"{action}:{e}")
        # edit + fail standalone
        for action in ["NOTE_EDITED", "EXPORT_VERIFICATION_FAILED"]:
            ev = events.get(action)
            if event_schema and ev:
                for e in validate_against_schema(ev, event_schema):
                    err(errors, "EVENT_GOLDEN_SCHEMA", f"{action}:{e}")

    # export golden verify
    export_golden = load("PHASE0A_EXPORT_GOLDEN_VECTOR.v2.json") or {}
    if export_golden:
        members = {}
        for name in EXPORT_MEMBERS:
            p = root / "fixtures" / name
            if not p.is_file():
                err(errors, "EXPORT_FIXTURE_MISSING", name)
            else:
                members[name] = p.read_bytes()
                if sha256_bytes(members[name]) != export_golden.get("member_sha256", {}).get(name):
                    err(errors, "EXPORT_MEMBER_HASH", name)
        if members:
            for e in verify_export_bundle(members):
                err(errors, "EXPORT_VERIFY", e)
            zpath = root / "fixtures/selected-note-golden.zip"
            if zpath.is_file():
                if sha256_file(zpath) != export_golden.get("zip_sha256"):
                    err(errors, "EXPORT_ZIP_HASH")
            # identity formulas produce receipt values
            rec = export_golden.get("receipt") or {}
            if rec:
                if export_receipt_schema := schemas.get("PHASE0A_EXPORT_RECEIPT.schema.json"):
                    for e in validate_against_schema(rec, export_receipt_schema):
                        err(errors, "RECEIPT_SCHEMA", e)

    # relay goldens
    relay_g = load("PHASE0A_RELAY_GOLDEN_VECTORS.v1.json") or {}
    if relay_g:
        for key in ("success", "error", "timeout"):
            item = relay_g.get(key) or {}
            req = item.get("request")
            if req and schemas.get("PHASE0A_RELAY_REQUEST.schema.json"):
                for e in validate_against_schema(req, schemas["PHASE0A_RELAY_REQUEST.schema.json"]):
                    err(errors, "RELAY_REQ_SCHEMA", f"{key}:{e}")
            if req:
                got = fake_relay_complete(req)
                exp = item.get("result")
                if got != exp:
                    # compare reason codes at least
                    if got.get("reason_code") != exp.get("reason_code"):
                        err(errors, "RELAY_GOLDEN_MISMATCH", key)

    # evidence vectors and exact byte resolution
    evidence_fixture_manifest_paths: set[str] = set()
    evidence_json_paths: set[str] = set()
    protocol = load("PHASE0A_EVIDENCE_PROTOCOL.v1.json") or {}
    vectors = load("PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json") or {}
    if vectors:
        if vectors.get("application_candidate_exists") is not False:
            err(errors, "EVIDENCE_VECTOR_FALSE_CANDIDATE_CLAIM")
        if "SYNTHETIC" not in (vectors.get("label") or vectors.get("status") or ""):
            if vectors.get("status") != "SCHEMA_AND_CONSISTENCY_FIXTURE_ONLY_NOT_APPLICATION_EVIDENCE":
                err(errors, "EVIDENCE_VECTOR_STATUS_INVALID")
        positive = vectors.get("positive_fixture") or {}
        binding = positive.get("candidate_binding") or {}
        evidence = positive.get("candidate_evidence") or {}
        if binding_schema:
            for e in validate_against_schema(binding, binding_schema):
                err(errors, "BINDING_INSTANCE", e)
        # unsafe binding checks on schema constants
        if binding.get("workspace_path") not in (WORKSPACE,):
            err(errors, "BINDING_WORKSPACE")
        if binding.get("branch") == "main":
            err(errors, "BINDING_MAIN_BRANCH")
        if binding.get("server_bind") in ("0.0.0.0", "::"):
            err(errors, "BINDING_UNSAFE_BIND")
        if binding.get("git_remotes"):
            err(errors, "BINDING_REMOTES")
        if evidence_schema:
            for e in validate_against_schema(evidence, evidence_schema):
                err(errors, "EVIDENCE_INSTANCE", e)
        # contract + normative hashes
        contract_hash = sha256_file(root / "PHASE0A_ACCEPTANCE_CONTRACT.v4.json")
        if binding.get("contract_sha256") != contract_hash:
            err(errors, "EVIDENCE_CONTRACT_HASH_MISMATCH")
        if evidence.get("contract_sha256") != contract_hash:
            err(errors, "EVIDENCE_CONTRACT_HASH_MISMATCH")
        nm_path = root / "PHASE0A_NORMATIVE_MANIFEST.v1.json"
        if nm_path.is_file():
            nm_hash = sha256_file(nm_path)
            if binding.get("normative_manifest_sha256") != nm_hash:
                err(errors, "EVIDENCE_NORMATIVE_HASH_MISMATCH")
            if evidence.get("normative_manifest_sha256") != nm_hash:
                err(errors, "EVIDENCE_NORMATIVE_HASH_MISMATCH")
        expected_binding_hash = sha256_bytes(canonical_json_bytes(binding))
        if evidence.get("candidate_binding_sha256") != expected_binding_hash:
            err(errors, "EVIDENCE_BINDING_HASH_MISMATCH")
        # times
        if evidence.get("finished_at", "") < evidence.get("started_at", ""):
            err(errors, "EVIDENCE_TIME_REVERSED")
        declared_root = protocol.get("synthetic_fixture_root")
        if declared_root != vectors.get("synthetic_fixture_root"):
            err(errors, "EVIDENCE_ROOT_DECLARATION_MISMATCH")
        root_pure = PurePosixPath(str(declared_root or ""))
        if (
            not declared_root
            or root_pure.is_absolute()
            or ".." in root_pure.parts
            or "\\" in str(declared_root)
            or str(root_pure) != str(declared_root)
        ):
            err(errors, "EVIDENCE_ROOT_UNSAFE")
            evidence_root = root / "__invalid_evidence_root__"
        else:
            evidence_root = root.joinpath(*root_pure.parts)
        evidence_root_resolved = evidence_root.resolve(strict=False)
        root_resolved = root.resolve(strict=False)
        if (
            evidence_root_resolved != root_resolved
            and root_resolved not in evidence_root_resolved.parents
        ):
            err(errors, "EVIDENCE_ROOT_UNSAFE")
        if evidence_root.is_symlink() or any(
            parent.is_symlink() for parent in evidence_root.parents if parent != root
        ):
            err(errors, "EVIDENCE_ROOT_SYMLINK")
        resolved_results = []
        all_result_groups = [
            ("case", evidence.get("case_results") or []),
            ("assertion", evidence.get("assertion_results") or []),
            ("mutant", evidence.get("mutant_results") or []),
        ]
        case_result_map = {
            item.get("case_id"): item for item in evidence.get("case_results") or []
            if isinstance(item, dict)
        }
        if set(case_result_map) != {item.get("case_id") for item in cases}:
            err(errors, "EVIDENCE_CASE_RESULT_SET_MISMATCH")
        deferred_case_ids = {item.get("case_id") for item in deferred_cases}
        for case in cases:
            declared = case_result_map.get(case.get("case_id"))
            if not declared:
                continue
            if case.get("case_id") in deferred_case_ids:
                expected_semantics = (
                    "DEFERRED", "DEFERRED", DEFERRED_REASON_CODE, False
                )
            else:
                observed_case = evaluate_case(case, root)
                expected_semantics = (
                    "PASS", observed_case.get("transition"), observed_case.get("reason_code"), True
                )
            declared_semantics = (
                declared.get("status"), declared.get("transition"), declared.get("reason_code"),
                (declared.get("observed") or {}).get("counted_in_pass_total")
            )
            if declared_semantics != expected_semantics:
                err(errors, "EVIDENCE_CASE_RESULT_SEMANTIC_MISMATCH", case.get("case_id"))

        assertion_case = {item.get("assertion_id"): item.get("case_id") for item in assertions}
        assertion_result_map = {
            item.get("assertion_id"): item for item in evidence.get("assertion_results") or []
            if isinstance(item, dict)
        }
        if set(assertion_result_map) != set(assertion_case):
            err(errors, "EVIDENCE_ASSERTION_RESULT_SET_MISMATCH")
        for assertion_id, case_id in assertion_case.items():
            result = assertion_result_map.get(assertion_id) or {}
            expected_status = "DEFERRED" if case_id in deferred_case_ids else "PASS"
            if result.get("status") != expected_status:
                err(errors, "EVIDENCE_ASSERTION_RESULT_SEMANTIC_MISMATCH", str(assertion_id))

        test_case_ids = {item.get("test_id"): set(item.get("case_ids") or []) for item in tests}
        mutant_result_map = {
            item.get("mutant_id"): item for item in evidence.get("mutant_results") or []
            if isinstance(item, dict)
        }
        if set(mutant_result_map) != {item.get("mutant_id") for item in mutants}:
            err(errors, "EVIDENCE_MUTANT_RESULT_SET_MISMATCH")
        for mutant in mutants:
            result = mutant_result_map.get(mutant.get("mutant_id")) or {}
            should_defer = bool(test_case_ids.get(mutant.get("test_id"), set()) & deferred_case_ids)
            if result.get("killed") is not (not should_defer):
                err(errors, "EVIDENCE_MUTANT_RESULT_SEMANTIC_MISMATCH", str(mutant.get("mutant_id")))

        seen_evidence_paths: set[str] = set()
        for result_kind, results in all_result_groups:
            for result in results:
                if result_kind == "case" and gate_schema:
                    for e in validate_against_schema(result, gate_schema):
                        err(errors, "GATE_CASE_INSTANCE", e)
                evidence_path = result.get("evidence_path")
                evidence_hash = result.get("evidence_sha256") or ""
                if evidence_hash == ZERO64 or not HEX64.fullmatch(str(evidence_hash)):
                    err(errors, "FICTITIOUS_EVIDENCE_HASH", str(evidence_path or ""))
                if not isinstance(evidence_path, str) or not evidence_path:
                    err(errors, "EVIDENCE_PATH_MISSING", result_kind)
                    continue
                pure = PurePosixPath(evidence_path)
                unsafe = (
                    pure.is_absolute()
                    or ".." in pure.parts
                    or "\\" in evidence_path
                    or str(pure) != evidence_path
                    or evidence_path.startswith("./")
                )
                if unsafe:
                    err(errors, "EVIDENCE_PATH_UNSAFE", evidence_path)
                    continue
                if evidence_path in seen_evidence_paths:
                    err(errors, "EVIDENCE_PATH_DUPLICATE", evidence_path)
                    continue
                seen_evidence_paths.add(evidence_path)
                target = evidence_root.joinpath(*pure.parts)
                resolved = target.resolve(strict=False)
                if resolved != evidence_root_resolved and evidence_root_resolved not in resolved.parents:
                    err(errors, "EVIDENCE_PATH_UNSAFE", evidence_path)
                    continue
                if target.is_symlink() or any(parent.is_symlink() for parent in target.parents if parent != root):
                    err(errors, "EVIDENCE_PATH_SYMLINK", evidence_path)
                    continue
                if not target.is_file():
                    err(errors, "EVIDENCE_BYTES_MISSING", evidence_path)
                    continue
                if sha256_file(target) != evidence_hash:
                    err(errors, "EVIDENCE_BYTES_HASH_MISMATCH", evidence_path)
                if target.suffix == ".json":
                    try:
                        fixture_payload = load_json(target)
                        declared_body = {
                            key: value for key, value in result.items()
                            if key not in {"evidence_path", "evidence_sha256"}
                        }
                        if fixture_payload.get("result") != declared_body:
                            err(errors, "EVIDENCE_FIXTURE_DECLARATION_MISMATCH", evidence_path)
                    except Exception as exc:
                        err(errors, "EVIDENCE_FIXTURE_JSON_INVALID", f"{evidence_path}:{exc}")
                round_relative = target.relative_to(root).as_posix()
                evidence_fixture_manifest_paths.add(round_relative)
                if target.suffix == ".json":
                    evidence_json_paths.add(round_relative)
                resolved_results.append((evidence_hash, evidence_path))

        expected_payload_text = "".join(
            f"{evidence_hash}  {evidence_path}\n"
            for evidence_hash, evidence_path in sorted(resolved_results, key=lambda item: item[1])
        )
        payload_rel = protocol.get("payload_manifest", {}).get("path")
        payload_pure = PurePosixPath(str(payload_rel or ""))
        payload_safe = (
            isinstance(payload_rel, str)
            and bool(payload_rel)
            and not payload_pure.is_absolute()
            and ".." not in payload_pure.parts
            and "\\" not in payload_rel
            and str(payload_pure) == payload_rel
            and not payload_rel.startswith("./")
        )
        if not payload_safe:
            err(errors, "PAYLOAD_MANIFEST_PATH_UNSAFE", str(payload_rel or ""))
            payload_path = root / "__invalid_payload_manifest__"
        else:
            payload_path = root.joinpath(*payload_pure.parts)
        payload_resolved = payload_path.resolve(strict=False)
        if (
            payload_resolved != root_resolved
            and root_resolved not in payload_resolved.parents
        ):
            err(errors, "PAYLOAD_MANIFEST_PATH_UNSAFE", str(payload_rel or ""))
            payload_safe = False
        if payload_path.is_symlink():
            err(errors, "PAYLOAD_MANIFEST_PATH_SYMLINK", str(payload_rel or ""))
            payload_safe = False
        if not payload_safe or not payload_path.is_file():
            err(errors, "PAYLOAD_MANIFEST_BYTES_MISSING")
        else:
            payload_bytes = payload_path.read_bytes()
            if payload_bytes != expected_payload_text.encode("utf-8"):
                err(errors, "PAYLOAD_MANIFEST_CONTENT_MISMATCH")
            payload_hash = sha256_bytes(payload_bytes)
            if evidence.get("payload_manifest_sha256") != payload_hash:
                err(errors, "PAYLOAD_MANIFEST_HASH_MISMATCH")
            if positive.get("payload_manifest_sha256") != payload_hash:
                err(errors, "PAYLOAD_MANIFEST_OUTER_HASH_MISMATCH")
            evidence_fixture_manifest_paths.add(payload_path.relative_to(root).as_posix())
        if evidence_root.is_dir():
            actual_fixture_files = {
                path.relative_to(root).as_posix()
                for path in evidence_root.rglob("*")
                if path.is_file() and not ignored_bytecode_path(path)
            }
            if actual_fixture_files != evidence_fixture_manifest_paths:
                err(errors, "EVIDENCE_FIXTURE_SET_MISMATCH")
        # summary
        summary = evidence.get("summary") or {}
        case_statuses = [item.get("status") for item in evidence.get("case_results") or []]
        assertion_statuses = [item.get("status") for item in evidence.get("assertion_results") or []]
        mutant_killed_values = [item.get("killed") for item in evidence.get("mutant_results") or []]
        derived_summary = {
            "expected_cases": len(case_statuses),
            "executed_cases": sum(value != "DEFERRED" for value in case_statuses),
            "passed_cases": sum(value == "PASS" for value in case_statuses),
            "failed_cases": sum(value == "FAIL" for value in case_statuses),
            "deferred_cases": sum(value == "DEFERRED" for value in case_statuses),
            "expected_assertions": len(assertion_statuses),
            "passed_assertions": sum(value == "PASS" for value in assertion_statuses),
            "failed_assertions": sum(value == "FAIL" for value in assertion_statuses),
            "deferred_assertions": sum(value == "DEFERRED" for value in assertion_statuses),
            "required_mutants": len(mutant_killed_values),
            "killed_mutants": sum(value is True for value in mutant_killed_values),
            "deferred_mutants": sum(value is False for value in mutant_killed_values),
            "surviving_mutants": 0,
        }
        for field, derived_value in derived_summary.items():
            if summary.get(field) != derived_value:
                err(errors, "EVIDENCE_SUMMARY_DERIVATION_MISMATCH", field)
        if summary.get("surviving_mutants", 1) != 0:
            err(errors, "EVIDENCE_SURVIVING_MUTANT")
        if summary.get("deferred_cases", 0) > 0:
            if evidence.get("status") == "CANDIDATE_TESTS_PASS":
                err(errors, "DEFERRED_EVIDENCE_FALSE_PASS_CLAIM")
            if summary.get("candidate_pass_eligible") is not False:
                err(errors, "DEFERRED_EVIDENCE_PASS_ELIGIBLE")
        if summary.get("executed_cases") != len(decided_cases):
            err(errors, "EVIDENCE_EXECUTED_CASE_COUNT_MISMATCH")
        if summary.get("passed_cases") != len(decided_cases) or summary.get("failed_cases") != 0:
            err(errors, "EVIDENCE_CASE_SUMMARY_MISMATCH")
        if summary.get("deferred_cases") != len(deferred_cases):
            err(errors, "EVIDENCE_DEFERRED_CASE_COUNT_MISMATCH")
        if summary.get("passed_assertions") != len(decided_cases) * 2:
            err(errors, "EVIDENCE_ASSERTION_SUMMARY_MISMATCH")
        if summary.get("deferred_assertions") != len(deferred_cases) * 2:
            err(errors, "EVIDENCE_ASSERTION_SUMMARY_MISMATCH")
        if summary.get("killed_mutants") != len(decided_cases):
            err(errors, "EVIDENCE_MUTANT_SUMMARY_MISMATCH")
        if summary.get("deferred_mutants") != len(deferred_cases):
            err(errors, "EVIDENCE_MUTANT_SUMMARY_MISMATCH")
        # payload manifest must not equal envelope self-ref cycle field inside results
        if evidence.get("payload_manifest_sha256") in (None, ZERO64, "0"*64):
            err(errors, "PAYLOAD_MANIFEST_MISSING_OR_ZERO")
        # oracle id
        if evidence.get("oracle_id") != "pa.phase0a.independent_oracle.v2":
            err(errors, "EVIDENCE_ORACLE_ID")
        # no evidence_manifest_sha256 cyclic field
        if "evidence_manifest_sha256" in evidence:
            err(errors, "EVIDENCE_MANIFEST_CYCLE_FIELD")

    # host matrix complete
    host_m = load("PHASE0A_HOST_PREFLIGHT_MATRIX.v1.json") or {}
    if host_m:
        states = host_m.get("states") or {}
        for s in HOST_STATES:
            if s not in states:
                err(errors, "HOST_STATE_MISSING", s)
            else:
                if states[s] != host_preflight_decision(s):
                    err(errors, "HOST_STATE_MISMATCH", s)

    # normative manifest integrity
    nm = load("PHASE0A_NORMATIVE_MANIFEST.v1.json")
    authority_strings_scanned = 0
    if not nm:
        err(errors, "NORMATIVE_MANIFEST_MISSING")
    else:
        members = nm.get("members") or []
        paths = []
        member_roles = {}
        for m in members:
            p = m.get("path")
            paths.append(p)
            member_roles[p] = m.get("role")
            if not isinstance(p, str):
                err(errors, "NORMATIVE_MEMBER_PATH_INVALID")
                continue
            if p == "PHASE0A_NORMATIVE_MANIFEST.v1.json":
                err(errors, "NORMATIVE_MANIFEST_SELF_LISTED")
            pure = PurePosixPath(p)
            if pure.is_absolute() or ".." in pure.parts or "\\" in p or str(pure) != p:
                err(errors, "NORMATIVE_MEMBER_PATH_UNSAFE", p)
                continue
            suffix = Path(p).suffix
            if (
                suffix not in NORMATIVE_TEXTUAL_SUFFIXES
                and p not in ALLOWED_NORMATIVE_BINARY_MEMBERS
            ):
                err(errors, "NORMATIVE_MEMBER_UNSUPPORTED_FORMAT", p)
            fp = root / p
            if ignored_bytecode_path(fp):
                err(errors, "FORBIDDEN_BYTECODE_MANIFEST_ENTRY", p)
            if fp.is_symlink():
                err(errors, "NORMATIVE_MEMBER_SYMLINK", p)
            if not fp.is_file():
                err(errors, "NORMATIVE_MEMBER_MISSING", p)
            else:
                if m.get("sha256") != sha256_file(fp):
                    err(errors, "NORMATIVE_MEMBER_HASH", p)
        if len(paths) != len(set(paths)):
            err(errors, "NORMATIVE_MEMBER_DUPLICATE")
        manifest_path_set = set(paths)
        for required_path, required_role in sorted(REQUIRED_NORMATIVE_MEMBER_ROLES.items()):
            if required_path not in manifest_path_set:
                err(errors, "NORMATIVE_REQUIRED_MEMBER_MISSING", required_path)
            elif member_roles.get(required_path) != required_role:
                err(errors, "NORMATIVE_REQUIRED_MEMBER_ROLE_MISMATCH", required_path)
        if "PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json" in manifest_path_set:
            err(errors, "NORMATIVE_EVIDENCE_ENVELOPE_CYCLE")
        missing_evidence_members = evidence_fixture_manifest_paths - manifest_path_set
        if missing_evidence_members:
            for missing in sorted(missing_evidence_members):
                err(errors, "EVIDENCE_NOT_NORMATIVE_MEMBER", missing)
        for evidence_member in sorted(evidence_fixture_manifest_paths & manifest_path_set):
            if member_roles.get(evidence_member) != "evidence_fixture":
                err(errors, "EVIDENCE_NORMATIVE_ROLE_MISMATCH", evidence_member)
        # must cover critical roles
        roles = {m.get("role") for m in members}
        for role in [
            "precedence", "canonical_rules", "security_constants", "acceptance_contract",
            "schema", "dag", "oracle", "evidence_protocol", "evidence_fixture", "export_spec"
        ]:
            if role not in roles:
                err(errors, "NORMATIVE_ROLE_MISSING", role)

    # R21-F01: package membership, not a declaration layer, defines scan coverage.
    # The scan therefore includes every shipped file plus SHA256SUMS.txt itself.
    package_files = sorted(
        (
            path for path in root.rglob("*")
            if path.is_file() and not ignored_bytecode_path(path)
        ),
        key=lambda item: item.relative_to(root).as_posix(),
    )
    package_paths = {path.relative_to(root).as_posix() for path in package_files}
    if len(package_paths) != len(package_files):
        err(errors, "PACKAGE_MEMBER_DUPLICATE")

    round_checksum_path = root / "SHA256SUMS.txt"
    checksum_declared_paths: set[str] = set()
    if round_checksum_path.is_file():
        for line in round_checksum_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                _digest, relative = line.split("  ", 1)
            except ValueError:
                err(errors, "CHECKSUM_LINE_MALFORMED", line)
                continue
            checksum_declared_paths.add(relative)
    else:
        err(errors, "CHECKSUM_MANIFEST_MISSING")
    expected_checksum_paths = package_paths - {"SHA256SUMS.txt"}
    for missing in sorted(expected_checksum_paths - checksum_declared_paths):
        err(errors, "PACKAGE_MEMBER_UNCLASSIFIED", missing)
    for extra in sorted(checksum_declared_paths - expected_checksum_paths):
        err(errors, "PACKAGE_CHECKSUM_MEMBER_UNEXPECTED", extra)
    package_python_paths = {
        relative for relative in package_paths if PurePosixPath(relative).suffix.casefold() == ".py"
    }
    for extra in sorted(package_python_paths - ALLOWED_PACKAGE_PYTHON_MEMBERS):
        err(errors, "PACKAGE_PYTHON_MEMBER_UNCLASSIFIED", extra)
    for missing in sorted(ALLOWED_PACKAGE_PYTHON_MEMBERS - package_python_paths):
        err(errors, "PACKAGE_PYTHON_MEMBER_MISSING", missing)
    expected_locked_python = ALLOWED_PACKAGE_PYTHON_MEMBERS - {"meta_validate_round22.py"}
    if set(ABSOLUTE_PACKAGE_PYTHON_SHA256) != expected_locked_python:
        err(errors, "PACKAGE_PYTHON_LOCK_SET_MISMATCH")
    for relative in sorted(expected_locked_python & package_python_paths):
        if sha256_file(root / relative) != ABSOLUTE_PACKAGE_PYTHON_SHA256.get(relative):
            err(errors, "PACKAGE_PYTHON_MEMBER_HASH_MISMATCH", relative)

    absolute_negative_contexts: dict[tuple[str, str], str] = {}
    for index, value in enumerate(ABSOLUTE_AUTHORITY_REJECT_SUBSTRINGS):
        absolute_negative_contexts[(
            "PHASE0A_SECURITY_CONSTANTS.v1.json",
            f"$/authority/reject_substrings/{index}",
        )] = normalized_text(value)
        absolute_negative_contexts[(
            "PHASE0A_BUILD_DAG.v2.json",
            f"$/authority_scan/reject_substrings/{index}",
        )] = normalized_text(value)
    for index, value in enumerate(ABSOLUTE_AUTHORITY_PROBE_PAYLOADS):
        absolute_negative_contexts[(
            "PHASE0A_SECURITY_CONSTANTS.v1.json",
            f"$/authority/probe_payloads/{index}",
        )] = normalized_text(value)
    for index, value in {
        1: ABSOLUTE_AUTHORITY_REJECT_SUBSTRINGS[12],
        3: ABSOLUTE_AUTHORITY_REJECT_SUBSTRINGS[13],
        12: ABSOLUTE_AUTHORITY_REJECT_SUBSTRINGS[9],
        15: ABSOLUTE_AUTHORITY_REJECT_SUBSTRINGS[18],
        16: ABSOLUTE_AUTHORITY_REJECT_SUBSTRINGS[19],
        18: ABSOLUTE_AUTHORITY_REJECT_SUBSTRINGS[21],
    }.items():
        absolute_negative_contexts[(
            "PHASE0A_SECURITY_CONSTANTS.v1.json",
            f"$/authority/canonical_negative_policy_tokens/{index}",
        )] = normalized_text(value)
    absolute_negative_contexts[(
        "PHASE0A_SECURITY_CONSTANTS.v1.json", "$/authority/vocabulary/11"
    )] = normalized_text(ABSOLUTE_AUTHORITY_REJECT_SUBSTRINGS[19])
    for pointer, value in {
        "$/nodes/0/forbidden_checks/0": ABSOLUTE_AUTHORITY_REJECT_SUBSTRINGS[13],
        "$/nodes/1/forbidden_checks/0": ABSOLUTE_AUTHORITY_REJECT_SUBSTRINGS[21],
        "$/nodes/4/forbidden_checks/0": ABSOLUTE_AUTHORITY_REJECT_SUBSTRINGS[9],
        "$/nodes/4/forbidden_checks/3": ABSOLUTE_AUTHORITY_REJECT_SUBSTRINGS[18],
    }.items():
        absolute_negative_contexts[("PHASE0A_BUILD_DAG.v2.json", pointer)] = normalized_text(value)
    absolute_validator_negative_values = {
        normalized_text(value)
        for sequence in (
            REQUIRED_AUTHORITY_PROHIBITED_PAYLOADS,
            ABSOLUTE_AUTHORITY_REJECT_SUBSTRINGS,
            ABSOLUTE_AUTHORITY_PROBE_PAYLOADS,
        )
        for value in sequence
    }

    def authority_leaves_for_text(
        relative: str, text_value: str, suffix: str
    ) -> list[tuple[str, str, bool]]:
        leaves: list[tuple[str, str, bool]] = []
        if suffix == ".json":
            document = load_json_text(text_value)
            leaves.extend((*leaf, False) for leaf in string_fields(document))
        elif suffix == ".jsonl":
            for line_number, line in enumerate(text_value.splitlines(), 1):
                if line.strip():
                    leaves.extend(
                        (*leaf, False)
                        for leaf in string_fields(
                            load_json_text(line), f"$line/{line_number}"
                        )
                    )
        elif suffix == ".py":
            tree = ast.parse(text_value, filename=relative)
            declared_negative_node_ids: set[int] = set()
            if relative == "meta_validate_round22.py":
                for statement in tree.body:
                    targets = []
                    value_node = None
                    if isinstance(statement, ast.Assign):
                        targets = statement.targets
                        value_node = statement.value
                    elif isinstance(statement, ast.AnnAssign):
                        targets = [statement.target]
                        value_node = statement.value
                    if (
                        value_node is not None
                        and any(
                            isinstance(target, ast.Name)
                            and target.id in {
                                "REQUIRED_AUTHORITY_PROHIBITED_PAYLOADS",
                                "ABSOLUTE_AUTHORITY_REJECT_SUBSTRINGS",
                                "ABSOLUTE_AUTHORITY_PROBE_PAYLOADS",
                            }
                            for target in targets
                        )
                    ):
                        declared_negative_node_ids.update(
                            id(node) for node in ast.walk(value_node)
                            if isinstance(node, ast.Constant) and isinstance(node.value, str)
                        )
            for node in ast.walk(tree):
                if not isinstance(node, ast.Constant):
                    continue
                if isinstance(node.value, str):
                    leaves.append((
                        f"$ast/{node.lineno}/{node.col_offset}",
                        node.value,
                        id(node) in declared_negative_node_ids
                        and normalized_text(node.value) in absolute_validator_negative_values,
                    ))
                elif isinstance(node.value, bytes):
                    # A Python bytes literal is still shipped textual authority surface.
                    # Decode losslessly enough to preserve every ASCII policy phrase;
                    # Otherwise prohibited operational bytes bypass string-only AST scans.
                    leaves.append((
                        f"$ast-bytes/{node.lineno}/{node.col_offset}",
                        node.value.decode("utf-8", errors="surrogateescape"),
                        False,
                    ))
            def fold_static_text(node: ast.AST) -> str | None:
                if isinstance(node, ast.Constant):
                    if isinstance(node.value, str):
                        return node.value
                    if isinstance(node.value, bytes):
                        return node.value.decode("utf-8", errors="surrogateescape")
                    return None
                if isinstance(node, ast.FormattedValue):
                    value = fold_static_text(node.value)
                    if value is None:
                        return None
                    if node.conversion == ord("r"):
                        value = repr(value)
                    elif node.conversion == ord("a"):
                        value = ascii(value)
                    if node.format_spec is not None:
                        spec = fold_static_text(node.format_spec)
                        if spec is None:
                            return None
                        try:
                            value = format(value, spec)
                        except Exception:
                            return None
                    return value
                if isinstance(node, ast.JoinedStr):
                    values = [fold_static_text(item) for item in node.values]
                    return None if any(item is None for item in values) else "".join(values)
                if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
                    left = fold_static_text(node.left)
                    right = fold_static_text(node.right)
                    return None if left is None or right is None else left + right
                if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Mod):
                    template = fold_static_text(node.left)
                    if template is None:
                        return None
                    if isinstance(node.right, (ast.Tuple, ast.List)):
                        values = [fold_static_text(item) for item in node.right.elts]
                        if any(item is None for item in values):
                            return None
                        operand: object = tuple(values)
                    else:
                        operand = fold_static_text(node.right)
                        if operand is None:
                            return None
                    try:
                        return template % operand
                    except Exception:
                        return None
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
                    base = fold_static_text(node.func.value)
                    if base is None:
                        return None
                    if node.func.attr == "format" and not node.keywords:
                        values = [fold_static_text(item) for item in node.args]
                        if any(item is None for item in values):
                            return None
                        try:
                            return base.format(*values)
                        except Exception:
                            return None
                    if (
                        node.func.attr == "join"
                        and len(node.args) == 1
                        and isinstance(node.args[0], (ast.List, ast.Tuple))
                    ):
                        values = [fold_static_text(item) for item in node.args[0].elts]
                        if any(item is None for item in values):
                            return None
                        return base.join(values)
                return None

            for expression in ast.walk(tree):
                if isinstance(expression, (ast.Constant, ast.FormattedValue)):
                    continue
                composed = fold_static_text(expression)
                if composed is not None:
                    leaves.append((
                        f"$ast-composed/{expression.lineno}/{expression.col_offset}",
                        composed,
                        False,
                    ))
            for token in tokenize.generate_tokens(io.StringIO(text_value).readline):
                if token.type == tokenize.COMMENT:
                    leaves.append(
                        (f"$comment/{token.start[0]}/{token.start[1]}", token.string, False)
                    )
        else:
            leaves.append(("$text", text_value, False))
        return leaves

    def scan_authority_leaves(
        relative: str, leaves: list[tuple[str, str, bool]]
    ) -> None:
        nonlocal authority_strings_scanned
        for pointer, value, declared_negative_context in leaves:
            authority_strings_scanned += 1
            normalized = normalized_text(value)
            hits = [
                phrase for phrase in AUTHORITY_REJECT_SUBSTRINGS
                if normalized_text(phrase) in normalized
            ]
            if not hits:
                continue
            allowed_negative = (
                relative == "meta_validate_round22.py" and declared_negative_context
            )
            expected_negative = absolute_negative_contexts.get((relative, pointer))
            if expected_negative is not None and normalized == expected_negative:
                allowed_negative = True
            if not allowed_negative:
                err(errors, "AUTHORITY_PROHIBITED_TEXT", f"{relative}:{pointer}:{hits[0]}")

    for path in package_files:
        relative = path.relative_to(root).as_posix()
        pure = PurePosixPath(relative)
        if pure.is_absolute() or ".." in pure.parts or "\\" in relative or str(pure) != relative:
            err(errors, "PACKAGE_MEMBER_PATH_UNSAFE", relative)
            continue
        if path.is_symlink():
            err(errors, "PACKAGE_MEMBER_SYMLINK", relative)
            continue
        scan_authority_leaves(relative, [("$path", relative, False)])
        suffix = path.suffix.casefold()
        if suffix in NORMATIVE_TEXTUAL_SUFFIXES:
            try:
                text_value = path.read_text(encoding="utf-8")
                leaves = authority_leaves_for_text(relative, text_value, suffix)
            except Exception as exc:
                err(errors, "PACKAGE_TEXT_PARSE_ERROR", f"{relative}:{exc}")
                continue
            scan_authority_leaves(relative, leaves)
            continue
        expected_binary_hash = ALLOWED_PACKAGE_BINARY_MEMBERS.get(relative)
        if expected_binary_hash is None:
            try:
                path.read_text(encoding="utf-8")
                err(errors, "PACKAGE_TEXT_SMUGGLING_AS_BINARY", relative)
            except UnicodeDecodeError:
                err(errors, "PACKAGE_BINARY_MEMBER_UNCLASSIFIED", relative)
            continue
        if sha256_file(path) != expected_binary_hash:
            err(errors, "PACKAGE_BINARY_HASH_MISMATCH", relative)
            continue
        try:
            with zipfile.ZipFile(path, "r") as archive:
                if archive.testzip() is not None:
                    err(errors, "PACKAGE_BINARY_ZIP_CRC_FAILURE", relative)
                for info in archive.infolist():
                    member_pure = PurePosixPath(info.filename)
                    if (
                        info.is_dir()
                        or member_pure.is_absolute()
                        or ".." in member_pure.parts
                        or "\\" in info.filename
                        or str(member_pure) != info.filename
                        or info.flag_bits & 0x1
                    ):
                        err(errors, "PACKAGE_BINARY_ZIP_MEMBER_UNSAFE", f"{relative}:{info.filename}")
                        continue
                    member_relative = f"{relative}!/{info.filename}"
                    scan_authority_leaves(member_relative, [("$path", info.filename, False)])
                    member_suffix = Path(info.filename).suffix.casefold()
                    if member_suffix not in NORMATIVE_TEXTUAL_SUFFIXES:
                        err(errors, "PACKAGE_BINARY_ZIP_MEMBER_UNCLASSIFIED", member_relative)
                        continue
                    try:
                        member_text = archive.read(info).decode("utf-8")
                        member_leaves = authority_leaves_for_text(
                            member_relative, member_text, member_suffix
                        )
                    except Exception as exc:
                        err(errors, "PACKAGE_BINARY_ZIP_TEXT_PARSE_ERROR", f"{member_relative}:{exc}")
                        continue
                    scan_authority_leaves(member_relative, member_leaves)
        except (OSError, zipfile.BadZipFile) as exc:
            err(errors, "PACKAGE_BINARY_ZIP_INVALID", f"{relative}:{exc}")

    # Operational receipts are part of the gate, not presence-only paperwork.
    def load_operational_receipt(name: str) -> dict:
        try:
            value = load_json(root / name)
        except Exception as exc:
            err(errors, "OPERATIONAL_RECEIPT_JSON_INVALID", f"{name}:{exc}")
            return {}
        if not isinstance(value, dict):
            err(errors, "OPERATIONAL_RECEIPT_NOT_OBJECT", name)
            return {}
        return value

    operational = {
        name: load_operational_receipt(name)
        for name in (
            "SPEC_VALIDATION_RECEIPT.semantic.json",
            "SPEC_VALIDATION_RECEIPT.json",
            "ORACLE_RECEIPT.json",
            "TRANSITION_EVAL_RECEIPT.json",
            "EXPORT_GENERATOR_RECEIPT.json",
            "EXPORT_VERIFIER_RECEIPT.json",
            "CLOSURE_PROBE_RECEIPT.json",
            "MUTATION_RECEIPTS.json",
            "MUTATION_DETERMINISM_RECEIPT.json",
            "EXECUTION_RECEIPT.json",
        )
    }
    prohibited_positive_claim_keys = {
        "application_candidate_exists", "application_tests_run", "host_preflight_run",
        "deployment_performed", "external_authority_used", "candidate_pass_eligible",
        "application_implemented", "authority_granted",
    }

    def reject_positive_operational_claims(value, path: str) -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                child_path = f"{path}/{key}"
                if key in prohibited_positive_claim_keys and child is True:
                    err(errors, "OPERATIONAL_RECEIPT_POSITIVE_SCOPE_CLAIM", child_path)
                reject_positive_operational_claims(child, child_path)
        elif isinstance(value, list):
            for index, child in enumerate(value):
                reject_positive_operational_claims(child, f"{path}/{index}")

    for receipt_name, receipt_value in operational.items():
        reject_positive_operational_claims(receipt_value, receipt_name)

    for name, mode in (
        ("SPEC_VALIDATION_RECEIPT.semantic.json", "semantic_only"),
        ("SPEC_VALIDATION_RECEIPT.json", "full"),
    ):
        value = operational[name]
        expected = {
            "schema_version": "pa.phase0a.round22_spec_validation_receipt.v1",
            "status": "SPEC_CONTRACT_VALID",
            "validation_mode": mode,
            "application_candidate_exists": False,
            "application_tests_run": False,
            "host_preflight_run": False,
            "oracle_decided_cases": 54,
            "oracle_deferred_cases": 35,
            "candidate_pass_eligible": False,
            "error_count": 0,
            "errors": [],
        }
        if (
            set(value) != set(expected) | {"authority_strings_scanned"}
            or any(value.get(field) != expected_value for field, expected_value in expected.items())
            or not isinstance(value.get("authority_strings_scanned"), int)
            or value.get("authority_strings_scanned", 0) <= 0
        ):
            err(errors, "SPEC_VALIDATION_RECEIPT_INVALID", name)
        if value.get("authority_strings_scanned") != authority_strings_scanned:
            err(errors, "RECEIPT_AUTHORITY_COUNT_MISMATCH", name)

    oracle_receipt = operational["ORACLE_RECEIPT.json"]
    oracle_expected = {
        "oracle_id": "pa.phase0a.independent_oracle.v2",
        "control": "OUTSIDE_CANDIDATE",
        "total_cases": 89,
        "decided_cases": 54,
        "pass_denominator": 54,
        "passed": 54,
        "failed": 0,
        "deferred": 35,
        "invalid_cases": 0,
        "semantic_corpus_sha256": SECURITY_CONSTANTS["oracle"]["contract_semantic_corpus_sha256"],
        "semantic_corpus_valid": True,
        "aggregate_invariants_ok": True,
        "deferred_excluded_from_pass_totals": True,
        "spec_oracle_valid": True,
        "candidate_pass_eligible": False,
        "candidate_pass_blocker": "DEFERRED_REQUIRED_CASES",
        "failures": [],
    }
    if oracle_receipt != oracle_expected:
        err(errors, "ORACLE_RECEIPT_INVALID")

    transition_receipt = operational["TRANSITION_EVAL_RECEIPT.json"]
    transition_expected = {
        "schema_version": "pa.phase0a.round22_transition_eval_receipt.v1",
        "total": 36,
        "allowed_count": 2,
        "forbidden_count": 34,
        "hold_origin_count": 12,
        "hold_terminal_ok": True,
        "other_forbidden_ok": True,
        "allowed_set_matches_evaluator_constants": True,
        "ok": True,
    }
    if any(
        transition_receipt.get(field) != expected_value
        for field, expected_value in transition_expected.items()
    ):
        err(errors, "TRANSITION_RECEIPT_INVALID")
    if set(transition_receipt) != {
        "schema_version", "matrix_source", "total", "allowed_count",
        "forbidden_count", "allowed", "hold_origin_count", "hold_terminal_ok",
        "other_forbidden_ok", "allowed_set_matches_evaluator_constants",
        "n80_checks", "ok",
    }:
        err(errors, "TRANSITION_RECEIPT_KEY_SET_INVALID")
    transition_allowed = {
        (row.get("n50"), row.get("n60"), row.get("n70"))
        for row in transition_receipt.get("allowed", [])
        if isinstance(row, dict) and row.get("allowed") is True and row.get("n80_eligible") is True
    }
    if transition_allowed != REQUIRED_ALLOWED_TRACES:
        err(errors, "TRANSITION_RECEIPT_ALLOWED_SET_INVALID")
    n80_receipt_checks = transition_receipt.get("n80_checks") or {}
    if len(n80_receipt_checks) != 9 or not all(value is True for value in n80_receipt_checks.values()):
        err(errors, "TRANSITION_RECEIPT_N80_CHECKS_INVALID")

    export_generator_receipt = operational["EXPORT_GENERATOR_RECEIPT.json"]
    export_receipt_truth = export_golden.get("receipt") or {}
    export_expected = {
        "export_id": export_receipt_truth.get("export_id"),
        "content_set_sha256": export_receipt_truth.get("content_set_sha256"),
        "receipt_hash": export_receipt_truth.get("receipt_hash"),
        "zip_sha256": export_golden.get("zip_sha256"),
        "matches_golden": True,
    }
    if export_generator_receipt != export_expected:
        err(errors, "EXPORT_GENERATOR_RECEIPT_INVALID")
    if operational["EXPORT_VERIFIER_RECEIPT.json"] != {"errors": [], "ok": True}:
        err(errors, "EXPORT_VERIFIER_RECEIPT_INVALID")

    closure_receipt = operational["CLOSURE_PROBE_RECEIPT.json"]
    if (
        (closure_receipt.get("baseline_validation") or {}).get(
            "authority_strings_scanned"
        )
        != authority_strings_scanned
    ):
        err(errors, "RECEIPT_AUTHORITY_COUNT_MISMATCH", "CLOSURE_PROBE_RECEIPT.json")
    closure_findings = closure_receipt.get("findings") or {}
    required_findings = {
        *(f"R19-F0{index}" for index in range(1, 8)),
        *(f"R21-F0{index}" for index in range(1, 5)),
    }
    closure_negative = closure_receipt.get("negative_mutation_results") or []
    closure_summary = closure_receipt.get("summary") or {}
    closure_semantics = sorted(
        (
            {
                "probe_id": item.get("probe_id"),
                "expected_error_codes": item.get("expected_error_codes"),
            }
            for item in closure_negative if isinstance(item, dict)
        ),
        key=lambda item: str(item.get("probe_id")),
    )
    closure_semantics_digest = sha256_bytes(canonical_json_bytes(closure_semantics))
    closure_negative_ok = (
        isinstance(closure_negative, list)
        and len(closure_negative) == REQUIRED_CLOSURE_NEGATIVE_COUNT
        and len({item.get("probe_id") for item in closure_negative if isinstance(item, dict)})
        == REQUIRED_CLOSURE_NEGATIVE_COUNT
        and closure_semantics_digest == REQUIRED_CLOSURE_SEMANTICS_SHA256
        and all(
            isinstance(item, dict)
            and item.get("exit_code") not in (None, 0)
            and item.get("rejected") is True
            and item.get("rejected_for_intended_reason") is True
            and set(item.get("expected_error_codes") or [])
            <= set(item.get("observed_error_codes") or [])
            for item in closure_negative
        )
    )
    closure_expected_summary = {
        "findings_total": 11,
        "findings_closed": 11,
        "negative_mutations_run": REQUIRED_CLOSURE_NEGATIVE_COUNT,
        "negative_mutations_rejected_for_intended_reason": REQUIRED_CLOSURE_NEGATIVE_COUNT,
        "false_green": 0,
        "deterministic_fields_only": True,
    }
    if (
        closure_receipt.get("schema_version") != "pa.phase0a.round22_closure_probe_receipt.v1"
        or set(closure_receipt) != {
            "schema_version", "round", "status", "baseline_validation", "findings",
            "negative_mutation_results", "cache_noise_probe", "preservation", "summary",
        }
        or closure_receipt.get("round") != "ROUND_022_CONTROLLING_PHASE0A_REPAIR"
        or closure_receipt.get("status") != "PASS"
        or set(closure_findings) != required_findings
        or not all(
            isinstance(closure_findings.get(finding), dict)
            and closure_findings[finding].get("closed") is True
            for finding in required_findings
        )
        or not closure_negative_ok
        or closure_summary != closure_expected_summary
    ):
        err(errors, "CLOSURE_RECEIPT_INVALID")
    f01_receipt = closure_findings.get("R19-F01") or {}
    f02_receipt = closure_findings.get("R19-F02") or {}
    f03_receipt = closure_findings.get("R19-F03") or {}
    f04_receipt = closure_findings.get("R19-F04") or {}
    f05_receipt = closure_findings.get("R19-F05") or {}
    f06_receipt = closure_findings.get("R19-F06") or {}
    f07_receipt = closure_findings.get("R19-F07") or {}
    if not (
        (f01_receipt.get("garbage") or {}).get("counted_passes") == 0
        and (f01_receipt.get("invented_reason") or {}).get("counted_passes") == 0
        and (f01_receipt.get("reflexive_behaviour") or {}).get("counted_passes") == 0
        and f01_receipt.get("deferred_candidate_requirement_flip_rejected") is True
        and f01_receipt.get("fixture_immutability_flip_rejected") is True
    ):
        err(errors, "CLOSURE_RECEIPT_F01_INVALID")
    if not (
        f02_receipt.get("phrase_mutations") == 10
        and f02_receipt.get("phrase_mutations_rejected") == 10
        and f02_receipt.get("missing_vocabulary_terms") == []
    ):
        err(errors, "CLOSURE_RECEIPT_F02_INVALID")
    if not (
        f03_receipt.get("behavioral_classes") == 12
        and f03_receipt.get("behavioral_classes_rejected") == 12
        and f03_receipt.get("hostile_vectors") == 7
        and f03_receipt.get("hostile_vectors_rejected") == 7
        and f03_receipt.get("renamed_echo_rejected") is True
    ):
        err(errors, "CLOSURE_RECEIPT_F03_INVALID")
    f04_baseline = f04_receipt.get("baseline_resolution") or {}
    if not (
        f04_baseline.get("all_resolved") is True
        and f04_baseline.get("declared_results") == 356
        and f04_baseline.get("matching_hashes") == 356
        and f04_receipt.get("negative_mutations") == 4
        and f04_receipt.get("negative_mutations_rejected") == 4
    ):
        err(errors, "CLOSURE_RECEIPT_F04_INVALID")
    if not (
        f05_receipt.get("locked_constants_hash_matches") is True
        and f05_receipt.get("schema_mutations") == 3
        and f05_receipt.get("schema_mutations_rejected") == 3
    ):
        err(errors, "CLOSURE_RECEIPT_F05_INVALID")
    if not (
        f06_receipt.get("cache_noise_full_validation_accepted") is True
        and f06_receipt.get("forbidden_bytecode_entries") == []
        and f06_receipt.get("bytecode_files_created_by_documented_commands") == []
    ):
        err(errors, "CLOSURE_RECEIPT_F06_INVALID")
    if not (
        f07_receipt.get("total_traces") == 36
        and f07_receipt.get("allowed_traces") == 2
        and f07_receipt.get("forbidden_traces") == 34
        and f07_receipt.get("hold_origin_traces") == 12
        and f07_receipt.get("hold_origin_releases") == 0
    ):
        err(errors, "CLOSURE_RECEIPT_F07_INVALID")
    r21_f01_receipt = closure_findings.get("R21-F01") or {}
    r21_f02_receipt = closure_findings.get("R21-F02") or {}
    r21_f03_receipt = closure_findings.get("R21-F03") or {}
    r21_f04_receipt = closure_findings.get("R21-F04") or {}
    if not (
        r21_f01_receipt.get("closed_binary_allowlist_count") == 1
        and r21_f01_receipt.get("closed_binary_hash_matches") is True
        and r21_f01_receipt.get("negative_mutations") == 13
        and r21_f01_receipt.get("negative_mutations_rejected") == 13
        and f02_receipt.get("successor_r21_f01_closed") is True
    ):
        err(errors, "CLOSURE_RECEIPT_R21_F01_INVALID")
    if not (
        r21_f02_receipt.get("absolute_max_length") == ABSOLUTE_SLUG_MAX_LENGTH
        and r21_f02_receipt.get("runtime_max_length") == ABSOLUTE_SLUG_MAX_LENGTH
        and r21_f02_receipt.get("boundary_plus_one_present") is True
        and r21_f02_receipt.get("negative_mutations") == 2
        and r21_f02_receipt.get("negative_mutations_rejected") == 2
        and f05_receipt.get("successor_r21_f02_closed") is True
    ):
        err(errors, "CLOSURE_RECEIPT_R21_F02_INVALID")
    if not (
        r21_f03_receipt.get("declared_domains") == ABSOLUTE_EXPORT_DOMAINS
        and r21_f03_receipt.get("runtime_domains") == ABSOLUTE_EXPORT_DOMAINS
        and r21_f03_receipt.get("negative_mutations") == 3
        and r21_f03_receipt.get("negative_mutations_rejected") == 3
    ):
        err(errors, "CLOSURE_RECEIPT_R21_F03_INVALID")
    if not (
        r21_f04_receipt.get("all_counters_equal") is True
        and r21_f04_receipt.get("live_authority_strings_scanned")
        == authority_strings_scanned
        and r21_f04_receipt.get("negative_mutations") == 2
        and r21_f04_receipt.get("negative_mutations_rejected") == 2
    ):
        err(errors, "CLOSURE_RECEIPT_R21_F04_INVALID")
    preservation_receipt = closure_receipt.get("preservation") or {}
    if not (
        preservation_receipt.get("ok") is True
        and (preservation_receipt.get("n80_identity") or {}).get("dimensions_tested") == 8
        and (preservation_receipt.get("n80_identity") or {}).get("dimensions_rejected") == 8
        and (preservation_receipt.get("mutation_harness") or {}).get("ok") is True
        and (preservation_receipt.get("operational_receipt_integrity") or {}).get(
            "rejected_for_intended_reason"
        ) is True
        and (preservation_receipt.get("operational_receipt_extra_claim") or {}).get(
            "rejected_for_intended_reason"
        ) is True
        and (preservation_receipt.get("commands_and_export") or {}).get("ok") is True
    ):
        err(errors, "CLOSURE_RECEIPT_PRESERVATION_INVALID")

    mutation_receipt = operational["MUTATION_RECEIPTS.json"]
    mutation_registry = mutation_receipt.get("registry_exact") or []
    registry_digest = sha256_bytes(canonical_json_bytes(sorted(mutation_registry)))
    mutation_results = mutation_receipt.get("results") or []
    mutation_result_ids = [
        item.get("mutation_id") for item in mutation_results if isinstance(item, dict)
    ]
    mutation_semantics = sorted(
        (
            {
                "mutation_id": item.get("mutation_id"),
                "expected_reason_codes": item.get("expected_reason_codes"),
                "required_rejectors": item.get("required_rejectors"),
            }
            for item in mutation_results if isinstance(item, dict)
        ),
        key=lambda item: str(item.get("mutation_id")),
    )
    mutation_semantics_digest = sha256_bytes(canonical_json_bytes(mutation_semantics))
    full_tool_set = {
        "semantic_validator", "full_validator", "independent_oracle",
        "transition_evaluator", "export_generator", "export_verifier",
    }
    mutation_rows_ok = (
        isinstance(mutation_results, list)
        and len(mutation_results) == REQUIRED_MUTATION_COUNT
        and len(set(mutation_result_ids)) == REQUIRED_MUTATION_COUNT
        and sorted(mutation_result_ids) == sorted(mutation_registry)
        and all(
            isinstance(item, dict)
            and item.get("expected") == "REJECT"
            and item.get("observed") == "REJECTED"
            and item.get("mutation_changed_tree") is True
            and item.get("mutation_present_after_rebind") is True
            and item.get("reason_codes_matched") is True
            and set(item.get("expected_reason_codes") or [])
            <= set(item.get("observed_reason_codes") or [])
            and set((item.get("tools") or {}).keys()) == full_tool_set
            and all(
                (item.get("tools") or {}).get(rejector, {}).get("exit_code") not in (None, 0)
                for rejector in item.get("required_rejectors") or []
            )
            for item in mutation_results
        )
    )
    mutation_summary = mutation_receipt.get("summary") or {}
    mutation_baseline_tools = (mutation_receipt.get("baseline") or {}).get("tools") or {}
    if (
        mutation_receipt.get("schema_version") != "pa.phase0a.round22_mutation_receipt.v1"
        or set(mutation_receipt) != {
            "schema_version", "round", "status", "source_tree_modified", "execution_boundary",
            "python_invocation", "pythonhashseed_note", "toolchain_mode",
            "tool_command_templates", "registry_count", "registry_exact",
            "selected_count", "complete_registry_run", "baseline", "results", "summary",
        }
        or mutation_receipt.get("round") != "ROUND_022_CONTROLLING_PHASE0A_REPAIR"
        or mutation_receipt.get("status") != "PASS"
        or mutation_receipt.get("toolchain_mode") != "all_documented_tools_per_mutation"
        or mutation_receipt.get("complete_registry_run") is not True
        or mutation_receipt.get("source_tree_modified") is not False
        or mutation_receipt.get("registry_count") != REQUIRED_MUTATION_COUNT
        or mutation_receipt.get("selected_count") != REQUIRED_MUTATION_COUNT
        or registry_digest != REQUIRED_MUTATION_REGISTRY_SHA256
        or mutation_semantics_digest != REQUIRED_MUTATION_SEMANTICS_SHA256
        or not mutation_rows_ok
        or mutation_summary != {
            "mutation_classes": REQUIRED_MUTATION_COUNT,
            "rejected": REQUIRED_MUTATION_COUNT,
            "false_green": 0,
            "rejected_wrong_reason": 0,
        }
        or (mutation_receipt.get("baseline") or {}).get("ok") is not True
        or set(mutation_baseline_tools) != full_tool_set
        or not all(item.get("exit_code") == 0 for item in mutation_baseline_tools.values())
    ):
        err(errors, "MUTATION_RECEIPT_INVALID")
    mutation_markdown_path = root / "MUTATION_RECEIPTS.md"
    mutation_markdown = mutation_markdown_path.read_text(encoding="utf-8") if mutation_markdown_path.is_file() else ""
    if (
        "Status: `PASS`" not in mutation_markdown
        or f"Registry classes: {REQUIRED_MUTATION_COUNT}" not in mutation_markdown
        or f"Rejected for intended reason: {REQUIRED_MUTATION_COUNT}" not in mutation_markdown
        or "False green: 0" not in mutation_markdown
    ):
        err(errors, "MUTATION_MARKDOWN_RECEIPT_INVALID")

    determinism_receipt = operational["MUTATION_DETERMINISM_RECEIPT.json"]
    determinism_mutation = determinism_receipt.get("mutation") or {}
    determinism_closure = determinism_receipt.get("closure") or {}
    mutation_seed_commands = determinism_mutation.get("commands") or []
    closure_seed_commands = determinism_closure.get("commands") or []
    mutation_seed_commands_ok = mutation_seed_commands == [
        "PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=1 python3 -S run_round22_mutations.py --full --output-json <seed1-json> --output-md <seed1-md>",
        "PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=2 python3 -S run_round22_mutations.py --full --output-json <seed2-json> --output-md <seed2-md>",
    ]
    closure_seed_commands_ok = closure_seed_commands == [
        "PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=1 python3 -S run_round22_closure_probes.py --output-json <seed1-json>",
        "PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=2 python3 -S run_round22_closure_probes.py --output-json <seed2-json>",
    ]
    if not (
        determinism_receipt.get("schema_version")
        == "pa.phase0a.round22_mutation_determinism_receipt.v1"
        and set(determinism_receipt) == {
            "schema_version", "status", "python_invocation", "seeds", "mutation", "closure",
        }
        and determinism_receipt.get("status") == "PASS"
        and determinism_receipt.get("python_invocation") == "PYTHONDONTWRITEBYTECODE=1 python3 -S"
        and determinism_receipt.get("seeds") == ["1", "2"]
        and determinism_mutation.get("exit_codes") == [0, 0]
        and determinism_mutation.get("json_byte_identical") is True
        and determinism_mutation.get("markdown_byte_identical") is True
        and determinism_mutation.get("json_sha256") == sha256_file(root / "MUTATION_RECEIPTS.json")
        and determinism_mutation.get("markdown_sha256") == sha256_file(root / "MUTATION_RECEIPTS.md")
        and determinism_mutation.get("registry_count") == REQUIRED_MUTATION_COUNT
        and determinism_mutation.get("rejected") == REQUIRED_MUTATION_COUNT
        and determinism_mutation.get("false_green") == 0
        and mutation_seed_commands_ok
        and determinism_closure.get("exit_codes") == [0, 0]
        and determinism_closure.get("json_byte_identical") is True
        and determinism_closure.get("json_sha256") == sha256_file(root / "CLOSURE_PROBE_RECEIPT.json")
        and determinism_closure.get("findings_closed") == 11
        and determinism_closure.get("false_green") == 0
        and closure_seed_commands_ok
    ):
        err(errors, "MUTATION_DETERMINISM_RECEIPT_INVALID")

    execution_receipt = operational["EXECUTION_RECEIPT.json"]
    execution_results = execution_receipt.get("results") or {}
    execution_scope = execution_receipt.get("scope") or {}
    execution_hashes = execution_receipt.get("receipt_sha256") or {}
    expected_receipt_hash_names = {
        "SPEC_VALIDATION_RECEIPT.semantic.json",
        "SPEC_VALIDATION_RECEIPT.json",
        "ORACLE_RECEIPT.json",
        "TRANSITION_EVAL_RECEIPT.json",
        "EXPORT_GENERATOR_RECEIPT.json",
        "EXPORT_VERIFIER_RECEIPT.json",
        "CLOSURE_PROBE_RECEIPT.json",
        "MUTATION_RECEIPTS.json",
        "MUTATION_RECEIPTS.md",
        "MUTATION_DETERMINISM_RECEIPT.json",
    }
    execution_hashes_ok = (
        set(execution_hashes) == expected_receipt_hash_names
        and all(
            execution_hashes.get(name) == sha256_file(root / name)
            for name in expected_receipt_hash_names
        )
    )
    command_receipt_map = {
        "semantic_validation": "SPEC_VALIDATION_RECEIPT.semantic.json",
        "full_validation": "SPEC_VALIDATION_RECEIPT.json",
        "independent_oracle": "ORACLE_RECEIPT.json",
        "transition_evaluator": "TRANSITION_EVAL_RECEIPT.json",
        "export_generator": "EXPORT_GENERATOR_RECEIPT.json",
        "export_verifier": "EXPORT_VERIFIER_RECEIPT.json",
    }
    expected_execution_commands = {
        "semantic_validation": "PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=1 python3 -S meta_validate_round22.py --semantic-only",
        "full_validation": "PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=1 python3 -S meta_validate_round22.py",
        "independent_oracle": "PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=1 python3 -S independent_oracle.py",
        "transition_evaluator": "PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=1 python3 -S transition_evaluator.py",
        "export_generator": "PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=1 python3 -S export_generator.py",
        "export_verifier": "PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=1 python3 -S export_verifier.py",
    }
    execution_commands = execution_receipt.get("commands") or {}
    execution_commands_ok = set(execution_commands) == set(command_receipt_map)
    if execution_commands_ok:
        for command_name, receipt_name in command_receipt_map.items():
            command = execution_commands.get(command_name) or {}
            if not (
                command.get("exit_code") == 0
                and command.get("stdout_sha256") == sha256_file(root / receipt_name)
                and command.get("stderr_sha256") == EMPTY_SHA256
                and command.get("command") == expected_execution_commands[command_name]
            ):
                execution_commands_ok = False
                break
    if not (
        execution_receipt.get("schema_version") == "pa.phase0a.round22_execution_receipt.v1"
        and set(execution_receipt) == {
            "schema_version", "round", "adjudication", "status", "scope", "commands",
            "results", "receipt_sha256", "fresh_unpack_validation",
        }
        and execution_receipt.get("round") == "ROUND_022_CONTROLLING_PHASE0A_REPAIR"
        and execution_receipt.get("adjudication")
        == "ROUND022_REPAIR_COMPLETE_AWAITING_INDEPENDENT_REREVIEW"
        and execution_receipt.get("status") == "PASS"
        and execution_scope == {
            "application_candidate_exists": False,
            "application_tests_run": False,
            "host_preflight_run": False,
            "deployment_performed": False,
            "external_authority_used": False,
        }
        and execution_results == {
            "findings_closed": 11,
            "findings_total": 11,
            "mutation_classes": REQUIRED_MUTATION_COUNT,
            "mutations_rejected": REQUIRED_MUTATION_COUNT,
            "false_green": 0,
            "mutation_seed_receipts_byte_identical": True,
            "closure_seed_receipts_byte_identical": True,
        }
        and execution_hashes_ok
        and execution_commands_ok
        and (execution_receipt.get("fresh_unpack_validation") or {}).get("expected_exit_code") == 0
        and (execution_receipt.get("fresh_unpack_validation") or {}).get("bytecode_entries_permitted") is False
        and (execution_receipt.get("fresh_unpack_validation") or {}).get("required_command")
        == "PYTHONDONTWRITEBYTECODE=1 python3 -S 03_EXCHANGE/ROUND_022_CONTROLLING_PHASE0A_REPAIR/meta_validate_round22.py"
    ):
        err(errors, "EXECUTION_RECEIPT_INVALID")

    # package checksum if present
    if not args.semantic_only:
        manifest = root / "SHA256SUMS.txt"
        if manifest.is_file():
            checksum_listed = set()
            for line in manifest.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                try:
                    expected, rel = line.split("  ", 1)
                except ValueError:
                    err(errors, "CHECKSUM_LINE_MALFORMED", line)
                    continue
                if rel in checksum_listed:
                    err(errors, "CHECKSUM_DUPLICATE", rel)
                checksum_listed.add(rel)
                if rel == "SHA256SUMS.txt":
                    err(errors, "CHECKSUM_SELF_REF")
                    continue
                target = root / rel
                if ignored_bytecode_path(target):
                    err(errors, "FORBIDDEN_BYTECODE_MANIFEST_ENTRY", rel)
                    continue
                if not target.is_file() or sha256_file(target) != expected:
                    err(errors, "CHECKSUM_MISMATCH", rel)
            expected_checksum_paths = {
                path.relative_to(root).as_posix()
                for path in root.rglob("*")
                if path.is_file()
                and path != manifest
                and not ignored_bytecode_path(path)
            }
            if checksum_listed != expected_checksum_paths:
                for missing in sorted(expected_checksum_paths - checksum_listed):
                    err(errors, "CHECKSUM_UNLISTED", missing)
                for extra in sorted(checksum_listed - expected_checksum_paths):
                    err(errors, "CHECKSUM_UNEXPECTED", extra)
        else:
            err(errors, "CHECKSUM_MANIFEST_MISSING")

    status = "SPEC_CONTRACT_VALID" if not errors else "SPEC_CONTRACT_INVALID"
    receipt = {
        "schema_version": "pa.phase0a.round22_spec_validation_receipt.v1",
        "status": status,
        "validation_mode": "semantic_only" if args.semantic_only else "full",
        "application_candidate_exists": False,
        "application_tests_run": False,
        "host_preflight_run": False,
        "oracle_decided_cases": len(decided_cases) if contract else 0,
        "oracle_deferred_cases": len(deferred_cases) if contract else 0,
        "candidate_pass_eligible": False,
        "authority_strings_scanned": authority_strings_scanned,
        "error_count": len(errors),
        "errors": sort_stable(errors),
    }
    text = dumps_pretty(receipt)
    if args.receipt:
        args.receipt.write_text(text, encoding="utf-8")
    sys.stdout.write(text)
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
