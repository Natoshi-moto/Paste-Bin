#!/usr/bin/env python3
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile


SOURCE_RELAY = Path(__file__).resolve().parents[2]
ROUND_REL = Path("03_EXCHANGE/ROUND_016_CONTROLLING_PHASE0A_REPAIR")
SOURCE_ROUND = SOURCE_RELAY / ROUND_REL


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def save(path: Path, value) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def canonical(value) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def regenerate_manifest(round_dir: Path) -> None:
    manifest = round_dir / "SHA256SUMS.txt"
    files = sorted(p for p in round_dir.rglob("*") if p.is_file() and p != manifest)
    manifest.write_text(
        "".join(
            f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(round_dir).as_posix()}\n"
            for p in files
        ),
        encoding="utf-8",
    )


def mutate_json(round_dir: Path, filename: str, mutate) -> None:
    path = round_dir / filename
    value = load(path)
    mutate(value)
    save(path, value)


def replace_json(round_dir: Path, filename: str, value) -> None:
    save(round_dir / filename, value)


def rebind_contract_fixture(round_dir: Path) -> None:
    contract_hash = hashlib.sha256(
        (round_dir / "PHASE0A_ACCEPTANCE_CONTRACT.v3.json").read_bytes()
    ).hexdigest()
    vectors_path = round_dir / "PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json"
    vectors = load(vectors_path)
    positive = vectors["positive_fixture"]
    binding = positive["candidate_binding"]
    evidence = positive["candidate_evidence"]
    binding["contract_sha256"] = contract_hash
    evidence["contract_sha256"] = contract_hash
    evidence["candidate_binding_sha256"] = hashlib.sha256(canonical(binding)).hexdigest()
    save(vectors_path, vectors)


def empty_candidate_binding(round_dir: Path) -> None:
    replace_json(round_dir, "PHASE0A_CANDIDATE_BINDING.schema.json", {})


def empty_candidate_evidence(round_dir: Path) -> None:
    replace_json(round_dir, "PHASE0A_CANDIDATE_EVIDENCE.schema.json", {})


def empty_gate_case_schema(round_dir: Path) -> None:
    replace_json(round_dir, "PHASE0A_GATE_CASE_EVIDENCE.schema.json", {})


def empty_dag_schema(round_dir: Path) -> None:
    replace_json(round_dir, "PHASE0A_DAG_SCHEMA.v1.json", {})


def vacuous_case_fixtures(round_dir: Path) -> None:
    def edit(value):
        for case in value["cases"]:
            case["fixture_inline"] = {}
    mutate_json(round_dir, "PHASE0A_ACCEPTANCE_CONTRACT.v3.json", edit)
    rebind_contract_fixture(round_dir)


def noop_mutation_operators(round_dir: Path) -> None:
    def edit(value):
        for mutant in value["mutants"]:
            mutant["mutation_operator"] = "NO_OP"
    mutate_json(round_dir, "PHASE0A_ACCEPTANCE_CONTRACT.v3.json", edit)
    rebind_contract_fixture(round_dir)


def final_condition_constant_true(round_dir: Path) -> None:
    def edit(value):
        for index, condition in enumerate(value["conditions"]):
            if condition["condition_id"] == "REREVIEW_PASS_OR_INITIAL_PASS_CONFIRMED":
                value["conditions"][index] = {
                    "condition_id": "REREVIEW_PASS_OR_INITIAL_PASS_CONFIRMED",
                    "type": "constant",
                    "value": True,
                }
    mutate_json(round_dir, "PHASE0A_CONDITION_REGISTRY.v1.json", edit)


def rereview_checks_removed(round_dir: Path) -> None:
    def edit(value):
        node = next(n for n in value["nodes"] if n["node_id"] == "P0A-N70-INDEPENDENT-REREVIEW")
        node["kind"] = "noop"
        node["required_checks"] = []
    mutate_json(round_dir, "PHASE0A_BUILD_DAG.v1.json", edit)


def initial_review_contract_check_removed(round_dir: Path) -> None:
    def edit(value):
        node = next(n for n in value["nodes"] if n["node_id"] == "P0A-N50-INDEPENDENT-REVIEW")
        node["required_checks"] = ["do not execute candidate acceptance tests"]
    mutate_json(round_dir, "PHASE0A_BUILD_DAG.v1.json", edit)


def slug_traversal_allowed(round_dir: Path) -> None:
    def edit(value):
        value["properties"]["slug"]["pattern"] = "^.*$"
        value["x-phase0a-transition-rules"]["slug_reserved"] = []
    mutate_json(round_dir, "PHASE0A_NOTE_STATE.schema.json", edit)


def published_status_added(round_dir: Path) -> None:
    def edit(value):
        value["properties"]["status"]["enum"].append("published")
    mutate_json(round_dir, "PHASE0A_NOTE_STATE.schema.json", edit)


def action_detail_mapping_removed(round_dir: Path) -> None:
    mutate_json(
        round_dir,
        "PHASE0A_PROVENANCE_EVENT.schema.json",
        lambda value: value.__setitem__("x-phase0a-action-detail-branch", {}),
    )


def canonical_hash_domains_changed(round_dir: Path) -> None:
    def edit(value):
        value["hashes"]["note_state"]["domain_prefix_utf8_then_nul"] = "BROKEN-NOTE-DOMAIN"
        value["hashes"]["provenance_event"]["domain_prefix_utf8_then_nul"] = "BROKEN-EVENT-DOMAIN"
        value["hashes"]["export_receipt"]["domain_prefix_utf8_then_nul"] = "BROKEN-RECEIPT-DOMAIN"
    mutate_json(round_dir, "PHASE0A_CANONICAL_RULES.v1.json", edit)


def export_write_boundary_widened(round_dir: Path) -> None:
    def edit(value):
        value["write_boundary"]["public_repository"] = True
        value["write_boundary"]["outside_workspace"] = True
    mutate_json(round_dir, "PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v2.json", edit)


def export_receipt_self_hash_enabled(round_dir: Path) -> None:
    def edit(value):
        value["members"]["export-receipt.json"]["receipt_hash_excludes_field"] = None
    mutate_json(round_dir, "PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v2.json", edit)


def runner_evidence_bypass(round_dir: Path) -> None:
    def edit(value):
        value["command"] = ["true"]
        value["final_evidence"] = {
            "status_logic": {"CANDIDATE_TESTS_PASS": "runner says PASS"}
        }
    mutate_json(round_dir, "PHASE0A_RUNNER_INTERFACE.v1.json", edit)


def fictitious_evidence_hashes(round_dir: Path) -> None:
    def edit(value):
        evidence = value["positive_fixture"]["candidate_evidence"]
        for result in evidence["case_results"]:
            result["evidence_sha256"] = "0" * 64
        for result in evidence["assertion_results"]:
            result["evidence_sha256"] = "0" * 64
        for result in evidence["mutant_results"]:
            result["evidence_sha256"] = "0" * 64
        evidence["evidence_manifest_sha256"] = "0" * 64
    mutate_json(round_dir, "PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json", edit)


def dag_hidden_provider_authority(round_dir: Path) -> None:
    def edit(value):
        node = next(n for n in value["nodes"] if n["node_id"] == "P0A-N40-BUILD-CANDIDATE")
        node["required_checks"].append("connect DeepSeek with operator credentials")
    mutate_json(round_dir, "PHASE0A_BUILD_DAG.v1.json", edit)


def unsupported_implementation_claim(round_dir: Path) -> None:
    def edit(value):
        value["application_implemented"] = True
        value["candidate_pass_target"] = "CANDIDATE_TESTS_PASS_ALREADY_ACHIEVED"
    mutate_json(round_dir, "NO_IMPLEMENTATION_CANDIDATE.json", edit)


def remove_dashboard_export_status_coherently(round_dir: Path) -> None:
    contract_path = round_dir / "PHASE0A_ACCEPTANCE_CONTRACT.v3.json"
    contract = load(contract_path)
    test_id = "T-G-P0A-DASHBOARD-EXPORT-STATUS"
    test = next(t for t in contract["tests"] if t["test_id"] == test_id)
    case_ids = set(test["case_ids"])
    assertion_ids = set(test["assertion_ids"])
    mutant_ids = set(test["mutant_ids"])
    for gate in contract["gates"]:
        gate["test_ids"] = [value for value in gate["test_ids"] if value != test_id]
    contract["tests"] = [value for value in contract["tests"] if value["test_id"] != test_id]
    contract["cases"] = [value for value in contract["cases"] if value["case_id"] not in case_ids]
    contract["assertions"] = [value for value in contract["assertions"] if value["assertion_id"] not in assertion_ids]
    contract["mutants"] = [value for value in contract["mutants"] if value["mutant_id"] not in mutant_ids]
    contract["counts"] = {
        "inherited_named_tests": 63,
        "round16_additional_tests": len(contract["tests"]) - 63,
        "total_tests": len(contract["tests"]),
        "total_cases": len(contract["cases"]),
        "total_assertions": len(contract["assertions"]),
        "total_mutants": len(contract["mutants"]),
    }
    save(contract_path, contract)

    runner_path = round_dir / "PHASE0A_RUNNER_INTERFACE.v1.json"
    runner = load(runner_path)
    runner["required_runner_methods"] = [
        value for value in runner["required_runner_methods"] if value != test["runner_method"]
    ]
    save(runner_path, runner)

    contract_hash = hashlib.sha256(contract_path.read_bytes()).hexdigest()
    vectors_path = round_dir / "PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json"
    vectors = load(vectors_path)
    positive = vectors["positive_fixture"]
    binding = positive["candidate_binding"]
    evidence = positive["candidate_evidence"]
    binding["contract_sha256"] = contract_hash
    evidence["contract_sha256"] = contract_hash
    evidence["case_results"] = [value for value in evidence["case_results"] if value["case_id"] not in case_ids]
    evidence["assertion_results"] = [value for value in evidence["assertion_results"] if value["assertion_id"] not in assertion_ids]
    evidence["mutant_results"] = [value for value in evidence["mutant_results"] if value["mutant_id"] not in mutant_ids]
    evidence["candidate_binding_sha256"] = hashlib.sha256(canonical(binding)).hexdigest()
    evidence["summary"] = {
        "expected_cases": len(contract["cases"]),
        "executed_cases": len(contract["cases"]),
        "passed_cases": len(contract["cases"]),
        "failed_cases": 0,
        "skipped_cases": 0,
        "expected_assertions": len(contract["assertions"]),
        "passed_assertions": len(contract["assertions"]),
        "failed_assertions": 0,
        "required_mutants": len(contract["mutants"]),
        "killed_mutants": len(contract["mutants"]),
        "surviving_mutants": 0,
    }
    save(vectors_path, vectors)


PROBES = [
    ("R17-M01-EMPTY-CANDIDATE-BINDING-SCHEMA", empty_candidate_binding),
    ("R17-M02-EMPTY-CANDIDATE-EVIDENCE-SCHEMA", empty_candidate_evidence),
    ("R17-M03-EMPTY-GATE-CASE-SCHEMA", empty_gate_case_schema),
    ("R17-M04-EMPTY-DAG-SCHEMA", empty_dag_schema),
    ("R17-M05-VACUOUS-INLINE-FIXTURES", vacuous_case_fixtures),
    ("R17-M06-NOOP-MUTATION-OPERATORS", noop_mutation_operators),
    ("R17-M07-FINAL-CONDITION-CONSTANT-TRUE", final_condition_constant_true),
    ("R17-M08-REREVIEW-CHECKS-REMOVED", rereview_checks_removed),
    ("R17-M09-INITIAL-REVIEW-TEST-EXECUTION-REMOVED", initial_review_contract_check_removed),
    ("R17-M10-SLUG-TRAVERSAL-ALLOWED", slug_traversal_allowed),
    ("R17-M11-PUBLISHED-STATUS-ADDED", published_status_added),
    ("R17-M12-ACTION-DETAIL-MAPPING-REMOVED", action_detail_mapping_removed),
    ("R17-M13-CANONICAL-HASH-DOMAINS-CHANGED", canonical_hash_domains_changed),
    ("R17-M14-EXPORT-WRITE-BOUNDARY-WIDENED", export_write_boundary_widened),
    ("R17-M15-EXPORT-RECEIPT-SELF-HASH-ENABLED", export_receipt_self_hash_enabled),
    ("R17-M16-RUNNER-EVIDENCE-BYPASS", runner_evidence_bypass),
    ("R17-M17-FICTITIOUS-EVIDENCE-HASHES", fictitious_evidence_hashes),
    ("R17-M18-HIDDEN-PROVIDER-AUTHORITY-IN-DAG", dag_hidden_provider_authority),
    ("R17-M19-UNSUPPORTED-IMPLEMENTATION-CLAIM", unsupported_implementation_claim),
    ("R17-M20-REQUIRED-DASHBOARD-TEST-REMOVED-COHERENTLY", remove_dashboard_export_status_coherently),
]


baseline = subprocess.run(
    ["python3", "-S", str(SOURCE_ROUND / "meta_validate_round16.py"), "--root", str(SOURCE_ROUND), "--semantic-only"],
    capture_output=True,
    text=True,
)
if baseline.returncode != 0:
    raise SystemExit("baseline semantic validator failed")

results = []
for probe_id, mutate in PROBES:
    with tempfile.TemporaryDirectory(prefix="pa-round17-probe-") as temp:
        relay = Path(temp) / "relay"
        shutil.copytree(SOURCE_RELAY, relay)
        round_dir = relay / ROUND_REL
        mutate(round_dir)
        regenerate_manifest(round_dir)
        run = subprocess.run(
            ["python3", "-S", str(round_dir / "meta_validate_round16.py"), "--root", str(round_dir), "--semantic-only"],
            capture_output=True,
            text=True,
        )
        false_green = run.returncode == 0 and '"status": "SPEC_CONTRACT_VALID"' in run.stdout
        results.append(
            {
                "probe_id": probe_id,
                "expected": "REJECT",
                "validator_exit_code": run.returncode,
                "observed": "FALSE_GREEN" if false_green else "REJECTED",
                "stdout_sha256": hashlib.sha256(run.stdout.encode()).hexdigest(),
                "stderr_sha256": hashlib.sha256(run.stderr.encode()).hexdigest(),
                "checksum_co_updated": True,
            }
        )

receipt = {
    "schema_version": "pa.phase0a.round17_adversarial_probe.v1",
    "baseline_exit_code": baseline.returncode,
    "baseline_stdout_sha256": hashlib.sha256(baseline.stdout.encode()).hexdigest(),
    "probe_count": len(results),
    "false_green": sum(item["observed"] == "FALSE_GREEN" for item in results),
    "rejected": sum(item["observed"] == "REJECTED" for item in results),
    "results": results,
}
output = Path("/tmp/round17-adversarial-probes.json")
output.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps(receipt, indent=2))
raise SystemExit(1 if receipt["false_green"] else 0)
