# Pioneer Alignment — Round 017 Independent Phase 0A Build-Readiness Review

Version: v1  
Date: 2026-08-01  
Actor: independent Phase 0A build-readiness critic  
Posture: specification review and disposable mutation testing only

## 1. Authority understood

I was authorised to inspect the complete relay, execute the Round 016 validators,
test disposable copies, adjudicate only the narrow local Phase 0A specification,
write this Round 017 review, and return one complete relay ZIP.

I was not authorised to build application code, initialise or mutate a Git
repository, create a branch or commit, configure a remote, push to GitHub, request
credentials, connect a provider, deploy, change public infrastructure, spend money,
create identities/balances/governance/federation, or promote the wider architecture
into canon.

The operator's GitHub intent remains correctly bounded: a private backup/pastebin may
be used only after a fresh exact single-use authorisation. No such authority exists in
this round and no remote action occurred.

## 2. Corpus and commands actually reviewed

Received archive:

- filename: `Pioneer-Alignment-Single-Relay-v7.zip`;
- detached SHA-256: `e91ba666ebd5b0e84c5d751c7216660b0e595fa5ce11668773cdbe379d60485a`;
- entries: 217 unique files;
- archive test: PASS;
- absolute/traversal paths: none;
- duplicate paths: none;
- symlinks: none;
- wrapper directory: none;
- immutable input manifest: PASS, 206/206 files;
- received current manifest: PASS, 216/216 covered files.

I read the original 272-line Phase 0A builder handoff, the Round 015 review and
finding records, every Round 016 normative file, both Round 016 programs, supplied
receipts, golden export members, build DAG, condition registry, candidate schemas,
and the Round 017 controlling prompt.

The mandatory commands and their exact results are recorded in
`EXECUTION_RECEIPT.json`. All independent mutations were made in disposable complete
relay copies. No Round 016 or earlier byte was changed.

## 3. Independent execution results

| Execution | Result |
|---|---:|
| Immutable input verification | PASS — 206 files |
| Round 016 full meta-validator | exit 0 — `SPEC_CONTRACT_VALID` |
| Supplied Round 016 mutation suite | 36 rejected, 0 reported false-green |
| Contract inventory | 89 tests, 89 cases, 178 assertions, 89 mutants |
| Concrete case payloads | 0 |
| Executable candidate mutation definitions | 0 |
| Candidate application | none |
| Candidate tests | not run |
| Host preflight | not run |
| Independent Round 017 adversarial probes | 20/20 material false-greens |

All 89 cases use `APPLY_NAMED_CASE`; every inline fixture supplies only a symbolic
base, scenario name, `test_name`, and `gate_id`. Every mutant is a string of the form
`INVERT_OR_BYPASS::<name>`. The referenced future runner
`scripts/run_phase0a_acceptance.py` is not present in this relay and is assigned to the
candidate repository itself.

The supplied mutation receipt is also nondeterministic. Running the same 36 classes
under `PYTHONHASHSEED=1` and `PYTHONHASHSEED=2` produced different JSON hashes because
the cycle detector iterates an unordered set:

- seed 1: `a5f3d6696f79a3fdfcc8ad816454b705d74e5ee6e9466968e527b341de417613`;
- seed 2: `493187ae5a7c5ae2db616e32e36994fc623956cce917d7a6282b75f227bafa7e`.

## 4. Adjudication

`HOLD_FOR_PHASE0A_SPEC_REPAIR`

Round 016 made substantial useful repairs. The original builder handoff now has clear
precedence; the bad Round 014 combined-note and global-export replacements are
superseded; the correct selected-note member set is restored; host/application claims
remain honestly absent; and the current prose grants no provider, public, remote,
deployment, economic, identity, governance, production, credential or spending
authority.

It is nevertheless unsafe to hand the package to a builder as an executable
acceptance contract. A candidate-controlled program can copy declared expected values,
mark every symbolic mutant killed, and manufacture a structurally green receipt
without exercising an application. The build/review DAG can also convert a HOLD into
an apparent final PASS because its receipt meanings are prose, not enforced state
transitions.

The small local notes application remains viable. The wider Rounds 3–10 HOLD is
separate and is not a prerequisite for repairing this narrow gate.

## 5. Finding-by-finding review of the six repairs

### Repair 1 — controlling precedence and bounded scope

Disposition: `PARTIALLY_CLOSED`.

The original builder handoff is correctly hash-pinned and ranked first. The current
Round 016 files preserve the wider HOLD and contain no present authority widening.
However, the validator does not require the exact prohibition key set, validate source
rank/effect semantics, or bind every normative Round 016 file. A checksum-updated DAG
instruction to connect DeepSeek and a public export write boundary both passed while
the validator still claimed `SPEC_CONTRACT_VALID`.

### Repair 2 — separate note-state and provenance-event schemas

Disposition: `PARTIALLY_CLOSED`.

The two closed shapes restore the required note fields, version/state binding, six
event actions, previous-event hash, and append-only/atomicity requirements. Their
behavioural rules remain non-standard `x-phase0a-*` annotations. Standard JSON Schema
therefore accepts an action with the wrong detail branch, a mismatched subject, or
transition-invalid state unless a separate reducer rejects it. Golden vectors cover
only create and preview, not edit, export, verification pass/fail, or invalid pairings.

The Round 016 validator does not apply either schema. Widening the slug to `.*`,
removing reserved slugs, adding `published`, erasing the action/detail map, or changing
the canonical hash domains all remained green.

### Repair 3 — deterministic selected-note export

Disposition: `PARTIALLY_CLOSED`.

The authorised six-member product, member order, frozen cut, STORE ZIP, fixed metadata,
manifest/receipt separation, and detached outer ZIP digest are directionally correct.
The fixture ZIP itself matches the supplied member bytes.

The specification does not define the domain-separated preimage for
`content_set_sha256` or any derivation for `export_id`, although both affect receipt and
ZIP bytes and neither appears as a repeatability input. The validator does not derive
the export from note/event inputs, recompute the receipt object, or enforce all ZIP
header and write-boundary rules. Enabling a self-hashing receipt and allowing writes
outside the workspace/public repository both remained green.

### Repair 4 — executable acceptance and candidate-evidence boundary

Disposition: `NOT_CLOSED`.

The IDs and counts are internally connected, but the cases are labels rather than
fixtures, the mutants are labels rather than transformations, and the oracle is
candidate-owned. The candidate-binding, candidate-evidence and gate-case schemas are
required by filename but never loaded or applied by `meta_validate_round16.py`.
Replacing each schema with `{}` independently remained green.

The positive evidence vector is honestly labelled synthetic, but it demonstrates the
weakness: zero/dummy Git identifiers, repeated nonexistent evidence hashes and a fake
manifest hash are accepted. No callable verifier accepts arbitrary future candidate
evidence and resolves its hashes to actual files.

### Repair 5 — narrow build/review DAG

Disposition: `PARTIALLY_CLOSED`.

The nine nodes, path/hash references, topological checks, explicit re-review node and
bootstrap exception are genuine improvements. Their outcome semantics are not
executable. Six branch conditions are declared but unused; N50, N60 and N70 have no
closed receipt schemas; and N80 consumes only a claimed N70 receipt, not the exact
reviewed binding/source/evidence.

The following trace is structurally possible under the supplied objects:

1. N50 says `HOLD`.
2. N60 says `NOT_REQUIRED`.
3. N70 says `INITIAL_PASS_CONFIRMED`.
4. N80 sees that permitted string and releases.

Changing the final condition to constant true, erasing the N50/N70 checks, and making
N70 a no-op all remained green. After an honest N70 PASS, source files, remotes or an
untracked network adapter may also change before N80 because the handoff is not bound
to the reviewed tree.

### Repair 6 — mutation-tested semantic validation

Disposition: `NOT_CLOSED`.

The supplied 36 mutations are real disposable copies, but their coverage is dominated
by missing IDs/fields and stale hash/reference failures. The validator accepts any
mutation receipt with at least 25 entries claiming nonzero rejection; it does not
require the exact mutation registry or intended error code.

Round 017 ran 20 checksum-co-updated material mutations, legitimately rebinding
dependent contract/vector hashes where required. All 20 returned exit 0 and
`SPEC_CONTRACT_VALID`. Exact records are in `EXECUTION_RECEIPT.json`.

## 6. Original-builder-handoff preservation review

| Controlling requirement | Current text | Machine-enforced closure |
|---|---|---|
| Local dashboard and banner | Preserved | No concrete DOM/HTTP fixture |
| Create/edit/preview bounded notes | Preserved | Symbolic cases only |
| Local embedded persistence/migrations | Preserved | Symbolic cases only |
| Six-action hash-linked provenance | Shape restored | Conditional behaviour and four action vectors absent |
| Selected-note deterministic export | Product restored | Identity formulas/generator incomplete |
| Deterministic fake Relay only | Named | No closed Relay schemas/algorithm/vectors |
| Raw-HTML rejection | Not preserved exactly | Script/handler cases currently expect ACCEPT-by-escaping |
| Localhost/Host/Origin/CSRF/body policy | Named | No exact request/socket fixtures |
| Required repository files and `STATUS.json` fields | Controlling prose only | Not enumerated in the acceptance contract |
| Failure evidence before repair | Named | No receipt schema or temporal/history proof |
| All 13 final-report items and command ledger | Named generically | No exact field inventory |
| No remote/provider/public/deployment authority | Present and correct | Cross-file enforcement incomplete |

A coherent removal of the dashboard `export_status` test, its case/assertions/mutant,
runner method and synthetic results remained green after counts and hashes were
legitimately updated. Thus the 26 Round 016 additions are not frozen as an exact
preservation floor.

The original instruction requires raw-HTML rejection. Round 016 instead expects
`ACCEPT` for script tags and event handlers after escaping. The safe resolution is to
reject raw HTML before persistence while still escaping defensively during rendering.

## 7. False-green and candidate-evidence review

### R17-P0A-001 — CRITICAL — symbolic cases and mutants

- **Claim:** a no-application runner can satisfy all 89 cases by echoing expected
  transition/reason values and `killed: true`.
- **File/field:** `PHASE0A_ACCEPTANCE_CONTRACT.v3.json` `cases`, `assertions`,
  `mutants`; `PHASE0A_RUNNER_INTERFACE.v1.json` `command`.
- **Reproduction:** replace every `fixture_inline` with `{}` or every
  `mutation_operator` with `NO_OP`, rebind the dependent contract/vector hashes, run
  the semantic validator; both return `SPEC_CONTRACT_VALID`.
- **Affected requirement:** executable acceptance contract and real candidate tests.
- **Required repair:** concrete immutable inputs/operations/observable outputs and
  executable candidate mutations; move the oracle outside candidate-controlled code.
- **Closure test:** an echo runner and a no-op mutant must fail without starting or
  materially changing the candidate.

### R17-P0A-002 — CRITICAL — schemas are present but unapplied

- **Claim:** load-bearing schemas can be empty while the specification stays green.
- **File/field:** candidate-binding, candidate-evidence, gate-case and DAG schema files;
  `meta_validate_round16.py` required-file loop.
- **Reproduction:** replace each schema independently with `{}`, regenerate the Round
  016 checksum, and run full/semantic validation; each returns valid.
- **Affected requirement:** exact candidate/evidence boundary and fail-closed gates.
- **Required repair:** validate every schema against its metaschema and apply it to
  every instance; reject duplicate JSON keys and require exact normative invariants.
- **Closure test:** empty/gutted schemas and unsafe candidate bindings (`/`, `main`,
  `0.0.0.0`, non-empty remotes) must fail with specific codes.

### R17-P0A-003 — CRITICAL — candidate evidence is self-attested and cyclic

- **Claim:** candidate PASS does not resolve to real Git objects or evidence bytes, and
  the manifest rule is self-referential.
- **File/field:** runner `final_evidence.manifest`; candidate evidence result hashes and
  `evidence_manifest_sha256`.
- **Reproduction:** replace every evidence/result/manifest digest with zero; the
  validator remains green. The runner also says its manifest covers every evidence file
  except itself while candidate evidence contains the manifest hash.
- **Affected requirement:** candidate-bound inspectable evidence.
- **Required repair:** raw evidence and binding -> payload manifest (excluding manifest
  and summary) -> candidate-evidence envelope -> detached final receipt; each result
  must include a safe relative path and verified byte hash.
- **Closure test:** missing/altered/unlisted/escaped evidence, fake Git objects, repeated
  arbitrary hashes, reversed times and a manifest cycle all fail.

### R17-P0A-004 — CRITICAL — review/HOLD state machine is bypassable

- **Claim:** a HOLD can be converted to final eligibility by untyped downstream
  receipt strings.
- **File/field:** condition registry; DAG N50/N60/N70/N80.
- **Reproduction:** the `HOLD -> NOT_REQUIRED -> INITIAL_PASS_CONFIRMED` trace has no
  machine prohibition; changing the final condition to constant true also stays green.
- **Affected requirement:** mandatory independent review and re-review.
- **Required repair:** closed node receipt schemas plus an executable transition table;
  HOLD terminal, no-op only after exact PASS, repair only after REPAIR_REQUIRED, and
  actor/candidate identity bound at every edge.
- **Closure test:** exhaustive outcome matrix permits only
  `PASS -> NOT_REQUIRED -> INITIAL_PASS_CONFIRMED` and
  `REPAIR_REQUIRED -> REPAIRED -> PASS_AFTER_REPAIR`.

### R17-P0A-005 — CRITICAL — final handoff is not the reviewed candidate

- **Claim:** N80 can package bytes different from those reviewed at N70.
- **File/field:** `PHASE0A_BUILD_DAG.v1.json` N80 `consumes` and
  `required_checks`.
- **Reproduction:** N80 consumes only the re-review receipt, not binding/tree/source
  manifest/evidence, and permits “clean or explained” status.
- **Affected requirement:** trustworthy final local ZIP and status.
- **Required repair:** N80 consumes the exact reviewed binding/manifests, packages the
  immutable reviewed tree, and immediately rechecks remotes, bind, provider absence and
  tracked/untracked state.
- **Closure test:** post-N70 source edit, untracked adapter or new remote must block N80.

### R17-P0A-006 — CRITICAL — semantic validator has broad false-green coverage

- **Claim:** `false_green: 0` is true only for the supplied 36 mutation classes.
- **File/field:** `meta_validate_round16.py`; Round 016 mutation registry/receipt.
- **Reproduction:** 20/20 Round 017 material mutations remained green, including empty
  schemas/fixtures, no-op mutants, traversal slug, published status, changed hash
  domains, widened export writes, self-hashing receipt, runner evidence bypass,
  fictitious evidence, constant final condition, erased review checks, hidden provider
  instruction, false implementation claim and coherent required-test removal.
- **Affected requirement:** fail-closed specification validation.
- **Required repair:** exact semantic invariants, dependency-aware mutations, exact
  error-code oracle, exact unique receipt coverage, and deterministic output ordering.
- **Closure test:** every supplied and Round 017 mutation fails for its intended reason
  in full and semantic modes across multiple `PYTHONHASHSEED` values.

### R17-P0A-007 — HIGH — export identity and verifier are incomplete

- **Claim:** two independent builders cannot uniquely derive every receipt/ZIP byte
  from the normative text.
- **File/field:** selected-note export `content_set_sha256`, `export_id`; golden vector;
  meta-validator export checks.
- **Reproduction:** no formula for either identity is present; changing receipt-hash
  exclusion or canonical receipt domain remains green.
- **Affected requirement:** deterministic export and receipts.
- **Required repair:** exact domain-separated preimages, closed metadata/receipt
  schemas, input-to-ZIP generator and independent verifier.
- **Closure test:** two fresh independent generators reproduce the golden ZIP exactly;
  random IDs, self-reference and any member/header mutation fail.

### R17-P0A-008 — HIGH — original handoff floor is removable

- **Claim:** required functionality can be coherently removed without invalidating the
  machine contract.
- **File/field:** acceptance-contract Round 016 additions and original-handoff mapping.
- **Reproduction:** remove dashboard export status and all dependent objects, update
  counts/bindings; validator returns valid.
- **Affected requirement:** dashboard, required repository/report/security disciplines.
- **Required repair:** one exact hash-pinned handoff-requirement registry with mandatory
  test IDs, required files, STATUS/report fields, raw-HTML policy and final sealing order.
- **Closure test:** removal of any requirement/test/file/report field fails.

### R17-P0A-009 — HIGH — host/lock and branch paths are incomplete

- **Claim:** the DAG names host states but cannot exhaustively decide them or produce
  the writer receipt required by candidate binding.
- **File/field:** condition registry; N10/N20 outputs; candidate binding
  `active_writer_receipt_sha256`.
- **Reproduction:** host conditions are unused; N10 outputs a decision, not the closed
  receipt whose digest is later mandatory.
- **Affected requirement:** exact safe host preflight and single writer.
- **Required repair:** typed path/realpath/repository/lock receipt and exhaustive
  fail-closed state matrix.
- **Closure test:** absent, empty, Git, non-empty non-Git, symlink, unwritable, stale
  lock and live foreign lock cases all take exactly one defined path.

### R17-P0A-010 — HIGH — Relay and web security remain name-only

- **Claim:** typed Relay, raw-HTML rejection and localhost request policy lack exact
  schemas/fixtures/oracles.
- **File/field:** acceptance cases for Relay, raw HTML and web; no normative Relay
  schema or fake algorithm exists.
- **Reproduction:** each fixture contains only its test name; the raw script/event
  handler cases expect ACCEPT rather than the requested rejection.
- **Affected requirement:** fake/offline Relay, raw-HTML rejection and localhost-only
  security.
- **Required repair:** closed Relay schemas/limits/hash rules/goldens; concrete hostile
  HTTP/HTML inputs; observed socket/network evidence.
- **Closure test:** independent fake adapters match exact bytes, no network adapter can
  load, raw HTML creates no note/event, and hostile bind/Host/Origin/CSRF/body cases fail.

## 8. Build DAG and independent re-review path

The current graph is structurally acyclic and all named node/output references resolve.
That is real progress. It is not an executable release graph.

Round 018 must provide:

1. closed receipts for host preflight, writer lock, initial review, repair decision,
   re-review and final handoff;
2. a deterministic evaluator for every allowed and forbidden trace;
3. a terminal HOLD edge;
4. explicit PASS/no-op and REPAIR_REQUIRED/repaired branches;
5. candidate/spec/source/evidence hashes carried unchanged or intentionally replaced
   through each edge;
6. an N80 seal over the exact reviewed tree with no post-review difference.

## 9. Authority-boundary review

No actual public, provider, remote, deployment, identity, NEX/LEX, federation,
governance, credential, production, spending or GitHub authority widening was found in
the unmodified Round 016 package. Host state and application state are explicitly
unverified. Those are positive findings.

The machine encoding is unnecessarily ambiguous: `prohibited_authority` stores `false`
for prohibited actions, which naturally reads as “not prohibited”. Use an unambiguous
`authority_granted: false` or a `prohibited_actions` array. More importantly, the
validator must compare this boundary against every command, DAG node, export path and
adapter declaration. Present prose is controlling, but a green badge does not currently
prove that all subordinate files obey it.

## 10. Required amendments

Round 018 must, at minimum:

1. publish one exact normative Phase 0A manifest covering precedence, canonical rules,
   schemas, fixtures, goldens, runner/oracle, evidence contract, DAG and conditions;
2. bind that normative-manifest hash into candidate binding, candidate evidence, review
   receipts and final handoff;
3. apply closed schemas and cross-file semantic checks rather than presence-check them;
4. replace all symbolic cases with concrete immutable inputs, operations and observable
   outputs, preserving the exact handoff/test floor;
5. replace mutant labels with executable material candidate mutations and an
   independently controlled oracle;
6. define an acyclic, path-resolved evidence package and verify real Git/file bytes;
7. define typed DAG receipts and a complete executable transition evaluator;
8. bind N80 to the exact re-reviewed tree and forbid post-review source/remote changes;
9. finish export identity formulas, schemas, generator and independent verification;
10. add exact fake Relay, raw-HTML rejection and localhost/web-security schemas/vectors;
11. bind required repository files, STATUS/detached-commit semantics, failure chronology,
    command ledger and all final report/ZIP exclusions;
12. rerun dependency-aware official and Round 017 mutations with exact reason codes and
    deterministic receipts.

## 11. Residual blockers and unknowns

The following are preserved honestly and are not claimed closed:

1. `/home/anon/Projects/Pioneer-Alignment-App` host/path/repository/writer state;
2. application implementation or candidate test evidence;
3. fresh exact private-GitHub backup authority;
4. wider Rounds 3–10 architecture;
5. exact canon snapshots required only for that wider architecture;
6. real identities, balances, ballots, providers, federation or private-person data;
7. deployment, production, DNS, Cloudflare, credentials or spending.

A selected-note provenance excerpt also filters a globally hash-linked ledger. If other
notes interleave, predecessor links in the excerpt may point to omitted events. Round
018 should either declare the excerpt non-contiguous and non-self-verifying or provide a
privacy-safe bridge/anchor format and an interleaved-note golden vector.

## 12. Exact next action

The controlling ChatGPT should perform one bounded Round 018 specification/gate repair
under a new exchange directory. It must not build the application or touch any
repository/remote/provider/public/production state.

Round 018 should implement the twelve amendments above, include the Round 017 twenty
mutation classes as mandatory dependency-aware tests, and return one complete v9 relay
for independent re-review. Phase 0A may be released to a local builder only after the
independent oracle, concrete fixtures, acyclic evidence protocol and executable review
state machine all reject their negative controls and every material mutation.
