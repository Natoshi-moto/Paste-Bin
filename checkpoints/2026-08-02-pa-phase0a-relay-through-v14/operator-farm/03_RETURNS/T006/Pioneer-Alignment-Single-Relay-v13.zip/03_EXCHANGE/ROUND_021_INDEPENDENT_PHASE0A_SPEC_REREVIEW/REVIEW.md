# Round 021 — independent Phase 0A specification re-review of Round 020

Adjudication: **`HOLD_FOR_FURTHER_PHASE0A_SPEC_REPAIR`**

Reviewer: independent Round 021 Phase 0A specification/gate reviewer.
Reviewed package: `03_EXCHANGE/ROUND_020_CONTROLLING_PHASE0A_REPAIR`.
Input archive: `Pioneer-Alignment-Single-Relay-v11.zip`,
SHA-256 `77d2ae654e770ba7008074edcb0c55fe0bc15021dac010fd2dced0b63ceea044` — verified
against both declared copies before unpacking.

This reviewer did not author Round 020, did not build an application, did not
mutate a repository, and took no external action. No credential, provider, DNS,
Cloudflare, deployment, wallet, on-chain or GitHub operation was performed.

---

## 1. Verdict in one paragraph

Round 020 is a large and mostly genuine repair. Every official tool reproduces
green, the full 46-class registry rejects with zero false greens, receipts are
byte-identical across `PYTHONHASHSEED=1` and `2`, and five of the seven Round 019
findings are closed against attacks well beyond their registered representatives.
But Round 020 is held. Of twelve material mutation classes invented outside the
46-class registry, **three false-green**. One of them is disqualifying on its own:
a file carrying verbatim prohibited-authority directives — *push the candidate
tree to a public GitHub repository*, *deploy to Cloudflare*, *change DNS using
provider credentials*, *bind to 0.0.0.0*, *connect DeepSeek as provider* — can be
shipped inside the Round 020 package, be covered by the round checksum manifest,
and still pass all six documented tools with exit 0. That is an authority-widening
green path, and the release criteria forbid release when one exists.

---

## 2. Commands executed

All Python invoked as `PYTHONDONTWRITEBYTECODE=1 python3 -S`. Official tools were
run on a disposable unpack, never on the shipped tree, because several of them
write receipts next to themselves; the shipped Round 020 bytes were confirmed
unchanged afterwards.

```text
sha256sum /home/anon/Downloads/Pioneer-Alignment-Single-Relay-v11.zip
unzip -q Pioneer-Alignment-Single-Relay-v11.zip -d relay

python3 -S 04_TOOLS/verify_input_manifest.py
cd 03_EXCHANGE/ROUND_020_CONTROLLING_PHASE0A_REPAIR
python3 -S meta_validate_round20.py --semantic-only
python3 -S meta_validate_round20.py
python3 -S independent_oracle.py
python3 -S transition_evaluator.py
python3 -S export_generator.py
python3 -S export_verifier.py
python3 -S run_round20_closure_probes.py

PYTHONHASHSEED=1 python3 -S run_round20_mutations.py --full --output-json ... --output-md ...
PYTHONHASHSEED=2 python3 -S run_round20_mutations.py --full --output-json ... --output-md ...
PYTHONHASHSEED=1 python3 -S run_round20_closure_probes.py --output-json ...
PYTHONHASHSEED=2 python3 -S run_round20_closure_probes.py --output-json ...

python3 -S run_round20_mutations.py --full --only R19-P01... --only R19-P08... (8 classes)

python3 -S r21_probes.py --relay-root <relay> --output-json receipts/INDEPENDENT_PROBE_RECEIPT.json
python3 -S r21_authority_surface.py --relay-root <relay> --output-json receipts/AUTHORITY_SURFACE_RECEIPT.json
```

### 2.1 Reproduction results

| Check | Claimed by R020 | Observed by R021 | Verdict |
|---|---|---|---|
| `verify_input_manifest.py` | exit 0 | exit 0, 800 immutable files | reproduces |
| `meta_validate --semantic-only` | `SPEC_CONTRACT_VALID` | `SPEC_CONTRACT_VALID`, 0 errors | reproduces |
| `meta_validate` (full) | `SPEC_CONTRACT_VALID` | `SPEC_CONTRACT_VALID`, 0 errors | reproduces |
| `independent_oracle.py` | 54 decided / 35 deferred, `candidate_pass_eligible=false` | identical | reproduces |
| `transition_evaluator.py` | 36 traces, 2 allowed, 12 HOLD-origin terminal | identical | reproduces |
| `export_generator.py` | `matches_golden=true` | identical, all four digests match | reproduces |
| `export_verifier.py` | `ok=true` | identical | reproduces |
| Registry mutations | 46 rejected / 0 false-green | 46 rejected / 0 false-green / 0 wrong-reason | reproduces |
| Closure probes | 23 negatives, 7 findings, PASS | identical | reproduces |
| Seed identity (mutations) | byte-identical seeds 1 and 2 | byte-identical, JSON **and** Markdown | reproduces |
| Seed identity (closure) | byte-identical | byte-identical | reproduces |
| R19-P01..P08 re-applied | reject | 8/8 reject, 0 wrong-reason | reproduces |

The official evidence is honest as far as it goes. Nothing in the Round 020
receipt set was found to be fabricated.

---

## 3. Independent probes — twelve classes outside the registry

Each probe is applied to a disposable full-relay copy under `/tmp` and is
coherently rebound using Round 020's *own* `rebind_acyclic` helper, which
re-hashes normative-manifest members, rebinds contract and manifest digests into
the evidence envelope, and regenerates the round checksum file. Probes that touch
`PHASE0A_SECURITY_CONSTANTS.v1.json` additionally repin the SHA-256 constant
embedded in `lib_phase0a.py`, exactly as Round 020's own closure probes do.

That repinning step matters and is worth recording. On the first pass, four
probes appeared to "reject" with all six tools exiting 1 and **no structured
reason codes at all**. That was not a security control firing — it was
`RuntimeError: SECURITY_CONSTANTS_DIGEST_MISMATCH` at import, crashing every tool
before any semantic check ran. Scored naively, Round 020 would have been credited
with four rejections it had not earned. After repinning, three of those four
reject for genuine structured reasons and one false-greens. A reviewer who does
not repin will overstate Round 020's coverage.

False-green criterion, identical to Rounds 019 and 020: all six documented tools
exit 0 after the mutation.

| Probe | Attack | Result | Reason codes |
|---|---|---|---|
| R21-P01-RUNNER-METHOD-REASSIGN | swap `runner_method` between two deferred cases (field is excluded from the locked semantic projection) | REJECTED | `TEST_CASE_SEMANTIC_BINDING_MISMATCH` |
| R21-P02-SLUG-MAXLENGTH-WIDEN | widen `slug.max_length` 80 → 100000 in constants **and** schema, repinned | **FALSE GREEN** | — |
| R21-P03-AUTHORITY-ZERO-WIDTH-HOMOGLYPH | authority directives with ZWSP, NBSP, ZWJ and a Cyrillic homoglyph | REJECTED | `AUTHORITY_PROHIBITED_TEXT` |
| R21-P04-MARKDOWN-DATAURI-ACTIVE-CONTENT | `data:text/html;base64` link and obfuscated `javascript:` URIs persisted as safe markdown | REJECTED | `ORACLE_EXPECTATION_MISMATCH`, `EVIDENCE_CASE_RESULT_SEMANTIC_MISMATCH` |
| R21-P05-EVIDENCE-EXTRA-UNLISTED-FILE | unreferenced extra file smuggled into the synthetic evidence root | REJECTED | `EVIDENCE_FIXTURE_SET_MISMATCH` |
| R21-P06-HOLD-RENAME-VOCAB-EXTENSION | renamed HOLD origin `HOLD_CLEARED` admitted via extended n50 vocabulary | REJECTED | `TRANSITION_EXHAUSTIVE_CARDINALITY_MISMATCH`, `TRANSITION_N50_INDEPENDENT_ANCHOR_MISMATCH` |
| R21-P07-DEFERRED-COUNTED-IN-PASS-TOTAL | launder all 35 deferred cases into the pass denominator at the declaration layer only | REJECTED | `DEFERRED_SPEC_PASS_CLAIM`, `ORACLE_DEFERRED_COUNT_MISMATCH`, `ORACLE_PASS_DENOMINATOR_MISMATCH` |
| R21-P08-EXPORT-DOMAIN-COHERENT-REBIND | change the normative `export_id` domain separator | **FALSE GREEN** | — |
| R21-P09-NEW-REFLEXIVE-OPERATION-NAME | reflexive echo under unblacklisted kind `REPLAY_DECLARED_OBSERVABLE` | REJECTED | `CASE_NOT_ORACLE_DECIDABLE`, `INVALID_FIXTURE_INPUT` |
| R21-P10-AUTHORITY-IN-SUBDIRECTORY-FILE | prohibited-authority directives in an undeclared package file | **FALSE GREEN** | — |
| R21-P11-EVIDENCE-SYMLINK-ESCAPE | evidence path replaced by symlink to identical bytes outside the tree | REJECTED | `NORMATIVE_MEMBER_SYMLINK`, `EVIDENCE_PATH_UNSAFE` |
| R21-P12-ASSERTION-OWNERSHIP-REASSIGN | handoff-floor assertions reassigned to another test, totals preserved | REJECTED | `CASE_ASSERTION_SEMANTIC_SET_MISMATCH` |

**invented = 12, false_green = 3, rejected = 9.**

The probe receipt is byte-identical across `PYTHONHASHSEED=1` and `2`.

---

## 4. Findings

### R21-F01 — CRITICAL — authority scan is bounded by manifest membership, not package membership

`meta_validate_round20.py` scans string leaves and literals of files that are
declared members of `PHASE0A_NORMATIVE_MANIFEST.v1.json`. Round-package membership
is a strictly larger set: `SHA256SUMS.txt` covers every file in the round
directory. Files in the gap ship with the package, are checksum-covered, and are
never authority-scanned.

`r21_authority_surface.py` tests eight locations and extensions with payloads
copied verbatim from `authority.reject_substrings`. **All eight are unscanned:**

| Location | Extension | In round `SHA256SUMS.txt` | Result |
|---|---|---|---|
| `OPERATOR_NOTES.md` | Markdown | yes | UNSCANNED |
| `OPERATOR_PLAN.json` | JSON | yes | UNSCANNED |
| `operator_helper.py` | Python | yes | UNSCANNED |
| `operator.txt` | text | yes | UNSCANNED |
| `operator.jsonl` | JSONL | yes | UNSCANNED |
| `goldens/OPERATOR_NOTES.md` | Markdown | yes | UNSCANNED |
| `fixtures/OPERATOR_NOTES.md` | Markdown | yes | UNSCANNED |
| `evidence_fixtures/OPERATOR_NOTES.md` | Markdown | yes | UNSCANNED |

This is not a subdirectory-recursion bug; it is systemic across every location and
every declared-supported extension, including the exact JSON and Python member
types Round 020's summary claims to cover.

Round 020 did consider adjacent shapes and closes both of them:
`R20-F02-MANIFEST-OMISSION-RELABEL-BYPASS` *removes* an existing required member
(caught, because required members must be present), and
`R20-F02-UNSUPPORTED-NORMATIVE-EXTENSION` *adds a declared member* with an
unsupported extension (caught, because declared members are extension-checked).
Neither tests the simplest move: add a file and simply do not declare it. There is
no check binding package membership to normative membership, so the attacker
never has to touch the manifest at all.

R19-F02's closure test was: *"an instruction naming any prohibited action, in any
normative file, in any field, must fail with a specific code."* Round 020 satisfies
that sentence only under the reading that an undeclared file is not "normative".
Under the operative reading — can this package be greened while it contains
instructions to push to public GitHub and deploy to Cloudflare — the answer is yes.
**R19-F02 is not closed.**

Suggested repair: require that every file covered by the round `SHA256SUMS.txt` be
either a declared normative member or a member of an explicit, hash-pinned
non-normative allowlist, and authority-scan the union. Fail closed on any file in
neither set.

### R21-F02 — HIGH — `slug.max_length` is coherently weakenable

`SLUG_MAX_LENGTH` is a real enforced control: `lib_phase0a.py:206` rejects any slug
longer than it. `meta_validate_round20.py:285` cross-checks the note schema's
`maxLength` against it and raises `SLUG_MAX_LENGTH_SOURCE_MISMATCH` on divergence.
That is a *consistency* check, not a *floor* check — moving both together passes.

The behavioral corpus cannot catch the drift either: the longest entry in
`slug.hostile_corpus` is 14 characters, so no fixture exercises the length bound at
all. Widening 80 → 100000 in constants and schema together, with the
`lib_phase0a.py` pin refreshed, greens all six tools.

`R20-C05-SLUG-SOURCE-COHERENT-WEAKEN-MATRIX` covers `pattern` and `reserved` only.
This is the same defect shape R19-F05 described — a security constant silently
weakened while everything stays green — surviving in the one dimension the matrix
does not enumerate. **R19-F05 is not fully closed.**

Suggested repair: pin `max_length` to an exact expected value independently of the
schema, and add over-length entries to `hostile_corpus` so the bound is
behaviorally exercised.

### R21-F03 — MEDIUM — normative export identity domains are unenforced

`PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v3.json` declares
`identity.export_id.domain = "PA-P0A-EXPORT-ID-V1"`, and matching domains for
`content_set_sha256` and `receipt_hash`. `lib_phase0a.py:62-64` hardcodes those
three constants. Nothing cross-checks the two. The validator inspects the export
spec only for the *presence* of `identity.content_set_sha256` and
`identity.export_id` (`meta_validate_round20.py:359-361`), never their values.

Changing the spec's declared domain to `PA-P0A-EXPORT-ID-V2` greens all six tools,
because `export_generator.py` derives everything from the hardcoded library
constant and compares against the golden vector, which is also library-derived.

`R17-M13-CANONICAL-HASH-DOMAINS-CHANGED` rejects, but it attacks
`PHASE0A_CANONICAL_RULES.v2.json`, whose hash domains *are* cross-checked. The
export spec's identity block is not.

This is not a live bypass — today's golden still reproduces. It matters because of
what release means here: the spec is what a bounded local builder implements from.
A builder reading a silently altered spec would derive different export
identities than the reference library, and the gate would not detect the
divergence. An unenforced normative field in the exact document being handed off is
material to that handoff.

Suggested repair: assert the three declared spec domains equal
`DOMAIN_EXPORT_ID`, `DOMAIN_CONTENT_SET` and `DOMAIN_RECEIPT`.

### R21-F04 — MEDIUM — shipped operational receipts do not reproduce

The shipped receipts disagree with a fresh run of the shipped tools on the shipped
bytes, and with each other. `authority_strings_scanned` is reported as:

| Source | Value |
|---|---|
| `CLOSURE_PROBE_RECEIPT.json` `baseline_validation` | 15590 |
| `SPEC_VALIDATION_RECEIPT.json` and `.semantic.json` | 15597 |
| live re-run, both modes, three independent unpacks | **15600** |

Consequently `MUTATION_RECEIPTS.json` and `CLOSURE_PROBE_RECEIPT.json` do not
reproduce byte-identically. Every one of the 94 diffs in `MUTATION_RECEIPTS.json`
is a `stdout_sha256` field differing only because the embedded scan count differs;
`MUTATION_RECEIPTS.md` reproduces exactly, and **every verdict — 46 rejected, 0
false-green, 0 wrong-reason — matches.** File timestamps show why: the receipts
were written at 17:36 and `PHASE0A_NORMATIVE_MANIFEST.v1.json` was regenerated at
17:38 and never re-receipted. `EXECUTION_RECEIPT.json` half-admits this with
`"performed_on_pre_final_archive": true`.

The internal cross-hash chain is self-consistent — each receipt's file digest
matches its `receipt_sha256` entry — so this is staleness, not fabrication, and no
verdict is affected. But `REPAIR_SUMMARY.md` claims operational receipts are
"content-validated and cross-hashed", and the validator does not notice that its
own shipped receipt disagrees with its live output. Reported as MEDIUM: it is an
integrity-hygiene defect, not a bypass, and it is not the reason for the HOLD.

---

## 5. Round 019 finding disposition

| Finding | R020 claim | R021 verdict | Basis |
|---|---|---|---|
| R19-F01 oracle blind/echoing | closed | **CLOSED** | 54 decided / 35 deferred reproduce; R19-P01 rejects; R21-P09 shows a *new* reflexive operation name fails closed rather than echoing |
| R19-F02 authority scan dead code | closed | **OPEN** | R21-F01: eight undeclared-file locations ship prohibited-authority text and green all six tools |
| R19-F03 raw HTML by case-ID substring | closed | **CLOSED** | R19-P07 rejects; R21-P04 shows detection is payload-semantic and reaches non-tag active content (`data:text/html`, obfuscated `javascript:`) |
| R19-F04 evidence hashes unresolved | closed | **CLOSED** | R19-P04 rejects; R21-P05 and R21-P11 both rejected with `EVIDENCE_FIXTURE_SET_MISMATCH`, `EVIDENCE_PATH_UNSAFE`, `NORMATIVE_MEMBER_SYMLINK` |
| R19-F05 schema constants weakenable | closed | **OPEN** | R21-F02: `max_length` widens coherently 80 → 100000 while green |
| R19-F06 documented command fails on clean unpack | closed | **CLOSED** | documented command returns exit 0 on three fresh unpacks; no manifest-covered byte modified; zero bytecode entries in the archive |
| R19-F07 declared-example gates vacuous | closed | **CLOSED** | R19-P05 rejects; R21-P06 shows forbidden traces are exhaustively derived — extending the n50 vocabulary raises `FORBIDDEN_EXAMPLES_DERIVATION_MISMATCH` and `TRANSITION_EXHAUSTIVE_CARDINALITY_MISMATCH` |

Closed: 5. Open: 2 (R19-F02, R19-F05).

---

## 6. Hard questions

**1. Are R19-F01..F07 actually closed, or only closed against the known 46-class
registry?**

Five are genuinely closed — they reject attacks materially different from their
registered representatives, which is the real test. Two are closed only against
their registry representatives. R19-F02's scan is complete over the set it scans
and blind to everything outside it; R19-F05's cross-check covers two of the three
constants it protects. The pattern is the same in both: Round 020 built strong
enforcement over an enumerated set and did not close the set.

**2. Is DEFERRED honest? Can deferred cases launder candidate PASS or release?**

Yes, honest; no laundering found. `candidate_pass_eligible` is computed as
`not failures and not deferred` from the oracle's own per-case dispositions, not
from any declared count. R21-P07 attacked this hard: it flagged every deferred
test and assertion `counted_in_spec_oracle_pass_total`, rebound the denominator to
89 with 0 deferred, set `candidate_pass_eligible_at_spec_stage` true, cleared the
blocker, and switched off `candidate_pass_requires_zero_deferred` — all without
touching a single case body, so the locked semantic corpus hash was unchanged. It
was rejected with eight distinct structured codes including `DEFERRED_SPEC_PASS_CLAIM`
and `ORACLE_PASS_DENOMINATOR_MISMATCH`. The deferral of 35 candidate-required cases
is real and correctly blocks candidate PASS. This is the strongest part of the
Round 020 repair.

**3. Can you green the package after injecting public GitHub push / Cloudflare
deploy language?**

**Yes.** This is the disqualifying finding. Eight of eight tested locations
accept verbatim `reject_substrings` text and green all six tools — see R21-F01.
Obfuscated payloads inside *declared* members are caught correctly (R21-P03: ZWSP,
NBSP, ZWJ and Cyrillic homoglyph all raise `AUTHORITY_PROHIBITED_TEXT`), so the
scanner itself is sound. The failure is coverage, not detection.

**4. Can raw HTML still persist via rename/rewrite games?**

No. Detection is payload-semantic and independent of case and test identifiers.
R19-P07 rejects on re-application, and R21-P04 shows the guard reaches beyond the
tag-shaped pattern list: a `data:text/html;base64` markdown link and
whitespace/entity-obfuscated `javascript:` URIs, containing no angle bracket at
all, were independently judged unsafe by the oracle and produced
`ORACLE_EXPECTATION_MISMATCH` against the case's ACCEPT expectation. R19-F03 is
closed.

**5. Is HOLD still terminal? Can N80 release non-reviewed bytes?**

HOLD is terminal and N80 identity holds. All 36 N50/N60/N70 traces are derived
exhaustively; exactly 2 are admitted; all 12 HOLD-origin traces return terminal.
R21-P06 attacked terminality as a *naming* property — adding a renamed
HOLD-equivalent origin `HOLD_CLEARED` to the n50 vocabulary with a matching
allowed trace — and was rejected against an independent anchor
(`TRANSITION_N50_INDEPENDENT_ANCHOR_MISMATCH`,
`TRANSITION_ALLOWED_INDEPENDENT_ANCHOR_MISMATCH`,
`TRANSITION_EXHAUSTIVE_CARDINALITY_MISMATCH`). The N80 checker independently
rejects binding, tree, source-manifest and evidence identity mismatches plus
remotes, non-loopback bind, provider adapters and forbidden untracked files. No
path was found by which N80 releases non-reviewed bytes.

**6. Did Round 020 break export identity or hashseed determinism?**

Determinism is intact: mutation and closure receipts are byte-identical across
`PYTHONHASHSEED=1` and `2` in both JSON and Markdown, and my own probe receipt is
seed-identical too. Export identity reproduces exactly — `export_id`,
`content_set_sha256`, `receipt_hash` and `zip_sha256` all match the golden vector,
and R17-M14/M15 (write-boundary widen, self-hashing receipt) still reject. The one
defect is R21-F03: the *declared normative* domain separators are decorative,
enforced nowhere against the hardcoded library constants. Identity is not broken;
its specification is not binding.

**7. Exact next actor and action.**

Next actor: **controlling Phase 0A repair engineer, Round 022**, scope
`BOUNDED_PHASE0A_SPECIFICATION_AND_EXECUTABLE_GATE_REPAIR_ONLY`.

Required actions, in order:

1. Close R21-F01. Bind authority-scan coverage to round-package membership: every
   file in the round `SHA256SUMS.txt` must be a declared normative member or on an
   explicit hash-pinned non-normative allowlist; scan the union; fail closed on
   any file in neither set. Add the eight `r21_authority_surface.py` variants as
   permanent registry classes.
2. Close R21-F02. Pin `slug.max_length` to an independently anchored exact value
   and add over-length entries to `slug.hostile_corpus`.
3. Close R21-F03. Assert the three export-spec identity domains equal
   `DOMAIN_EXPORT_ID`, `DOMAIN_CONTENT_SET` and `DOMAIN_RECEIPT`.
4. Close R21-F04. Regenerate every operational receipt as the final build step,
   after the last manifest regeneration, and reconcile the three
   `authority_strings_scanned` values.
5. Adopt `r21_probes.py` (all twelve classes) into the registry, and adopt the
   constants-repin discipline so that a `SECURITY_CONSTANTS_DIGEST_MISMATCH` crash
   is never scored as a rejection.
6. Return `Pioneer-Alignment-Single-Relay-v13.zip` for a Round 023 independent
   re-review.

Not authorised for the next actor, unchanged: application build, repository
mutation, host preflight, deployment, DNS/Cloudflare, credentials, provider
connection, public GitHub, public NEX/LEX, federation, governance, spending.

---

## 7. Scope and claims not made

No application candidate exists. Application tests were not run. Host preflight
was not run. No repository was mutated, no branch or commit created, no remote
configured, no provider connected, no credential accessed, no deployment, DNS or
Cloudflare action taken, no money spent, no wider architecture promoted, and no
prior-round bytes altered. All probe trees were disposable copies beneath `/tmp`
and were destroyed after use.

The four preserved external blockers are unchanged and remain outside Phase 0A
specification scope:
`EXACT_WRITABLE_PHASE0A_HOST_STATE_UNVERIFIED`,
`NO_APPLICATION_IMPLEMENTATION_EVIDENCE`,
`NO_CURRENT_PRIVATE_GITHUB_BACKUP_AUTHORITY`,
`EXACT_CANON_SOURCE_SNAPSHOTS_MISSING_FOR_WIDER_ARCHITECTURE`.
