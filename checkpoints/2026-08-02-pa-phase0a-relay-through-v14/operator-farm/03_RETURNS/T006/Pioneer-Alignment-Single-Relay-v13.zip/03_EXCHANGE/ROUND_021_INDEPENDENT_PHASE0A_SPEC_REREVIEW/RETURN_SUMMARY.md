# Round 021 return summary

Adjudication: **`HOLD_FOR_FURTHER_PHASE0A_SPEC_REPAIR`**

The Phase 0A specification is **not** released to a bounded local builder.

## Why

Round 020's own evidence reproduces completely and honestly. All six documented
tools return exit 0, the 46-class registry rejects with zero false greens and zero
wrong-reason rejections, closure probes close all seven Round 019 findings against
23 negatives, receipts are byte-identical across `PYTHONHASHSEED=1` and `2`, and
all eight Round 019 probe classes still reject on re-application.

Twelve material mutation classes invented outside that registry were run against
disposable relay copies, each coherently rebound with Round 020's own
`rebind_acyclic` helper. **Three false-greened.** The release criteria require zero.

- **R21-F01 (CRITICAL)** — a file carrying verbatim prohibited-authority
  directives (*push the candidate tree to a public GitHub repository*, *deploy to
  Cloudflare*, *change DNS using provider credentials*, *bind to 0.0.0.0*,
  *connect DeepSeek as provider*) can ship inside the Round 020 package, be
  covered by the round checksum manifest, and still green all six tools. The
  authority scan enumerates declared normative members; package membership is
  larger; everything in the gap is unscanned. Verified at 8 of 8 locations across
  Markdown, JSON, JSONL, text and Python, including top level. This is an
  authority-widening green path, which the criteria forbid outright.
- **R21-F02 (HIGH)** — `slug.max_length` can be widened 80 → 100000 coherently
  across constants and schema while green. The cross-check is a consistency check,
  not a floor, and the hostile corpus has no over-length entry.
- **R21-F03 (MEDIUM)** — the normative export-identity domain separators are
  enforced nowhere against the hardcoded library constants; the declared spec
  value can be changed undetected.
- **R21-F04 (MEDIUM, non-blocking)** — shipped operational receipts are stale.
  `authority_strings_scanned` reads 15590 / 15597 / 15600 across the closure
  receipt, the spec receipts and a live run. Staleness only: the cross-hash chain
  is self-consistent and every verdict matches.

## Round 019 findings

Closed: R19-F01, R19-F03, R19-F04, R19-F06, R19-F07 — genuinely, against attacks
materially different from their registered representatives.
Open: **R19-F02** (successor R21-F01) and **R19-F05** (successor R21-F02). Both
were closed over an enumerated set that was never itself closed.

## What held up under attack

Worth recording, because these were the priority attack surfaces and they held:

- **DEFERRED is honest.** All 35 candidate-required deferrals are real and block
  candidate PASS. A declaration-layer laundering attack that left every case body
  untouched — so the locked corpus hash never changed — was rejected with eight
  distinct structured codes.
- **HOLD is terminal**, including against a renamed HOLD origin admitted through
  an extended vocabulary; terminality is anchored independently, not by string.
- **N80 cannot release non-reviewed bytes.**
- **Raw HTML / active content** detection is payload-semantic and reaches beyond
  tag shapes to `data:text/html` and obfuscated `javascript:` URIs.
- **Evidence integrity** rejects symlink escape, path escape and fixture-set drift.
- **Export identity and hash-seed determinism** reproduce exactly.

## Methodological note for the next reviewer

`lib_phase0a.py` pins the SHA-256 of `PHASE0A_SECURITY_CONSTANTS.v1.json` and
raises `SECURITY_CONSTANTS_DIGEST_MISMATCH` at import. Any probe that edits that
file without repinning crashes all six tools before a single semantic check runs.
Four probes initially looked "rejected" for exactly that reason — all six tools
exit 1, no structured reason codes. Scored naively, Round 020 would have been
credited with four rejections it had not earned; after repinning, one of the four
false-greens. **A rejection with no structured reason code should be treated as
inconclusive until the crash cause is identified.**

## Next actor

**Controlling Phase 0A repair engineer, Round 022.** Scope unchanged:
`BOUNDED_PHASE0A_SPECIFICATION_AND_EXECUTABLE_GATE_REPAIR_ONLY`. Close R21-F01
through R21-F04, adopt all twelve `r21_probes.py` classes and the eight
`r21_authority_surface.py` variants into the registry, and return
`Pioneer-Alignment-Single-Relay-v13.zip` for a Round 023 independent re-review.

## Scope

No application candidate exists. Application tests not run. Host preflight not
run. No repository mutation, branch, commit, remote, push, provider connection,
credential access, deployment, DNS or Cloudflare action, spending, public
NEX/LEX/federation/governance, or canon promotion. No prior-round bytes altered.
All probe trees were disposable copies beneath `/tmp` and were destroyed.
