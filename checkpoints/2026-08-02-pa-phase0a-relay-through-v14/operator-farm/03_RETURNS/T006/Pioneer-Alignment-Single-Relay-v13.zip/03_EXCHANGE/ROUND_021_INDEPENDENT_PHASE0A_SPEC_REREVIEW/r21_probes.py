#!/usr/bin/env python3
"""Round 021 independent probe harness.

Twelve material mutation classes invented outside the Round 020 46-class
registry.  Every probe is applied to a disposable full-relay copy under /tmp and
is coherently rebound with Round 020's own `rebind_acyclic` helper, so a probe
that still greens is a genuine false green and not a checksum artefact.

False green criterion (identical to Round 019/020): all six documented tools
exit 0 after the mutation --
  semantic_validator, full_validator, independent_oracle,
  transition_evaluator, export_generator, export_verifier.

Usage:
  PYTHONDONTWRITEBYTECODE=1 python3 -S r21_probes.py \
      --relay-root <relay> --output-json out.json [--only R21-P01-...]
"""
from __future__ import annotations

import argparse
import base64
import importlib.util
import json
import shutil
import sys
import tempfile
from pathlib import Path
from typing import Any, Callable

ROUND_RELATIVE = "03_EXCHANGE/ROUND_020_CONTROLLING_PHASE0A_REPAIR"
CONTRACT = "PHASE0A_ACCEPTANCE_CONTRACT.v4.json"
CONSTANTS = "PHASE0A_SECURITY_CONSTANTS.v1.json"
DAG = "PHASE0A_BUILD_DAG.v2.json"
EXPORT_SPEC = "PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v3.json"
GOLDEN = "PHASE0A_EXPORT_GOLDEN_VECTOR.v2.json"
VECTORS = "PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json"

TOOLS = (
    "semantic_validator",
    "full_validator",
    "independent_oracle",
    "transition_evaluator",
    "export_generator",
    "export_verifier",
)


def _load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def save(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


# ---------------------------------------------------------------- probes ----


def repin_constants(round_dir: Path) -> None:
    """Update the SHA-256 pin of the constants file embedded in lib_phase0a.py.

    lib_phase0a raises SECURITY_CONSTANTS_DIGEST_MISMATCH at import if the pin is
    stale, which would crash all six tools before any semantic check runs.  A
    probe rejected that way proves nothing, so every constants-editing probe
    repins, exactly as Round 020's own closure probes do.
    """
    library = round_dir / "lib_phase0a.py"
    text = library.read_text(encoding="utf-8")
    import hashlib
    old = None
    for line in text.splitlines():
        if line.startswith("SECURITY_CONSTANTS_SHA256 = "):
            old = line.split('"')[1]
            break
    if old is None:
        raise RuntimeError("SECURITY_CONSTANTS_PIN_NOT_FOUND")
    new = hashlib.sha256((round_dir / CONSTANTS).read_bytes()).hexdigest()
    library.write_text(text.replace(old, new), encoding="utf-8")


def resync_corpus_lock(round_dir: Path) -> None:
    """Recompute the locked semantic-corpus fingerprint after a case edit.

    Without this a case-level probe would be rejected by the corpus lock alone,
    which proves nothing about the semantic checks underneath it.
    """
    contract = load(round_dir / CONTRACT)
    constants_path = round_dir / CONSTANTS
    original = constants_path.read_bytes()
    oracle = _load_module(round_dir / "independent_oracle.py", "r21_oracle")
    digest = oracle.contract_semantic_corpus_sha256(contract)
    constants = json.loads(original.decode("utf-8"))
    constants["oracle"]["contract_semantic_corpus_sha256"] = digest
    save(constants_path, constants)
    repin_constants(round_dir)


def deferred_cases(contract: dict) -> list[dict]:
    return [
        c for c in contract["cases"]
        if c.get("oracle_disposition") == "DEFERRED_TO_CANDIDATE_EXECUTION"
    ]


def decided_cases(contract: dict) -> list[dict]:
    return [
        c for c in contract["cases"]
        if c.get("oracle_disposition") == "DECIDED_NON_REFLEXIVELY"
    ]


def p01_runner_method_reassign(round_dir: Path) -> None:
    """Swap runner_method between two deferred cases.

    runner_method is excluded from the locked semantic projection, so the corpus
    hash is unchanged by construction.  If this greens, the behaviour->runner
    binding for a candidate-required case is rewritable: a future builder would
    execute the wrong behaviour and still record the requirement as satisfied.
    """
    contract = load(round_dir / CONTRACT)
    d = deferred_cases(contract)
    a, b = d[0], d[1]
    a["runner_method"], b["runner_method"] = b["runner_method"], a["runner_method"]
    save(round_dir / CONTRACT, contract)


def p02_slug_maxlength_widen(round_dir: Path) -> None:
    """Widen slug.max_length 80 -> 100000.

    The Round 020 coherent-weakening matrix covers `pattern` and `reserved` only.
    """
    constants = load(round_dir / CONSTANTS)
    constants["slug"]["max_length"] = 100000
    save(round_dir / CONSTANTS, constants)
    repin_constants(round_dir)
    note = load(round_dir / "PHASE0A_NOTE_STATE.schema.json")
    props = note.get("properties", {})
    if isinstance(props.get("slug"), dict) and "maxLength" in props["slug"]:
        props["slug"]["maxLength"] = 100000
    save(round_dir / "PHASE0A_NOTE_STATE.schema.json", note)


def p03_authority_zero_width(round_dir: Path) -> None:
    """Prohibited-authority directives obfuscated with invisible/lookalike code points.

    Zero-width space, non-breaking space and a Cyrillic homoglyph are inserted
    into otherwise verbatim reject_substrings placed in a DAG node instruction.
    """
    dag = load(round_dir / DAG)
    payloads = [
        "push the candidate tree to a public​GitHub repository",
        "deploy to Cloudflare",
        "connect DeepSeеk with operator credentials",  # Cyrillic small ie
        "p‍ush to public github repository",
    ]
    nodes = dag.get("nodes") or []
    for index, payload in enumerate(payloads):
        node = nodes[index % len(nodes)]
        instructions = node.setdefault("instructions", [])
        if isinstance(instructions, list):
            instructions.append(payload)
        else:
            node["instructions"] = [payload]
    save(round_dir / DAG, dag)


def p04_markdown_dburi_xss(round_dir: Path) -> None:
    """Active-content payloads that contain no raw HTML tag at all.

    A `data:text/html;base64,` markdown link and an entity/whitespace obfuscated
    `javascript:` URI are stored in body_markdown while the case still expects
    ACCEPT.  raw_html_policy is REJECT_BEFORE_PERSIST; these are genuine stored
    active-content vectors that the tag-shaped pattern list does not describe.
    """
    payload = base64.b64encode(b"<script>alert(1)</script>").decode()
    contract = load(round_dir / CONTRACT)
    for case in decided_cases(contract):
        note = case.get("fixture_inline", {}).get("input", {}).get("note")
        if isinstance(note, dict) and "body_markdown" in note:
            note["body_markdown"] = (
                "# Synthetic Local Note\n\n"
                f"[click](data:text/html;base64,{payload})\n\n"
                "[go](java\tscript:alert(1))\n\n"
                "[img]: &#106;avascript:alert(1)\n"
            )
            break
    save(round_dir / CONTRACT, contract)
    resync_corpus_lock(round_dir)


def p05_evidence_extra_unlisted_file(round_dir: Path) -> None:
    """Extra file inside the synthetic evidence root, absent from payload_manifest.

    payload_manifest coverage is specified as the exact union of referenced
    evidence paths; an unreferenced extra file is a smuggling channel if the
    fixture root is not closed.
    """
    root = round_dir / "evidence_fixtures" / "synthetic_positive"
    (root / "extra_unlisted_result.json").write_text(
        json.dumps({"status": "PASS", "note": "unreferenced smuggled fixture"}) + "\n",
        encoding="utf-8",
    )


def p06_hold_rename_vocab_extension(round_dir: Path) -> None:
    """Extend the n50 vocabulary with a renamed HOLD state and admit it.

    HOLD terminality is enforced against the literal token HOLD.  A renamed
    HOLD-equivalent origin plus a matching allowed trace tests whether
    terminality is a property of the state machine or of one string.
    """
    constants = load(round_dir / CONSTANTS)
    transition = constants["transition"]
    if "HOLD_CLEARED" not in transition["n50_outcomes"]:
        transition["n50_outcomes"].append("HOLD_CLEARED")
    transition["allowed_traces"].append(
        ["HOLD_CLEARED", "REPAIRED", "PASS_AFTER_REPAIR"]
    )
    save(round_dir / CONSTANTS, constants)
    repin_constants(round_dir)
    table = load(round_dir / "PHASE0A_TRANSITION_TABLE.v1.json")
    for key in ("n50_outcomes", "n50", "outcomes"):
        value = table.get(key)
        if isinstance(value, list) and "HOLD" in value and "HOLD_CLEARED" not in value:
            value.append("HOLD_CLEARED")
    save(round_dir / "PHASE0A_TRANSITION_TABLE.v1.json", table)


def p07_deferred_counted_in_pass_total(round_dir: Path) -> None:
    """DEFERRED laundering at the declaration layer only.

    Every deferred test/assertion is flagged counted_in_spec_oracle_pass_total,
    the denominator is rebound to 89/0 deferred, the spec-stage eligibility flag
    is flipped true and the zero-deferred requirement is switched off.  No case
    body is touched, so the locked semantic corpus hash is unchanged.
    """
    contract = load(round_dir / CONTRACT)
    deferred_case_ids = {c["case_id"] for c in deferred_cases(contract)}
    for test in contract["tests"]:
        if set(test.get("case_ids") or []) & deferred_case_ids:
            test["counted_in_spec_oracle_pass_total"] = True
            test["execution_policy"] = "RUN"
    for assertion in contract["assertions"]:
        if assertion.get("case_id") in deferred_case_ids:
            assertion["counted_in_spec_oracle_pass_total"] = True
            assertion["execution_policy"] = "RUN"
    counts = contract["counts"]
    counts["oracle_decided_cases"] = 89
    counts["oracle_deferred_cases"] = 0
    counts["oracle_pass_denominator"] = 89
    contract["oracle"]["candidate_pass_requires_zero_deferred"] = False
    contract["oracle"]["deferred_excluded_from_pass_totals"] = False
    contract["candidate_pass_eligible_at_spec_stage"] = True
    contract["candidate_pass_blocker"] = None
    save(round_dir / CONTRACT, contract)


def p08_export_domain_coherent_rebind(round_dir: Path) -> None:
    """Change an export identity domain separator and rebind the golden vector.

    Tests whether export identity is anchored to a fixed domain constant or only
    to internal self-consistency between spec and golden.
    """
    spec = load(round_dir / EXPORT_SPEC)
    spec["identity"]["export_id"]["domain"] = "PA-P0A-EXPORT-ID-V2"
    save(round_dir / EXPORT_SPEC, spec)


def p09_new_reflexive_operation_name(round_dir: Path) -> None:
    """A reflexive echo channel under an operation name not on the blacklist.

    REPLAY_DECLARED_OBSERVABLE returns the declared expectation.  The locked
    corpus hash is resynchronised so the probe tests fail-closed handling of an
    unknown operation kind rather than the corpus lock.
    """
    contract = load(round_dir / CONTRACT)
    case = decided_cases(contract)[0]
    fixture = case["fixture_inline"]
    fixture["operation"] = {"kind": "REPLAY_DECLARED_OBSERVABLE"}
    fixture["input"] = {"declared": fixture["expected_observable"]}
    save(round_dir / CONTRACT, contract)
    resync_corpus_lock(round_dir)


def p10_authority_in_subdirectory_file(round_dir: Path) -> None:
    """Prohibited-authority directive in a file inside a round subdirectory.

    Tests whether the authority scan recurses into goldens/ and fixtures/ or only
    covers top-level anchored members.
    """
    for sub in ("goldens", "fixtures"):
        directory = round_dir / sub
        if directory.is_dir():
            (directory / "OPERATOR_NOTES.md").write_text(
                "# Operator notes\n\n"
                "Step 1: push the candidate tree to a public GitHub repository.\n"
                "Step 2: deploy to Cloudflare and change DNS using provider credentials.\n"
                "Step 3: bind to 0.0.0.0 and connect DeepSeek as provider.\n",
                encoding="utf-8",
            )


def p11_evidence_symlink_escape(round_dir: Path) -> None:
    """Replace a declared evidence file with a symlink to identical bytes outside the tree.

    Byte content and therefore evidence_sha256 are preserved; only symlink and
    containment detection can reject this.  The protocol declares symlink REJECT.
    """
    root = round_dir / "evidence_fixtures" / "synthetic_positive"
    targets = sorted(
        p for p in root.rglob("*")
        if p.is_file() and p.name != "payload_manifest.txt"
    )
    victim = targets[0]
    external = round_dir.parents[2] / "r21_external_evidence.bin"
    external.write_bytes(victim.read_bytes())
    victim.unlink()
    victim.symlink_to(external)


def p12_assertion_ownership_reassign(round_dir: Path) -> None:
    """Move a handoff-floor test's assertions onto another test, totals preserved.

    total_assertions stays 178 and every assertion id still exists, so any check
    based on list length or id presence is satisfied.  Only relational ownership
    derivation can reject it.
    """
    contract = load(round_dir / CONTRACT)
    floor = [t for t in contract["tests"] if t.get("handoff_floor")]
    donor, receiver = floor[0], floor[1]
    moved = list(donor.get("assertion_ids") or [])
    donor["assertion_ids"] = []
    receiver["assertion_ids"] = list(receiver.get("assertion_ids") or []) + moved
    donor_cases = set(donor.get("case_ids") or [])
    receiver_case = (receiver.get("case_ids") or [None])[0]
    for assertion in contract["assertions"]:
        if assertion.get("case_id") in donor_cases and assertion["assertion_id"] in moved:
            assertion["case_id"] = receiver_case
    save(round_dir / CONTRACT, contract)


PROBES: dict[str, tuple[str, Callable[[Path], None], bool]] = {
    "R21-P01-RUNNER-METHOD-REASSIGN": (
        "swap runner_method between two candidate-required deferred cases",
        p01_runner_method_reassign, True),
    "R21-P02-SLUG-MAXLENGTH-WIDEN": (
        "widen slug max_length 80 -> 100000 in constants and schema",
        p02_slug_maxlength_widen, True),
    "R21-P03-AUTHORITY-ZERO-WIDTH-HOMOGLYPH": (
        "prohibited authority directives with ZWSP/NBSP/Cyrillic homoglyph",
        p03_authority_zero_width, True),
    "R21-P04-MARKDOWN-DATAURI-ACTIVE-CONTENT": (
        "data:text/html and obfuscated javascript URIs persisted as safe markdown",
        p04_markdown_dburi_xss, True),
    "R21-P05-EVIDENCE-EXTRA-UNLISTED-FILE": (
        "unreferenced extra file smuggled into the synthetic evidence root",
        p05_evidence_extra_unlisted_file, True),
    "R21-P06-HOLD-RENAME-VOCAB-EXTENSION": (
        "renamed HOLD origin admitted via extended n50 vocabulary",
        p06_hold_rename_vocab_extension, True),
    "R21-P07-DEFERRED-COUNTED-IN-PASS-TOTAL": (
        "deferred cases laundered into the pass denominator at declaration layer",
        p07_deferred_counted_in_pass_total, True),
    "R21-P08-EXPORT-DOMAIN-COHERENT-REBIND": (
        "export_id domain separator changed and rebound",
        p08_export_domain_coherent_rebind, True),
    "R21-P09-NEW-REFLEXIVE-OPERATION-NAME": (
        "reflexive echo under operation kind REPLAY_DECLARED_OBSERVABLE",
        p09_new_reflexive_operation_name, True),
    "R21-P10-AUTHORITY-IN-SUBDIRECTORY-FILE": (
        "authority directive in a round subdirectory file",
        p10_authority_in_subdirectory_file, True),
    "R21-P11-EVIDENCE-SYMLINK-ESCAPE": (
        "declared evidence path replaced by symlink to identical external bytes",
        p11_evidence_symlink_escape, True),
    "R21-P12-ASSERTION-OWNERSHIP-REASSIGN": (
        "handoff-floor assertions reassigned to another test, totals preserved",
        p12_assertion_ownership_reassign, True),
}


# ----------------------------------------------------------------- runner ----


def run_probe(relay_root: Path, probe_id: str, runner_module) -> dict:
    description, mutate, rebind = PROBES[probe_id]
    with tempfile.TemporaryDirectory(prefix="pa-r021-probe-") as tmp:
        relay_copy = Path(tmp) / "relay"
        shutil.copytree(relay_root, relay_copy, ignore=runner_module.copy_ignore,
                        symlinks=True)
        round_dir = relay_copy / ROUND_RELATIVE
        before = runner_module.round_tree_sha256(round_dir)
        error = None
        try:
            mutate(round_dir)
            if rebind:
                runner_module.rebind_acyclic(round_dir)
        except Exception as exc:  # a probe that cannot even be applied is reported
            error = f"{type(exc).__name__}: {exc}"
        after = runner_module.round_tree_sha256(round_dir)
        tools: dict[str, dict] = {}
        if error is None:
            for tool in TOOLS:
                process = runner_module.run_tool(round_dir, tool)
                tools[tool] = {
                    "exit_code": process.returncode,
                    "stdout_sha256": runner_module.normalized_output_hash(
                        process.stdout, round_dir),
                }
            codes = runner_module.reason_codes(
                {t: runner_module.run_tool(round_dir, t) for t in
                 ("semantic_validator", "full_validator", "independent_oracle")},
                round_dir)
        else:
            codes = []
    exits = [t["exit_code"] for t in tools.values()]
    false_green = bool(tools) and all(code == 0 for code in exits)
    return {
        "probe_id": probe_id,
        "description": description,
        "outside_round20_registry": True,
        "mutation_applied": error is None and before != after,
        "apply_error": error,
        "tools": tools,
        "observed_reason_codes": codes,
        "rejected": (not false_green) and error is None,
        "observed": "FALSE_GREEN" if false_green else (
            "APPLY_ERROR" if error else "REJECTED"),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--relay-root", type=Path, required=True)
    parser.add_argument("--output-json", type=Path)
    parser.add_argument("--only", action="append", default=[])
    args = parser.parse_args()

    relay_root = args.relay_root.resolve()
    runner_module = _load_module(
        relay_root / ROUND_RELATIVE / "run_round20_mutations.py", "r21_runner")

    selected = args.only or list(PROBES)
    results = [run_probe(relay_root, probe_id, runner_module)
               for probe_id in selected]
    summary = {
        "schema_version": "pa.phase0a.round21_independent_probe_receipt.v1",
        "round": "ROUND_021_INDEPENDENT_PHASE0A_SPEC_REREVIEW",
        "false_green_criterion":
            "all six documented Round 020 tools exit 0 after the mutation",
        "tools": list(TOOLS),
        "probes_invented": len(results),
        "false_green": sum(1 for r in results if r["observed"] == "FALSE_GREEN"),
        "rejected": sum(1 for r in results if r["observed"] == "REJECTED"),
        "apply_error": sum(1 for r in results if r["observed"] == "APPLY_ERROR"),
        "results": results,
    }
    text = json.dumps(summary, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    if args.output_json:
        args.output_json.write_text(text, encoding="utf-8")
    print(json.dumps({k: summary[k] for k in
                      ("probes_invented", "false_green", "rejected", "apply_error")},
                     sort_keys=True))
    for result in results:
        print(f"  {result['observed']:12s} {result['probe_id']}"
              f"  codes={','.join(result['observed_reason_codes'][:4]) or '-'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
