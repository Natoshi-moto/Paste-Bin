# Round 019 Return Summary

**Adjudication:** `HOLD_FOR_FURTHER_PHASE0A_SPEC_REPAIR`

**Next actor:** controlling engineer, bounded Round 020 specification and gate repair

## Result in one paragraph

Round 018's own 31 mutation classes all reject, deterministically, and I reproduced its
receipts byte-for-byte. But the registry is not the gate — it is a sample of it. I
invented eight material mutations outside that registry and **seven passed every
documented Round 018 tool**. The specification can currently be edited to say that
home-wide writes are acceptable, that a `<script>` payload may be persisted, and that
the builder should push to a public GitHub repository, and every validator, the
oracle, the transition evaluator and both export tools still return exit 0. Phase 0A
must not be released to a builder on this specification.

## Verification results

| Check | Result |
|---|---|
| Archive SHA-256 vs expected | MATCH |
| Immutable input manifest | PASS — 365 files |
| Round 018 validator (documented invocation) | **exit 1 — see R19-F06** |
| Round 018 validator (`PYTHONDONTWRITEBYTECODE=1`) | exit 0 — `SPEC_CONTRACT_VALID` |
| Independent oracle | exit 0 — 89/89 (but see R19-F01) |
| Transition evaluator | exit 0 |
| Export generator / verifier | exit 0 — golden reproduced |
| Mutation suite, `PYTHONHASHSEED=1` and `2` | 31/31 rejected, receipts byte-identical |
| Round 017's twenty adversarial classes | 20/20 still reject for intended reasons |
| **Round 019 independent probes** | **8 run — 7 false-green** |

## What Round 018 genuinely closed

Four Round 017 findings are properly closed, and Round 020 should carry this work
forward unchanged:

- **HOLD is terminal.** I enumerated all 36 N50/N60/N70 combinations independently;
  exactly two traces are admitted and no HOLD-origin trace survives.
- **N80 cannot release non-reviewed bytes.** All four reviewed digests are compared,
  and remotes, non-localhost bind, provider adapters and forbidden untracked paths
  are independently refused.
- **Export identity is complete and reproducible.** An independent generator
  reproduced the golden ZIP exactly.
- **Mutation receipts are deterministic.** The Round 017 hash-seed nondeterminism is
  gone.

The fake Relay, the web-security vectors and the authority declarations are also
genuine improvements. No actual authority widening exists in the package as shipped.

## Why it is still a HOLD

Seven false-greens trace to one recurring mistake: **gates keyed on names, declared
lists, or values the mutation itself can rewrite.**

| Finding | Severity | Substance |
|---|---|---|
| R19-F01 | CRITICAL | The oracle reports 89/89 but 60 cases pass with garbage input and 42 echo any expectation you write. `APPLY_NAMED_CASE` was blacklisted; the same behaviour returned as `CANDIDATE_OBSERVE`. |
| R19-F02 | CRITICAL | `AUTHORITY_REJECT_SUBSTRINGS` is defined and never used. The real scan misses GitHub, push, deploy, Cloudflare and DNS. |
| R19-F03 | CRITICAL | Raw-HTML rejection is enforced by case-ID substring. Rename the case and it inverts to ACCEPT. |
| R19-F04 | HIGH | No code path ever resolves an `evidence_sha256` to the bytes it claims to hash. |
| R19-F05 | HIGH | The slug pattern and reserved list can be weakened; the oracle's hardcoded copies never cross-check the schema. |
| R19-F06 | HIGH | The documented validator command fails on a clean unpack because `__pycache__` bytes are hash-pinned and rewritten on import. |
| R19-F07 | MEDIUM | Emptying `forbidden_examples` deletes the forbidden-trace check. Behaviour stays safe; the regression test does not. |

## Required for Round 020

1. Make the oracle decide every case it counts, or exclude undecided cases from the
   pass total under an explicit `DEFERRED` label.
2. Use the declared authority substring list, extend it to the full prohibited
   vocabulary, and scan every string field of every normative file.
3. Key raw-HTML enforcement to fixture payloads, not case names.
4. Resolve evidence hashes against real bytes; pin `evidence_fixtures/` in the
   normative manifest.
5. Assert schema/oracle constant equality; test the slug pattern against a hostile
   corpus.
6. Remove `__pycache__` from the archive and manifests, or disable bytecode writing in
   every entry point.
7. Replace declared-example iteration with exhaustive derivation or exact-ID minimums.
8. Adopt and test the general rule: no gate may be keyed on an identifier, a list
   length, or a value the mutation can rewrite.
9. Add all eight Round 019 probe classes to the mandatory registry with exact expected
   reason codes.

## Boundaries observed

No application was built. No repository was created or mutated. No branch, commit,
remote, push, credential, provider, deployment, DNS, Cloudflare, public state or
spending occurred. No network call was made. `/home/anon/Projects/Pioneer-Alignment-App`
was never touched, and its state remains unverified. All eight probe mutations ran in
disposable temporary directories destroyed on exit. No prior round or original
artifact byte was altered.

All seven external blockers carried in from Round 018 remain open and are preserved
verbatim in `FINDING_CLOSURE.json`. The wider Rounds 3–10 architecture remains a
separate HOLD and is not a prerequisite for repairing this narrow gate.

## Files in this directory

| File | Contents |
|---|---|
| `REVIEW.md` | Full re-review, finding-by-finding closure, seven new findings |
| `FINDING_CLOSURE.json` | Machine-readable disposition of all ten Round 017 findings plus seven new ones |
| `EXECUTION_RECEIPT.json` | Every command run, with exit codes and digests |
| `RETURN_SUMMARY.md` | This file |
| `SHA256SUMS.txt` | Digests of every file in this directory |
| `r19_probes.py` | The eight independent probe definitions |
| `r19_verify.py` | Re-verification of each probe across the full toolchain and both validation modes |
| `receipts/r19-mut-seed1.{json,md}` | Mutation receipts under `PYTHONHASHSEED=1` |
| `receipts/r19-mut-seed2.{json,md}` | Mutation receipts under `PYTHONHASHSEED=2` |
| `receipts/r19-probes.json` | First-pass probe results |
| `receipts/r19-probes-verified.json` | Full-toolchain verification, with proof each mutation persisted |
