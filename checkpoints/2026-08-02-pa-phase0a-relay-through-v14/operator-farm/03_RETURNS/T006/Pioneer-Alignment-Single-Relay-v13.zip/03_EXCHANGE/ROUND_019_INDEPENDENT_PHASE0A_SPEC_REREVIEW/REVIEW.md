# Pioneer Alignment — Round 019 Independent Phase 0A Specification Re-review

Version: v1
Date: 2026-08-01
Actor: independent Phase 0A specification re-reviewer (not the author of Round 018, not the application builder)
Posture: specification review and disposable mutation testing only

## 1. Adjudication

```text
HOLD_FOR_FURTHER_PHASE0A_SPEC_REPAIR
```

Round 018 is a large and mostly honest repair. Several Round 017 findings are
genuinely closed, and I say so specifically in section 6. But the central Round 017
defect is **not** closed: the acceptance gate still cannot distinguish a correct
candidate from a candidate that simply declares itself correct.

I ran eight material mutations that Round 018's registry does not contain. Seven of
the eight passed every documented Round 018 tool — validator (both `--semantic-only`
and full mode), independent oracle, transition evaluator, export generator and export
verifier all returned exit 0 on a specification that had been materially weakened.

Round 017's stated release precondition was that "the independent oracle, concrete
fixtures, acyclic evidence protocol and executable review state machine all reject
their negative controls and every material mutation." Two of those four still do not.
Phase 0A must not be released to a bounded local builder on this specification.

## 2. Authority understood

I was authorised to read and analyse the supplied relay, execute the Round 018 tools,
mutate disposable `/tmp` copies, write only under
`03_EXCHANGE/ROUND_019_INDEPENDENT_PHASE0A_SPEC_REREVIEW/` plus the exact control,
tool and manifest paths listed in `CURRENT_STATE.json`, and return one complete relay.

I was not authorised to build application code, initialise or mutate any repository,
create a branch or commit, configure a remote, push to GitHub, request or use
credentials, connect a provider, deploy, change DNS/Cloudflare/hosting/production,
create public accounts, NEX, LEX, federation, governance or real identities, spend
money, approve operator decisions, or promote the wider Rounds 3–10 architecture.

I took none of those actions. No repository was created or mutated. No network call
was made. No host path was touched. Every mutation ran inside a disposable
`tempfile.TemporaryDirectory` and was destroyed on exit. `/home/anon/Projects/Pioneer-Alignment-App`
was never read, created, or written.

## 3. Corpus and integrity

Received archive:

- filename: `Pioneer-Alignment-Single-Relay-v9.zip`
- detached SHA-256: `d1fa17f84dda2842bd7d3b391ae377bdb570d514c33dcf85f6d8a14381e4d753`
- expected SHA-256 (from the Round 019 prompt): identical — **match**
- entries: 375, all unique
- absolute or traversal paths: none
- symlinks: none
- wrapper directory: none; six numbered top-level directories
- `zipfile.testzip()`: clean
- immutable input manifest: **PASS, 365/365 files**

I read the complete 272-line original builder handoff, the Round 017 review, the
Round 018 `START_HERE.md`, `REPAIR_SUMMARY.md`, `REQUEST_FOR_INDEPENDENT_REREVIEW.md`
and `MUTATION_RECEIPTS.md`, and the Round 018 normative JSON set, `lib_phase0a.py`,
`meta_validate_round18.py`, `independent_oracle.py`, `run_round18_mutations.py`,
`transition_evaluator.py`, `export_generator.py` and `export_verifier.py`.

## 4. Independent execution results

| Execution | Result |
|---|---|
| Received archive SHA-256 vs expected | MATCH |
| Immutable input manifest | PASS — 365 files |
| `meta_validate_round18.py` (full, documented invocation) | **exit 1 — `SPEC_CONTRACT_INVALID`** (see R19-F06) |
| `meta_validate_round18.py` (full, `PYTHONDONTWRITEBYTECODE=1`) | exit 0 — `SPEC_CONTRACT_VALID` |
| `independent_oracle.py` | exit 0 — 89/89 cases pass |
| `transition_evaluator.py` | exit 0 — 2 allowed traces, N80 identity checks true |
| `export_generator.py` | exit 0 — `matches_golden: true` |
| `export_verifier.py` | exit 0 — `ok: true` |
| `run_round18_mutations.py`, `PYTHONHASHSEED=1` | exit 0 — 31 rejected, 0 false-green |
| `run_round18_mutations.py`, `PYTHONHASHSEED=2` | exit 0 — 31 rejected, 0 false-green |
| Mutation receipt determinism across seeds | **PASS — byte-identical** |
| Reproduced receipt vs shipped `MUTATION_RECEIPTS.json` | **PASS — byte-identical** |
| Round 017's twenty adversarial classes | 20/20 rejected, each for its intended reason |
| **Round 019 independent material probes** | **8 run — 7 false-green, 1 rejected** |

Both seeds produced mutation receipt SHA-256
`d820ff55e107e32869dbfe009412cd011c18589e04963b3a06e15bc616b336f0`, which also equals
the digest of the shipped `MUTATION_RECEIPTS.json`. The Round 017 nondeterminism
finding is genuinely closed.

Golden export identity reproduced independently:

```text
export_id           export_161df160ab63e145d6347b0fc7d657c3
content_set_sha256  1401e40961077f281e106ff9a3db1d46e0502a54b948031d065d6215c43374b1
receipt_hash        01487ef2ed4d6304022d280005c8834420ffea4f6c0ce27ae0412a10f320cd5a
zip_sha256          9fbe23d06c8e99e48fc65270a93501041ab39840c54b28ac6760b6a446933bd9
```

## 5. Round 019 independent probes

Each probe copies the pristine Round 018 directory into a disposable temporary
directory, applies one coherent material mutation, re-pins every dependent hash
exactly as `run_round18_mutations.py` does (contract hash, normative manifest member
hashes, candidate binding hash, round `SHA256SUMS.txt`), and then runs the full
documented toolchain. A probe counts as false-green only if **every** documented tool
returns exit 0.

| Probe | Mutation | Result |
|---|---|---|
| `R19-P01-ECHO-CASE-EXPECTATION-FLIP` | Flip a write-boundary case from REJECT to ACCEPT | **FALSE_GREEN** |
| `R19-P02-SLUG-PATTERN-SUBTLE-WEAKEN` | Note-schema slug pattern widened to admit `..` and `.env` | **FALSE_GREEN** |
| `R19-P03-DAG-PUBLIC-GITHUB-PUSH` | Add "push the candidate tree to a public GitHub repository" to N40 | **FALSE_GREEN** |
| `R19-P04-EVIDENCE-FIXTURE-TAMPER` | Append bytes to a synthetic evidence fixture | **FALSE_GREEN** |
| `R19-P05-FORBIDDEN-EXAMPLES-REMOVED` | Empty the transition table's `forbidden_examples` | **FALSE_GREEN** |
| `R19-P06-RESERVED-SLUGS-TRIMMED` | Reduce reserved slugs from ten to one | **FALSE_GREEN** |
| `R19-P07-RAW-HTML-CASE-EVASION` | Rename a raw-HTML case out of the blacklist and flip it to ACCEPT | **FALSE_GREEN** |
| `R19-P08-DUPLICATE-JSON-KEY` | Inject a duplicate top-level JSON key | REJECTED (correct) |

For each false-green I re-read the mutated tree afterwards and confirmed the mutation
was still materially present — none was silently reverted by the re-pinning step.
Exact records: `receipts/r19-probes.json` and `receipts/r19-probes-verified.json`.
The probe programs are `r19_probes.py` and `r19_verify.py` in this directory.

## 6. Round 017 findings — closure disposition

### Genuinely closed

**R17-P0A-004 — review/HOLD state machine bypassable — `CLOSED`.**
I independently enumerated all 3 × 3 × 4 = 36 combinations of N50/N60/N70 outcomes
through `evaluate_review_trace`. Exactly two are admitted:
`PASS → NOT_REQUIRED → INITIAL_PASS_CONFIRMED` and
`REPAIR_REQUIRED → REPAIRED → PASS_AFTER_REPAIR`. Every trace originating in `HOLD`
is refused with `HOLD_TERMINAL` before any further evaluation, so **HOLD is terminal**
and the Round 017 `HOLD → NOT_REQUIRED → INITIAL_PASS_CONFIRMED` trace is dead. This
is a real closure and it survived my attempt to widen it (`R19-P05` weakens the
declared examples but cannot re-admit a HOLD trace through the evaluator itself).

**R17-P0A-005 — final handoff not the reviewed candidate — `CLOSED`.**
`n80_identity_check` compares all four reviewed digests (binding, tree, source
manifest, evidence) against the handoff digests and independently rejects non-empty
remotes, any bind other than `127.0.0.1`, any provider adapter and any forbidden
untracked path. **N80 cannot release non-reviewed bytes.**

**R17-P0A-006 (determinism half) — `CLOSED`.** Receipts are byte-identical across
`PYTHONHASHSEED` values and reproduce the shipped receipt exactly.

**R17-P0A-007 — export identity incomplete — `CLOSED`.** Domain-separated preimages
for `content_set_sha256` and `export_id` are specified, and an independent
generator/verifier pair reproduces the golden ZIP byte-for-byte.

### Not closed

**R17-P0A-001 — symbolic cases and echo runner — `NOT_CLOSED`.** See R19-F01.
Round 018 removed the literal string `APPLY_NAMED_CASE` and the validator now
blacklists it, but the same echo behaviour was reintroduced under the operation kind
`CANDIDATE_OBSERVE`, which the blacklist does not name.

**R17-P0A-002 (partial) / R17-P0A-008 — handoff floor removable — `PARTIALLY_CLOSED`.**
Whole-requirement and whole-test deletion is now correctly frozen (`R18-M20`,
`R18-M28` both reject). But a requirement can still be **hollowed out in place**
rather than removed: `R19-P07` renames a raw-HTML case out of the substring blacklist
and inverts it to ACCEPT while every ID count, the requirement registry and the
runner method list stay coherent.

**R17-P0A-003 — evidence self-attested — `PARTIALLY_CLOSED`.** Zero digests, missing
paths, traversal, reversed times and the manifest cycle field are all now rejected —
real progress. But the closure test Round 017 wrote was "missing/**altered**/unlisted/
escaped evidence ... fail", and altered evidence does not fail. See R19-F04.

**R17-P0A-006 (coverage half) — `NOT_CLOSED`.** `false_green: 0` remains true only
for the 31 supplied classes. Seven of my eight new classes are false-green.

**R17-P0A-009 — host/lock paths — `PRESERVED_BLOCKER`.** The host preflight matrix is
now exhaustive over all nine declared states and agrees with `host_preflight_decision`
for each. The underlying blocker (actual writable host state) is correctly unverified
and remains open.

**R17-P0A-010 — Relay and web security name-only — `PARTIALLY_CLOSED`.** Closed Relay
schemas, a deterministic offline algorithm and concrete Host/Origin/CSRF/bind/body/path
vectors now exist and are genuinely executed by the oracle. The raw-HTML half is
undermined by R19-F03.

## 7. Round 019 findings

### R19-F01 — CRITICAL — the oracle is blind to 60 of 89 fixtures and echoes 42

- **Claim:** `independent_oracle.py` does not evaluate most of the contract. It
  reports 89/89 PASS while examining neither the input nor the correctness of the
  expectation for the majority of cases.
- **File/field:** `independent_oracle.py` lines 137–140; operation kinds
  `CANDIDATE_OBSERVE` (40 cases), `PROVENANCE_SCENARIO` (2),
  `VERIFY_EXPORT_GOLDEN` (9), `VERIFY_EXPORT_HASHES` (1).
- **Mechanism:** the branch for `PROVENANCE_SCENARIO`, `CANDIDATE_OBSERVE` and
  `EVALUATE_NAMED_BEHAVIOUR` returns
  `result(expected["transition"], expected["reason_code"])`. Because `result()`
  computes `ok` by comparing its own arguments against `expected`, the comparison is
  reflexive and `pass` is unconditionally `True`. `VERIFY_EXPORT_GOLDEN` and
  `VERIFY_EXPORT_HASHES` return hardcoded constants without reading `inp` at all.
- **Measurement:** replacing each case's `input` with `{"__garbage__": true}` leaves
  **60 of 89** cases passing. Replacing each case's `expected_observable` with an
  invented reason code leaves **42 of 89** passing — the oracle will certify
  `{"transition": "ACCEPT", "reason_code": "ANY_NONSENSE_I_WANT"}`.
- **Reproduction:** `R19-P01`. Flip
  `C-G-P0A-WRITE-BOUNDARY-NO-HOME-WIDE-WRITE-001` from REJECT to ACCEPT — that is,
  declare that home-wide writes are acceptable — re-pin all dependent hashes, and run
  every documented tool. All return exit 0.
- **Affected requirement:** executable acceptance contract; independent oracle;
  Round 017's `R17-P0A-001` closure test.
- **Required repair:** every case must be decided by an operation kind that actually
  consumes `input` and derives the observable independently. `CANDIDATE_OBSERVE` is
  not an oracle operation — it is a deferral. Either give those 42 cases real
  fixtures and real evaluators, or move them out of the oracle's pass count and mark
  them explicitly `DEFERRED_TO_CANDIDATE_EXECUTION` so the 89/89 figure stops
  overstating what was verified.
- **Closure test:** garbage input must fail every case; an inverted expectation must
  fail its case; the reported pass count must equal the number of cases the oracle
  genuinely decided.

### R19-F02 — CRITICAL — the DAG authority scan is dead code and misses GitHub, push and deploy

- **Claim:** the specification can instruct the builder to push to a public GitHub
  repository, and validation stays green.
- **File/field:** `meta_validate_round18.py` line 80 defines
  `AUTHORITY_REJECT_SUBSTRINGS` — including `"public GitHub push"` — and **never
  references it again**. The scan actually performed (lines 364–372) is an inline
  literal test for `deepseek`, `operator credentials`, `connect provider` and
  `0.0.0.0` only.
- **Reproduction:** `R19-P03`. Append `"push the candidate tree to a public GitHub
  repository for backup"` to `P0A-N40-BUILD-CANDIDATE.required_checks`. Validator
  exit 0, all tools green.
- **Note:** the same gap admits `deploy`, `publish`, `Cloudflare`, `DNS`, `credential`,
  `npm publish` and `tunnel` instructions. This directly contradicts the operator's
  standing constraint that a private GitHub backup requires fresh exact single-use
  authorisation.
- **Affected requirement:** authority-boundary enforcement across every subordinate
  file; the operator's GitHub, deployment and DNS prohibitions.
- **Required repair:** use the declared list, extend it to the full prohibited-action
  vocabulary already present in `CURRENT_STATE.json` and
  `PHASE0A_PRECEDENCE_AND_SUPERSESSION.v2.json`, and scan **every** string field of
  every normative file — not only `required_checks` of DAG nodes.
- **Closure test:** an instruction naming any prohibited action, in any normative
  file, in any field, must fail with a specific code.

### R19-F03 — CRITICAL — raw-HTML rejection is enforced by case-ID substring, not by semantics

- **Claim:** the raw-HTML floor can be inverted by renaming a case.
- **File/field:** `meta_validate_round18.py` lines 268–273 enforce
  `expected_transition == "REJECT"` only for case IDs containing the literal
  substrings `SCRIPT-TAG`, `EVENT-HANDLER` or `JAVASCRIPT-URL`.
- **Reproduction:** `R19-P07`. Rename `C-G-P0A-RAWHTML-SCRIPT-TAG-REJECTED-001` to
  `...-BOLD-TAG-...` consistently across the contract, runner interface and
  requirement registry; switch its operation kind to `CANDIDATE_OBSERVE`; set its
  expectation to ACCEPT/OK. Counts, requirement bindings and runner methods all stay
  coherent. Every tool returns exit 0, and the specification now tells the builder
  that a `<script>` payload is acceptable to persist.
- **Interaction:** this is R19-F01 acting as an escape hatch for the handoff floor —
  any requirement whose enforcement depends on a case's declared expectation can be
  neutralised by routing that case through the echo channel.
- **Affected requirement:** original handoff line 86, "Raw HTML must not execute";
  `HR-RAW-HTML`; Round 017 `R17-P0A-008`.
- **Required repair:** bind raw-HTML enforcement to the fixture's **payload**, not its
  name. Any case whose `input.body_markdown` matches `RAW_HTML_PATTERNS` must be
  required to expect `REJECT`/`RAW_HTML_REJECTED`, and must be routed to
  `VALIDATE_RAW_HTML`, regardless of what the case is called.
- **Closure test:** injecting a `<script>` body into any case, under any name, must
  force a REJECT expectation or fail validation.

### R19-F04 — HIGH — evidence hashes are never resolved to evidence bytes

- **Claim:** the evidence protocol validates the shape of a hash but never checks that
  it is the hash of anything.
- **File/field:** `meta_validate_round18.py` lines 549–561 check that
  `evidence_sha256` is non-zero and that `evidence_path` is traversal-safe, then stop.
  No code path opens the referenced bytes. Across the entire round, the only Python
  reference to `evidence_fixtures/` is the **exclusion** on
  `run_round18_mutations.py` line 37.
- **Evidence:** the 90 fixtures under `evidence_fixtures/synthetic_positive/` do in
  fact hash correctly today — I verified `case_000.json` against the declared
  `4ca823e4…` and it matches, which I read as good faith by the Round 018 author. The
  defect is that nothing enforces it.
- **Reproduction:** `R19-P04`. Append bytes to
  `evidence_fixtures/synthetic_positive/case_000.json`. Its declared
  `evidence_sha256` is now wrong. All tools return exit 0.
- **Compounding factor:** those 90 files are hash-pinned by the relay-level manifests
  but are **not** members of `PHASE0A_NORMATIVE_MANIFEST.v1.json` (46 members, zero
  from `evidence_fixtures/`), and `regenerate_round_checksums` deliberately drops them
  from the round manifest. So the mutation harness itself cannot detect any evidence
  fixture tampering in any mutant tree.
- **Affected requirement:** Round 017 `R17-P0A-003` closure test — "missing/**altered**/
  unlisted/escaped evidence … fail".
- **Required repair:** resolve every `evidence_path` relative to the declared evidence
  root, hash the bytes, and compare against `evidence_sha256`; include the fixture
  tree in the normative manifest; stop excluding it from checksum regeneration.
- **Closure test:** a single flipped byte in any evidence fixture must fail with a
  specific code.

### R19-F05 — HIGH — schema security constants are unenforced and may silently diverge from the oracle

- **Claim:** the note schema's slug pattern and reserved-slug list — the artefacts a
  builder actually implements from — can be weakened while the oracle, which uses its
  own hardcoded copies, keeps reporting 89/89.
- **File/field:** `meta_validate_round18.py` lines 141–148 reject the slug pattern
  only if it is `None`, `^.*$` or `.*`, and accept any reserved list containing
  `admin`. `lib_phase0a.py` lines 20–25 hold independent hardcoded copies
  (`SLUG_RE`, `RESERVED_SLUGS`). Nothing cross-checks the two.
- **Reproduction:** `R19-P02` sets the pattern to `^[a-z0-9.\-]{1,64}$`, which admits
  `..`, `...`, `a..b` and `.env` — all green. `R19-P06` reduces the reserved list from
  ten entries to `["admin"]`, freeing `api`, `assets`, `export`, `health`, `login`,
  `notes`, `preview`, `receipts` and `static` — all green.
- **Affected requirement:** original handoff line 89, "reject duplicate or unsafe
  slugs"; path-traversal gates for preview and export.
- **Required repair:** assert exact equality between the schema's pattern and reserved
  list and the oracle's constants, and additionally test the pattern behaviourally
  against a fixed corpus of hostile slugs.
- **Closure test:** any divergence between schema and oracle constants fails; the
  schema pattern must reject every member of the hostile-slug corpus.

### R19-F06 — HIGH — the documented validator invocation fails on a clean unpack

- **Claim:** step 1 of the required Round 019 work (verify integrity) and step 2 (run
  the validator) are mutually exclusive as documented.
- **Reproduction:** unpack v9 and run the exact command from Round 018's
  `START_HERE.md`, `python3 -S meta_validate_round18.py`. It returns **exit 1**,
  `SPEC_CONTRACT_INVALID`, `CHECKSUM_MISMATCH:__pycache__/lib_phase0a.cpython-314.pyc`.
- **Mechanism:** the relay ships `__pycache__/*.pyc` and hash-pins those bytes in
  `SHA256SUMS.txt`, `INPUT_SHA256SUMS.txt` and `CURRENT_SHA256SUMS.txt`. The validator
  imports `lib_phase0a`, CPython rewrites the cache file, and the full-mode checksum
  pass then compares against the now-stale pin. `-S` does not disable bytecode writing.
  Running the tools also *creates* new unlisted `.pyc` files, which makes
  `verify_input_manifest.py` report `IMMUTABLE_PATH_UNLISTED` afterwards.
- **Consequence:** the shipped `SPEC_VALIDATION_RECEIPT.json` (`SPEC_CONTRACT_VALID`,
  mode `full`) is not reproducible by following the shipped instructions. I obtained
  `SPEC_CONTRACT_VALID` only by setting `PYTHONDONTWRITEBYTECODE=1`, which is
  documented nowhere in the relay. A reviewer following the instructions literally
  would conclude the package is invalid; a reviewer who re-ran to "fix" it would be
  silently mutating immutable input.
- **Required repair:** exclude `__pycache__` from all three manifests and from the
  archive, or set `sys.dont_write_bytecode = True` at the top of every entry point.
  This is mechanical and low-risk, but it must be fixed before a builder is handed a
  gate whose first instruction fails.

### R19-F07 — MEDIUM — declared-example gates are vacuously satisfiable

- **Claim:** several checks iterate over a declared list and therefore pass trivially
  when the list is emptied.
- **File/field:** `meta_validate_round18.py` lines 417–420 iterate
  `tt.get("forbidden_examples") or []`.
- **Reproduction:** `R19-P05`. Setting `forbidden_examples` to `[]` removes the only
  executable check that forbidden traces are actually refused; validation stays green.
- **Mitigating factor:** `evaluate_review_trace` remains correct, so the *behaviour*
  is still safe — this is a lost regression test, not an open bypass. That is why it
  is MEDIUM and not CRITICAL.
- **Required repair:** enforce a minimum forbidden-example set by exact ID, or derive
  forbidden traces exhaustively from the outcome vocabulary rather than trusting a
  declared list.

## 8. Original-handoff preservation review

| Controlling requirement | Machine-enforced closure |
|---|---|
| Local dashboard and banner | Test ID frozen; case content echo-only (R19-F01) |
| Create/edit/preview bounded notes | Note/event/version cases genuinely evaluated |
| Local embedded persistence and migrations | All four migration cases are echo-channel |
| Six-action hash-linked provenance | Genuinely closed — schema, domains and chained goldens verified |
| Selected-note deterministic export | Genuinely closed — identity formulas reproduce the golden ZIP |
| Deterministic fake Relay only | Genuinely closed — 9 relay cases really execute the algorithm |
| Raw-HTML rejection | **Invertible by rename** (R19-F03) |
| Localhost/Host/Origin/CSRF/body policy | Genuinely closed — 10 web cases really execute |
| Required repository files and `STATUS.json` | Registry frozen against deletion; field content unverified |
| Failure evidence before repair | Shape verified; bytes never resolved (R19-F04) |
| All 13 final-report items and command ledger | Registry-bound; content unverified |
| No remote/provider/public/deployment authority | **Scan is dead code** (R19-F02) |

## 9. Authority-boundary review

I found **no actual** authority widening in the unmodified Round 018 package. Every
`authority_granted` key is `false`, `prohibited_actions` is complete, the claims block
correctly states `application_implemented: false` and `host_path_verified: false`,
`NO_IMPLEMENTATION_CANDIDATE.json` is honest, and the ambiguous Round 016
`prohibited_authority` encoding that Round 017 criticised has been replaced with the
unambiguous `authority_granted` form. The controlling handoff hash matches the original
artifact. These are genuine positives.

The defect is enforcement, not intent: R19-F02 means those correct declarations are not
actually checked against the instructions the builder would follow.

## 10. Preserved external blockers

None of the following is closed, and Round 018 correctly does not claim otherwise:

1. exact writable host state at `/home/anon/Projects/Pioneer-Alignment-App` — unverified;
2. application implementation and candidate test evidence — absent;
3. fresh exact private-GitHub backup authority — not granted;
4. wider Rounds 3–10 architecture — separate HOLD;
5. exact canon snapshots for that wider architecture — missing;
6. real identities, balances, ballots, providers, federation, private-person data — none;
7. deployment, production, DNS, Cloudflare, credentials, spending — none.

I made no host, application, Git, remote, provider or production claim, and I verified
none of these. Whether HOLD is terminal was asked as a specification question and is
answered in section 6: yes, terminal in the evaluator, and N80 cannot release
non-reviewed bytes.

## 11. Required amendments for Round 020

1. Make the oracle decide every case it counts: eliminate the reflexive `result()`
   comparison, give `CANDIDATE_OBSERVE` cases real inputs and evaluators, or exclude
   them from the pass total under an explicit `DEFERRED` label (R19-F01).
2. Use `AUTHORITY_REJECT_SUBSTRINGS`, extend it to the full prohibited vocabulary, and
   scan every string field of every normative file (R19-F02).
3. Bind raw-HTML enforcement to fixture payloads rather than case-ID substrings
   (R19-F03).
4. Resolve every declared evidence hash against real bytes; add `evidence_fixtures/`
   to the normative manifest and stop excluding it from checksum regeneration
   (R19-F04).
5. Assert schema/oracle constant equality and test the slug pattern behaviourally
   against a hostile corpus (R19-F05).
6. Remove `__pycache__` from the archive and all manifests, or disable bytecode writing
   in every entry point, so the documented commands are reproducible (R19-F06).
7. Replace declared-example iteration with exhaustive derivation or exact-ID minimums
   (R19-F07).
8. Adopt a general anti-pattern rule and test for it: **no gate may be keyed on an
   identifier, a declared list length, or a value the mutation can rewrite.** Every
   probe I ran exploits some version of that single mistake.
9. Add all eight Round 019 probe classes to the mandatory mutation registry with exact
   expected reason codes, and re-run under at least two `PYTHONHASHSEED` values.

## 12. Exact next action

The controlling engineer should perform one bounded Round 020 specification and gate
repair under a new exchange directory, implementing the nine amendments above. No
application code, repository, remote, provider, host, public or production action is
authorised by this review.

Phase 0A may be released to a bounded local builder only once the independent oracle
genuinely decides every case it counts, the raw-HTML and authority floors are enforced
semantically rather than by name, evidence hashes resolve to real bytes, and all
thirty-nine mutation classes (31 existing plus 8 from Round 019) reject for their
intended reasons.

The small local notes application remains viable, and the Round 018 work on export
identity, the review state machine, N80 sealing, the fake Relay and web-security
vectors is solid and should be carried forward unchanged. The wider Rounds 3–10 HOLD
is separate and is not a prerequisite for repairing this narrow gate.
