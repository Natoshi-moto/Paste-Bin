#!/usr/bin/env python3
"""Round 019 independent adversarial probes against the Round 018 spec gate.

Each probe copies the pristine Round 018 directory into a disposable tmp dir,
applies a coherent material mutation (co-updating dependent hashes exactly as
run_round18_mutations.py does), then runs the documented toolchain:
  - meta_validate_round18.py --semantic-only  (official suite criterion)
  - independent_oracle.py                     (documented re-review step)
A probe is FALSE_GREEN only if every documented tool stays green.
"""
from __future__ import annotations
import hashlib, json, shutil, subprocess, sys, tempfile
from pathlib import Path

SOURCE = Path(sys.argv[1]).resolve()

def load(p): return json.loads(Path(p).read_text(encoding="utf-8"))
def save(p, v): Path(p).write_text(json.dumps(v, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
def sha(b): return hashlib.sha256(b).hexdigest()
def canonical(v): return json.dumps(v, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()

def regenerate_round_checksums(rd: Path):
    manifest = rd / "SHA256SUMS.txt"
    files = sorted(p for p in rd.rglob("*") if p.is_file() and p != manifest and "evidence_fixtures" not in p.parts)
    manifest.write_text("".join(f"{sha(p.read_bytes())}  {p.relative_to(rd).as_posix()}\n" for p in files), encoding="utf-8")

def rebind(rd: Path):
    cpath = rd / "PHASE0A_ACCEPTANCE_CONTRACT.v4.json"
    ch = sha(cpath.read_bytes())
    vpath = rd / "PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json"
    vectors = load(vpath)
    binding = vectors["positive_fixture"]["candidate_binding"]
    evidence = vectors["positive_fixture"]["candidate_evidence"]
    binding["contract_sha256"] = ch
    evidence["contract_sha256"] = ch
    nm = rd / "PHASE0A_NORMATIVE_MANIFEST.v1.json"
    # coherent attacker also re-pins the normative manifest member hashes
    manifest = load(nm)
    for m in manifest.get("members", []):
        fp = rd / m["path"]
        if fp.is_file():
            m["sha256"] = sha(fp.read_bytes())
    save(nm, manifest)
    nh = sha(nm.read_bytes())
    binding["normative_manifest_sha256"] = nh
    evidence["normative_manifest_sha256"] = nh
    evidence["candidate_binding_sha256"] = sha(canonical(binding))
    save(vpath, vectors)

def run(rd: Path, cmd):
    return subprocess.run(["python3", "-S"] + cmd, capture_output=True, text=True, cwd=rd)

# ---------------- probes ----------------

def p01_echo_case_expectation_flip(rd: Path):
    """Flip a security REJECT expectation to ACCEPT on an oracle echo-channel case."""
    c = load(rd / "PHASE0A_ACCEPTANCE_CONTRACT.v4.json")
    case = next(x for x in c["cases"] if x["case_id"] == "C-G-P0A-WRITE-BOUNDARY-NO-HOME-WIDE-WRITE-001")
    case["fixture_inline"]["expected_observable"] = {"transition": "ACCEPT", "reason_code": "OK"}
    if "expected_transition" in case: case["expected_transition"] = "ACCEPT"
    if "expected_reason_code" in case: case["expected_reason_code"] = "OK"
    save(rd / "PHASE0A_ACCEPTANCE_CONTRACT.v4.json", c)

def p02_slug_pattern_subtle_weaken(rd: Path):
    """Weaken note schema slug pattern to admit '..' while avoiding the three blacklisted wildcard values."""
    s = load(rd / "PHASE0A_NOTE_STATE.schema.json")
    s["properties"]["slug"]["pattern"] = "^[a-z0-9.\\-]{1,64}$"
    save(rd / "PHASE0A_NOTE_STATE.schema.json", s)

def p03_dag_public_github_push(rd: Path):
    """Hidden authority widening the DAG scan substrings do not cover."""
    d = load(rd / "PHASE0A_BUILD_DAG.v2.json")
    node = next(n for n in d["nodes"] if n["node_id"] == "P0A-N40-BUILD-CANDIDATE")
    node["required_checks"].append("push the candidate tree to a public GitHub repository for backup")
    save(rd / "PHASE0A_BUILD_DAG.v2.json", d)

def p04_evidence_fixture_tamper(rd: Path):
    """Flip bytes in evidence_fixtures/ (excluded from round checksum regeneration)."""
    targets = sorted((rd / "evidence_fixtures").rglob("*"))
    files = [p for p in targets if p.is_file()]
    if not files:
        raise RuntimeError("no evidence fixtures found")
    f = files[0]
    f.write_bytes(f.read_bytes() + b"\ntampered\n")

def p05_forbidden_examples_removed(rd: Path):
    t = load(rd / "PHASE0A_TRANSITION_TABLE.v1.json")
    t["forbidden_examples"] = []
    save(rd / "PHASE0A_TRANSITION_TABLE.v1.json", t)

def p06_reserved_slugs_trimmed(rd: Path):
    s = load(rd / "PHASE0A_NOTE_STATE.schema.json")
    s["x-phase0a-slug-reserved"] = ["admin"]
    save(rd / "PHASE0A_NOTE_STATE.schema.json", s)

def p07_raw_html_case_evasion(rd: Path):
    """Rename SCRIPT-TAG identifiers and convert the case to the echo channel expecting ACCEPT."""
    cpath = rd / "PHASE0A_ACCEPTANCE_CONTRACT.v4.json"
    text = cpath.read_text(encoding="utf-8").replace("SCRIPT-TAG", "BOLD-TAG")
    cpath.write_text(text, encoding="utf-8")
    c = load(cpath)
    case = next(x for x in c["cases"] if "BOLD-TAG" in x["case_id"])
    case["fixture_inline"]["operation"]["kind"] = "CANDIDATE_OBSERVE"
    case["fixture_inline"]["expected_observable"] = {"transition": "ACCEPT", "reason_code": "OK"}
    if "expected_transition" in case: case["expected_transition"] = "ACCEPT"
    if "expected_reason_code" in case: case["expected_reason_code"] = "OK"
    save(cpath, c)
    for other in ["PHASE0A_RUNNER_INTERFACE.v2.json", "PHASE0A_HANDOFF_REQUIREMENT_REGISTRY.v1.json"]:
        p = rd / other
        p.write_text(p.read_text(encoding="utf-8").replace("SCRIPT-TAG", "BOLD-TAG"), encoding="utf-8")

def p08_duplicate_json_key(rd: Path):
    """Verify the duplicate-key rejection claim (expected: REJECTED)."""
    p = rd / "PHASE0A_CANONICAL_RULES.v2.json"
    text = p.read_text(encoding="utf-8")
    idx = text.rindex("}")
    dup = text[:idx].rstrip().rstrip("}").rstrip().rstrip(",")
    # append a duplicate of the top-level "schema_version" key
    v = load(p)
    injected = dup + f',\n  "schema_version": {json.dumps(v.get("schema_version", "dup"))}\n}}\n'
    p.write_text(injected, encoding="utf-8")

PROBES = [
    ("R19-P01-ECHO-CASE-EXPECTATION-FLIP", p01_echo_case_expectation_flip, True),
    ("R19-P02-SLUG-PATTERN-SUBTLE-WEAKEN", p02_slug_pattern_subtle_weaken, True),
    ("R19-P03-DAG-PUBLIC-GITHUB-PUSH", p03_dag_public_github_push, True),
    ("R19-P04-EVIDENCE-FIXTURE-TAMPER", p04_evidence_fixture_tamper, True),
    ("R19-P05-FORBIDDEN-EXAMPLES-REMOVED", p05_forbidden_examples_removed, True),
    ("R19-P06-RESERVED-SLUGS-TRIMMED", p06_reserved_slugs_trimmed, True),
    ("R19-P07-RAW-HTML-CASE-EVASION", p07_raw_html_case_evasion, True),
    ("R19-P08-DUPLICATE-JSON-KEY", p08_duplicate_json_key, True),
]

def main():
    results = []
    for pid, fn, needs_rebind in PROBES:
        with tempfile.TemporaryDirectory(prefix="pa-r19-probe-") as tmp:
            rd = Path(tmp) / "round"
            shutil.copytree(SOURCE, rd)
            fn(rd)
            if needs_rebind:
                rebind(rd)
                regenerate_round_checksums(rd)
            val = run(rd, [str(rd / "meta_validate_round18.py"), "--root", str(rd), "--semantic-only"])
            orc = run(rd, [str(rd / "independent_oracle.py"), str(rd / "PHASE0A_ACCEPTANCE_CONTRACT.v4.json")])
            rejected = val.returncode != 0 or orc.returncode != 0
            errors = []
            try:
                errors = json.loads(val.stdout).get("errors", [])
            except Exception:
                pass
            results.append({
                "probe_id": pid,
                "validator_exit": val.returncode,
                "oracle_exit": orc.returncode,
                "observed": "REJECTED" if rejected else "FALSE_GREEN",
                "validator_errors": errors[:6],
            })
            print(f"{pid}: validator={val.returncode} oracle={orc.returncode} -> {'REJECTED' if rejected else 'FALSE_GREEN'}", flush=True)
    out = Path(sys.argv[2])
    out.write_text(json.dumps({"probes": results,
        "false_green": sum(1 for r in results if r["observed"] == "FALSE_GREEN")}, indent=2) + "\n", encoding="utf-8")

if __name__ == "__main__":
    main()
