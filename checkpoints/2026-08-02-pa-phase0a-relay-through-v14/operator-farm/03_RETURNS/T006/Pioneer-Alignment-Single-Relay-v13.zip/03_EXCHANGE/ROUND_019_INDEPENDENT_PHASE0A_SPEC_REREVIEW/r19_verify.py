#!/usr/bin/env python3
"""Verify each Round 019 false-green probe under BOTH semantic-only and full modes,
and confirm the mutation is materially present in the mutated tree (not silently reverted)."""
from __future__ import annotations
import json, shutil, subprocess, sys, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import r19_probes as P

SOURCE = Path(sys.argv[1]).resolve()

def run(rd, cmd):
    return subprocess.run(["python3", "-S"] + cmd, capture_output=True, text=True, cwd=rd)

CHECKS = {
    "R19-P01-ECHO-CASE-EXPECTATION-FLIP": lambda rd: next(
        x["fixture_inline"]["expected_observable"]
        for x in P.load(rd / "PHASE0A_ACCEPTANCE_CONTRACT.v4.json")["cases"]
        if x["case_id"] == "C-G-P0A-WRITE-BOUNDARY-NO-HOME-WIDE-WRITE-001"),
    "R19-P02-SLUG-PATTERN-SUBTLE-WEAKEN": lambda rd: P.load(rd / "PHASE0A_NOTE_STATE.schema.json")["properties"]["slug"]["pattern"],
    "R19-P03-DAG-PUBLIC-GITHUB-PUSH": lambda rd: [
        c for n in P.load(rd / "PHASE0A_BUILD_DAG.v2.json")["nodes"] for c in (n.get("required_checks") or [])
        if "GitHub" in c],
    "R19-P04-EVIDENCE-FIXTURE-TAMPER": lambda rd: sorted(
        p.name for p in (rd / "evidence_fixtures").rglob("*") if p.is_file() and b"tampered" in p.read_bytes()),
    "R19-P05-FORBIDDEN-EXAMPLES-REMOVED": lambda rd: P.load(rd / "PHASE0A_TRANSITION_TABLE.v1.json")["forbidden_examples"],
    "R19-P06-RESERVED-SLUGS-TRIMMED": lambda rd: P.load(rd / "PHASE0A_NOTE_STATE.schema.json")["x-phase0a-slug-reserved"],
    "R19-P07-RAW-HTML-CASE-EVASION": lambda rd: [
        (x["case_id"], x["fixture_inline"]["expected_observable"])
        for x in P.load(rd / "PHASE0A_ACCEPTANCE_CONTRACT.v4.json")["cases"] if "BOLD-TAG" in x["case_id"]],
}

def main():
    out = []
    for pid, fn, _ in P.PROBES:
        with tempfile.TemporaryDirectory(prefix="pa-r19-verify-") as tmp:
            rd = Path(tmp) / "round"
            shutil.copytree(SOURCE, rd)
            fn(rd)
            P.rebind(rd)
            P.regenerate_round_checksums(rd)
            sem = run(rd, [str(rd / "meta_validate_round18.py"), "--root", str(rd), "--semantic-only"])
            full = run(rd, [str(rd / "meta_validate_round18.py"), "--root", str(rd)])
            orc = run(rd, [str(rd / "independent_oracle.py"), str(rd / "PHASE0A_ACCEPTANCE_CONTRACT.v4.json")])
            trn = run(rd, [str(rd / "transition_evaluator.py")])
            exg = run(rd, [str(rd / "export_generator.py")])
            exv = run(rd, [str(rd / "export_verifier.py")])
            state = None
            if pid in CHECKS:
                try:
                    state = CHECKS[pid](rd)
                except Exception as e:
                    state = f"CHECK_ERROR:{e}"
            def errs(cp):
                try: return json.loads(cp.stdout).get("errors", [])
                except Exception: return ["<unparsed>"]
            rec = {
                "probe_id": pid,
                "mutation_present_in_tree": state,
                "semantic_only_exit": sem.returncode,
                "full_exit": full.returncode,
                "full_errors": errs(full)[:8],
                "oracle_exit": orc.returncode,
                "transition_evaluator_exit": trn.returncode,
                "export_generator_exit": exg.returncode,
                "export_verifier_exit": exv.returncode,
            }
            greens = all(rec[k] == 0 for k in ("semantic_only_exit", "full_exit", "oracle_exit",
                                              "transition_evaluator_exit", "export_generator_exit", "export_verifier_exit"))
            rec["all_documented_tools_green"] = greens
            rec["verdict"] = "FALSE_GREEN" if greens else "REJECTED"
            out.append(rec)
            print(f"{pid}: sem={sem.returncode} full={full.returncode} oracle={orc.returncode} "
                  f"trn={trn.returncode} gen={exg.returncode} ver={exv.returncode} -> {rec['verdict']}", flush=True)
            if not greens and rec["full_errors"]:
                print(f"    full errors: {rec['full_errors']}", flush=True)
    Path(sys.argv[2]).write_text(json.dumps({
        "probes": out,
        "false_green_count": sum(1 for r in out if r["verdict"] == "FALSE_GREEN"),
        "rejected_count": sum(1 for r in out if r["verdict"] == "REJECTED"),
    }, indent=2) + "\n", encoding="utf-8")

if __name__ == "__main__":
    main()
