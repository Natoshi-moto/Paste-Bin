# Round 016 Final Package-Validation Correction

During final single-ZIP assembly, the full validator correctly exposed a
checksum-coverage defect in its own package-integrity check.

## Defect

The validator excluded every file whose basename was `SHA256SUMS.txt` from the
expected Round 016 coverage set. That unintentionally excluded the required
nested file:

`fixtures/SHA256SUMS.txt`

The Round 016 outer checksum manifest correctly included that nested fixture
manifest, so the overly broad exclusion caused:

`ROUND16_SHA256SUMS_COVERAGE_MISMATCH`

## Repair

The validator now excludes only its own root manifest object:

```python
p != manifest
```

It no longer excludes nested checksum artifacts by basename.

## Revalidation

After the repair:

- the same semantic validator was used;
- all 36 disposable checksum-co-updated mutation classes were rerun;
- all 36 were rejected;
- false greens: 0;
- the complete Round 016 checksum coverage was regenerated;
- full package validation was rerun.

This correction changes no Phase 0A product authority, canon, implementation
claim, repository state, host-state claim, provider boundary, public boundary,
or wider-architecture posture.
