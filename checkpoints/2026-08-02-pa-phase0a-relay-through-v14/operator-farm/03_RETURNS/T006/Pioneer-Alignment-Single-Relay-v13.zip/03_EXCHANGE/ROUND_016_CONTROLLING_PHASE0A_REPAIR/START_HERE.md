# START HERE — Round 016 Controlling Phase 0A Repair

**Precedence:** `PHASE0A_PRECEDENCE_AND_SUPERSESSION.v1.json`  
**Controlling source:** original `Pioneer-Alignment-Phase-0A-Builder-Handoff-v1.md`  
**Status:** specification contract only; no implementation candidate  
**Wider architecture:** separate HOLD

## Read order

1. `PHASE0A_PRECEDENCE_AND_SUPERSESSION.v1.json`
2. `REPAIR_SUMMARY.md`
3. `PHASE0A_CANONICAL_RULES.v1.json`
4. `PHASE0A_NOTE_STATE.schema.json`
5. `PHASE0A_PROVENANCE_EVENT.schema.json`
6. `PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v2.json`
7. `PHASE0A_ACCEPTANCE_CONTRACT.v3.json`
8. `PHASE0A_RUNNER_INTERFACE.v1.json`
9. `PHASE0A_BUILD_DAG.v1.json`
10. `MUTATION_RECEIPTS.md`
11. `SPEC_VALIDATION_RECEIPT.json`
12. `RETURN_SUMMARY.md`

## Inventory

### Precedence and boundaries

- `PHASE0A_PRECEDENCE_AND_SUPERSESSION.v1.json`
- `NO_IMPLEMENTATION_CANDIDATE.json`

### Canonical note and provenance

- `PHASE0A_CANONICAL_RULES.v1.json`
- `PHASE0A_NOTE_STATE.schema.json`
- `PHASE0A_PROVENANCE_EVENT.schema.json`
- `PHASE0A_NOTE_EVENT_GOLDEN_VECTORS.v1.json`

### Selected-note export

- `PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v2.json`
- `PHASE0A_EXPORT_GOLDEN_VECTOR.v1.json`
- `fixtures/index.html`
- `fixtures/source.md`
- `fixtures/metadata.json`
- `fixtures/provenance.jsonl`
- `fixtures/SHA256SUMS.txt`
- `fixtures/export-receipt.json`
- `fixtures/selected-note-golden.zip`

### Acceptance and evidence

- `PHASE0A_GATE_CASE_EVIDENCE.schema.json`
- `PHASE0A_ACCEPTANCE_CONTRACT.v3.json`
- `PHASE0A_CANDIDATE_BINDING.schema.json`
- `PHASE0A_CANDIDATE_EVIDENCE.schema.json`
- `PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json`
- `PHASE0A_RUNNER_INTERFACE.v1.json`

### Build and review path

- `PHASE0A_CONDITION_REGISTRY.v1.json`
- `PHASE0A_DAG_SCHEMA.v1.json`
- `PHASE0A_BUILD_DAG.v1.json`

### Validation and receipts

- `meta_validate_round16.py`
- `run_round16_mutations.py`
- `MUTATION_RECEIPTS.json`
- `MUTATION_RECEIPTS.md`
- `SPEC_VALIDATION_RECEIPT.json`
- `PACKAGE_VALIDATION_CORRECTION.md`
- `REPAIR_SUMMARY.md`
- `RETURN_SUMMARY.md`
- `SHA256SUMS.txt`

## Claim boundary

`SPEC_CONTRACT_VALID` means the supplied specification is internally consistent
under the checks and mutations reported here.

It does not mean:

- the application exists;
- candidate tests passed;
- the host path is writable or inactive;
- a repository was created;
- a commit exists;
- any public or remote action is authorised.
