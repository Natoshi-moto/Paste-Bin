# Synthetic Local Note

This is **local-only**.
