# Round 016 — Controlling Phase 0A Repair Summary

**Posture:** `SPEC_CONTRACT_VALID` target only  
**Application candidate:** none  
**Repository mutation:** none  
**Host preflight:** not run  
**Wider Rounds 3–10 architecture:** separate HOLD

## Repair 1 — Precedence and bounded scope

`PHASE0A_PRECEDENCE_AND_SUPERSESSION.v1.json` makes the original Phase 0A
builder handoff controlling for the narrow local note application.

It supersedes, only for this lane, the three conflicting Round 014 files:

1. combined note/event replacement;
2. global deterministic export replacement;
3. broad build DAG.

All public, provider, identity, NEX/LEX, federation, governance, credential,
deployment, production, remote and spending boundaries remain prohibited.

## Repair 2 — Exact note and provenance schemas

Separate closed schemas now preserve:

- stable note ID and sequential version;
- title, slug, summary, Markdown body, status;
- injected RFC 3339 UTC timestamps;
- previous-state hash and state hash;
- all six required provenance actions;
- actor, action, subject, timestamp, previous-event hash and event hash;
- create sentinels;
- append-only rejection;
- atomic note/create-edit event transactions.

Golden vectors bind exact canonical bytes and SHA-256 results.

## Repair 3 — Exact selected-note export

The authorised product is restored:

- `index.html`;
- `source.md`;
- `metadata.json`;
- `provenance.jsonl`;
- `SHA256SUMS.txt`;
- `export-receipt.json`.

The frozen cut precedes `EXPORT_GENERATED`. Generation and verification events
are appended after the bundle and are never included in that same bundle.
The manifest excludes itself and the receipt; the receipt binds the manifest.
ZIP entries use `STORE`, fixed metadata and fixed order. A byte-level golden ZIP
is supplied.

## Repair 4 — Executable acceptance contract

All 63 inherited named tests are mapped exactly once to present immutable inline
case IDs, assertion IDs and required mutant IDs.

Twenty-six additional tests bind:

- dashboard and `LOCAL-ONLY / NO LIVE AUTHORITY` banner;
- end-to-end note workflow;
- typed fake Relay and provenance;
- repository discipline;
- failure receipts;
- scans;
- final report and ZIP exclusions.

Closed candidate-binding and candidate-evidence schemas distinguish
`SPEC_CONTRACT_VALID` from `CANDIDATE_TESTS_PASS`.

A synthetic structural evidence vector tests wrong-candidate, missing/skipped,
summary and surviving-mutant rejection without claiming an application exists.

## Repair 5 — Narrow build and review DAG

The Phase 0A-only DAG now contains:

1. input verification;
2. exact host/path preflight;
3. existing-repository recovery or explicit new-repository bootstrap exception;
4. architecture/spec freeze;
5. candidate build;
6. independent review;
7. repair/no-op decision;
8. mandatory independent re-review or initial-pass confirmation;
9. final local handoff.

All node, condition, output, review and hash references resolve. The host remains
unverified until runtime.

## Repair 6 — Mutation-tested validation

Thirty-six checksum-co-updated mutations were run in disposable complete relay
copies through the same Round 016 semantic validator.

Result:

```text
Mutation classes: 36
Rejected:         36
False green:      0
```

The suite covers missing/extra schema fields, removed provenance actions,
previous-hash removal, export cycles, gate/test/case/assertion removal,
duplicates, zero assertions, skips, bogus IDs, wrong candidate binding,
surviving mutants, inconsistent evidence, dangling DAG references, cycles,
unknown conditions, repair bypass and authority widening.

## Preserved blockers

Round 016 does not close or manufacture evidence for:

- missing exact binding-canon snapshots for the wider architecture;
- private GitHub backup authority;
- actual host state at `/home/anon/Projects/Pioneer-Alignment-App`;
- application implementation or candidate tests;
- wider S01–S07 architecture;
- real identities, balances, ballots, providers, federation or private-person data.

## Final assembly validation

The final package-integrity pass found one validator coverage-expression defect:
nested checksum manifests were excluded by basename. The expression was narrowed
to exclude only the root Round 016 checksum file. This did not alter product
semantics. Full validation and all 36 mutations were rerun afterward.

See `PACKAGE_VALIDATION_CORRECTION.md`.
