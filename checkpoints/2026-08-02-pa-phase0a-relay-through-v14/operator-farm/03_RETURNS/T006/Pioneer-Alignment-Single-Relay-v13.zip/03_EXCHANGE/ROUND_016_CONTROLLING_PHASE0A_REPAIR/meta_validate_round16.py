#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import argparse
import hashlib
import json
import sys
import unicodedata
import zipfile


def digest_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def digest(path: Path) -> str:
    return digest_bytes(path.read_bytes())


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def canonical_json_bytes(value):
    def check(v):
        if isinstance(v, float):
            raise ValueError("floats prohibited")
        if isinstance(v, dict):
            for k, val in v.items():
                if not isinstance(k, str):
                    raise ValueError("non-string key")
                if unicodedata.normalize("NFC", k) != k:
                    raise ValueError("non-NFC key")
                check(val)
        elif isinstance(v, list):
            for item in v:
                check(item)
        elif isinstance(v, str):
            if unicodedata.normalize("NFC", v) != v:
                raise ValueError("non-NFC string")
        elif isinstance(v, (int, bool)) or v is None:
            return
        else:
            raise ValueError(f"unsupported value {type(v)}")
    check(value)
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def unique_ids(items, key, errors, code):
    seen = set()
    for item in items:
        value = item.get(key)
        if not isinstance(value, str) or not value:
            errors.append(f"{code}: missing {key}")
        elif value in seen:
            errors.append(f"{code}: duplicate {value}")
        else:
            seen.add(value)
    return seen


def validate_evidence_fixture(contract, vectors, errors):
    if vectors.get("status") != "SCHEMA_AND_CONSISTENCY_FIXTURE_ONLY_NOT_APPLICATION_EVIDENCE":
        errors.append("EVIDENCE_VECTOR_STATUS_INVALID")
        return
    if vectors.get("application_candidate_exists") is not False:
        errors.append("EVIDENCE_VECTOR_FALSE_CANDIDATE_CLAIM")
    positive = vectors.get("positive_fixture", {})
    binding = positive.get("candidate_binding", {})
    evidence = positive.get("candidate_evidence", {})
    if positive.get("expected_validation") != "ACCEPT":
        errors.append("EVIDENCE_VECTOR_EXPECTED_NOT_ACCEPT")
    if evidence.get("candidate_id") != binding.get("candidate_id"):
        errors.append("EVIDENCE_WRONG_CANDIDATE")
    expected_binding_hash = digest_bytes(canonical_json_bytes(binding))
    if evidence.get("candidate_binding_sha256") != expected_binding_hash:
        errors.append("EVIDENCE_BINDING_HASH_MISMATCH")
    contract_hash = digest(ROOT / "PHASE0A_ACCEPTANCE_CONTRACT.v3.json")
    if binding.get("contract_sha256") != contract_hash or evidence.get("contract_sha256") != contract_hash:
        errors.append("EVIDENCE_CONTRACT_HASH_MISMATCH")
    expected_cases = {x["case_id"]: x for x in contract["cases"]}
    expected_assertions = {x["assertion_id"]: x for x in contract["assertions"]}
    expected_mutants = {x["mutant_id"]: x for x in contract["mutants"]}
    case_results = evidence.get("case_results", [])
    assertion_results = evidence.get("assertion_results", [])
    mutant_results = evidence.get("mutant_results", [])
    case_ids = [x.get("case_id") for x in case_results]
    assertion_ids = [x.get("assertion_id") for x in assertion_results]
    mutant_ids = [x.get("mutant_id") for x in mutant_results]
    if len(case_ids) != len(set(case_ids)) or set(case_ids) != set(expected_cases):
        errors.append("EVIDENCE_CASE_ID_SET_MISMATCH")
    if len(assertion_ids) != len(set(assertion_ids)) or set(assertion_ids) != set(expected_assertions):
        errors.append("EVIDENCE_ASSERTION_ID_SET_MISMATCH")
    if len(mutant_ids) != len(set(mutant_ids)) or set(mutant_ids) != set(expected_mutants):
        errors.append("EVIDENCE_MUTANT_ID_SET_MISMATCH")
    for result in case_results:
        case = expected_cases.get(result.get("case_id"))
        if not case:
            continue
        if result.get("transition") != case["expected_transition"] or result.get("reason_code") != case["expected_reason_code"]:
            errors.append("EVIDENCE_CASE_EXPECTATION_MISMATCH")
        if result.get("status") != "PASS":
            errors.append("EVIDENCE_CASE_NOT_PASS")
    if any(x.get("status") != "PASS" for x in assertion_results):
        errors.append("EVIDENCE_ASSERTION_NOT_PASS")
    if any(x.get("killed") is not True for x in mutant_results):
        errors.append("EVIDENCE_SURVIVING_MUTANT")
    summary = evidence.get("summary", {})
    exact = {
        "expected_cases": len(expected_cases),
        "executed_cases": len(expected_cases),
        "passed_cases": len(expected_cases),
        "failed_cases": 0,
        "skipped_cases": 0,
        "expected_assertions": len(expected_assertions),
        "passed_assertions": len(expected_assertions),
        "failed_assertions": 0,
        "required_mutants": len(expected_mutants),
        "killed_mutants": len(expected_mutants),
        "surviving_mutants": 0,
    }
    if summary != exact:
        errors.append("EVIDENCE_SUMMARY_INCONSISTENT")
    if evidence.get("status") != "CANDIDATE_TESTS_PASS":
        errors.append("EVIDENCE_POSITIVE_STATUS_INVALID")


parser = argparse.ArgumentParser()
parser.add_argument("--root", type=Path)
parser.add_argument("--semantic-only", action="store_true")
parser.add_argument("--receipt", type=Path)
args = parser.parse_args()

ROOT = (args.root or Path(__file__).resolve().parent).resolve()
RELAY = ROOT.parents[1]
errors = []

required_files = [
    "PHASE0A_PRECEDENCE_AND_SUPERSESSION.v1.json",
    "PHASE0A_CANONICAL_RULES.v1.json",
    "PHASE0A_NOTE_STATE.schema.json",
    "PHASE0A_PROVENANCE_EVENT.schema.json",
    "PHASE0A_NOTE_EVENT_GOLDEN_VECTORS.v1.json",
    "PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v2.json",
    "PHASE0A_EXPORT_GOLDEN_VECTOR.v1.json",
    "PHASE0A_GATE_CASE_EVIDENCE.schema.json",
    "PHASE0A_CANDIDATE_BINDING.schema.json",
    "PHASE0A_CANDIDATE_EVIDENCE.schema.json",
    "PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json",
    "PHASE0A_ACCEPTANCE_CONTRACT.v3.json",
    "PHASE0A_RUNNER_INTERFACE.v1.json",
    "PHASE0A_CONDITION_REGISTRY.v1.json",
    "PHASE0A_DAG_SCHEMA.v1.json",
    "PHASE0A_BUILD_DAG.v1.json",
    "NO_IMPLEMENTATION_CANDIDATE.json",
]
for name in required_files:
    if not (ROOT / name).is_file():
        errors.append("REQUIRED_FILE_MISSING:" + name)

if errors:
    print(json.dumps({"status": "SPEC_CONTRACT_INVALID", "errors": errors}, indent=2))
    sys.exit(1)

precedence = load(ROOT / "PHASE0A_PRECEDENCE_AND_SUPERSESSION.v1.json")
canonical = load(ROOT / "PHASE0A_CANONICAL_RULES.v1.json")
note_schema = load(ROOT / "PHASE0A_NOTE_STATE.schema.json")
event_schema = load(ROOT / "PHASE0A_PROVENANCE_EVENT.schema.json")
golden = load(ROOT / "PHASE0A_NOTE_EVENT_GOLDEN_VECTORS.v1.json")
export = load(ROOT / "PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v2.json")
export_golden = load(ROOT / "PHASE0A_EXPORT_GOLDEN_VECTOR.v1.json")
contract = load(ROOT / "PHASE0A_ACCEPTANCE_CONTRACT.v3.json")
runner = load(ROOT / "PHASE0A_RUNNER_INTERFACE.v1.json")
conditions = load(ROOT / "PHASE0A_CONDITION_REGISTRY.v1.json")
dag = load(ROOT / "PHASE0A_BUILD_DAG.v1.json")
no_candidate = load(ROOT / "NO_IMPLEMENTATION_CANDIDATE.json")
vectors = load(ROOT / "PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json")

# 1. Precedence and boundaries.
builder_path = RELAY / "01_ORIGINAL_ARTIFACTS/Pioneer-Alignment-Phase-0A-Builder-Handoff-v1.md"
if precedence.get("controlling_source", {}).get("path") != "01_ORIGINAL_ARTIFACTS/Pioneer-Alignment-Phase-0A-Builder-Handoff-v1.md":
    errors.append("PRECEDENCE_CONTROLLING_SOURCE_WRONG")
elif not builder_path.is_file() or precedence["controlling_source"].get("sha256") != digest(builder_path):
    errors.append("PRECEDENCE_CONTROLLING_SOURCE_HASH_MISMATCH")
superseded = {x.get("path") for x in precedence.get("superseded_for_narrow_phase0a_lane", [])}
expected_superseded = {
    "03_EXCHANGE/ROUND_014_CONTROLLING_REPAIR/PHASE0A_CANONICAL_NOTE_EVENT_SCHEMA.v1.json",
    "03_EXCHANGE/ROUND_014_CONTROLLING_REPAIR/PHASE0A_DETERMINISTIC_EXPORT_SPEC.v1.json",
    "03_EXCHANGE/ROUND_014_CONTROLLING_REPAIR/BUILD_DAG.v3.json",
}
if superseded != expected_superseded:
    errors.append("PRECEDENCE_SUPERSESSION_SET_WRONG")
for item in precedence.get("superseded_for_narrow_phase0a_lane", []):
    target = RELAY / item.get("path", "")
    if not target.is_file() or item.get("sha256") != digest(target):
        errors.append("PRECEDENCE_SUPERSEDED_HASH_MISMATCH:" + item.get("path", ""))
if precedence.get("wider_architecture_posture") != "HOLD_SEPARATE_NOT_PHASE0A_BUILD_PREREQUISITE":
    errors.append("WIDER_HOLD_POSTURE_INVALID")
for key, value in precedence.get("prohibited_authority", {}).items():
    if value is not False:
        errors.append("AUTHORITY_WIDENED:" + key)
allowed = precedence.get("allowed_product", {})
if allowed != {
    "workspace": "/home/anon/Projects/Pioneer-Alignment-App",
    "branch": "phase-0a/local-vertical-slice",
    "bind": "127.0.0.1",
    "remote_count": 0,
    "purpose": "local note create/edit/preview/export plus deterministic fake Relay",
}:
    errors.append("ALLOWED_PRODUCT_CHANGED")
claims = precedence.get("claims", {})
if claims.get("candidate_tests_pass_may_be_claimed_without_candidate_evidence") is not False or claims.get("host_path_verified") is not False or claims.get("application_implemented") is not False:
    errors.append("UNSUPPORTED_CLAIM_ENABLED")

# 2. Closed note/event schemas and golden vectors.
exact_note_fields = {
    "schema_version","note_id","version","title","slug","summary","body_markdown",
    "status","created_at","updated_at","previous_state_hash","state_hash",
}
if note_schema.get("additionalProperties") is not False:
    errors.append("NOTE_SCHEMA_NOT_CLOSED")
if set(note_schema.get("required", [])) != exact_note_fields:
    errors.append("NOTE_REQUIRED_FIELDS_WRONG")
if set(note_schema.get("properties", {})) != exact_note_fields:
    errors.append("NOTE_PROPERTIES_WRONG")
if note_schema.get("x-phase0a-transition-rules", {}).get("create", {}).get("previous_state_hash") != "0"*64:
    errors.append("NOTE_CREATE_SENTINEL_WRONG")
if note_schema.get("x-phase0a-transition-rules", {}).get("atomicity") is None:
    errors.append("NOTE_ATOMICITY_MISSING")

exact_actions = {
    "NOTE_CREATED","NOTE_EDITED","PREVIEW_GENERATED","EXPORT_GENERATED",
    "EXPORT_VERIFICATION_PASSED","EXPORT_VERIFICATION_FAILED",
}
exact_event_fields = {
    "schema_version","event_id","timestamp","actor","action","subject",
    "previous_event_hash","note_id","note_version","note_state_hash","details","event_hash",
}
if event_schema.get("additionalProperties") is not False:
    errors.append("EVENT_SCHEMA_NOT_CLOSED")
if set(event_schema.get("required", [])) != exact_event_fields:
    errors.append("EVENT_REQUIRED_FIELDS_WRONG")
if set(event_schema.get("properties", {})) != exact_event_fields:
    errors.append("EVENT_PROPERTIES_WRONG")
if set(event_schema.get("properties", {}).get("action", {}).get("enum", [])) != exact_actions:
    errors.append("EVENT_ACTION_SET_WRONG")
chain_rules = event_schema.get("x-phase0a-chain-rules", {})
if chain_rules.get("first_event_previous_event_hash") != "0"*64:
    errors.append("EVENT_CREATE_SENTINEL_WRONG")
if set(chain_rules.get("atomic_with_note_state", [])) != {"NOTE_CREATED","NOTE_EDITED"}:
    errors.append("EVENT_ATOMIC_ACTION_SET_WRONG")
if "UPDATE" not in chain_rules.get("append_only", "") or "DELETE" not in chain_rules.get("append_only", ""):
    errors.append("EVENT_APPEND_ONLY_RULE_MISSING")

note = golden.get("note", {})
calc_note = digest_bytes(b"PA-P0A-NOTE-STATE-V1\x00" + canonical_json_bytes({k:v for k,v in note.items() if k != "state_hash"}))
if note.get("state_hash") != calc_note or golden.get("expected", {}).get("note_state_hash") != calc_note:
    errors.append("GOLDEN_NOTE_HASH_MISMATCH")
prior = "0"*64
for event in golden.get("events", []):
    if event.get("previous_event_hash") != prior:
        errors.append("GOLDEN_EVENT_LINK_MISMATCH")
    calc = digest_bytes(b"PA-P0A-PROVENANCE-EVENT-V1\x00" + canonical_json_bytes({k:v for k,v in event.items() if k != "event_hash"}))
    if event.get("event_hash") != calc:
        errors.append("GOLDEN_EVENT_HASH_MISMATCH")
    prior = event.get("event_hash")

# 3. Selected-note export and fixture.
expected_order = ["index.html","source.md","metadata.json","provenance.jsonl","SHA256SUMS.txt","export-receipt.json"]
expected_content = ["index.html","source.md","metadata.json","provenance.jsonl"]
if export.get("members", {}).get("exact_entry_order") != expected_order:
    errors.append("EXPORT_MEMBER_ORDER_WRONG")
manifest_spec = export.get("members", {}).get("SHA256SUMS.txt", {})
if manifest_spec.get("exact_listed_members") != expected_content:
    errors.append("EXPORT_MANIFEST_MEMBER_SET_WRONG")
if manifest_spec.get("lists_self") is not False or manifest_spec.get("lists_export_receipt") is not False:
    errors.append("EXPORT_SELF_REFERENCE_ENABLED")
if export.get("members", {}).get("export-receipt.json", {}).get("not_listed_by_manifest") is not True:
    errors.append("EXPORT_RECEIPT_CYCLE")
if export.get("zip_container", {}).get("compression") != "STORE":
    errors.append("EXPORT_COMPRESSION_NOT_DETERMINISTIC_STORE")
for action in ("EXPORT_GENERATED","EXPORT_VERIFICATION_PASSED","EXPORT_VERIFICATION_FAILED"):
    if "never included in the same bundle" not in export.get("event_treatment", {}).get(action, ""):
        errors.append("EXPORT_EVENT_ACYCLIC_RULE_MISSING:" + action)

fixture_dir = ROOT / "fixtures"
zip_path = fixture_dir / "selected-note-golden.zip"
if not zip_path.is_file():
    errors.append("EXPORT_GOLDEN_ZIP_MISSING")
else:
    with zipfile.ZipFile(zip_path, "r") as archive:
        names = archive.namelist()
        if names != expected_order:
            errors.append("EXPORT_GOLDEN_ZIP_ORDER_WRONG")
        if archive.comment:
            errors.append("EXPORT_GOLDEN_ZIP_COMMENT")
        for info in archive.infolist():
            if info.compress_type != zipfile.ZIP_STORED or info.date_time != (1980,1,1,0,0,0):
                errors.append("EXPORT_GOLDEN_ZIP_METADATA_WRONG")
            expected_bytes = (fixture_dir / info.filename).read_bytes()
            if archive.read(info.filename) != expected_bytes:
                errors.append("EXPORT_GOLDEN_MEMBER_BYTES_MISMATCH")
    if export_golden.get("zip_sha256") != digest(zip_path):
        errors.append("EXPORT_GOLDEN_ZIP_HASH_MISMATCH")
for name, expected_hash in export_golden.get("member_sha256", {}).items():
    path = fixture_dir / name
    if not path.is_file() or digest(path) != expected_hash:
        errors.append("EXPORT_GOLDEN_MEMBER_HASH_MISMATCH:" + name)

# 4. Acceptance contract and inherited 63 tests.
floor_path = RELAY / contract.get("source_floor", {}).get("path", "")
if not floor_path.is_file() or contract.get("source_floor", {}).get("sha256") != digest(floor_path):
    errors.append("ACCEPTANCE_FLOOR_HASH_MISMATCH")
else:
    floor = load(floor_path)
    expected_floor = {(g["id"], name) for g in floor["gates"] for name in g["tests"]}
    actual_floor = {(t["gate_id"], t["name"]) for t in contract.get("tests", []) if any(g["gate_id"] == t["gate_id"] and g["source"] == "ROUND14_FLOOR" for g in contract.get("gates", []))}
    if len(expected_floor) != 63 or actual_floor != expected_floor:
        errors.append("ACCEPTANCE_63_TEST_MAPPING_MISMATCH")

gate_ids = unique_ids(contract.get("gates", []), "gate_id", errors, "GATE_ID")
test_ids = unique_ids(contract.get("tests", []), "test_id", errors, "TEST_ID")
case_ids = unique_ids(contract.get("cases", []), "case_id", errors, "CASE_ID")
assertion_ids = unique_ids(contract.get("assertions", []), "assertion_id", errors, "ASSERTION_ID")
mutant_ids = unique_ids(contract.get("mutants", []), "mutant_id", errors, "MUTANT_ID")
tests_by_id = {x["test_id"]:x for x in contract.get("tests", []) if x.get("test_id") in test_ids}
cases_by_id = {x["case_id"]:x for x in contract.get("cases", []) if x.get("case_id") in case_ids}
assertions_by_id = {x["assertion_id"]:x for x in contract.get("assertions", []) if x.get("assertion_id") in assertion_ids}
mutants_by_id = {x["mutant_id"]:x for x in contract.get("mutants", []) if x.get("mutant_id") in mutant_ids}
referenced_cases=[]; referenced_assertions=[]; referenced_mutants=[]
for gate in contract.get("gates", []):
    if not gate.get("test_ids"):
        errors.append("GATE_HAS_ZERO_TESTS:" + gate.get("gate_id",""))
    if any(tid not in test_ids for tid in gate.get("test_ids", [])):
        errors.append("GATE_DANGLING_TEST:" + gate.get("gate_id",""))
for test in contract.get("tests", []):
    if test.get("gate_id") not in gate_ids:
        errors.append("TEST_DANGLING_GATE:" + test.get("test_id",""))
    if not test.get("case_ids") or not test.get("assertion_ids") or not test.get("mutant_ids"):
        errors.append("TEST_ZERO_REFERENCES:" + test.get("test_id",""))
    for cid in test.get("case_ids", []):
        if cid not in case_ids:
            errors.append("TEST_DANGLING_CASE:" + test.get("test_id",""))
        referenced_cases.append(cid)
    for aid in test.get("assertion_ids", []):
        if aid not in assertion_ids:
            errors.append("TEST_DANGLING_ASSERTION:" + test.get("test_id",""))
        referenced_assertions.append(aid)
    for mid in test.get("mutant_ids", []):
        if mid not in mutant_ids:
            errors.append("TEST_DANGLING_MUTANT:" + test.get("test_id",""))
        referenced_mutants.append(mid)
for case in contract.get("cases", []):
    if case.get("immutable") is not True or case.get("execution_policy") != "RUN":
        errors.append("CASE_SKIPPED_OR_MUTABLE:" + case.get("case_id",""))
for assertion in contract.get("assertions", []):
    if assertion.get("case_id") not in case_ids:
        errors.append("ASSERTION_DANGLING_CASE:" + assertion.get("assertion_id",""))
for mutant in contract.get("mutants", []):
    if mutant.get("test_id") not in test_ids or mutant.get("required_killed") is not True:
        errors.append("MUTANT_INVALID:" + mutant.get("mutant_id",""))
if set(referenced_cases) != case_ids or len(referenced_cases) != len(case_ids):
    errors.append("CASE_REFERENCE_COVERAGE_OR_UNIQUENESS_FAILURE")
if set(referenced_assertions) != assertion_ids or len(referenced_assertions) != len(assertion_ids):
    errors.append("ASSERTION_REFERENCE_COVERAGE_OR_UNIQUENESS_FAILURE")
if set(referenced_mutants) != mutant_ids or len(referenced_mutants) != len(mutant_ids):
    errors.append("MUTANT_REFERENCE_COVERAGE_OR_UNIQUENESS_FAILURE")
counts = contract.get("counts", {})
exact_counts = {
    "inherited_named_tests": 63,
    "round16_additional_tests": len(test_ids)-63,
    "total_tests": len(test_ids),
    "total_cases": len(case_ids),
    "total_assertions": len(assertion_ids),
    "total_mutants": len(mutant_ids),
}
if counts != exact_counts:
    errors.append("ACCEPTANCE_COUNTS_INCONSISTENT")
required_additions = {
    "G-P0A-DASHBOARD","G-P0A-E2E","G-P0A-RELAY-SCHEMA","G-P0A-REPOSITORY",
    "G-P0A-FAILURE-RECEIPTS","G-P0A-FINAL-HANDOFF","G-P0A-SECURITY-SCANS",
}
if not required_additions.issubset(gate_ids):
    errors.append("ORIGINAL_HANDOFF_ADDITIONAL_GATES_MISSING")
if set(runner.get("required_runner_methods", [])) != {x["runner_method"] for x in contract.get("tests", [])}:
    errors.append("RUNNER_METHOD_SET_MISMATCH")
if runner.get("request_per_case", {}).get("skip_allowed") is not False:
    errors.append("RUNNER_SKIP_ALLOWED")
if contract.get("status") != "SPECIFICATION_ONLY_NO_CANDIDATE_RESULTS":
    errors.append("CONTRACT_FALSE_CANDIDATE_STATUS")
validate_evidence_fixture(contract, vectors, errors)

# 5. DAG references, conditions, cycles, hashes and re-review.
condition_ids = unique_ids(conditions.get("conditions", []), "condition_id", errors, "CONDITION_ID")
node_ids = unique_ids(dag.get("nodes", []), "node_id", errors, "NODE_ID")
input_ids = unique_ids(dag.get("inputs", []), "input_id", errors, "INPUT_ID")
node_map = {x["node_id"]:x for x in dag.get("nodes", []) if x.get("node_id") in node_ids}
output_refs=set()
for node in dag.get("nodes", []):
    for out in node.get("outputs", []):
        ref=f"output:{node['node_id']}/{out}"
        if ref in output_refs:
            errors.append("DUPLICATE_OUTPUT_REFERENCE:" + ref)
        output_refs.add(ref)
for item in dag.get("inputs", []):
    if item.get("kind") == "path_sha256":
        target = RELAY / item.get("path","")
        if not target.is_file() or item.get("sha256") != digest(target):
            errors.append("DAG_INPUT_HASH_MISMATCH:" + item.get("input_id",""))
    elif item.get("kind") == "manifest_selector":
        manifest = ROOT / item.get("manifest","")
        selector = item.get("selector","")
        if not manifest.is_file():
            errors.append("DAG_MANIFEST_MISSING:" + item.get("input_id",""))
        else:
            entries={}
            for line in manifest.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    h, rel=line.split("  ",1); entries[rel]=h
            target=ROOT/selector
            if selector not in entries or not target.is_file() or entries.get(selector) != digest(target):
                errors.append("DAG_MANIFEST_SELECTOR_UNRESOLVED:" + item.get("input_id",""))
    else:
        errors.append("DAG_INPUT_KIND_UNKNOWN:" + item.get("input_id",""))
for node in dag.get("nodes", []):
    for dep in node.get("depends_on", []):
        if dep not in node_ids:
            errors.append("DAG_DANGLING_NODE:" + dep)
    for cid in node.get("condition_ids", []):
        if cid not in condition_ids:
            errors.append("DAG_UNDECLARED_CONDITION:" + cid)
    rp=node.get("review_path")
    if rp is not None and rp not in node_ids:
        errors.append("DAG_DANGLING_REVIEW_PATH:" + str(rp))
    for ref in node.get("consumes", []):
        if ref.startswith("input:"):
            if ref.split(":",1)[1] not in input_ids:
                errors.append("DAG_DANGLING_INPUT_REF:" + ref)
        elif ref.startswith("output:"):
            if ref not in output_refs:
                errors.append("DAG_DANGLING_OUTPUT_REF:" + ref)
        else:
            errors.append("DAG_REFERENCE_FORMAT_INVALID:" + ref)
# Topological cycle detection.
temp=set(); perm=set()
def visit(n):
    if n in perm:
        return
    if n in temp:
        errors.append("DAG_CYCLE:" + n)
        return
    temp.add(n)
    for dep in node_map.get(n,{}).get("depends_on",[]):
        if dep in node_map:
            visit(dep)
    temp.remove(n); perm.add(n)
for nid in node_ids:
    visit(nid)
if dag.get("final_node") != "P0A-N80-FINAL-HANDOFF" or dag.get("final_node") not in node_ids:
    errors.append("DAG_FINAL_NODE_INVALID")
n60=node_map.get("P0A-N60-REPAIR-DECISION",{})
n70=node_map.get("P0A-N70-INDEPENDENT-REREVIEW",{})
n80=node_map.get("P0A-N80-FINAL-HANDOFF",{})
if n60.get("review_path") != "P0A-N70-INDEPENDENT-REREVIEW":
    errors.append("DAG_REPAIR_MISSING_REREVIEW_PATH")
if "P0A-N60-REPAIR-DECISION" not in n70.get("depends_on",[]):
    errors.append("DAG_REREVIEW_NOT_AFTER_REPAIR")
if "P0A-N70-INDEPENDENT-REREVIEW" not in n80.get("depends_on",[]):
    errors.append("DAG_FINAL_BYPASSES_REREVIEW")
if n80.get("condition_ids") != ["REREVIEW_PASS_OR_INITIAL_PASS_CONFIRMED"]:
    errors.append("DAG_FINAL_CONDITION_INVALID")
host=dag.get("host_preflight",{})
if host.get("workspace") != "/home/anon/Projects/Pioneer-Alignment-App" or host.get("branch") != "phase-0a/local-vertical-slice" or host.get("remote_count") != 0 or host.get("server_bind") != "127.0.0.1" or host.get("host_verified_in_round16") is not False:
    errors.append("DAG_HOST_PREFLIGHT_BOUNDARY_INVALID")
bootstrap=dag.get("bootstrap_exception",{})
if bootstrap.get("id") != "P0A-NEW-REPOSITORY-BOOTSTRAP-V1" or "skipping recovery for an existing repository" not in bootstrap.get("does_not_allow",[]):
    errors.append("DAG_BOOTSTRAP_EXCEPTION_INVALID")
if "S06R-P0A" in json.dumps(dag):
    errors.append("DAG_LEGACY_DANGLING_REVIEW_PRESENT")

# 6. No implementation claim.
if no_candidate.get("status") != "NO_IMPLEMENTATION_CANDIDATE" or no_candidate.get("application_tests_run") is not False or no_candidate.get("host_preflight_run") is not False or no_candidate.get("repository_mutated") is not False:
    errors.append("NO_CANDIDATE_RECEIPT_INVALID")

# 7. Full package integrity and mutation receipts.
if not args.semantic_only:
    manifest = ROOT / "SHA256SUMS.txt"
    if not manifest.is_file():
        errors.append("ROUND16_SHA256SUMS_MISSING")
    else:
        entries={}
        for line in manifest.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                h, rel=line.split("  ",1)
            except ValueError:
                errors.append("ROUND16_SHA256SUMS_MALFORMED")
                continue
            if rel in entries:
                errors.append("ROUND16_SHA256SUMS_DUPLICATE:" + rel)
            entries[rel]=h
            target=ROOT/rel
            if not target.is_file() or digest(target) != h:
                errors.append("ROUND16_SHA256SUMS_MISMATCH:" + rel)
        expected={
            p.relative_to(ROOT).as_posix()
            for p in ROOT.rglob("*")
            if p.is_file() and p != manifest
        }
        if set(entries) != expected:
            errors.append("ROUND16_SHA256SUMS_COVERAGE_MISMATCH")
    receipt_path=ROOT/"MUTATION_RECEIPTS.json"
    if not receipt_path.is_file():
        errors.append("MUTATION_RECEIPTS_MISSING")
    else:
        mr=load(receipt_path)
        if mr.get("status") != "ALL_REQUIRED_MUTATIONS_REJECTED":
            errors.append("MUTATION_RECEIPTS_STATUS_INVALID")
        tests_m=mr.get("tests",[])
        if len(tests_m) < 25 or any(x.get("result") != "REJECTED" or x.get("validator_exit_code") == 0 for x in tests_m):
            errors.append("MUTATION_RECEIPTS_INCOMPLETE_OR_FALSE_GREEN")

status = "SPEC_CONTRACT_VALID" if not errors else "SPEC_CONTRACT_INVALID"
receipt = {
    "schema_version":"pa.phase0a.round16_spec_validation.v1",
    "status":status,
    "validation_mode":"SEMANTIC_ONLY" if args.semantic_only else "FULL",
    "application_candidate_exists":False,
    "application_tests_run":False,
    "host_preflight_run":False,
    "checked":{
        "inherited_tests":63,
        "total_tests":len(test_ids),
        "total_cases":len(case_ids),
        "total_assertions":len(assertion_ids),
        "total_mutants":len(mutant_ids),
        "dag_nodes":len(node_ids),
    },
    "errors":errors,
}
if args.receipt:
    args.receipt.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps(receipt, indent=2))
sys.exit(0 if not errors else 1)
