#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import argparse
import copy
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile


SOURCE_ROUND = Path(__file__).resolve().parent
SOURCE_RELAY = SOURCE_ROUND.parents[1]


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def save(path, obj):
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def regenerate_round_checksum(round_dir: Path):
    manifest = round_dir / "SHA256SUMS.txt"
    files = sorted(p for p in round_dir.rglob("*") if p.is_file() and p != manifest)
    manifest.write_text(
        "".join(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(round_dir).as_posix()}\n" for p in files),
        encoding="utf-8",
    )


def mutate_json(round_dir, name, fn):
    path = round_dir / name
    obj = load(path)
    fn(obj)
    save(path, obj)


def m_note_missing(obj):
    obj["required"].remove("summary")

def m_note_extra(obj):
    obj["properties"]["unexpected_field"]={"type":"string"}

def m_event_action(obj):
    obj["properties"]["action"]["enum"].remove("EXPORT_VERIFICATION_FAILED")

def m_event_prev(obj):
    obj["required"].remove("previous_event_hash")

def m_export_member(obj):
    obj["members"]["exact_entry_order"][0]="page.html"

def m_export_self(obj):
    obj["members"]["SHA256SUMS.txt"]["exact_listed_members"].append("export-receipt.json")
    obj["members"]["SHA256SUMS.txt"]["lists_export_receipt"]=True

def m_remove_gate(obj):
    obj["gates"]=obj["gates"][1:]

def m_remove_test(obj):
    target=next(t for t in obj["tests"] if t["gate_id"]=="G-P0A-SCHEMA")
    obj["tests"].remove(target)

def m_remove_case(obj):
    obj["cases"]=obj["cases"][1:]

def m_remove_assertion(obj):
    obj["assertions"]=obj["assertions"][1:]

def m_duplicate_test(obj):
    obj["tests"].append(copy.deepcopy(obj["tests"][0]))

def m_zero_assertions(obj):
    obj["tests"][0]["assertion_ids"]=[]

def m_skip_case(obj):
    obj["cases"][0]["execution_policy"]="SKIP"

def m_bogus_mutant(obj):
    obj["tests"][0]["mutant_ids"]=["M-BOGUS"]

def m_wrong_candidate(obj):
    obj["positive_fixture"]["candidate_evidence"]["candidate_id"]="p0a-candidate-ffffffffffffffff"

def m_skipped_summary(obj):
    obj["positive_fixture"]["candidate_evidence"]["summary"]["skipped_cases"]=1

def m_surviving_mutant(obj):
    obj["positive_fixture"]["candidate_evidence"]["mutant_results"][0]["killed"]=False
    obj["positive_fixture"]["candidate_evidence"]["summary"]["killed_mutants"]-=1
    obj["positive_fixture"]["candidate_evidence"]["summary"]["surviving_mutants"]=1

def m_inconsistent_summary(obj):
    obj["positive_fixture"]["candidate_evidence"]["summary"]["executed_cases"]-=1

def m_unknown_assertion(obj):
    obj["positive_fixture"]["candidate_evidence"]["assertion_results"][0]["assertion_id"]="A-UNKNOWN"

def m_dag_node(obj):
    obj["nodes"][1]["depends_on"]=["P0A-N99-MISSING"]

def m_dag_output(obj):
    obj["nodes"][1]["consumes"]=["output:P0A-N00-VERIFY-INPUTS/O-MISSING"]

def m_dag_review(obj):
    obj["nodes"][4]["review_path"]="P0A-N99-MISSING"

def m_dag_hash(obj):
    target=next(x for x in obj["inputs"] if x["kind"]=="path_sha256")
    target["sha256"]="f"*64

def m_dag_cycle(obj):
    obj["nodes"][0]["depends_on"]=["P0A-N80-FINAL-HANDOFF"]

def m_dag_condition(obj):
    obj["nodes"][0]["condition_ids"]=["UNDECLARED_CONDITION"]

def m_dag_rereview(obj):
    target=next(x for x in obj["nodes"] if x["node_id"]=="P0A-N60-REPAIR-DECISION")
    target["review_path"]=None

def m_auth_network(obj):
    obj["prohibited_authority"]["public_network"]=True

def m_auth_remote(obj):
    obj["prohibited_authority"]["github_remote_creation_or_push"]=True

def m_auth_provider(obj):
    obj["prohibited_authority"]["external_provider"]=True

def m_auth_deploy(obj):
    obj["prohibited_authority"]["deployment"]=True

def m_false_candidate(obj):
    obj["application_tests_run"]=True

def m_export_event_cycle(obj):
    obj["event_treatment"]["EXPORT_GENERATED"]="included in the same bundle"

def m_runner_skip(obj):
    obj["request_per_case"]["skip_allowed"]=True

def m_floor_hash(obj):
    obj["source_floor"]["sha256"]="0"*64

def m_note_sentinel(obj):
    obj["x-phase0a-transition-rules"]["create"]["previous_state_hash"]="1"*64

def m_event_sentinel(obj):
    obj["x-phase0a-chain-rules"]["first_event_previous_event_hash"]="1"*64


MUTATIONS = [
    ("M01_NOTE_MISSING_REQUIRED_FIELD","PHASE0A_NOTE_STATE.schema.json",m_note_missing),
    ("M02_NOTE_EXTRA_FIELD","PHASE0A_NOTE_STATE.schema.json",m_note_extra),
    ("M03_PROVENANCE_ACTION_REMOVED","PHASE0A_PROVENANCE_EVENT.schema.json",m_event_action),
    ("M04_PROVENANCE_PREVIOUS_HASH_REMOVED","PHASE0A_PROVENANCE_EVENT.schema.json",m_event_prev),
    ("M05_EXPORT_WRONG_MEMBER","PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v2.json",m_export_member),
    ("M06_EXPORT_SELF_REFERENTIAL_RECEIPT","PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v2.json",m_export_self),
    ("M07_PHASE0A_GATE_REMOVED","PHASE0A_ACCEPTANCE_CONTRACT.v3.json",m_remove_gate),
    ("M08_PHASE0A_TEST_REMOVED","PHASE0A_ACCEPTANCE_CONTRACT.v3.json",m_remove_test),
    ("M09_PHASE0A_CASE_REMOVED","PHASE0A_ACCEPTANCE_CONTRACT.v3.json",m_remove_case),
    ("M10_PHASE0A_ASSERTION_REMOVED","PHASE0A_ACCEPTANCE_CONTRACT.v3.json",m_remove_assertion),
    ("M11_DUPLICATE_TEST_ID","PHASE0A_ACCEPTANCE_CONTRACT.v3.json",m_duplicate_test),
    ("M12_ZERO_ASSERTIONS","PHASE0A_ACCEPTANCE_CONTRACT.v3.json",m_zero_assertions),
    ("M13_SKIPPED_CASE","PHASE0A_ACCEPTANCE_CONTRACT.v3.json",m_skip_case),
    ("M14_BOGUS_MUTANT_ID","PHASE0A_ACCEPTANCE_CONTRACT.v3.json",m_bogus_mutant),
    ("M15_WRONG_CANDIDATE","PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json",m_wrong_candidate),
    ("M16_SKIPPED_CASE_SUMMARY","PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json",m_skipped_summary),
    ("M17_SURVIVING_MUTANT","PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json",m_surviving_mutant),
    ("M18_INCONSISTENT_SUMMARY","PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json",m_inconsistent_summary),
    ("M19_UNKNOWN_ASSERTION_RESULT","PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json",m_unknown_assertion),
    ("M20_DAG_DANGLING_NODE","PHASE0A_BUILD_DAG.v1.json",m_dag_node),
    ("M21_DAG_DANGLING_OUTPUT","PHASE0A_BUILD_DAG.v1.json",m_dag_output),
    ("M22_DAG_DANGLING_REVIEW","PHASE0A_BUILD_DAG.v1.json",m_dag_review),
    ("M23_DAG_WRONG_INPUT_HASH","PHASE0A_BUILD_DAG.v1.json",m_dag_hash),
    ("M24_DAG_CYCLE","PHASE0A_BUILD_DAG.v1.json",m_dag_cycle),
    ("M25_DAG_UNDECLARED_CONDITION","PHASE0A_BUILD_DAG.v1.json",m_dag_condition),
    ("M26_REPAIR_WITHOUT_REREVIEW","PHASE0A_BUILD_DAG.v1.json",m_dag_rereview),
    ("M27_AUTHORITY_PUBLIC_NETWORK","PHASE0A_PRECEDENCE_AND_SUPERSESSION.v1.json",m_auth_network),
    ("M28_AUTHORITY_REMOTE_PUSH","PHASE0A_PRECEDENCE_AND_SUPERSESSION.v1.json",m_auth_remote),
    ("M29_AUTHORITY_EXTERNAL_PROVIDER","PHASE0A_PRECEDENCE_AND_SUPERSESSION.v1.json",m_auth_provider),
    ("M30_AUTHORITY_DEPLOYMENT","PHASE0A_PRECEDENCE_AND_SUPERSESSION.v1.json",m_auth_deploy),
    ("M31_FALSE_APPLICATION_TEST_CLAIM","NO_IMPLEMENTATION_CANDIDATE.json",m_false_candidate),
    ("M32_EXPORT_LIFECYCLE_CYCLE","PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v2.json",m_export_event_cycle),
    ("M33_RUNNER_SKIP_ALLOWED","PHASE0A_RUNNER_INTERFACE.v1.json",m_runner_skip),
    ("M34_ACCEPTANCE_FLOOR_HASH_WRONG","PHASE0A_ACCEPTANCE_CONTRACT.v3.json",m_floor_hash),
    ("M35_NOTE_CREATE_SENTINEL_WRONG","PHASE0A_NOTE_STATE.schema.json",m_note_sentinel),
    ("M36_EVENT_CREATE_SENTINEL_WRONG","PHASE0A_PROVENANCE_EVENT.schema.json",m_event_sentinel),
]


parser=argparse.ArgumentParser()
parser.add_argument("--output-json",type=Path,required=True)
parser.add_argument("--output-md",type=Path,required=True)
args=parser.parse_args()

baseline=subprocess.run(
    [sys.executable,"-S",str(SOURCE_ROUND/"meta_validate_round16.py"),"--root",str(SOURCE_ROUND),"--semantic-only"],
    capture_output=True,text=True,
)
if baseline.returncode != 0:
    print("baseline failed")
    print(baseline.stdout)
    print(baseline.stderr)
    raise SystemExit(2)

results=[]
for test_id, filename, fn in MUTATIONS:
    with tempfile.TemporaryDirectory(prefix="pa-round16-mut-") as td:
        relay=Path(td)/"relay"
        shutil.copytree(SOURCE_RELAY,relay)
        rdir=relay/"03_EXCHANGE/ROUND_016_CONTROLLING_PHASE0A_REPAIR"
        mutate_json(rdir,filename,fn)
        regenerate_round_checksum(rdir)
        run=subprocess.run(
            [sys.executable,"-S",str(rdir/"meta_validate_round16.py"),"--root",str(rdir),"--semantic-only"],
            capture_output=True,text=True,
        )
        rejected=run.returncode != 0 and "SPEC_CONTRACT_INVALID" in run.stdout
        results.append({
            "test_id":test_id,
            "mutated_file":filename,
            "expected":"REJECT",
            "validator":"meta_validate_round16.py --semantic-only",
            "checksum_co_updated":True,
            "validator_exit_code":run.returncode,
            "result":"REJECTED" if rejected else "FALSE_GREEN",
            "stdout":run.stdout,
            "stderr":run.stderr,
        })

status="ALL_REQUIRED_MUTATIONS_REJECTED" if all(x["result"]=="REJECTED" for x in results) else "FALSE_GREEN_PRESENT"
receipt={
    "schema_version":"pa.phase0a.round16_mutation_receipts.v1",
    "status":status,
    "source_tree_modified":False,
    "execution_boundary":"complete relay copied into disposable temporary directories outside the immutable relay tree",
    "validator":"the same Round 016 semantic validator used by the supplied specification; each mutant checksum was co-updated",
    "baseline":{"exit_code":baseline.returncode,"stdout":baseline.stdout,"stderr":baseline.stderr},
    "summary":{
        "mutation_classes":len(results),
        "rejected":sum(x["result"]=="REJECTED" for x in results),
        "false_green":sum(x["result"]!="REJECTED" for x in results),
    },
    "tests":results,
}
args.output_json.write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
lines=[
    "# Round 016 Mutation Test Receipt",
    "",
    f"**Status:** `{status}`",
    "",
    f"- Mutation classes: {len(results)}",
    f"- Rejected: {receipt['summary']['rejected']}",
    f"- False green: {receipt['summary']['false_green']}",
    "- Source tree modified: no",
    "- Each disposable mutant had its local checksum co-updated before the semantic validator ran.",
    "",
    "| ID | Mutated file | Exit | Result |",
    "|---|---|---:|---|",
]
for x in results:
    lines.append(f"| `{x['test_id']}` | `{x['mutated_file']}` | {x['validator_exit_code']} | `{x['result']}` |")
args.output_md.write_text("\n".join(lines)+"\n",encoding="utf-8")
print(json.dumps(receipt["summary"],indent=2))
raise SystemExit(0 if status=="ALL_REQUIRED_MUTATIONS_REJECTED" else 1)
