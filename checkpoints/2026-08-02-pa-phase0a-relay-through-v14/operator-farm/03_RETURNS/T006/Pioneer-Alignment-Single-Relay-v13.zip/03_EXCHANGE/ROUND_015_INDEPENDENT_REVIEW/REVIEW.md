# Pioneer Alignment — Round 015 Independent Review

Version: v1  
Date: 2026-08-01  
Actor: independent high-reasoning architecture critic  
Posture: review, mutation testing and adjudication only

## 1. Authority understood

I was authorised to inspect the complete relay, test Round 014 on disposable copies,
adjudicate all Round 011 and Round 013 findings, write this Round 015 review and return
one complete relay ZIP. I was not authorised to build application code, mutate a Git
repository, create a branch or commit, push to GitHub, connect a provider, use
credentials, deploy, change public infrastructure, spend money, enrol real identities
or promote provisional architecture into binding canon.

The operator's GitHub intent is preserved: private backup/pastebin continuity only,
with one fresh exact single-use approval per backup. No such approval exists in this
round and no remote action occurred.

## 2. Relay and manifest verification

Received archive:

- filename: `Pioneer-Alignment-Single-Relay-v5(1).zip`;
- outer SHA-256: `c777188b07b63402c46c0506fbcdd21241f374fb1d60c6c6c8290a6ce08ac566`;
- entries: 176 unique paths;
- uncompressed bytes: 1,615,966;
- archive test: PASS;
- absolute/traversal paths: none;
- duplicate paths: none;
- symlinks: none;
- wrapper directory: none;
- immutable input manifest: PASS, 166/166 files;
- current manifest: PASS, 175/175 covered files, correctly excluding itself.

The received `FILE_INVENTORY.json` is not accurate despite being current-version
labelled. It lists stale byte counts and hashes for both manifest files:

- `CURRENT_SHA256SUMS.txt`: declared 21,060 bytes, actual 27,327;
- `INPUT_SHA256SUMS.txt`: declared 20,254 bytes, actual 26,456.

It declares 176 files, lists 175, and does not state that its own path is excluded.
This is a manifest-generation ordering defect, not evidence that immutable source files
changed. The returned v6 control tooling uses a cycle-free ordering and explicit
inventory exclusions.

## 3. Command and mutation-test results

Mandatory baseline commands all returned zero:

| Command | Result |
|---|---|
| `python3 generate_round14_views.py --check` | PASS — `PASS generated views` |
| `python3 validate_round14.py` | PASS — broad `ROUND14 VALIDATION PASS` claim |
| `python3 SYNTHETIC_GENESIS/verify_genesis.py` | PASS — fixed-file hashes match |

The generated-view check is real: mutating the graph without regenerating its view is
detected. The broader validator claim is not. A 12-class disposable-copy mutation suite
caught only the stale-view mutation. The following eleven material mutants still
returned `ROUND14 VALIDATION PASS`:

1. regenerated graph containing an edge to a nonexistent node;
2. unknown DAG enable/dependency condition;
3. valid-reference DAG cycle;
4. removal of Nostr and Noted from adapter integration;
5. gate registry requiring assertion and mutant IDs absent from the corpus;
6. every Phase 0A acceptance-floor test list emptied;
7. invalid genesis signature with its adjacent file hash updated;
8. arbitrary genesis canonical-body byte with its adjacent expected hash updated;
9. privacy golden vector changed from rejecting a public payload hash to accepting it;
10. double compensation enabled and emergency restart reset enabled;
11. public-blocker closure predicate replaced with `TRUE`.

Additional independent mutations also passed: an orphan/deleted graph edge, severing
`S06R-ADAPTERS` from integration, blank accepted-base paths, mutation of both supplied
schema-description files, changing the emergency window from 30 to 365 days, enabling
Noted with institutional effects, adding `nex_work_receipt` to maturity inputs, and
erasing Round 013 finding mappings.

The validator's in-memory "planted defects" do not run mutated artifacts through the
real validator. They prove only tautologies such as a changed byte having a changed
hash or a locally constructed missing node being missing.

## 4. Executive adjudication

`HOLD_FOR_ADDITIONAL_ARCHITECTURE_REPAIR`

Round 014 contains substantial useful repair work. The generated views are genuinely
lossless, the supplied unmodified synthetic-genesis bytes are internally coherent,
the GitHub boundary is correct, the original authority wording is restored, and the
recovery requirements are materially stronger.

It is nevertheless not build-ready. The decisive defects are executable, not
philosophical:

- every one of the 114 gate fixture paths is absent;
- the gate evidence schema has no runner or semantic validator;
- the DAG accepts cycles, undeclared conditions, dangling review paths and missing
  static hash receipts;
- the genesis verifier re-hashes supplied outputs rather than deriving and validating
  them;
- privacy and membrane rules are prose/data objects without closed machine schemas or
  reducers;
- the Phase 0A repair contradicts its controlling builder handoff and points to a
  nonexistent `S06R-P0A` review node.

Architecture-level disposition totals across the requested 42 findings:

| Disposition | Count |
|---|---:|
| `CLOSED_AT_ARCHITECTURE_SPEC_LEVEL` | 5 |
| `PARTIALLY_CLOSED` | 35 |
| `OPEN` | 1 |
| `EXTERNAL_EVIDENCE_BLOCKER` | 1 |
| `SUPERSEDED_BY_STRONGER_REPAIR` | 0 |

Architecture-level closure is not implementation closure and grants no build, GitHub,
provider, deployment or public authority.

## 5. Round 011 finding-by-finding table

| ID | Disposition | Round 015 adjudication |
|---|---|---|
| R11-001 | `EXTERNAL_EVIDENCE_BLOCKER` | Exact binding-canon snapshots remain honestly absent. |
| R11-002 | `PARTIALLY_CLOSED` | JSON/Markdown parity is lossless, but graph referential and semantic validity is unchecked; seven forbidden-edge endpoints are undefined. |
| R11-003 | `PARTIALLY_CLOSED` | Coherent fixture bytes exist, but the supplied verifier does not derive state, event ID, checkpoint or signatures. |
| R11-004 | `PARTIALLY_CLOSED` | Stronger membrane wording exists, but the live `WORK_REP -> COMPETENCE -> ROLE -> EVT -> LEX -> GOV` path remains generic and no reducer proves isolation. |
| R11-005 | `PARTIALLY_CLOSED` | Structured references improve the DAG, but cycles, conditions, review paths, accepted bases and static hash pointers are not validated. |
| R11-006 | `PARTIALLY_CLOSED` | One registry/schema/corpus exists, but 114 fixtures and a runner are absent and semantic ID mutants pass. |
| R11-007 | `PARTIALLY_CLOSED` | The clean-room requirement is credible; exact runnable independent replay vectors and implementation evidence remain absent. |
| R11-008 | `PARTIALLY_CLOSED` | Receipt roles are separated in a descriptive schema, but repaired candidates go from S06F to S06A without a mandatory independent re-review node. |
| R11-009 | `PARTIALLY_CLOSED` | Note version/state binding is added, but the replacement event is not the required hash-linked Phase 0A provenance event. |
| R11-010 | `PARTIALLY_CLOSED` | ZIP determinism is specified, but the required selected-note publication bundle is replaced by a different global JSONL export. |
| R11-011 | `CLOSED_AT_ARCHITECTURE_SPEC_LEVEL` | Detached final-commit receipt rule remains correct. |
| R11-012 | `PARTIALLY_CLOSED` | Public/private payload separation is directionally sound; no closed envelope/sidecar/purge schema or executable low-entropy test exists. |
| R11-013 | `PARTIALLY_CLOSED` | Local logical-time/finality boundaries are clearer, but vectors and framing are insufficient for clean implementations. |
| R11-014 | `PARTIALLY_CLOSED` | No-standing-authority, private purpose, expiry, single use and recursive inspection are explicit; private-only/non-force validation, consumption and postflight schemas are absent. No backup is authorised. |
| R11-015 | `PARTIALLY_CLOSED` | The unmodified DAG routes adapters through integration/review, but removal of two adapter dependencies and severing review still pass. |
| R11-016 | `PARTIALLY_CLOSED` | Decisions are populated, but the advertised fail-closed lint does not exist and parameter mutation passes. |
| R11-017 | `PARTIALLY_CLOSED` | Bundle, restore, SBOM and double-build requirements are strong prose, but there is no runner/receipt schema and bundle-before-mutation deadlocks a brand-new repository. |
| R11-018 | `PARTIALLY_CLOSED` | The acceptance-floor labels include browser controls, but exact fixtures, runner and complete Host/Origin/CSRF policy are absent. |
| R11-019 | `PARTIALLY_CLOSED` | Blockers are named and candidate-shaped, but predicates are inert strings; `TRUE` passes the validator. |
| R11-020 | `PARTIALLY_CLOSED` | Scope is corrected, but reproducible parser and subject tuple are still absent. |
| R11-021 | `CLOSED_AT_ARCHITECTURE_SPEC_LEVEL` | The 95-entry mapping has unique legacy and canonical IDs and uses `R9-B###` as primary blocker IDs. |
| R11-022 | `CLOSED_AT_ARCHITECTURE_SPEC_LEVEL` | Inner manifest and detached outer digest are non-self-referential and verified. |
| R11-023 | `PARTIALLY_CLOSED` | Evidence shape exists, but no runner rejects wrong candidates or inconsistent summaries. |
| R11-024 | `PARTIALLY_CLOSED` | One-domain settlement is stated, but no atomic lineage schema/reducer or race/derivative semantics exist. |
| R11-025 | `PARTIALLY_CLOSED` | Equal proposal quota is stated, but no withdrawal/retry/sponsor/concurrency state machine exists. |
| R11-026 | `PARTIALLY_CLOSED` | Civic-only voting and legacy supersession are clear, but generic `LEX -> GOV` remains and transition/remediation semantics are not executable. |
| R11-027 | `PARTIALLY_CLOSED` | Anonymous envelope/nullifier direction is sound, but no proof, delegation, recovery or duplicate-vote reducer is supplied. |
| R11-028 | `PARTIALLY_CLOSED` | Relatedness factors are listed, but transitive collapse, unknown evidence, appeal/privacy and recovery continuity are undefined. |
| R11-029 | `PARTIALLY_CLOSED` | Fingerprint fields and restart non-reset are stated, but there is no cumulative hard cap, equivalence algorithm or deterministic post-cap transition. |
| R11-030 | `PARTIALLY_CLOSED` | Threats are listed, but no observer model, metric/bound, mapping schema or deletion transition exists. |
| R11-031 | `PARTIALLY_CLOSED` | Precommit/abort/isolation rules improve the design, but seed combination, deadlines, independence and grind-resistance tests remain undefined. |

## 6. Round 013 finding-by-finding table

| ID | Disposition | Round 015 adjudication |
|---|---|---|
| R13-001 | `PARTIALLY_CLOSED` | Generators and `--check` now exist, but the broad validator accepts eleven material semantic mutants in the primary suite. |
| R13-002 | `PARTIALLY_CLOSED` | Dependencies are structured, but cycle/condition/review-path checks are absent and all 14 static `sha256_source` paths are missing. |
| R13-003 | `OPEN` | Gate names are decorative: the corpus has 114 absent fixtures, generic mutants, no runner and no mapping from the 63 Phase 0A tests. |
| R13-004 | `PARTIALLY_CLOSED` | Fixture files and coherent expected bytes exist, but clean derivation and signature/linkage verification do not. |
| R13-005 | `PARTIALLY_CLOSED` | A supersession map and membrane contract exist, but they are not shared closed schemas/reducers and the transitive role path persists. |
| R13-006 | `PARTIALLY_CLOSED` | Actor/anonymous/confidential separation resolves the headline contradiction, but vectors are mostly descriptions and machine schemas/framing remain incomplete. |
| R13-007 | `CLOSED_AT_ARCHITECTURE_SPEC_LEVEL` | Full NEX isolation, external-rail list and operator start/expiry semantics are restored in the normative graph. |
| R13-008 | `PARTIALLY_CLOSED` | Namespace mapping is complete; public-blocker predicates and evidence validation remain non-executable. |
| R13-009 | `PARTIALLY_CLOSED` | Exact-looking files exist, but they omit controlling Phase 0A fields/events and specify the wrong export product. |
| R13-010 | `PARTIALLY_CLOSED` | The policy reflects the operator's clarified intent and grants no authority, but private-only/non-force validation, consumption and postflight rules are not executable. |
| R13-011 | `CLOSED_AT_ARCHITECTURE_SPEC_LEVEL` | The received inventory was stale; the returned v6 protocol/tooling now uses explicit mutable paths and cycle-free manifest/inventory generation. |

## 7. Fourteen-amendment review

| Class | Result | Core reason |
|---:|---|---|
| 1 | `EXTERNAL_EVIDENCE_BLOCKER` | Missing canon bytes are honestly preserved, not fabricated. |
| 2 | `PARTIALLY_CLOSED` | Lossless views work; semantic/schema mutation coverage does not. |
| 3 | `PARTIALLY_CLOSED` | Structured DAG references work only for the small subset the validator checks. |
| 4 | `PARTIALLY_CLOSED` | Present adapter path is correct but is not invariant under validator-tested mutations. |
| 5 | `PARTIALLY_CLOSED` | Evidence schema/corpus names exist without fixtures or a runner. |
| 6 | `PARTIALLY_CLOSED` | Gate IDs are restored, but Phase 0A behaviour and export contradict the controlling handoff. |
| 7 | `PARTIALLY_CLOSED` | Genesis bytes are coherent but not independently derived by the verifier. |
| 8 | `PARTIALLY_CLOSED` | Supersession and membrane policy exist without closed reducers. |
| 9 | `PARTIALLY_CLOSED` | Envelope separation is improved; machine schemas and executable privacy vectors are absent. |
| 10 | `PARTIALLY_CLOSED` | Registries are populated, but lint and closure evaluation are inert. |
| 11 | `PARTIALLY_CLOSED` | Federation/Noted bounds are useful requirements, not complete executable protocols. |
| 12 | `PARTIALLY_CLOSED` | Recovery/authenticity requirements are strong but lack a bootstrap exception, receipt schema and runner. |
| 13 | `PARTIALLY_CLOSED` | GitHub purpose and no-authority posture are safe; exact executable private/non-force/postflight controls remain absent. |
| 14 | `CLOSED_AT_ARCHITECTURE_SPEC_LEVEL` | v6 repairs the received inventory/control generation cycle. |

Full records and objective tests are in `AMENDMENT_REVIEW.json`.

## 8. Graph and generated-view parity

`generate_round14_views.py --check` genuinely detects source/view drift. Both generated
Markdown files include canonical JSON that parses equal to their source objects, so the
declared lossless representation claim is valid.

That does not validate graph meaning. The graph admits regenerated orphan edges. Its
forbidden-edge list refers to seven undefined endpoints:

`SOCIAL_VISIBILITY`, `EVIDENCE`, `CLAIM_TRUTH`, `ROLE_GOVERNANCE_POWER`,
`TASK_ELIGIBILITY`, `FEDERATION`, and `GOVERNANCE_IDENTITY`.

Those symbolic targets do not block paths through actual nodes. In particular,
`WORK_REP -> COMPETENCE -> ROLE -> EVT -> LEX -> GOV` remains present while the
purported governance-role prohibition targets nonexistent `ROLE_GOVERNANCE_POWER`.
A closed graph schema must distinguish nodes, typed external concepts and forbidden
path predicates, then enforce referential integrity and transitive invariants.

## 9. DAG and enabled-adapter review path

Round 014 corrects the original S04 dependency and, as supplied, includes all three
optional adapters in `S05-ADAPTERS` and `S06R-ADAPTERS`. The machine contract remains
non-executable:

- `BUILD_DAG_SCHEMA.v3.json` is a list of required names and prose rules, not a JSON
  Schema or validator;
- a valid-reference cycle passes;
- undeclared condition strings pass;
- `review_path: S06R-P0A` points to no node;
- 14 static input `sha256_source` paths name nonexistent individual `.sha256` files;
- empty accepted-base paths pass;
- removal of Nostr/Noted integration passes because only AT is explicitly checked;
- severing adapter review passes;
- S06F repair flows directly to S06A, although the receipt rule requires the repaired
  candidate to be independently re-reviewed.

Round 016 must supply a closed condition registry, topological/configuration validator,
review-path referential checks, actual hash references and an explicit repair-to-review
loop.

## 10. Gate evidence and Phase 0A acceptance floor

The registry contains 38 gates, each with three named case paths: 114 paths total and
zero corresponding fixture files. Mutants are generic labels such as
`invert_primary_predicate`, not executable candidate mutations. No gate runner, evidence
validator or candidate-bound receipt exists. The supplied validator checks counts and
case-ID equality but does not bind assertion/mutant IDs to the corpus, execute a test or
validate `pa.gate_evidence.v1` instances.

The 12 Phase 0A gate identifiers are restored, but the test lists are not wired to the
gate corpus and can all be emptied while validation stays green.

More seriously, the exact Phase 0A files contradict the controlling builder handoff:

| Controlling Phase 0A requirement | Round 014 replacement defect |
|---|---|
| note has title, slug, summary, body, status and timestamps | `note_state` omits summary, status and timestamps |
| provenance covers create, edit, preview, export and export verification | event schema permits only create/update/delete |
| event has timestamp, actor, action, subject, previous-event hash and canonical hash | replacement omits timestamp, actor and previous-event hash |
| export one selected note with rendered HTML, source, metadata, provenance excerpt, `SHA256SUMS.txt` and receipt | replacement exports global `notes.jsonl`, `events.jsonl`, `manifest.json` and `README.txt` |

The deterministic ZIP metadata work is reusable, but it cannot silently replace the
product the operator authorised.

## 11. Genesis and clean-room replay boundary

Independent checking confirmed that the supplied unmodified fixture is internally
coherent: public keys derive from the supplied deterministic test seeds, the genesis
signature verifies and the event-ID formula matches.

`verify_genesis.py` does not establish those facts. It compares hashes of adjacent
files to values in an adjacent expected file. It does not:

- derive keys, canonical event bytes or state from `GENESIS_INPUTS.json`;
- verify Ed25519 signatures;
- recompute and compare `genesis_event_id`;
- derive the checkpoint body or state hash;
- validate `GENESIS_MANIFEST.json`;
- reject an input/event linkage mismatch.

An invalid signature and an arbitrary canonical-body mutation both pass when the
adjacent expected hash is updated. This is a useful fixture pack, not the requested
clean-room derivation proof.

## 12. NEX/LEX, maturity, role and compensation membranes

The strongest Round 014 policy decisions are directionally correct: work/NEX/social
inputs are forbidden from maturity; only current-cycle civic LEX is voting-eligible;
service/transferred LEX is non-voting; proposal slots are identity-capped; one
deliverable lineage is intended to settle in one domain; Noted has zero institutional
effect.

The file is a contract-shaped object, not a reducer/schema package. No transition
inputs/outputs, state keys, atomic claim rule, failure codes, concurrency semantics or
reference implementation exist. Material fields are not validated: double settlement,
emergency restart reset, Noted institutional effects and forbidden maturity inputs can
be introduced without making Round 014 red. Administrative-domain transitive collapse,
unknown evidence and appeal semantics also remain unspecified.

## 13. Anonymous ballots, event encoding, privacy and purge

Separating `ACTOR_EVENT_V2`, `ANONYMOUS_ACTION_V1` and
`CONFIDENTIAL_RECORD_V1` fixes the prior "anonymous ballot wearing a name badge"
contradiction. The public confidential envelope correctly prohibits a raw or
deterministic content commitment and keeps restricted integrity in a sidecar.

This remains prose rather than three closed schemas. Most golden vectors are natural-
language descriptions with no exact input bytes, canonical bytes or hashes. The
validator does not read them: changing `PRIVATE-001` from REJECT to ACCEPT passes.
Control-character JSON escaping and signature length framing are not byte-complete, and
the anonymous eligibility proof, delegation override, revocation and recovery/nullifier
continuity have no selected algorithms or reducer states. Purge safety needs an
executable low-entropy guessing test across every controlled store/export, not only a
prohibition sentence.

## 14. Parameter, finding and public-blocker registries

The 12 populated parameter decisions and 95 unique namespace mappings are genuine
improvements. The restored `R9-B###` primary namespace is collision-free in the supplied
mapping.

The parameter registry's fail-closed lint is not implemented. Parameter mutation passes
the validator. Public blockers are all open and candidate-shaped, but every one uses the
same prose closure predicate and no closure evaluator exists; replacing a predicate with
`TRUE` passes. A schema must be closed and an evaluator must recompute counts, candidate
identity, evidence hashes, subtest outcomes, independence and contradictory findings.

## 15. Repository recovery and GitHub backup policy

The recovery specification is a strong architecture requirement: exact repository state,
`git bundle --all`, an independently stored hash, destructive disposable restore, ref
verification, locked toolchain/dependencies, SBOM, network-disabled double builds and
`UNSIGNED_LOCAL_ARTIFACT` status are explicit. It still lacks a receipt schema and
runner, and its bundle-before-mutation rule needs a safe exception for creating a brand-
new repository. No drill has occurred because no repository mutation was authorised.

The GitHub policy correctly states:

- purpose is private backup/pastebin continuity only;
- standing and current push authority are false;
- the frozen public repository is excluded;
- approval is exact, expiring, single-use and consumed on one attempt;
- recursive archive, secret, private-data and nested-repository inspection is required;
- workflows, Pages, environments, webhooks and deployment are prohibited.

This materially narrows the policy defect but does not fully close its executable
approval/consumption/postflight contract. It does not authorise a backup.

## 16. Control-protocol and inventory review

`CURRENT_STATE.json` correctly had precedence and the v5 archive/root protocol was
unambiguous. The input and current checksum layers verified. The received inventory's
two stale manifest records came from a generation cycle: inventory recorded current
and input manifests before those files reached their final bytes.

The returned v6 tool/protocol resolves this by:

1. generating the next immutable-input manifest while excluding declared next-round
   mutable paths;
2. generating an inventory that explicitly excludes itself and the current manifest;
3. generating the current manifest last, covering every file except itself;
4. reporting the outer ZIP hash only after ZIP creation.

This is the only repair made outside the Round 015 review directory, and it is within
the expressly authorised control/tool/manifest paths.

## 17. Remaining evidence blockers

The following remain explicit:

1. exact byte snapshots and hashes of binding canon documents;
2. no fresh exact private-GitHub backup approval;
3. exact writable state, identity and active-writer status of
   `/home/anon/Projects/Pioneer-Alignment-App`;
4. no application implementation, repository, test, replay, restore-drill or public
   system evidence;
5. no real identity, ballot, balance, provider, federation or private-participant test
   data is authorised.

These are honest boundaries. They must not be converted into green architecture claims.

## 18. Minimal required amendments

Do not make the small local notes application wait for the entire constitutional system
to become executable. Round 016 should split the lanes and repair Phase 0A first.

Required narrow Phase 0A amendments:

1. Declare the original `Pioneer-Alignment-Phase-0A-Builder-Handoff-v1.md` controlling
   for Phase 0A; later corpus files may strengthen but not replace its functional scope.
2. Replace the note/event file with separate exact note-state and provenance-event
   schemas preserving summary, status, timestamps, note-version/state binding and the
   full create/edit/preview/export/verification hash chain.
3. Replace the export file with the authorised selected-note bundle while retaining the
   useful deterministic container rules.
4. Supply real fixtures and a runnable candidate-bound validator for the 12 Phase 0A
   gates, including every named test in the acceptance floor.
5. Add an actual `S06R-P0A` node or remove the dangling path and define the narrow
   independent-review receipt.
6. Bind every static input to an existing hash source.

Full-system amendments may remain a separate held lane:

1. strict graph/DAG/envelope/reducer schemas and semantic validators;
2. a condition registry, cycle/configuration analysis and repair-to-re-review loop;
3. generated genesis plus a separately authored signature/linkage/state verifier;
4. executable gate fixtures/runners and candidate-bound evidence evaluation;
5. explicit maturity/role/LEX/compensation/domain/emergency reducers;
6. byte-complete privacy vectors and purge-guessability tests.

## 19. Final posture and exact next action

Final posture: `HOLD_FOR_ADDITIONAL_ARCHITECTURE_REPAIR`.

Exact next action: the controlling ChatGPT should perform one bounded Round 016 that
repairs only the six Phase 0A items in section 18, carries the wider architecture as a
separate HOLD, and returns one v7 relay for a final narrow build-readiness check. It must
not build, push, deploy, request credentials or pretend the host path has been verified.

If and only if those six repairs pass executable mutation tests and the exact host path
is verified writable with no active writer, Phase 0A can be released to the builder
without waiting for Rounds 3–10 to become a public system.
