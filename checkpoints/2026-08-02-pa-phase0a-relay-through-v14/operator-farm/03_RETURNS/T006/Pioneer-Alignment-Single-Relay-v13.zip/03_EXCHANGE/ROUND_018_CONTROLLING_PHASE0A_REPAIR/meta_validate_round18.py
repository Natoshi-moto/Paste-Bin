#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from lib_phase0a import *

RELAY = ROOT.parents[1]

REQUIRED_FILES = [
    "PHASE0A_NORMATIVE_MANIFEST.v1.json",
    "PHASE0A_PRECEDENCE_AND_SUPERSESSION.v2.json",
    "PHASE0A_CANONICAL_RULES.v2.json",
    "PHASE0A_HANDOFF_REQUIREMENT_REGISTRY.v1.json",
    "PHASE0A_NOTE_STATE.schema.json",
    "PHASE0A_PROVENANCE_EVENT.schema.json",
    "PHASE0A_EXPORT_RECEIPT.schema.json",
    "PHASE0A_EXPORT_METADATA.schema.json",
    "PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v3.json",
    "PHASE0A_PROVENANCE_EXCERPT_POLICY.v1.json",
    "PHASE0A_RELAY_REQUEST.schema.json",
    "PHASE0A_RELAY_RESPONSE.schema.json",
    "PHASE0A_RELAY_ERROR.schema.json",
    "PHASE0A_FAKE_RELAY_ALGORITHM.v1.json",
    "PHASE0A_RELAY_GOLDEN_VECTORS.v1.json",
    "PHASE0A_WEB_SECURITY_VECTORS.v1.json",
    "PHASE0A_NOTE_EVENT_GOLDEN_VECTORS.v2.json",
    "PHASE0A_EXPORT_GOLDEN_VECTOR.v2.json",
    "PHASE0A_GATE_CASE_EVIDENCE.schema.json",
    "PHASE0A_CANDIDATE_BINDING.schema.json",
    "PHASE0A_CANDIDATE_EVIDENCE.schema.json",
    "PHASE0A_EVIDENCE_PROTOCOL.v1.json",
    "PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json",
    "PHASE0A_ACCEPTANCE_CONTRACT.v4.json",
    "PHASE0A_RUNNER_INTERFACE.v2.json",
    "PHASE0A_CONDITION_REGISTRY.v2.json",
    "PHASE0A_DAG_SCHEMA.v2.json",
    "PHASE0A_BUILD_DAG.v2.json",
    "PHASE0A_TRANSITION_TABLE.v1.json",
    "PHASE0A_RECEIPT_SCHEMAS.v1.json",
    "PHASE0A_HOST_PREFLIGHT_MATRIX.v1.json",
    "PHASE0A_REPOSITORY_FILE_REGISTRY.v1.json",
    "NO_IMPLEMENTATION_CANDIDATE.json",
    "lib_phase0a.py",
    "independent_oracle.py",
    "transition_evaluator.py",
    "export_generator.py",
    "export_verifier.py",
    "meta_validate_round18.py",
    "run_round18_mutations.py",
    "fixtures/index.html",
    "fixtures/source.md",
    "fixtures/metadata.json",
    "fixtures/provenance.jsonl",
    "fixtures/SHA256SUMS.txt",
    "fixtures/export-receipt.json",
    "fixtures/selected-note-golden.zip",
]

SCHEMA_FILES = [
    "PHASE0A_NOTE_STATE.schema.json",
    "PHASE0A_PROVENANCE_EVENT.schema.json",
    "PHASE0A_EXPORT_RECEIPT.schema.json",
    "PHASE0A_EXPORT_METADATA.schema.json",
    "PHASE0A_RELAY_REQUEST.schema.json",
    "PHASE0A_RELAY_RESPONSE.schema.json",
    "PHASE0A_RELAY_ERROR.schema.json",
    "PHASE0A_GATE_CASE_EVIDENCE.schema.json",
    "PHASE0A_CANDIDATE_BINDING.schema.json",
    "PHASE0A_CANDIDATE_EVIDENCE.schema.json",
    "PHASE0A_DAG_SCHEMA.v2.json",
]

AUTHORITY_REJECT_SUBSTRINGS = [
    "connect DeepSeek",
    "DeepSeek with operator credentials",
    "provider credentials",
    "0.0.0.0",
    "public GitHub push",
]


def err(errors, code, detail=""):
    errors.append(f"{code}" + (f":{detail}" if detail else ""))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--semantic-only", action="store_true")
    parser.add_argument("--receipt", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    relay = root.parents[1]
    errors: list[str] = []

    # presence
    for rel in REQUIRED_FILES:
        if not (root / rel).is_file():
            err(errors, "REQUIRED_FILE_MISSING", rel)

    if errors and not args.semantic_only:
        # still continue semantic if possible
        pass

    def load(name):
        try:
            return load_json(root / name)
        except Exception as e:
            err(errors, "JSON_LOAD", f"{name}:{e}")
            return None

    # schemas substantive + applied
    schemas = {}
    for sf in SCHEMA_FILES:
        sc = load(sf)
        schemas[sf] = sc
        if sc is None:
            continue
        for e in schema_is_substantive(sc):
            err(errors, "SCHEMA_NOT_SUBSTANTIVE", f"{sf}:{e}")
        # metaschema-ish: must have $schema and $id for schema files
        if not sc.get("$schema") or not sc.get("$id"):
            err(errors, "SCHEMA_META_MISSING", sf)

    note_schema = schemas.get("PHASE0A_NOTE_STATE.schema.json") or {}
    event_schema = schemas.get("PHASE0A_PROVENANCE_EVENT.schema.json") or {}
    binding_schema = schemas.get("PHASE0A_CANDIDATE_BINDING.schema.json") or {}
    evidence_schema = schemas.get("PHASE0A_CANDIDATE_EVIDENCE.schema.json") or {}
    dag_schema = schemas.get("PHASE0A_DAG_SCHEMA.v2.json") or {}
    gate_schema = schemas.get("PHASE0A_GATE_CASE_EVIDENCE.schema.json") or {}

    # note schema invariants
    if note_schema:
        slug = note_schema.get("properties", {}).get("slug", {})
        if slug.get("pattern") in (None, "^.*$", ".*"):
            err(errors, "SLUG_PATTERN_INSECURE")
        if "published" in (note_schema.get("properties", {}).get("status", {}).get("enum") or []):
            err(errors, "NOTE_STATUS_PUBLISHED_FORBIDDEN")
        reserved = note_schema.get("x-phase0a-slug-reserved") or []
        if not reserved or "admin" not in reserved:
            err(errors, "SLUG_RESERVED_MISSING")
        if note_schema.get("x-phase0a-state-hash-domain") != DOMAIN_NOTE:
            err(errors, "NOTE_HASH_DOMAIN_CHANGED")
        if note_schema.get("x-phase0a-raw-html") != "REJECT_BEFORE_PERSIST":
            err(errors, "RAW_HTML_POLICY_MISSING")

    if event_schema:
        branch = event_schema.get("x-phase0a-action-detail-branch") or {}
        if set(branch.keys()) != set(ACTIONS):
            err(errors, "ACTION_DETAIL_MAPPING_INCOMPLETE")
        if event_schema.get("x-phase0a-event-hash-domain") != DOMAIN_EVENT:
            err(errors, "EVENT_HASH_DOMAIN_CHANGED")
        if set(event_schema.get("x-phase0a-required-actions") or []) != set(ACTIONS):
            err(errors, "REQUIRED_ACTIONS_CHANGED")

    # canonical rules domains
    rules = load("PHASE0A_CANONICAL_RULES.v2.json") or {}
    hashes = rules.get("hashes", {})
    if hashes.get("note_state", {}).get("domain_prefix_utf8_then_nul") != DOMAIN_NOTE:
        err(errors, "CANONICAL_NOTE_DOMAIN")
    if hashes.get("provenance_event", {}).get("domain_prefix_utf8_then_nul") != DOMAIN_EVENT:
        err(errors, "CANONICAL_EVENT_DOMAIN")
    if hashes.get("export_receipt", {}).get("domain_prefix_utf8_then_nul") != DOMAIN_RECEIPT:
        err(errors, "CANONICAL_RECEIPT_DOMAIN")
    if hashes.get("content_set", {}).get("domain_prefix_utf8_then_nul") != DOMAIN_CONTENT_SET:
        err(errors, "CANONICAL_CONTENT_SET_DOMAIN")
    if hashes.get("export_id", {}).get("domain_prefix_utf8_then_nul") != DOMAIN_EXPORT_ID:
        err(errors, "CANONICAL_EXPORT_ID_DOMAIN")
    if rules.get("raw_html_policy", {}).get("on_persist") != "REJECT":
        err(errors, "RAW_HTML_MUST_REJECT")

    # export spec
    export_spec = load("PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v3.json") or {}
    wb = export_spec.get("write_boundary", {})
    if wb.get("public_repository") is not False or wb.get("outside_workspace") is not False:
        err(errors, "EXPORT_WRITE_BOUNDARY_WIDENED")
    if export_spec.get("members", {}).get("export-receipt.json", {}).get("receipt_hash_excludes_field") != "receipt_hash":
        err(errors, "EXPORT_RECEIPT_SELF_HASH")
    if not export_spec.get("identity", {}).get("content_set_sha256"):
        err(errors, "EXPORT_CONTENT_SET_FORMULA_MISSING")
    if not export_spec.get("identity", {}).get("export_id"):
        err(errors, "EXPORT_ID_FORMULA_MISSING")
    pep = export_spec.get("provenance_excerpt_policy", {})
    if pep.get("self_verifying_global_chain") is not False:
        err(errors, "PROVENANCE_EXCERPT_MUST_DECLARE_NON_SELF_VERIFYING")

    # precedence / authority
    prec = load("PHASE0A_PRECEDENCE_AND_SUPERSESSION.v2.json") or {}
    ag = prec.get("authority_granted") or {}
    for k in PROHIBITED_AUTHORITY_KEYS:
        if ag.get(k) is not False:
            err(errors, "AUTHORITY_GRANTED_NOT_FALSE", k)
    if set(prec.get("prohibited_actions") or []) < set(PROHIBITED_AUTHORITY_KEYS):
        err(errors, "PROHIBITED_ACTIONS_INCOMPLETE")
    claims = prec.get("claims") or {}
    if claims.get("application_implemented") is not False:
        err(errors, "FALSE_IMPLEMENTATION_CLAIM")
    if claims.get("host_path_verified") is not False:
        err(errors, "FALSE_HOST_CLAIM")
    cs = prec.get("controlling_source") or {}
    handoff = relay / "01_ORIGINAL_ARTIFACTS/Pioneer-Alignment-Phase-0A-Builder-Handoff-v1.md"
    if handoff.is_file():
        if cs.get("sha256") != sha256_file(handoff):
            err(errors, "HANDOFF_HASH_MISMATCH")

    # no implementation
    nic = load("NO_IMPLEMENTATION_CANDIDATE.json") or {}
    if nic.get("application_implemented") is not False:
        err(errors, "UNSUPPORTED_IMPLEMENTATION_CLAIM")
    if nic.get("application_tests_run") is not False:
        err(errors, "UNSUPPORTED_TESTS_CLAIM")
    if nic.get("host_preflight_run") is not False:
        err(errors, "UNSUPPORTED_HOST_CLAIM")

    # contract
    contract = load("PHASE0A_ACCEPTANCE_CONTRACT.v4.json") or {}
    if not contract:
        err(errors, "CONTRACT_MISSING")
    else:
        counts = contract.get("counts") or {}
        tests = contract.get("tests") or []
        cases = contract.get("cases") or []
        assertions = contract.get("assertions") or []
        mutants = contract.get("mutants") or []
        if counts.get("total_tests") != 89 or len(tests) != 89:
            err(errors, "TEST_COUNT", f"{len(tests)}")
        if len(cases) != 89 or counts.get("total_cases") != 89:
            err(errors, "CASE_COUNT")
        if len(assertions) != 178:
            err(errors, "ASSERTION_COUNT", str(len(assertions)))
        if len(mutants) != 89:
            err(errors, "MUTANT_COUNT", str(len(mutants)))
        # concrete fixtures
        for case in cases:
            fx = case.get("fixture_inline") or {}
            op = fx.get("operation") or {}
            if not fx.get("input") and fx.get("input") != {}:
                err(errors, "VACUOUS_FIXTURE", case.get("case_id"))
            if not op or op.get("kind") in (None, "APPLY_NAMED_CASE", ""):
                err(errors, "SYMBOLIC_CASE", case.get("case_id"))
            if not isinstance(fx.get("expected_observable"), dict):
                err(errors, "CASE_NO_OBSERVABLE", case.get("case_id"))
            if not case.get("immutable"):
                err(errors, "CASE_NOT_IMMUTABLE", case.get("case_id"))
        # mutants executable
        for m in mutants:
            mop = m.get("mutation_operator")
            if not isinstance(mop, dict) or not mop.get("executable"):
                err(errors, "MUTANT_NOT_EXECUTABLE", m.get("mutant_id"))
            if mop.get("kind") == "NO_OP" or mop.get("id") == "NO_OP" or mop.get("transform") == "NO_OP":
                err(errors, "NOOP_MUTANT", m.get("mutant_id"))
            if mop.get("control") != "OUTSIDE_CANDIDATE":
                err(errors, "MUTANT_CANDIDATE_CONTROLLED", m.get("mutant_id"))
        # oracle outside candidate
        oracle = contract.get("oracle") or {}
        if oracle.get("control") != "OUTSIDE_CANDIDATE":
            err(errors, "ORACLE_NOT_INDEPENDENT")
        if not oracle.get("echo_runner_rejected"):
            err(errors, "ECHO_RUNNER_NOT_REJECTED")
        # raw html cases must reject
        for case in cases:
            if "SCRIPT-TAG" in case["case_id"] or "EVENT-HANDLER" in case["case_id"] or "JAVASCRIPT-URL" in case["case_id"]:
                if case.get("expected_transition") != "REJECT":
                    err(errors, "RAW_HTML_MUST_REJECT_CASE", case["case_id"])
                if case.get("expected_reason_code") != "RAW_HTML_REJECTED":
                    err(errors, "RAW_HTML_REASON", case["case_id"])
        # handoff floor: dashboard export status must exist
        test_ids = {t["test_id"] for t in tests}
        if "T-G-P0A-DASHBOARD-EXPORT-STATUS" not in test_ids:
            err(errors, "HANDOFF_FLOOR_TEST_REMOVED", "T-G-P0A-DASHBOARD-EXPORT-STATUS")
        # unique ids
        for collection, key, code in [
            (tests, "test_id", "DUP_TEST"),
            (cases, "case_id", "DUP_CASE"),
            (assertions, "assertion_id", "DUP_ASSERTION"),
            (mutants, "mutant_id", "DUP_MUTANT"),
        ]:
            seen = set()
            for item in collection:
                v = item.get(key)
                if v in seen:
                    err(errors, code, v)
                seen.add(v)

    # requirement registry binds tests
    reg = load("PHASE0A_HANDOFF_REQUIREMENT_REGISTRY.v1.json") or {}
    if reg:
        required_ids = {
            "HR-DASHBOARD","HR-NOTE-WORKFLOW","HR-PERSISTENCE","HR-PROVENANCE","HR-EXPORT",
            "HR-RELAY","HR-RAW-HTML","HR-LOCALHOST","HR-REPO-FILES","HR-STATUS","HR-GIT",
            "HR-FAILURE","HR-FINAL-REPORT","HR-SECURITY-SCANS"
        }
        present_ids = {r.get("requirement_id") for r in (reg.get("requirements") or [])}
        for rid in sorted(required_ids):
            if rid not in present_ids:
                err(errors, "REQUIREMENT_REMOVED", rid)
        all_req_tests = set()
        for r in reg.get("requirements") or []:
            if r.get("removable") is not False:
                err(errors, "REQUIREMENT_MARKED_REMOVABLE", r.get("requirement_id"))
            for tid in r.get("mandatory_test_ids") or []:
                all_req_tests.add(tid)
        test_ids = {t["test_id"] for t in (contract.get("tests") or [])}
        for tid in all_req_tests:
            if tid not in test_ids:
                err(errors, "REQUIREMENT_TEST_MISSING", tid)

    # runner
    runner = load("PHASE0A_RUNNER_INTERFACE.v2.json") or {}
    if runner:
        cmd = runner.get("command") or []
        if cmd == ["true"] or (isinstance(cmd, list) and len(cmd) == 1 and cmd[0] in ("true", ":", "echo")):
            err(errors, "RUNNER_EVIDENCE_BYPASS")
        if "independent_oracle.py" not in json.dumps(runner):
            err(errors, "RUNNER_MISSING_ORACLE")
        fe = runner.get("final_evidence") or {}
        if not fe.get("protocol"):
            err(errors, "RUNNER_EVIDENCE_PROTOCOL_MISSING")
        if runner.get("oracle", {}).get("candidate_may_not_supply_oracle") is not True:
            err(errors, "CANDIDATE_ORACLE_ALLOWED")
        # all methods present
        methods = set(runner.get("required_runner_methods") or [])
        for t in contract.get("tests") or []:
            if t["runner_method"] not in methods:
                err(errors, "RUNNER_METHOD_MISSING", t["runner_method"])

    # DAG
    dag = load("PHASE0A_BUILD_DAG.v2.json") or {}
    if dag_schema and dag:
        for e in validate_against_schema(dag, dag_schema):
            err(errors, "DAG_SCHEMA_FAIL", e)
    if dag:
        nodes = dag.get("nodes") or []
        if len(nodes) != 9:
            err(errors, "DAG_NODE_COUNT", str(len(nodes)))
        by_id = {n["node_id"]: n for n in nodes}
        # N70 checks
        n70 = by_id.get("P0A-N70-INDEPENDENT-REREVIEW") or {}
        if n70.get("kind") == "noop":
            err(errors, "REREVIEW_NOOP")
        if not n70.get("required_checks"):
            err(errors, "REREVIEW_CHECKS_REMOVED")
        n50 = by_id.get("P0A-N50-INDEPENDENT-REVIEW") or {}
        checks50 = " ".join(n50.get("required_checks") or []).lower()
        if "acceptance" not in checks50 and "contract" not in checks50 and "oracle" not in checks50:
            err(errors, "INITIAL_REVIEW_TEST_EXECUTION_REMOVED")
        if any("do not execute" in c.lower() for c in (n50.get("required_checks") or [])):
            err(errors, "INITIAL_REVIEW_TEST_EXECUTION_REMOVED")
        n80 = by_id.get("P0A-N80-FINAL-HANDOFF") or {}
        consumes = n80.get("consumes") or []
        if not any("REVIEWED-BINDING" in c or "REVIEWED_BINDING" in c or "reviewed" in c.lower() for c in consumes):
            # require reviewed binding/tree/evidence
            if not any("BINDING" in c for c in consumes):
                err(errors, "N80_NOT_BOUND_TO_REVIEWED")
        if "O-REVIEWED-TREE" not in str(consumes) and not any("TREE" in c for c in consumes):
            err(errors, "N80_TREE_NOT_CONSUMED")
        # authority scan: only required_checks may not request prohibited actions
        # (forbidden_checks may name them as things to reject)
        for n in nodes:
            for c in (n.get("required_checks") or []):
                cl = c.lower()
                if "deepseek" in cl or "operator credentials" in cl or "connect provider" in cl:
                    err(errors, "HIDDEN_PROVIDER_AUTHORITY_IN_DAG", n["node_id"])
                if "0.0.0.0" in cl and "reject" not in cl and "forbid" not in cl and "not" not in cl:
                    err(errors, "HIDDEN_PROVIDER_OR_AUTHORITY", "0.0.0.0")
        # N80 condition not ALWAYS alone without eligibility
        if n80.get("condition_ids") == ["ALWAYS"]:
            err(errors, "N80_CONDITION_ALWAYS")
        if "N80_ELIGIBLE" not in (n80.get("condition_ids") or []):
            err(errors, "N80_ELIGIBILITY_MISSING")
        # topo + refs
        seen = set()
        for n in nodes:
            for d in n.get("depends_on") or []:
                if d not in by_id:
                    err(errors, "DAG_DANGLING_DEP", d)
            nid = n["node_id"]
            if nid in seen:
                err(errors, "DAG_DUP_NODE", nid)
            seen.add(nid)
        # conditions used
        cond_reg = load("PHASE0A_CONDITION_REGISTRY.v2.json") or {}
        cond_ids = {c["condition_id"] for c in cond_reg.get("conditions") or []}
        used = set()
        for n in nodes:
            for cid in n.get("condition_ids") or []:
                used.add(cid)
                if cid not in cond_ids:
                    err(errors, "DAG_UNKNOWN_CONDITION", cid)
        # final condition must not be constant true
        for c in cond_reg.get("conditions") or []:
            if c["condition_id"] == "N80_ELIGIBLE" and c.get("type") == "constant":
                err(errors, "FINAL_CONDITION_CONSTANT")
            if c["condition_id"] in ("REREVIEW_PASS_OR_INITIAL_PASS_CONFIRMED",) and c.get("type") == "constant":
                err(errors, "FINAL_CONDITION_CONSTANT_TRUE")
        if cond_reg.get("rules", {}).get("HOLD_is_terminal") is not True:
            err(errors, "HOLD_NOT_TERMINAL")

    # transition table
    tt = load("PHASE0A_TRANSITION_TABLE.v1.json") or {}
    if tt:
        allowed = {(t["n50"], t["n60"], t["n70"]) for t in tt.get("allowed_traces") or []}
        if ("PASS", "NOT_REQUIRED", "INITIAL_PASS_CONFIRMED") not in allowed:
            err(errors, "TRACE_PASS_MISSING")
        if ("REPAIR_REQUIRED", "REPAIRED", "PASS_AFTER_REPAIR") not in allowed:
            err(errors, "TRACE_REPAIR_MISSING")
        if len(allowed) != 2:
            err(errors, "TRACE_EXTRA_OR_MISSING", str(sorted(allowed)))
        # evaluate forbidden
        for fr in tt.get("forbidden_examples") or []:
            res = evaluate_review_trace(fr["n50"], fr["n60"], fr["n70"])
            if res["allowed"] or res["n80_eligible"]:
                err(errors, "FORBIDDEN_TRACE_ALLOWED", str(fr))

    # apply schemas to goldens
    note_gold = load("PHASE0A_NOTE_EVENT_GOLDEN_VECTORS.v2.json") or {}
    if note_gold and note_schema:
        n = note_gold.get("note")
        for e in validate_against_schema(n, note_schema):
            err(errors, "NOTE_GOLDEN_SCHEMA", e)
        for e in validate_note_state(n, "create"):
            err(errors, "NOTE_GOLDEN_SEMANTIC", e)
        events = note_gold.get("events") or {}
        if set(events.keys()) != set(ACTIONS):
            err(errors, "NOTE_GOLDEN_ACTIONS_INCOMPLETE", str(sorted(events.keys())))
        prev = ZERO64
        # chain create -> edit is separate branch; create -> preview for export
        for action in ["NOTE_CREATED", "PREVIEW_GENERATED", "EXPORT_GENERATED", "EXPORT_VERIFICATION_PASSED"]:
            ev = events.get(action)
            if not ev:
                err(errors, "NOTE_GOLDEN_EVENT_MISSING", action)
                continue
            if event_schema:
                for e in validate_against_schema(ev, event_schema):
                    err(errors, "EVENT_GOLDEN_SCHEMA", f"{action}:{e}")
            # chain validation with appropriate prior
            if action == "NOTE_CREATED":
                prior = ZERO64
            elif action == "PREVIEW_GENERATED":
                prior = events["NOTE_CREATED"]["event_hash"]
            elif action == "EXPORT_GENERATED":
                prior = events["PREVIEW_GENERATED"]["event_hash"]
            else:
                prior = events["EXPORT_GENERATED"]["event_hash"]
            for e in validate_event(ev, prior):
                err(errors, "EVENT_GOLDEN_SEMANTIC", f"{action}:{e}")
        # edit + fail standalone
        for action in ["NOTE_EDITED", "EXPORT_VERIFICATION_FAILED"]:
            ev = events.get(action)
            if event_schema and ev:
                for e in validate_against_schema(ev, event_schema):
                    err(errors, "EVENT_GOLDEN_SCHEMA", f"{action}:{e}")

    # export golden verify
    export_golden = load("PHASE0A_EXPORT_GOLDEN_VECTOR.v2.json") or {}
    if export_golden:
        members = {}
        for name in EXPORT_MEMBERS:
            p = root / "fixtures" / name
            if not p.is_file():
                err(errors, "EXPORT_FIXTURE_MISSING", name)
            else:
                members[name] = p.read_bytes()
                if sha256_bytes(members[name]) != export_golden.get("member_sha256", {}).get(name):
                    err(errors, "EXPORT_MEMBER_HASH", name)
        if members:
            for e in verify_export_bundle(members):
                err(errors, "EXPORT_VERIFY", e)
            zpath = root / "fixtures/selected-note-golden.zip"
            if zpath.is_file():
                if sha256_file(zpath) != export_golden.get("zip_sha256"):
                    err(errors, "EXPORT_ZIP_HASH")
            # identity formulas produce receipt values
            rec = export_golden.get("receipt") or {}
            if rec:
                if export_receipt_schema := schemas.get("PHASE0A_EXPORT_RECEIPT.schema.json"):
                    for e in validate_against_schema(rec, export_receipt_schema):
                        err(errors, "RECEIPT_SCHEMA", e)

    # relay goldens
    relay_g = load("PHASE0A_RELAY_GOLDEN_VECTORS.v1.json") or {}
    if relay_g:
        for key in ("success", "error", "timeout"):
            item = relay_g.get(key) or {}
            req = item.get("request")
            if req and schemas.get("PHASE0A_RELAY_REQUEST.schema.json"):
                for e in validate_against_schema(req, schemas["PHASE0A_RELAY_REQUEST.schema.json"]):
                    err(errors, "RELAY_REQ_SCHEMA", f"{key}:{e}")
            if req:
                got = fake_relay_complete(req)
                exp = item.get("result")
                if got != exp:
                    # compare reason codes at least
                    if got.get("reason_code") != exp.get("reason_code"):
                        err(errors, "RELAY_GOLDEN_MISMATCH", key)

    # evidence vectors
    vectors = load("PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json") or {}
    if vectors:
        if vectors.get("application_candidate_exists") is not False:
            err(errors, "EVIDENCE_VECTOR_FALSE_CANDIDATE_CLAIM")
        if "SYNTHETIC" not in (vectors.get("label") or vectors.get("status") or ""):
            if vectors.get("status") != "SCHEMA_AND_CONSISTENCY_FIXTURE_ONLY_NOT_APPLICATION_EVIDENCE":
                err(errors, "EVIDENCE_VECTOR_STATUS_INVALID")
        positive = vectors.get("positive_fixture") or {}
        binding = positive.get("candidate_binding") or {}
        evidence = positive.get("candidate_evidence") or {}
        if binding_schema:
            for e in validate_against_schema(binding, binding_schema):
                err(errors, "BINDING_INSTANCE", e)
        # unsafe binding checks on schema constants
        if binding.get("workspace_path") not in (WORKSPACE,):
            err(errors, "BINDING_WORKSPACE")
        if binding.get("branch") == "main":
            err(errors, "BINDING_MAIN_BRANCH")
        if binding.get("server_bind") in ("0.0.0.0", "::"):
            err(errors, "BINDING_UNSAFE_BIND")
        if binding.get("git_remotes"):
            err(errors, "BINDING_REMOTES")
        if evidence_schema:
            for e in validate_against_schema(evidence, evidence_schema):
                err(errors, "EVIDENCE_INSTANCE", e)
        # contract + normative hashes
        contract_hash = sha256_file(root / "PHASE0A_ACCEPTANCE_CONTRACT.v4.json")
        if binding.get("contract_sha256") != contract_hash:
            err(errors, "EVIDENCE_CONTRACT_HASH_MISMATCH")
        if evidence.get("contract_sha256") != contract_hash:
            err(errors, "EVIDENCE_CONTRACT_HASH_MISMATCH")
        nm_path = root / "PHASE0A_NORMATIVE_MANIFEST.v1.json"
        if nm_path.is_file():
            nm_hash = sha256_file(nm_path)
            if binding.get("normative_manifest_sha256") != nm_hash:
                err(errors, "EVIDENCE_NORMATIVE_HASH_MISMATCH")
            if evidence.get("normative_manifest_sha256") != nm_hash:
                err(errors, "EVIDENCE_NORMATIVE_HASH_MISMATCH")
        expected_binding_hash = sha256_bytes(canonical_json_bytes(binding))
        if evidence.get("candidate_binding_sha256") != expected_binding_hash:
            err(errors, "EVIDENCE_BINDING_HASH_MISMATCH")
        # times
        if evidence.get("finished_at", "") < evidence.get("started_at", ""):
            err(errors, "EVIDENCE_TIME_REVERSED")
        # case results evidence paths + non-zero hashes
        for result in evidence.get("case_results") or []:
            if gate_schema:
                for e in validate_against_schema(result, gate_schema):
                    err(errors, "GATE_CASE_INSTANCE", e)
            h = result.get("evidence_sha256") or ""
            if h == ZERO64 or h == "0" * 64:
                err(errors, "FICTITIOUS_EVIDENCE_HASH")
            if not result.get("evidence_path"):
                err(errors, "EVIDENCE_PATH_MISSING")
            else:
                for e in validate_evidence_paths([result["evidence_path"]]):
                    err(errors, e)
        # summary
        summary = evidence.get("summary") or {}
        if summary.get("surviving_mutants", 1) != 0:
            err(errors, "EVIDENCE_SURVIVING_MUTANT")
        # payload manifest must not equal envelope self-ref cycle field inside results
        if evidence.get("payload_manifest_sha256") in (None, ZERO64, "0"*64):
            err(errors, "PAYLOAD_MANIFEST_MISSING_OR_ZERO")
        # oracle id
        if evidence.get("oracle_id") != "pa.phase0a.independent_oracle.v1":
            err(errors, "EVIDENCE_ORACLE_ID")
        # no evidence_manifest_sha256 cyclic field
        if "evidence_manifest_sha256" in evidence:
            err(errors, "EVIDENCE_MANIFEST_CYCLE_FIELD")

    # host matrix complete
    host_m = load("PHASE0A_HOST_PREFLIGHT_MATRIX.v1.json") or {}
    if host_m:
        states = host_m.get("states") or {}
        for s in HOST_STATES:
            if s not in states:
                err(errors, "HOST_STATE_MISSING", s)
            else:
                if states[s] != host_preflight_decision(s):
                    err(errors, "HOST_STATE_MISMATCH", s)

    # normative manifest integrity
    nm = load("PHASE0A_NORMATIVE_MANIFEST.v1.json")
    if not nm:
        err(errors, "NORMATIVE_MANIFEST_MISSING")
    else:
        members = nm.get("members") or []
        if len(members) < 20:
            err(errors, "NORMATIVE_MANIFEST_TOO_SMALL")
        paths = []
        for m in members:
            p = m.get("path")
            paths.append(p)
            if p == "PHASE0A_NORMATIVE_MANIFEST.v1.json":
                err(errors, "NORMATIVE_MANIFEST_SELF_LISTED")
            fp = root / p
            if not fp.is_file():
                err(errors, "NORMATIVE_MEMBER_MISSING", p)
            else:
                if m.get("sha256") != sha256_file(fp):
                    err(errors, "NORMATIVE_MEMBER_HASH", p)
        # must cover critical roles
        roles = {m.get("role") for m in members}
        for role in ["precedence", "canonical_rules", "acceptance_contract", "schema", "dag", "oracle", "evidence_protocol", "export_spec"]:
            if role not in roles:
                err(errors, "NORMATIVE_ROLE_MISSING", role)

    # package checksum if present
    if not args.semantic_only:
        manifest = root / "SHA256SUMS.txt"
        if manifest.is_file():
            for line in manifest.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                expected, rel = line.split("  ", 1)
                if rel == "SHA256SUMS.txt":
                    err(errors, "CHECKSUM_SELF_REF")
                    continue
                target = root / rel
                if not target.is_file() or sha256_file(target) != expected:
                    err(errors, "CHECKSUM_MISMATCH", rel)

    status = "SPEC_CONTRACT_VALID" if not errors else "SPEC_CONTRACT_INVALID"
    receipt = {
        "schema_version": "pa.phase0a.round18_spec_validation_receipt.v1",
        "status": status,
        "validation_mode": "semantic_only" if args.semantic_only else "full",
        "application_candidate_exists": False,
        "application_tests_run": False,
        "host_preflight_run": False,
        "error_count": len(errors),
        "errors": sort_stable(errors),
    }
    text = dumps_pretty(receipt)
    if args.receipt:
        args.receipt.write_text(text, encoding="utf-8")
    sys.stdout.write(text)
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
