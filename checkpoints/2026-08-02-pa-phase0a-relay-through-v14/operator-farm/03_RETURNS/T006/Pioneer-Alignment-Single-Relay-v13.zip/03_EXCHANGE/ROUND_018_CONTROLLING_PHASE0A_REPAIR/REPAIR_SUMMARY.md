# Round 018 — Controlling Phase 0A Specification/Gate Repair

**Adjudication:** `ROUND018_REPAIR_COMPLETE_AWAITING_INDEPENDENT_REREVIEW`

## What Round 017 forced

Round 016 was internally consistent under its own weak oracle and still false-green on
20 material adversarial probes. Schemas were present but unapplied. Cases and mutants
were symbolic. Evidence was self-attested. HOLD could become final PASS by untyped
receipt strings. Export identity formulas were missing. Raw HTML expected ACCEPT-by-escaping.

## What Round 018 delivered

### 1. Single normative manifest
`PHASE0A_NORMATIVE_MANIFEST.v1.json` hash-pins every load-bearing file (schemas, rules,
contract, DAG, oracle, fixtures, tools). That hash is bound into candidate binding and
candidate evidence. The manifest does not list itself.

### 2. Schemas applied, not presence-checked
`meta_validate_round18.py` rejects empty/gutted schemas, validates instances against
schemas, rejects duplicate JSON keys, and enforces cross-file invariants (slug pattern,
reserved slugs, six actions, hash domains, write boundary, authority keys).

### 3. Concrete fixtures
All 89 cases carry immutable `input` / `operation` / `expected_observable` payloads.
No `APPLY_NAMED_CASE` remains. Mutants are executable material transforms controlled
outside candidate code (`OUTSIDE_CANDIDATE`).

### 4. Independent oracle
`independent_oracle.py` is outside candidate control, rejects echo/candidate-owned
oracles at the contract level, and evaluates pure fixtures (note/event/slug/html/relay/
export/web/path).

### 5. Acyclic evidence protocol
Raw evidence → payload manifest (excludes self/summary/envelope) → candidate evidence
envelope → detached final receipt. Zero digests, missing paths, traversal, reversed
times, and cyclic `evidence_manifest_sha256` fields are rejected.

### 6. Executable review state machine
Closed transition table admits only:

- `PASS → NOT_REQUIRED → INITIAL_PASS_CONFIRMED`
- `REPAIR_REQUIRED → REPAIRED → PASS_AFTER_REPAIR`

HOLD is terminal. N80 requires `N80_ELIGIBLE`, consumes reviewed binding/tree/evidence,
and rechecks remotes/bind/providers/untracked.

### 7. Export identity formulas
- `content_set_sha256 = SHA256(PA-P0A-CONTENT-SET-V1 || 0x00 || CJSON([{name,sha256}…]))`
- `export_id = export_ || SHA256(PA-P0A-EXPORT-ID-V1 || 0x00 || CJSON(identity fields))[:32]`
- receipt hash excludes itself; self-hashing prohibited
- golden ZIP regenerated and independently verified by generator+verifier

### 8. Fake Relay + web security
Closed request/response/error schemas, deterministic offline algorithm, goldens for
success/error/timeout, and concrete Host/Origin/CSRF/bind/body/path/HTML vectors.

### 9. Raw HTML
Reject before persistence (`RAW_HTML_REJECTED`). Defensive escaping on render does not
authorise persistence. Script/handler/javascript cases expect REJECT.

### 10. Handoff floor frozen
`PHASE0A_HANDOFF_REQUIREMENT_REGISTRY.v1.json` hash-pins original requirements to
mandatory test IDs, required files, STATUS fields, report fields, ZIP exclusions.
Coherent removal of dashboard export-status test or HR-DASHBOARD fails validation.

### 11. Provenance excerpt
Explicitly non-contiguous / non-self-verifying when other notes interleave. Interleaved
golden documents the declaration (no privacy-breaking bridge required for Phase 0A).

### 12. Mutation suite
31 mutations including all 20 Round 017 adversarial classes plus further controls.
Result: **31 rejected / 0 false-green / 0 wrong-reason**, byte-identical receipts under
`PYTHONHASHSEED=1` and `2`.

## Preserved blockers (honest)

- exact writable host state at `/home/anon/Projects/Pioneer-Alignment-App`
- application implementation / candidate tests
- private GitHub backup authority
- wider Rounds 3–10 architecture and missing wider canon snapshots
- real identity/economic/governance/provider/deployment/production state

## Normative hashes

- normative manifest: `bbbc6e34c695692f06c93f7b20b5b7f9662dcef874c65b704259c79200a8658b`
- acceptance contract: `8e47cbbef0ba5f59bc67c5b9a03af81ee4e5b3a8beb8516e06d1bedbf77fe6a1`
- mutation receipt: see `MUTATION_RECEIPTS.json`
