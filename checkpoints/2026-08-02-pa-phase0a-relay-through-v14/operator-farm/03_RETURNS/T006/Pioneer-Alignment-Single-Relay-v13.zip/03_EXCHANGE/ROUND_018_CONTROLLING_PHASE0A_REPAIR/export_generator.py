#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from lib_phase0a import *

def main():
    root = Path(__file__).resolve().parent
    gold = load_json(root / "PHASE0A_EXPORT_GOLDEN_VECTOR.v2.json")
    members = {name: (root / "fixtures" / name).read_bytes() for name in CONTENT_MEMBERS}
    # rebuild receipt+manifest+zip from content members + receipt inputs
    note_gold = load_json(root / "PHASE0A_NOTE_EVENT_GOLDEN_VECTORS.v2.json")
    note = note_gold["note"]
    cut = note_gold["events"]["PREVIEW_GENERATED"]
    receipt, manifest = build_export_receipt(
        note_id=note["note_id"], note_version=1, note_state_hash_value=note["state_hash"],
        frozen_cut_event_id=cut["event_id"], frozen_cut_event_hash=cut["event_hash"],
        renderer_version="phase0a-renderer-1", canonical_profile="PA-CJSON-1",
        member_bytes=members,
    )
    all_members = dict(members)
    all_members["SHA256SUMS.txt"] = manifest
    all_members["export-receipt.json"] = (json.dumps(receipt, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n").encode()
    z = build_export_zip(all_members)
    out = {
        "export_id": receipt["export_id"],
        "content_set_sha256": receipt["content_set_sha256"],
        "receipt_hash": receipt["receipt_hash"],
        "zip_sha256": sha256_bytes(z),
        "matches_golden": sha256_bytes(z) == gold["zip_sha256"] and receipt["export_id"] == gold["receipt"]["export_id"],
    }
    print(dumps_pretty(out), end="")
    return 0 if out["matches_golden"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
