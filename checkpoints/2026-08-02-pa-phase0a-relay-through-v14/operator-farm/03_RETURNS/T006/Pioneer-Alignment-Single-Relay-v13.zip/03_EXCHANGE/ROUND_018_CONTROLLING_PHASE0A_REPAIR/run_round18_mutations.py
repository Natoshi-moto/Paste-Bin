#!/usr/bin/env python3
"""Round 018 mutation suite: official + R17 adversarial classes. Deterministic receipts."""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

SOURCE = Path(__file__).resolve().parent


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def save(path: Path, value) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def canonical(value) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def regenerate_round_checksums(round_dir: Path) -> None:
    """Only regenerate round SHA256SUMS.txt; do not recompute normative manifest (mutations may intentionally desync)."""
    manifest = round_dir / "SHA256SUMS.txt"
    files = sorted(p for p in round_dir.rglob("*") if p.is_file() and p != manifest and "evidence_fixtures" not in p.parts)
    manifest.write_text(
        "".join(f"{sha256_bytes(p.read_bytes())}  {p.relative_to(round_dir).as_posix()}\n" for p in files),
        encoding="utf-8",
    )


def mutate_json(round_dir: Path, filename: str, mutate) -> None:
    path = round_dir / filename
    value = load(path)
    mutate(value)
    save(path, value)


def replace_json(round_dir: Path, filename: str, value) -> None:
    save(round_dir / filename, value)


def rebind_contract_and_vectors(round_dir: Path) -> None:
    """Co-update contract hash into evidence vectors when contract changes."""
    cpath = round_dir / "PHASE0A_ACCEPTANCE_CONTRACT.v4.json"
    if not cpath.is_file():
        return
    ch = sha256_bytes(cpath.read_bytes())
    vpath = round_dir / "PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json"
    if not vpath.is_file():
        return
    vectors = load(vpath)
    binding = vectors["positive_fixture"]["candidate_binding"]
    evidence = vectors["positive_fixture"]["candidate_evidence"]
    binding["contract_sha256"] = ch
    evidence["contract_sha256"] = ch
    # keep normative hash as-is (file may be stale relative to nm intentionally for some probes)
    nm = round_dir / "PHASE0A_NORMATIVE_MANIFEST.v1.json"
    if nm.is_file():
        nh = sha256_bytes(nm.read_bytes())
        binding["normative_manifest_sha256"] = nh
        evidence["normative_manifest_sha256"] = nh
    evidence["candidate_binding_sha256"] = sha256_bytes(canonical(binding))
    save(vpath, vectors)


def run_validator(round_dir: Path, semantic_only: bool = True) -> subprocess.CompletedProcess:
    cmd = ["python3", "-S", str(round_dir / "meta_validate_round18.py"), "--root", str(round_dir)]
    if semantic_only:
        cmd.append("--semantic-only")
    return subprocess.run(cmd, capture_output=True, text=True)


# ---- mutation definitions: id, expected_reason_substring, mutator ----

def m_empty_binding_schema(d):
    replace_json(d, "PHASE0A_CANDIDATE_BINDING.schema.json", {})


def m_empty_evidence_schema(d):
    replace_json(d, "PHASE0A_CANDIDATE_EVIDENCE.schema.json", {})


def m_empty_gate_schema(d):
    replace_json(d, "PHASE0A_GATE_CASE_EVIDENCE.schema.json", {})


def m_empty_dag_schema(d):
    replace_json(d, "PHASE0A_DAG_SCHEMA.v2.json", {})


def m_vacuous_fixtures(d):
    def edit(v):
        for case in v["cases"]:
            case["fixture_inline"] = {}
    mutate_json(d, "PHASE0A_ACCEPTANCE_CONTRACT.v4.json", edit)
    rebind_contract_and_vectors(d)


def m_noop_mutants(d):
    def edit(v):
        for m in v["mutants"]:
            m["mutation_operator"] = {"id": "NO_OP", "kind": "NO_OP", "executable": False, "control": "CANDIDATE", "transform": "NO_OP"}
    mutate_json(d, "PHASE0A_ACCEPTANCE_CONTRACT.v4.json", edit)
    rebind_contract_and_vectors(d)


def m_final_condition_true(d):
    def edit(v):
        for i, c in enumerate(v["conditions"]):
            if c["condition_id"] == "N80_ELIGIBLE":
                v["conditions"][i] = {"condition_id": "N80_ELIGIBLE", "type": "constant", "value": True}
    mutate_json(d, "PHASE0A_CONDITION_REGISTRY.v2.json", edit)


def m_rereview_checks_removed(d):
    def edit(v):
        node = next(n for n in v["nodes"] if n["node_id"] == "P0A-N70-INDEPENDENT-REREVIEW")
        node["kind"] = "noop"
        node["required_checks"] = []
    mutate_json(d, "PHASE0A_BUILD_DAG.v2.json", edit)


def m_initial_review_removed(d):
    def edit(v):
        node = next(n for n in v["nodes"] if n["node_id"] == "P0A-N50-INDEPENDENT-REVIEW")
        node["required_checks"] = ["do not execute candidate acceptance tests"]
    mutate_json(d, "PHASE0A_BUILD_DAG.v2.json", edit)


def m_slug_traversal(d):
    def edit(v):
        v["properties"]["slug"]["pattern"] = "^.*$"
        v["x-phase0a-slug-reserved"] = []
    mutate_json(d, "PHASE0A_NOTE_STATE.schema.json", edit)


def m_published_status(d):
    def edit(v):
        v["properties"]["status"]["enum"].append("published")
    mutate_json(d, "PHASE0A_NOTE_STATE.schema.json", edit)


def m_action_detail_removed(d):
    mutate_json(d, "PHASE0A_PROVENANCE_EVENT.schema.json", lambda v: v.__setitem__("x-phase0a-action-detail-branch", {}))


def m_hash_domains(d):
    def edit(v):
        v["hashes"]["note_state"]["domain_prefix_utf8_then_nul"] = "BROKEN-NOTE-DOMAIN"
        v["hashes"]["provenance_event"]["domain_prefix_utf8_then_nul"] = "BROKEN-EVENT-DOMAIN"
        v["hashes"]["export_receipt"]["domain_prefix_utf8_then_nul"] = "BROKEN-RECEIPT-DOMAIN"
    mutate_json(d, "PHASE0A_CANONICAL_RULES.v2.json", edit)


def m_export_write_widen(d):
    def edit(v):
        v["write_boundary"]["public_repository"] = True
        v["write_boundary"]["outside_workspace"] = True
    mutate_json(d, "PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v3.json", edit)


def m_export_self_hash(d):
    def edit(v):
        v["members"]["export-receipt.json"]["receipt_hash_excludes_field"] = None
    mutate_json(d, "PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v3.json", edit)


def m_runner_bypass(d):
    def edit(v):
        v["command"] = ["true"]
        v["final_evidence"] = {"status_logic": {"CANDIDATE_TESTS_PASS": "runner says PASS"}}
        v["oracle"] = {"module": "candidate_oracle.py", "control": "CANDIDATE", "candidate_may_not_supply_oracle": False}
    mutate_json(d, "PHASE0A_RUNNER_INTERFACE.v2.json", edit)


def m_fictitious_evidence(d):
    def edit(v):
        evidence = v["positive_fixture"]["candidate_evidence"]
        for result in evidence["case_results"]:
            result["evidence_sha256"] = "0" * 64
        for result in evidence["assertion_results"]:
            result["evidence_sha256"] = "0" * 64
        for result in evidence["mutant_results"]:
            result["evidence_sha256"] = "0" * 64
        evidence["payload_manifest_sha256"] = "0" * 64
    mutate_json(d, "PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json", edit)


def m_hidden_provider(d):
    def edit(v):
        node = next(n for n in v["nodes"] if n["node_id"] == "P0A-N40-BUILD-CANDIDATE")
        node["required_checks"].append("connect DeepSeek with operator credentials")
    mutate_json(d, "PHASE0A_BUILD_DAG.v2.json", edit)


def m_impl_claim(d):
    def edit(v):
        v["application_implemented"] = True
        v["candidate_pass_target"] = "CANDIDATE_TESTS_PASS_ALREADY_ACHIEVED"
    mutate_json(d, "NO_IMPLEMENTATION_CANDIDATE.json", edit)


def m_remove_dashboard(d):
    contract_path = d / "PHASE0A_ACCEPTANCE_CONTRACT.v4.json"
    contract = load(contract_path)
    test_id = "T-G-P0A-DASHBOARD-EXPORT-STATUS"
    test = next(t for t in contract["tests"] if t["test_id"] == test_id)
    case_ids = set(test["case_ids"])
    assertion_ids = set(test["assertion_ids"])
    mutant_ids = set(test["mutant_ids"])
    for gate in contract["gates"]:
        gate["test_ids"] = [x for x in gate["test_ids"] if x != test_id]
    contract["tests"] = [t for t in contract["tests"] if t["test_id"] != test_id]
    contract["cases"] = [c for c in contract["cases"] if c["case_id"] not in case_ids]
    contract["assertions"] = [a for a in contract["assertions"] if a["assertion_id"] not in assertion_ids]
    contract["mutants"] = [m for m in contract["mutants"] if m["mutant_id"] not in mutant_ids]
    contract["counts"] = {
        "inherited_named_tests": 63,
        "round16_additional_tests": len(contract["tests"]) - 63,
        "total_tests": len(contract["tests"]),
        "total_cases": len(contract["cases"]),
        "total_assertions": len(contract["assertions"]),
        "total_mutants": len(contract["mutants"]),
    }
    save(contract_path, contract)
    runner = load(d / "PHASE0A_RUNNER_INTERFACE.v2.json")
    runner["required_runner_methods"] = [x for x in runner["required_runner_methods"] if x != test["runner_method"]]
    save(d / "PHASE0A_RUNNER_INTERFACE.v2.json", runner)
    # coherent evidence trim
    vectors = load(d / "PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json")
    evidence = vectors["positive_fixture"]["candidate_evidence"]
    evidence["case_results"] = [x for x in evidence["case_results"] if x["case_id"] not in case_ids]
    evidence["assertion_results"] = [x for x in evidence["assertion_results"] if x["assertion_id"] not in assertion_ids]
    evidence["mutant_results"] = [x for x in evidence["mutant_results"] if x["mutant_id"] not in mutant_ids]
    evidence["summary"] = {
        "expected_cases": len(contract["cases"]),
        "executed_cases": len(contract["cases"]),
        "passed_cases": len(contract["cases"]),
        "failed_cases": 0,
        "skipped_cases": 0,
        "expected_assertions": len(contract["assertions"]),
        "passed_assertions": len(contract["assertions"]),
        "failed_assertions": 0,
        "required_mutants": len(contract["mutants"]),
        "killed_mutants": len(contract["mutants"]),
        "surviving_mutants": 0,
    }
    save(d / "PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json", vectors)
    rebind_contract_and_vectors(d)


def m_weak_note_schema(d):
    replace_json(d, "PHASE0A_NOTE_STATE.schema.json", {"type": "object"})


def m_binding_main_branch_const(d):
    def edit(v):
        v["properties"]["branch"]["const"] = "main"
    mutate_json(d, "PHASE0A_CANDIDATE_BINDING.schema.json", edit)


def m_binding_zero_bind(d):
    def edit(v):
        v["properties"]["server_bind"]["const"] = "0.0.0.0"
    mutate_json(d, "PHASE0A_CANDIDATE_BINDING.schema.json", edit)


def m_hold_not_terminal(d):
    def edit(v):
        v["rules"]["HOLD_is_terminal"] = False
    mutate_json(d, "PHASE0A_CONDITION_REGISTRY.v2.json", edit)


def m_extra_allowed_trace(d):
    def edit(v):
        v["allowed_traces"].append({"n50": "HOLD", "n60": "NOT_REQUIRED", "n70": "INITIAL_PASS_CONFIRMED", "n80": "ELIGIBLE"})
    mutate_json(d, "PHASE0A_TRANSITION_TABLE.v1.json", edit)


def m_n80_always(d):
    def edit(v):
        node = next(n for n in v["nodes"] if n["node_id"] == "P0A-N80-FINAL-HANDOFF")
        node["condition_ids"] = ["ALWAYS"]
        node["consumes"] = ["output:P0A-N70-INDEPENDENT-REREVIEW/O-REREVIEW-RECEIPT"]
    mutate_json(d, "PHASE0A_BUILD_DAG.v2.json", edit)


def m_raw_html_accept(d):
    def edit(v):
        v["raw_html_policy"]["on_persist"] = "ACCEPT_WITH_ESCAPING"
    mutate_json(d, "PHASE0A_CANONICAL_RULES.v2.json", edit)


def m_remove_requirement(d):
    def edit(v):
        v["requirements"] = [r for r in v["requirements"] if r["requirement_id"] != "HR-DASHBOARD"]
    mutate_json(d, "PHASE0A_HANDOFF_REQUIREMENT_REGISTRY.v1.json", edit)


def m_echo_oracle(d):
    def edit(v):
        v["oracle"] = {"id": "candidate-echo", "control": "CANDIDATE", "echo_runner_rejected": False}
    mutate_json(d, "PHASE0A_ACCEPTANCE_CONTRACT.v4.json", edit)
    rebind_contract_and_vectors(d)


def m_reversed_times(d):
    def edit(v):
        e = v["positive_fixture"]["candidate_evidence"]
        e["started_at"] = "2026-08-01T10:00:00Z"
        e["finished_at"] = "2026-08-01T09:00:00Z"
    mutate_json(d, "PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json", edit)


def m_authority_true(d):
    def edit(v):
        v["authority_granted"]["external_provider"] = True
    mutate_json(d, "PHASE0A_PRECEDENCE_AND_SUPERSESSION.v2.json", edit)


MUTATIONS = [
    # R17 twenty classes (mapped to R018 filenames)
    ("R17-M01-EMPTY-CANDIDATE-BINDING-SCHEMA", "SCHEMA_NOT_SUBSTANTIVE", m_empty_binding_schema),
    ("R17-M02-EMPTY-CANDIDATE-EVIDENCE-SCHEMA", "SCHEMA_NOT_SUBSTANTIVE", m_empty_evidence_schema),
    ("R17-M03-EMPTY-GATE-CASE-SCHEMA", "SCHEMA_NOT_SUBSTANTIVE", m_empty_gate_schema),
    ("R17-M04-EMPTY-DAG-SCHEMA", "SCHEMA_NOT_SUBSTANTIVE", m_empty_dag_schema),
    ("R17-M05-VACUOUS-INLINE-FIXTURES", "SYMBOLIC_CASE", m_vacuous_fixtures),
    ("R17-M06-NOOP-MUTATION-OPERATORS", "NOOP_MUTANT", m_noop_mutants),
    ("R17-M07-FINAL-CONDITION-CONSTANT-TRUE", "FINAL_CONDITION_CONSTANT", m_final_condition_true),
    ("R17-M08-REREVIEW-CHECKS-REMOVED", "REREVIEW", m_rereview_checks_removed),
    ("R17-M09-INITIAL-REVIEW-TEST-EXECUTION-REMOVED", "INITIAL_REVIEW_TEST_EXECUTION_REMOVED", m_initial_review_removed),
    ("R17-M10-SLUG-TRAVERSAL-ALLOWED", "SLUG_PATTERN_INSECURE", m_slug_traversal),
    ("R17-M11-PUBLISHED-STATUS-ADDED", "NOTE_STATUS_PUBLISHED_FORBIDDEN", m_published_status),
    ("R17-M12-ACTION-DETAIL-MAPPING-REMOVED", "ACTION_DETAIL_MAPPING_INCOMPLETE", m_action_detail_removed),
    ("R17-M13-CANONICAL-HASH-DOMAINS-CHANGED", "CANONICAL_", m_hash_domains),
    ("R17-M14-EXPORT-WRITE-BOUNDARY-WIDENED", "EXPORT_WRITE_BOUNDARY_WIDENED", m_export_write_widen),
    ("R17-M15-EXPORT-RECEIPT-SELF-HASH-ENABLED", "EXPORT_RECEIPT_SELF_HASH", m_export_self_hash),
    ("R17-M16-RUNNER-EVIDENCE-BYPASS", "RUNNER_EVIDENCE_BYPASS", m_runner_bypass),
    ("R17-M17-FICTITIOUS-EVIDENCE-HASHES", "FICTITIOUS_EVIDENCE_HASH", m_fictitious_evidence),
    ("R17-M18-HIDDEN-PROVIDER-AUTHORITY-IN-DAG", "HIDDEN_PROVIDER", m_hidden_provider),
    ("R17-M19-UNSUPPORTED-IMPLEMENTATION-CLAIM", "UNSUPPORTED_IMPLEMENTATION_CLAIM", m_impl_claim),
    ("R17-M20-REQUIRED-DASHBOARD-TEST-REMOVED-COHERENTLY", "HANDOFF_FLOOR_TEST_REMOVED", m_remove_dashboard),
    # additional controls
    ("R18-M21-WEAK-NOTE-SCHEMA", "SCHEMA_NOT_SUBSTANTIVE", m_weak_note_schema),
    ("R18-M22-BINDING-MAIN-BRANCH", "BINDING_INSTANCE", m_binding_main_branch_const),  # may also fail binding instance differently
    ("R18-M23-BINDING-0.0.0.0", "BINDING", m_binding_zero_bind),
    ("R18-M24-HOLD-NOT-TERMINAL", "HOLD_NOT_TERMINAL", m_hold_not_terminal),
    ("R18-M25-EXTRA-ALLOWED-HOLD-TRACE", "TRACE_EXTRA_OR_MISSING", m_extra_allowed_trace),
    ("R18-M26-N80-ALWAYS", "N80_", m_n80_always),
    ("R18-M27-RAW-HTML-ACCEPT", "RAW_HTML_MUST_REJECT", m_raw_html_accept),
    ("R18-M28-REMOVE-DASHBOARD-REQUIREMENT", "REQUIREMENT_REMOVED", m_remove_requirement),
    ("R18-M29-ECHO-ORACLE", "ORACLE_NOT_INDEPENDENT", m_echo_oracle),
    ("R18-M30-REVERSED-EVIDENCE-TIMES", "EVIDENCE_TIME_REVERSED", m_reversed_times),
    ("R18-M31-AUTHORITY-GRANTED-TRUE", "AUTHORITY_GRANTED_NOT_FALSE", m_authority_true),
]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-md", type=Path, required=True)
    parser.add_argument("--full", action="store_true")
    args = parser.parse_args()

    baseline = run_validator(SOURCE, semantic_only=not args.full)
    if baseline.returncode != 0:
        print(baseline.stdout)
        print(baseline.stderr)
        raise SystemExit("baseline validator failed")

    results = []
    for mid, expected_sub, mutator in MUTATIONS:
        with tempfile.TemporaryDirectory(prefix="pa-r18-mut-") as tmp:
            rd = Path(tmp) / "round"
            shutil.copytree(SOURCE, rd)
            mutator(rd)
            # co-update round checksum only
            regenerate_round_checksums(rd)
            run = run_validator(rd, semantic_only=True)
            rejected = run.returncode != 0
            # exact reason: expected substring in errors
            reason_hit = expected_sub in (run.stdout + run.stderr)
            status = "REJECTED" if rejected else "FALSE_GREEN"
            if rejected and not reason_hit:
                status = "REJECTED_WRONG_REASON"
            # Normalize validator JSON stdout for hash-seed-stable receipts
            try:
                payload = json.loads(run.stdout)
                if isinstance(payload, dict) and "errors" in payload:
                    payload["errors"] = sorted(payload["errors"])
                norm_out = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
            except Exception:
                norm_out = run.stdout
            results.append({
                "mutation_id": mid,
                "expected_reason_substring": expected_sub,
                "expected": "REJECT",
                "observed": status,
                "validator_exit_code": run.returncode,
                "reason_matched": bool(reason_hit),
                "stdout_sha256": sha256_bytes(norm_out.encode()),
                "stderr_sha256": sha256_bytes((run.stderr or "").encode()),
            })

    # sort for determinism
    results = sorted(results, key=lambda r: r["mutation_id"])
    rejected = sum(1 for r in results if r["observed"] in ("REJECTED", "REJECTED_WRONG_REASON"))
    false_green = sum(1 for r in results if r["observed"] == "FALSE_GREEN")
    wrong = sum(1 for r in results if r["observed"] == "REJECTED_WRONG_REASON")
    receipt = {
        "schema_version": "pa.phase0a.round18_mutation_receipt.v1",
        "status": "PASS" if false_green == 0 and wrong == 0 else "FAIL",
        "source_tree_modified": False,
        "execution_boundary": "disposable /tmp copies only",
        "pythonhashseed_note": "receipt bytes must be identical across PYTHONHASHSEED values; seed not recorded",
        "validator": "meta_validate_round18.py",
        "baseline_exit_code": baseline.returncode,
        "registry_exact": sorted(m[0] for m in MUTATIONS),
        "registry_count": len(MUTATIONS),
        "summary": {
            "mutation_classes": len(results),
            "rejected": rejected,
            "false_green": false_green,
            "rejected_wrong_reason": wrong,
        },
        "results": results,
    }
    # deterministic dump
    text = json.dumps(receipt, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    args.output_json.write_text(text, encoding="utf-8")
    md = [
        "# Round 018 Mutation Receipt",
        "",
        f"Status: `{receipt['status']}`",
        f"Classes: {len(results)}",
        f"Rejected: {rejected}",
        f"False green: {false_green}",
        f"Wrong reason: {wrong}",
        "",
        "| ID | Observed | Reason match |",
        "|---|---|---|",
    ]
    for r in results:
        md.append(f"| `{r['mutation_id']}` | {r['observed']} | {r['reason_matched']} |")
    args.output_md.write_text("\n".join(md) + "\n", encoding="utf-8")
    print(json.dumps(receipt["summary"], sort_keys=True))
    print(f"receipt_sha256={sha256_bytes(text.encode())}")
    return 0 if receipt["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
