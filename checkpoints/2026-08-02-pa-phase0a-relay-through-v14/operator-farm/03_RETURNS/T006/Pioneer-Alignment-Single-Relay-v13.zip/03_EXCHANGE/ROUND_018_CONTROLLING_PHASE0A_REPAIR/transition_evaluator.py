#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from lib_phase0a import *

def main():
    # exhaustive matrix
    n50s = ["PASS", "REPAIR_REQUIRED", "HOLD"]
    n60s = ["NOT_REQUIRED", "REPAIRED", "BLOCKED"]
    n70s = ["INITIAL_PASS_CONFIRMED", "PASS_AFTER_REPAIR", "FAIL", "BLOCKED"]
    rows = []
    for a in n50s:
        for b in n60s:
            for c in n70s:
                r = evaluate_review_trace(a, b, c)
                rows.append({"n50": a, "n60": b, "n70": c, **r})
    allowed = [r for r in rows if r["allowed"]]
    out = {
        "schema_version": "pa.phase0a.transition_eval_receipt.v1",
        "total": len(rows),
        "allowed_count": len(allowed),
        "allowed": allowed,
        "hold_terminal_ok": all(not r["allowed"] for r in rows if r["n50"] == "HOLD"),
        "expected_allowed": [
            {"n50": "PASS", "n60": "NOT_REQUIRED", "n70": "INITIAL_PASS_CONFIRMED"},
            {"n50": "REPAIR_REQUIRED", "n60": "REPAIRED", "n70": "PASS_AFTER_REPAIR"},
        ],
    }
    # n80 identity demo
    out["n80_identity_ok"] = not n80_identity_check("a","t","s","e","a","t","s","e",[], BIND, [], [])
    out["n80_identity_blocks_remote"] = bool(n80_identity_check("a","t","s","e","a","t","s","e",["origin"], BIND, [], []))
    out["n80_identity_blocks_tree_change"] = bool(n80_identity_check("a","t1","s","e","a","t2","s","e",[], BIND, [], []))
    print(dumps_pretty(out), end="")
    ok = out["allowed_count"] == 2 and out["hold_terminal_ok"] and out["n80_identity_ok"] and out["n80_identity_blocks_remote"] and out["n80_identity_blocks_tree_change"]
    return 0 if ok else 1

if __name__ == "__main__":
    raise SystemExit(main())
