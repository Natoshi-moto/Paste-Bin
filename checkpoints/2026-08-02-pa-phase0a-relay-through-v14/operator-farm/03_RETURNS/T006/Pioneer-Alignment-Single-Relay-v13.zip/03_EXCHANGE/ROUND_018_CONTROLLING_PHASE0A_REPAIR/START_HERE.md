# START HERE — Round 018 Controlling Phase 0A Repair

**Adjudication:** `ROUND018_REPAIR_COMPLETE_AWAITING_INDEPENDENT_REREVIEW`  
**Application candidate:** none  
**Host preflight:** not run  
**Repository mutation:** none  
**Wider Rounds 3–10:** separate HOLD

## Read order

1. `REPAIR_SUMMARY.md`
2. `PHASE0A_NORMATIVE_MANIFEST.v1.json` (sha256 `bbbc6e34c695692f06c93f7b20b5b7f9662dcef874c65b704259c79200a8658b`)
3. `PHASE0A_PRECEDENCE_AND_SUPERSESSION.v2.json`
4. `PHASE0A_CANONICAL_RULES.v2.json`
5. `PHASE0A_ACCEPTANCE_CONTRACT.v4.json`
6. `PHASE0A_BUILD_DAG.v2.json` + `PHASE0A_TRANSITION_TABLE.v1.json`
7. `PHASE0A_EVIDENCE_PROTOCOL.v1.json`
8. `meta_validate_round18.py` / `independent_oracle.py` / `run_round18_mutations.py`
9. `MUTATION_RECEIPTS.md`
10. `REQUEST_FOR_INDEPENDENT_REREVIEW.md`

## Claims

- Spec contract: `SPEC_CONTRACT_VALID`
- Mutations: 31 classes, 31 rejected, 0 false-green
- Deterministic mutation receipts across `PYTHONHASHSEED=1` and `2`
- No application, host, Git, remote, provider, or production claim

## Commands

```text
python3 -S meta_validate_round18.py
python3 -S independent_oracle.py
python3 -S transition_evaluator.py
python3 -S export_generator.py
python3 -S export_verifier.py
python3 -S run_round18_mutations.py --output-json MUTATION_RECEIPTS.json --output-md MUTATION_RECEIPTS.md
```
