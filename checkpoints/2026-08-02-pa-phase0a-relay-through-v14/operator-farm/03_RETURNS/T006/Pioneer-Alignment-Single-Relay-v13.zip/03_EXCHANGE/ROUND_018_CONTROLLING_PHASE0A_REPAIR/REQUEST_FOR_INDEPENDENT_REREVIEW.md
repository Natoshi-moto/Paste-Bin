# Request for Independent Phase 0A Spec Re-review

## Actor

Independent Phase 0A specification re-reviewer (not the controlling engineer who wrote Round 018).

## Mission

Re-review Round 018 only. Decide whether the narrow local-only Phase 0A specification
and executable gate are safe to hand to a bounded local builder.

## Mandatory checks

1. Verify immutable input manifest of the received relay.
2. Run `python3 -S 03_EXCHANGE/ROUND_018_CONTROLLING_PHASE0A_REPAIR/meta_validate_round18.py`.
3. Run `independent_oracle.py`, `transition_evaluator.py`, `export_generator.py`, `export_verifier.py`.
4. Run `run_round18_mutations.py` under at least two `PYTHONHASHSEED` values; receipts must match.
5. Re-apply all 20 Round 017 adversarial classes (included in the Round 018 suite).
6. Attempt additional material mutations beyond the registry if warranted.
7. Confirm HOLD is terminal and N80 cannot package non-reviewed bytes.
8. Confirm no application/host/Git/remote/provider/production claim is smuggled in.

## Allowed adjudication

- `PHASE0A_SPEC_RELEASED_TO_BOUNDED_LOCAL_BUILDER`
- `HOLD_FOR_FURTHER_PHASE0A_SPEC_REPAIR`
- `INSUFFICIENT_EVIDENCE`

## Prohibitions

Do not build the application, mutate a repository, create branches/commits, push,
request credentials, connect providers, deploy, alter DNS/Cloudflare/production,
or promote wider architecture.
