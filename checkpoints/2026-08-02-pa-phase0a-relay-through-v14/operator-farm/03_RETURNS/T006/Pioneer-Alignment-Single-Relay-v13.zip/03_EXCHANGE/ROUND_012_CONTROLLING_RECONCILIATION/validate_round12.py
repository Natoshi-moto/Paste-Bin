#!/usr/bin/env python3
from pathlib import Path
import json, sys

root = Path(__file__).resolve().parent
errors = []

graph = json.loads((root/"NORMATIVE_AUTHORITY_GRAPH.json").read_text())
node_ids = [n["id"] for n in graph["nodes"]]
if len(node_ids) != len(set(node_ids)):
    errors.append("duplicate graph node")
for e in graph["edges"]:
    if e["from"] not in node_ids or e["to"] not in node_ids:
        errors.append(f"orphan edge {e['id']}")
if any(e["from"]=="WORK_REP" and e["to"] in {"MATURITY","GOV"} for e in graph["edges"]):
    errors.append("work reputation authority leak")
for f in graph["forbidden_edges"]:
    if any(e["from"]==f["from"] and e["to"]==f["to"] for e in graph["edges"]):
        errors.append(f"forbidden edge present {f}")

dag = json.loads((root/"BUILD_DAG.json").read_text())
ids = {n["id"] for n in dag["nodes"]}
# Strip interface suffix and optional marker for topology.
deps = {n["id"]:[d.split(":")[0].rstrip("?") for d in n["depends_on"] if d.split(":")[0].rstrip("?") in ids] for n in dag["nodes"]}
temp=set(); perm=set()
def visit(n):
    if n in temp:
        errors.append(f"DAG cycle at {n}"); return
    if n in perm: return
    temp.add(n)
    for d in deps[n]: visit(d)
    temp.remove(n); perm.add(n)
for n in ids: visit(n)

gates = json.loads((root/"GATE_REGISTRY.json").read_text())["gates"]
gids=[g["gate_id"] for g in gates]
if len(gids)!=len(set(gids)): errors.append("duplicate gate id")
for g in gates:
    if g["minimum_assertions"] <= 0 or g["minimum_positive_cases"] <= 0 or g["minimum_negative_cases"] <= 0:
        errors.append(f"vacuous gate {g['gate_id']}")
    if g["empty_skipped_killed_zero_assertion_result"]!="FAIL":
        errors.append(f"non-fail-closed gate {g['gate_id']}")

disp=json.loads((root/"R11_FINDING_DISPOSITIONS.json").read_text())
if len(disp)!=31: errors.append(f"expected 31 finding dispositions, got {len(disp)}")
if len({d["finding_id"] for d in disp})!=31: errors.append("duplicate finding disposition")

if errors:
    print("\n".join(errors))
    sys.exit(1)
print("PASS: Round 012 architecture repair internal consistency")
