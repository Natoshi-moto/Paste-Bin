# Independent Replay and Tally Specification

Version: v1  
Status: Synthetic architecture requirement

## Independence definition

The reference verifier must:

- be separately authored;
- live in a separately versioned package or repository subtree;
- consume only the frozen wire/event specification and golden vectors;
- import neither the primary canonicaliser nor primary reducer;
- share no generated code with the primary implementation;
- use a different implementation language or independent runtime.

Recommended synthetic split:

- primary application: existing project language;
- independent verifier: Python 3 standard library only.

## Required outputs

Given the same corpus, each implementation emits:

- accepted event IDs in order;
- rejected event IDs and reason codes;
- checkpoint state hashes;
- NEX supply and balances where applicable;
- LEX supply and balances where applicable;
- proposal/tally/enactment state where applicable;
- privacy/purge state summary without payload disclosure.

## Mutation obligation

The harness must seed semantic mutations into:

- primary canonicalisation;
- verifier canonicalisation;
- primary reducer;
- verifier reducer;
- tally logic;
- capability evaluation.

Each mutation must turn at least one named gate red.

## Failure posture

Any disagreement means:

`HOLD — INDEPENDENT REPLAY DIVERGENCE`

No majority vote between implementations.

A third adjudication implementation or manual proof may locate the defect, but neither original implementation is presumed correct.
