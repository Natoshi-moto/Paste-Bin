# Review, Repair, Adjudication and Candidate Split

## S06R — Immutable review

- reviewers are read-only;
- exact candidate commit and artifact hashes are frozen;
- findings are immutable after issue except superseding clarifications;
- no reviewer repairs the candidate it reviewed.

## S06F — Per-finding repair

- one repair branch per coherent finding set;
- repair author cites finding IDs;
- failure evidence preserved;
- every repair adds a regression test;
- no severity downgrade by repair author.

## S06A — Independent adjudication

- separate identity from original reviewer and repair author;
- reproduces original finding;
- reproduces repair from a clean checkout;
- signs exact reviewed commit and artifacts;
- closes, narrows, defers-with-disabled-feature, or leaves open.

## S07 — Local candidate

Release tooling fails when:

- any Critical or High finding affecting a declared invariant is open;
- a deferred feature is enabled;
- independent review did not bind the exact merge commit;
- replay or gate parity fails.

Allowed label:

`LOCAL SYNTHETIC CANDIDATE — NO PUBLIC AUTHORITY`
