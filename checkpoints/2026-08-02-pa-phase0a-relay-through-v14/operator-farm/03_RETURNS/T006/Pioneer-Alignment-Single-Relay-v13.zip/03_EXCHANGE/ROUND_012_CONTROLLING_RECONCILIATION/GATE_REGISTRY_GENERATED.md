# Generated Gate Registry

Generated from `GATE_REGISTRY.json`.

| ID | Sweep | Gate | + cases | − cases | Mutation | Independent |
|---|---|---|---:|---:|---|---|
| `G-PRE-001` | PRE-S01 | Canon traceability | 1 | 1 | True | True |
| `G-PRE-002` | PRE-S01 | Graph parity | 1 | 1 | True | False |
| `G-PRE-003` | PRE-S01 | Genesis determinism | 5 | 10 | True | True |
| `G-PRE-004` | PRE-S01 | DAG topology | 1 | 5 | True | False |
| `G-S01-001` | S01 | Canonicalisation vectors | 20 | 20 | True | True |
| `G-S01-002` | S01 | Replay determinism | 50 | 50 | True | True |
| `G-S01-003` | S01 | Capability safety | 20 | 30 | True | True |
| `G-S01-004` | S01 | Time/freshness | 15 | 20 | True | True |
| `G-P0A-001` | P0A | Atomic note provenance | 10 | 20 | True | False |
| `G-P0A-002` | P0A | Acyclic export identity | 10 | 10 | True | False |
| `G-P0A-003` | P0A | Local web boundary | 10 | 20 | True | False |
| `G-S02-001` | S02 | NEX supply invariants | 50 | 100 | True | True |
| `G-S02-002` | S02 | Compensation-domain exclusivity | 20 | 30 | True | True |
| `G-S02-003` | S02 | NEX governance isolation | 20 | 50 | True | True |
| `G-S03C-001` | S03C | LOOM source authority | 30 | 50 | True | True |
| `G-S03C-002` | S03C | Privacy payload purge | 20 | 30 | True | True |
| `G-S03C-003` | S03C | Projection reproducibility | 30 | 30 | True | True |
| `G-S04-001` | S04 | One-human synthetic uniqueness | 50 | 100 | True | True |
| `G-S04-002` | S04 | Secret ballot model | 30 | 50 | True | True |
| `G-S04-003` | S04 | LEX agenda equality | 20 | 30 | True | True |
| `G-S04-004` | S04 | Emergency cumulative cap | 20 | 100 | True | True |
| `G-S04-005` | S04 | Administrative-domain independence | 20 | 50 | True | True |
| `G-S05-001` | S05 | Cross-domain membrane | 100 | 200 | True | True |
| `G-S05-002` | S05 | Fork privacy compiler | 20 | 40 | True | True |
| `G-S05A-001` | S05-ADAPTERS | Adapter removal | 10 | 20 | True | True |
| `G-S05A-002` | S05-ADAPTERS | Federation privacy | 20 | 40 | True | True |
| `G-S05A-003` | S05-ADAPTERS | Noted grinding/isolation | 30 | 100 | True | True |
| `G-S06-001` | S06A | Finding closure | 1 | 1 | True | True |
| `G-S07-001` | S07 | Release blocker | 1 | 1 | True | True |
