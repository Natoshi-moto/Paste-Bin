# Exact Source Snapshot Request

To close `R11-001`, attach the existing bundle:

`Pioneer-Alignment-Current-Handoff-2026-07-31-v1.zip`

Expected SHA-256 if this is the same preserved bundle:

`265e41dd5e74b7866cafae9a8c4bc414d3be121e3ac9157e415d9773d8c2bdce`

If that ZIP is unavailable, attach these exact files:

- `DECISION_REGISTER.md`
- `NEX_LEX_CANON.md`
- `PIONEER_ALIGNMENT_CHARTER.md`
- `NEXUS_SOCIAL_CANON.md`
- `PIONEER_ALIGNMENT_GENESIS_CANON.md`
- `CURRENT_STATUS_AND_ROADMAP.md`
- `SOURCE_REGISTER.md`
- `LOOM_SITE_HISTORY_RECALL_EXPERIMENT.md`
- `NEXUS_NATIVE_AI_DIRECTION.md`
- `Pioneer-Alignment-Governance-Handoff-Trigger-v0.2.md`

The files have been located as File Library references, but references cannot be honestly represented as exact byte snapshots inside the relay.

Do not retype or paraphrase them. Attach the original files.
