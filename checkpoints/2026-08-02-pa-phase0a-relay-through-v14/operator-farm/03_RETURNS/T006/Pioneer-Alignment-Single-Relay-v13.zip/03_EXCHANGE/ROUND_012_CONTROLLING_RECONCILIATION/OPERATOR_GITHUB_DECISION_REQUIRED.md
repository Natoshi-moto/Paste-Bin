# Operator Decision Required — Private GitHub Continuity

Proposed exact manifest:

- repository: `Natoshi-moto/pioneer-alignment-app`
- visibility: private
- public repository `Natoshi-moto/pioneer-alignment-public`: prohibited
- deployment/Pages/production: none
- secrets/environments: none
- default branch: `main`, integration-only
- development branches: explicitly named local/sweep/repair/review branches
- one writer per branch/worktree
- one integration writer
- no force push or history rewrite
- project-safe text/source/tests/synthetic fixtures/receipts: allowed
- credentials, real private data, databases, caches, raw sessions and restricted exploit evidence: excluded

Required operator response:

`APPROVE PRIVATE GITHUB MANIFEST`

or provide one replacement repository name and any changed field.

Approval authorises only the manifest as a future bounded continuity policy. It does not itself authorise an immediate push, production deployment, public visibility, workflow, Pages, secret, or external action.
