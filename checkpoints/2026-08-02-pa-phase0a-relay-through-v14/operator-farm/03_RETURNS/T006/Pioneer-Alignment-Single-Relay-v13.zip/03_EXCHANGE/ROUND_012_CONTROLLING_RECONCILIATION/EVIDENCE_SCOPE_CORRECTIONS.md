# Evidence Scope Corrections

## PA-NEXT material

Classification:

`REFERENCE_ONLY_SELECTED_TRANSCRIPT_EVIDENCE`

It applies only to the exact candidate/repository/commit/scope named in its receipt.

It does not block Phase 0A and does not prove full tool-event continuity unless the tool-event transcript is present.

## Static release evidence

Classification:

`REFERENCE_ONLY_NOT_SWEEP_EVIDENCE`

It may orient publication boundaries.

It cannot close a sweep gate unless repository, commit, candidate ID, scope and evidence type exactly match the gate.

Gate tooling rejects mismatched evidence.
