# Phase 0A Architecture Repair Addendum

Status: Required amendment to the local-only Application Foundation 0A handoff

## Scope remains unchanged

Phase 0A remains:

- local-only;
- synthetic/local operator only;
- fake-provider only;
- no NEX/LEX;
- no social accounts;
- no federation;
- no public network;
- no remote/push without a later approved GitHub authority manifest.

## Required repairs

### Note/version provenance

Every create/edit/preview/export event binds:

- note ID;
- note version;
- canonical note-state hash;
- prior-version hash;
- transaction ID;
- event type;
- logical time.

The note mutation and event append occur in one database transaction.

### Export identity

Define a frozen note-version cut and included-event boundary.

Acyclic order:

1. payload files;
2. payload manifest covering payload files;
3. detached receipt covering the payload manifest and export parameters.

The manifest and receipt do not cover themselves.

Operational “export occurred” events are not part of the payload identity they describe.

### Repository status

Tracked `STATUS.json` contains:

- source parent or input commit;
- schema/version;
- build state;
- placeholder `final_commit: DETACHED_RECEIPT_REQUIRED`.

The actual final commit appears in a detached handoff receipt after commit creation.

### Time and finality

Use an injected deterministic clock for tests.

Wall time is display metadata.

No claim of consensus, public finality or rollback-proof history.

### Local web hardening

Required:

- fixed loopback bind guard;
- socket assertion of exactly `127.0.0.1`;
- reject `0.0.0.0`, `::`, LAN and override binds;
- Host allowlist;
- Origin validation;
- CSRF tokens for state-changing methods;
- content-type and body limits;
- no unsafe raw HTML;
- path traversal rejection.

### Payload separation

Private note payloads and provenance envelopes are separate.

Synthetic purge fixtures must remove payloads from database, cache and export fixtures while preserving minimal non-content provenance.

## Acceptance

Phase 0A may be sealed only when gates `G-P0A-001` through `G-P0A-003` pass and the final detached commit receipt matches `git rev-parse HEAD`.
