# Generated Authority Graph

**Generated from:** `NORMATIVE_AUTHORITY_GRAPH.json`

```mermaid
flowchart TD
    GENESIS["Synthetic genesis manifest"]
    CONST["Constitution / accepted canon"]
    OP["Bootstrap operator / later constitutional roles"]
    ID["Identity + key registry"]
    MATURITY["Mature-human credential state"]
    ROLE["Role and capability grants"]
    CLOCK["Injected deterministic clock/events"]
    EVT["Canonical signed-event kernel"]
    HEAD["Head checkpoints"]
    REC["LOOM RECORD store"]
    ROUTE["LOOM ROUTE indexes"]
    CLAIM["LOOM CLAIM registry"]
    SOCIAL["Social events + projections"]
    MOD["Moderation / appeal / resolution"]
    TASK["Task publication"]
    BID["Bids"]
    CONTRACT["Accepted contract"]
    EXEC["Agent/human execution"]
    RECEIPT["Execution receipt"]
    VERIFY["Independent verification"]
    ADJ["Adjudication"]
    WORK_REP["Work reputation projection"]
    COMPETENCE["Role-specific competence projection"]
    NEX["NEX event ledger + epoch balances"]
    LEX["LEX event ledger + epoch balances"]
    GOV["Governance proposals / ballots"]
    ENACT["Rule enactment"]
    AI["Native social AI / Relay"]
    ATP["AT Protocol adapter"]
    NOSTR["Nostr adapter"]
    NOTED["Noted deterministic game adapter"]
    PUB["Static public publication"]
    GENESIS -->|"declares_synthetic_root"| CONST
    GENESIS -->|"declares_test_operator"| OP
    GENESIS -->|"declares_test_identities"| ID
    GENESIS -->|"declares_root_capabilities"| ROLE
    GENESIS -->|"declares_clock_source"| CLOCK
    CONST -->|"defines_roles"| ROLE
    OP -->|"exercises_only_declared_bootstrap_grants"| ROLE
    ID -->|"subjects_receive_grants"| ROLE
    ROLE -->|"authorises_event_types"| EVT
    ID -->|"signs_events"| EVT
    CLOCK -->|"supplies_deterministic_time_events"| EVT
    EVT -->|"creates_checkpoints"| HEAD
    EVT -->|"ingests_exact_accepted_bytes"| REC
    REC -->|"indexes_replaceably"| ROUTE
    REC -->|"supports_or_contradicts"| CLAIM
    ROUTE -->|"locates_records_without_authority"| AI
    REC -->|"authorised_context"| AI
    AI -->|"drafts_claim_candidate"| CLAIM
    EVT -->|"projects_social_state"| SOCIAL
    SOCIAL -->|"subject_of_actions"| MOD
    MOD -->|"appends_actions_appeals_resolutions"| EVT
    ROLE -->|"authorises_task_publication"| TASK
    TASK -->|"accepts_bids"| BID
    BID -->|"award_gate"| CONTRACT
    CONTRACT -->|"authorises_execution"| EXEC
    EXEC -->|"produces_receipt"| RECEIPT
    RECEIPT -->|"is_reproduced"| VERIFY
    VERIFY -->|"supplies_finding"| ADJ
    ADJ -->|"orders_defined_settlement"| NEX
    ADJ -->|"updates_evidence_projection"| WORK_REP
    EVT -->|"projects_work_history"| WORK_REP
    WORK_REP -->|"bounded_role_specific_input"| COMPETENCE
    COMPETENCE -->|"bounded_pool_eligibility_only"| ROLE
    EVT -->|"applies_valid_nex_events"| NEX
    EVT -->|"applies_valid_lex_events"| LEX
    ID -->|"identity_evidence_only"| MATURITY
    MATURITY -->|"one_human_credential_input"| GOV
    LEX -->|"source_eligible_ballot_expenditure"| GOV
    GOV -->|"authorises_separate_enactment"| ENACT
    ENACT -->|"changes_future_role_rules"| ROLE
    ENACT -->|"changes_future_validation_rules"| EVT
    SOCIAL -->|"bounded_export"| ATP
    ATP -->|"quarantined_import"| SOCIAL
    SOCIAL -->|"bounded_export"| NOSTR
    NOSTR -->|"quarantined_import"| SOCIAL
    VERIFY -->|"eligible_milestone_reference_only"| NOTED
    NOTED -->|"game_event_or_announcement"| SOCIAL
    CLAIM -->|"deliberate_promotion_only"| PUB
    REC -->|"source_evidence"| PUB
```

## Invariants

- `INV-001` **route_non_authority** — No CLAIM may cite a ROUTE as evidence.
- `INV-002` **signature_not_truth** — A valid signature proves authorship/control, not factual correctness.
- `INV-003` **projection_non_authority** — Feeds, reputation, AI summaries, popularity and search rank are derived.
- `INV-004` **no_self_settlement** — Related identities cannot span publisher, worker, sole verifier, adjudicator and ledger authority.
- `INV-005` **no_nex_from_engagement** — Social engagement cannot mint NEX.
- `INV-006` **no_nex_political_power** — NEX and NEX-domain work/reputation cannot affect maturity, civic LEX, proposal rights or ballot weight.
- `INV-007` **no_lex_intelligence_purchase** — LEX cannot buy reasoning, compute, NEX work or NEX settlement.
- `INV-008` **no_unit_conversion** — No direct or indirect NEX–LEX conversion or functional substitute.
- `INV-009` **no_external_value_rail** — No official external price, redemption, sale, debt, equity or payment claim.
- `INV-010` **append_only_correction** — Accepted events and accounting are repaired by new events.
- `INV-011` **explicit_epoch_continuity** — Every balance epoch has declared closure and transition rules.
- `INV-012` **moderation_purge_split** — Visibility, retraction, deletion request and verified purge are distinct.
- `INV-013` **ai_deny_by_default** — Content and model output cannot grant tool or state authority.
- `INV-014` **adapter_non_sovereignty** — External protocol state requires separate accepted Pioneer events.
- `INV-015` **noted_isolation** — Noted history cannot affect institutional eligibility, economics, truth, moderation or research assessment.
- `INV-016` **publication_isolation** — Static publication consumes reviewed promotion artifacts only.
- `INV-017` **narrow_freeze** — Failures freeze the narrowest affected scope.
- `INV-018` **operator_receipt** — Exceptional operator actions require scope, reason, time, effect and review.
- `INV-019` **one_compensation_domain** — One deliverable lineage may settle in exactly one compensation domain.
- `INV-020` **secret_ballot_model** — Binding ballot choices are not publicly linkable or transferable as proof.
