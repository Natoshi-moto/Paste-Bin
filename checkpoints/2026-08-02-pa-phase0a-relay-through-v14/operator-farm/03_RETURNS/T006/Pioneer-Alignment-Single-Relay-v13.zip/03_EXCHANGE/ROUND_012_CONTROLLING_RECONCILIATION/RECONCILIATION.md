# Round 012 Architecture Repair — Controlling Reconciliation

Version: v1-draft  
Date: 2026-08-01  
Status: `BLOCKED_PENDING_CANON_SNAPSHOTS_AND_OPERATOR_GITHUB_DECISION`

## Input integrity

The returned relay v2 opened successfully.

- ZIP entries: 100
- current manifest entries verified: 99/99
- immutable input entries verified: 92/92
- Round 011 adjudication: `HOLD_FOR_ARCHITECTURE_REPAIR`
- findings accepted for repair: 31/31

No original artifact or prior exchange round was modified.

## Adjudication of the critic

The controlling review accepts all 31 findings as material or valid evidentiary corrections.

No finding is dismissed.

Two external closures remain:

1. exact canon/source snapshots must be placed in the relay;
2. the operator must approve or replace the proposed private GitHub authority manifest before any remote write.

No repository write is authorised.

## Architecture repairs included

- one normative authority graph and generated view;
- explicit synthetic genesis;
- machine-readable build DAG;
- one non-vacuous gate registry;
- canonical event/time/finality/payload specification;
- genuinely independent replay contract;
- Phase 0A provenance/export/status/local-web repairs;
- one compensation domain per receipt;
- zero NEX/work effect on civic maturity;
- equal proposal throughput;
- governance-service LEX made non-binding;
- explicit secret-ballot model;
- machine-defined administrative-domain independence;
- cumulative emergency limits;
- federation privacy firewall;
- Noted precommit and institutional isolation;
- review/repair/adjudication separation;
- expanded public blockers;
- stable finding namespaces;
- evidence-scope corrections;
- GitHub manifest proposal.

## Source blocker

File Library references have been located for the controlling documents, but file references are not byte snapshots in this relay.

The relay must not claim R11-001 closed until exact files and SHA-256 values are present.

Voice-derived founder directions in Round 3 are downgraded to exploratory and non-binding unless an explicit decision receipt is added.

## Recommended next state

After source files and operator GitHub decision are supplied:

1. insert exact source snapshots under `ROUND_012_ARCHITECTURE_REPAIR/CANON_SNAPSHOTS/`;
2. update `CANON_INDEX.json` with byte counts and SHA-256;
3. validate all generated representations and DAG/gates;
4. create the complete relay v3;
5. return it to the independent critic for Round 013 re-review.

No implementation begins before that re-review.
