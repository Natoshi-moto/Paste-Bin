# Canonical Event, Time, Finality and Payload Specification

Version: v1  
Status: Normative for the synthetic local architecture only

## 1. Canonical data profile — `PA-CANON-JSON-v1`

Allowed values:

- null;
- booleans;
- UTF-8 strings normalised to Unicode NFC;
- signed 64-bit integers;
- arrays;
- objects with unique string keys.

Forbidden:

- floating-point numbers;
- NaN or infinity;
- duplicate keys;
- unpaired surrogates;
- implicit dates;
- platform-specific binary encodings.

Serialisation:

1. normalise every string and key to NFC;
2. sort object keys by unsigned UTF-8 byte sequence;
3. encode JSON with no insignificant whitespace;
4. encode control characters with lowercase `\u` escapes where required;
5. encode all other valid Unicode directly as UTF-8;
6. encode integers in shortest base-10 form;
7. end with no trailing newline for the canonical byte string.

`payload_hash` and `event_id` are computed over explicit domains:

```text
payload_hash = SHA256("PA-PAYLOAD-v1\0" || canonical_payload_bytes)
event_id     = SHA256("PA-EVENT-v1\0"   || canonical_unsigned_envelope_bytes)
```

The signature covers `event_id` plus the algorithm/policy identifier.

These profiles are synthetic choices, not final public cryptographic policy.

## 2. Event envelope

Required fields:

```text
schema
event_type
event_version
event_id
actor_id
capability_grant_id
logical_tick
observed_head
parent_event_ids
access_class
retention_class
payload_ref
payload_hash
algorithm_policy
signature
```

The unsigned envelope excludes `event_id` and `signature` only.

## 3. Local acceptance order

For each candidate event:

1. parse with strict limits;
2. canonicalise;
3. verify event ID;
4. verify algorithm policy and signature;
5. verify identity and capability at `observed_head`;
6. verify parent/head and freshness rules;
7. verify access/retention policy;
8. verify event-type state transition;
9. append atomically;
10. update projections;
11. emit checkpoint when required.

## 4. Time

Wall-clock timestamps are not an unstated oracle.

Synthetic time advances only through accepted `CLOCK_TICK` events.

- `logical_tick` determines expiry and ordering.
- optional display time is derived from a clock fixture and has no authority.
- clock rollback is rejected.
- expiry comparisons use logical ticks.
- the exact clock fixture is part of the replay corpus.

## 5. Stale heads and offline actions

Ordinary social events may be accepted from a stale head only under an event-specific merge rule.

The following require the current confirmed head and are rejected while head uncertainty exists:

- role/capability changes;
- key revocation/recovery;
- NEX or LEX settlement;
- ballots and delegation;
- moderation restriction;
- emergency action;
- enactment;
- epoch closure or transition.

A delayed offline action is evaluated against the authority state at acceptance, not only signing time.

## 6. Synthetic finality

Local synthetic finality means:

- the single declared local sequencer accepted the event;
- the event appears in a checkpoint;
- a clean independent replay reproduces the same checkpoint state hash.

It does not mean:

- consensus;
- public multi-writer finality;
- external timestamp truth;
- rollback impossibility;
- suffix-deletion impossibility.

Public admission, ordering, witness, finality and availability remain a public blocker.

## 7. Payload separation

The canonical envelope and payload are separate.

### Public archival payload

May be content-addressed and retained under its policy.

### Public social payload

May be hidden/retracted from projections while the minimal envelope remains.

### Restricted/private payload

- random non-guessable object identifier;
- encryption key scoped to retention class and subject;
- payload hash retained only inside the restricted metadata domain;
- public tombstone contains no raw text, reversible quotation or unsalted guessable hash.

### Purge

Verified purge destroys or removes:

- payload object;
- decryption key;
- caches;
- ROUTEs;
- exports/backups under the declared policy.

The minimal canonical envelope records that a purge occurred without preserving recoverable content.

## 8. Golden vectors

The implementation package must include:

- one object-key ordering vector;
- one Unicode NFC vector;
- one integer-boundary vector;
- duplicate-key rejection;
- float rejection;
- canonical payload hash;
- canonical event ID;
- valid signature;
- wrong-domain signature rejection;
- stale-head ordinary social acceptance fixture;
- stale-head high-authority rejection fixture;
- clock rollback rejection;
- purge replay with irrecoverable payload.

No builder may alter these vectors unilaterally after input freeze.
