# Normative Provisional Membrane Amendment — Rounds 5–8

Status: Provisional synthetic architecture correction; not canon

This document repairs cross-domain defects without changing the binding NEX/LEX perimeter.

## M1. One compensation domain per deliverable lineage

Every accepted deliverable receipt receives one immutable compensation domain:

- `NEX_WORK`;
- `LEX_SOCIAL_SERVICE`;
- `LEX_GOVERNANCE_SERVICE`;
- `UNCOMPENSATED`;
- `BARTER_ONLY`.

Copies, metadata rewrites, splits and derived receipts inherit the exclusion.

A second compensation requires an independently scoped deliverable with different acceptance evidence.

## M2. NEX and work reputation cannot affect civic status

Mature-human eligibility consumes identity evidence only.

The following have exactly zero effect on:

- maturity;
- civic LEX;
- proposal access;
- ballot weight;
- human governance credential.

Inputs with zero effect:

- NEX balances;
- NEX contracts;
- NEX work receipts;
- participant-funded work;
- work reputation;
- Noted history;
- social popularity.

Role-specific competence may use appropriately scoped evidence, but never creates civic standing.

## M3. Agenda access is equal

Each mature credential receives the same binding-proposal submission quota.

Transferred LEX may serve only as refundable anti-spam collateral.

It cannot increase proposal throughput.

The sponsor path remains available independent of wealth.

## M4. Governance-service LEX is non-binding

For the safest synthetic baseline:

- governance-service LEX never becomes binding-ballot eligible;
- it remains social-use LEX and may fund declared non-voting commitments;
- civic allocation is the only source of binding ballot expenditure.

Any future proposal to change this is a separate constitutional experiment, not a builder default.

## M5. Secret ballot model

The synthetic governance model uses:

- mature-human anonymous credential;
- proposal-specific nullifier;
- encrypted or commitment-based choice;
- public inclusion and aggregate tally proof;
- private receipt proving inclusion only, not vote choice;
- no public identity-choice link;
- no transferable proof of choice.

Delegation uses scoped delegation tokens and direct override without re-delegation.

A role conflict is proven through a privacy-preserving eligibility predicate or confidential adjudication record, not public ballot linkage.

## M6. Administrative-domain independence

Independence is evaluated by ultimate controller, organisation, funding, infrastructure, household/close relationship where relevant, and contractual dependency.

Nominally distinct identities under one ultimate controller count as one administrative domain.

Credential issuer, recovery guardian, original reviewer and appeal reviewer thresholds must be satisfied across disjoint domains.

Safety claims are conditional on fewer than the declared threshold of corrupt independent domains.

## M7. Emergency cumulative duration

Every emergency has:

- scope fingerprint;
- root-cause fingerprint;
- rolling-window cumulative duration;
- declarer;
- reviewers;
- restart linkage.

End/restart does not reset cumulative duration.

Substantially identical emergencies require increasing independent approval and hit a hard stop that the declarer and emergency panel cannot self-authorise past.

## M8. Federation privacy

Federation mapping receipts use:

- pairwise adapter identifiers;
- separately access-controlled mapping tables;
- no human-root, governance credential or proposal-nullifier identifier;
- coarse or delayed timing where possible;
- explicit imported-content retention basis and external-deletion transition.

Public export never contains the private identity join table.

## M9. Noted precommit and isolation

Noted is optional.

Before milestone outcome, the system precommits:

- eligible milestone class;
- slot assignment method;
- ruleset;
- randomness/seed source;
- abort treatment.

Aborted or repeated attempts cannot improve rarity.

Changing only Noted history must leave byte-identical:

- identity maturity;
- all reputation projections used institutionally;
- task/panel eligibility;
- moderation;
- NEX/LEX;
- governance;
- research assessment.

## M10. No direct or indirect substitute

A system failing any section above violates the NEX/LEX membrane even when no explicit swap event exists.
