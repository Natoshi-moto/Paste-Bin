# Round 023 independent Phase 0A specification re-review

Act as the independent rereviewer, not the Round 022 controller and not the
application builder. Verify the v13 immutable-input manifest before running any
other tool. Use `PYTHONDONTWRITEBYTECODE=1 python3 -S` for every Python invocation.

Scope: `INDEPENDENT_PHASE0A_SPECIFICATION_REREVIEW_OF_ROUND_022_ONLY`. Do not
build an application, mutate a repository, perform host preflight, use credentials,
connect providers, deploy, or take any external action.

Read Round 022's specifications, executable gates, summaries, closure mapping,
operational receipts, and rereview request completely. Reproduce semantic and full
validation, independent oracle, transition evaluator, export generator/verifier,
the complete closure suite, and all 66 registry mutations under
`PYTHONHASHSEED=1` and `2`. Receipts must be byte-identical across seeds.

Re-run the immutable original Round 021 harnesses:

```text
cd 03_EXCHANGE/ROUND_021_INDEPENDENT_PHASE0A_SPEC_REREVIEW
PYTHONDONTWRITEBYTECODE=1 python3 -S r21_probes.py --relay-root ../.. --output-json /tmp/r23-r21.json
PYTHONDONTWRITEBYTECODE=1 python3 -S r21_authority_surface.py --relay-root ../.. --output-json /tmp/r23-r21-authority.json
```

Invent coherently rebound attacks outside the shipped registry. Prioritize:

- package-wide text/binary membership, undeclared files, executable-path
  classification, Python bytes and static string composition;
- exact slug maximum 80 and a hostile boundary-plus-one vector;
- all three fixed export identity domains;
- live/shipped receipt freshness and cross-hash replay;
- honest DEFERRED semantics, terminal HOLD, and N80 reviewed-byte identity;
- payload-semantic active-content rejection and evidence containment.

Use the official rebind and security-constant repin discipline. A validator import
crash or digest mismatch is a harness failure, not an intended rejection. Preserve
the wider HOLD and all external blockers. Round 022's green receipts are evidence
to reproduce and attack, never authority to echo.

Return exactly one complete `Pioneer-Alignment-Single-Relay-v14.zip`, one detached
outer SHA-256, and exactly one independent adjudication.
