# Authority

The receiving ChatGPT is authorised to:

- read and analyse the included corpus;
- identify contradictions, omissions, unsafe defaults, false-green tests and
  authority leaks;
- produce architecture findings and minimal amendments;
- create an updated relay ZIP containing its review.

It is not authorised to:

- write project code;
- mutate repositories;
- create branches or commits;
- deploy;
- access credentials;
- connect providers;
- create public accounts, balances, federation or governance;
- change DNS, Cloudflare, hosting, domain or production state;
- spend money;
- make legal commitments;
- promote provisional architecture into binding canon;
- delete or rewrite evidence.
