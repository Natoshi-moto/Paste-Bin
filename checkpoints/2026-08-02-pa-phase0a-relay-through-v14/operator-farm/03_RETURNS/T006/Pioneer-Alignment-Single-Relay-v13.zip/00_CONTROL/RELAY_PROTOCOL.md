# Single-ZIP Relay Protocol — Round 023 independent re-review

## Immutable areas

The next actor must not modify:

- `01_ORIGINAL_ARTIFACTS/**`;
- `02_EXTRACTED_CORPUS/**`;
- `00_CONTROL/AUTHORITY.md`;
- every exchange directory through
  `03_EXCHANGE/ROUND_022_CONTROLLING_PHASE0A_REPAIR/**`.

Round 021's original probe harnesses and every Round 022 gate/receipt byte are
immutable evidence. Tests and mutations must use disposable complete copies
beneath `/tmp`.

## Writable areas

- `03_EXCHANGE/ROUND_023_INDEPENDENT_PHASE0A_SPEC_REREVIEW/**`;
- only the exact control/tool/manifest paths listed in
  `00_CONTROL/CURRENT_STATE.json`.

## Required return archive

Return the complete relay as `Pioneer-Alignment-Single-Relay-v14.zip`, with the
numbered directories directly at archive root. Return no delta and no loose
companion files. Report the outer ZIP SHA-256 detached from the archive.

## Integrity order

1. Finish the Round 023 review outputs and operational receipts.
2. Hash the new Round 023 files except their self-referential checksum file.
3. Transition state and `allowed_mutations` to the next actor.
4. Run the relay builder once to generate, in order, the next immutable-input
   manifest, cycle-free inventory, current manifest, and ZIP.
5. Exclude every `__pycache__/**` and `*.pyc`; reject every symlink.
6. Reopen and verify the built ZIP, then validate a fresh extraction read-only.
7. Make no byte edit after the final builder run; rebuild if any byte changes.
8. Report the detached outer hash out of band.

Round 023 adjudicates independently. A green Round 022 receipt is evidence to
reproduce and challenge, never authority.
