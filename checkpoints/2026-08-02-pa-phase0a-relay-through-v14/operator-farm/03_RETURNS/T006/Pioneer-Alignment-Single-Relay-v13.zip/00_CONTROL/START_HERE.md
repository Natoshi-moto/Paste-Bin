# START HERE — Pioneer Alignment Single-ZIP Relay v13

Current state: `AWAITING_INDEPENDENT_PHASE0A_SPEC_REREVIEW`

Current actor: independent Round 023 Phase 0A specification/gate rereviewer.

Round 022 reports
`ROUND022_REPAIR_COMPLETE_AWAITING_INDEPENDENT_REREVIEW`. This is a bounded
specification/gate repair result, not builder release. No application candidate
exists, no host or repository work was performed, and 35 candidate-required
cases remain honestly deferred.

Round 022's permanent registry has 66 classes: all 46 Round 020 classes, all 12
Round 021 invented probes, and all eight Round 021 authority-surface variants.
The controller reports 66 intended rejections, zero false greens, zero
wrong-reason rejections, and byte-identical receipts under hash seeds 1 and 2.
Its expanded closure suite includes package-wide authority coverage, closed
executable classification, exact slug length, fixed export domains, and live
receipt freshness. Round 023 must reproduce and challenge these claims.

Read in order:

1. `00_CONTROL/CURRENT_STATE.json`
2. `00_CONTROL/AUTHORITY.md`
3. `00_CONTROL/PROMPT_TO_EXECUTE.md`
4. `03_EXCHANGE/ROUND_022_CONTROLLING_PHASE0A_REPAIR/RETURN_SUMMARY.md`
5. `03_EXCHANGE/ROUND_022_CONTROLLING_PHASE0A_REPAIR/REPAIR_SUMMARY.md`
6. `03_EXCHANGE/ROUND_022_CONTROLLING_PHASE0A_REPAIR/FINDING_CLOSURE.json`
7. `03_EXCHANGE/ROUND_022_CONTROLLING_PHASE0A_REPAIR/EXECUTION_RECEIPT.json`
8. `03_EXCHANGE/ROUND_022_CONTROLLING_PHASE0A_REPAIR/REQUEST_FOR_INDEPENDENT_REREVIEW.md`

First command on a fresh unpack:

```text
PYTHONDONTWRITEBYTECODE=1 python3 -S 04_TOOLS/verify_input_manifest.py
```

Then reproduce every command in the Round 022 request for independent re-review,
including both hash seeds and the immutable original Round 021 probe harnesses.
An import crash is never an intended semantic rejection.

All Python entry points must use `PYTHONDONTWRITEBYTECODE=1 python3 -S`.

Return one full relay named `Pioneer-Alignment-Single-Relay-v14.zip`.
Do not build the application or expand authority.
