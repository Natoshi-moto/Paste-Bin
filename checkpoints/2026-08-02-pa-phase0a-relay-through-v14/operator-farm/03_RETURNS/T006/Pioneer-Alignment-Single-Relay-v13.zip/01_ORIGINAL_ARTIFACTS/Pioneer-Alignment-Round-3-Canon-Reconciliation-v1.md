# Pioneer Alignment — Round 3 Canon Reconciliation and Supersession Matrix
Version: v1
Date: 2026-08-01
Status: DESIGN RECONCILIATION — NOT A CANON AMENDMENT

## Purpose

Reconcile the founder voice interview with the current Pioneer Alignment charter,
NEX/LEX canon, Nexus social canon, LOOM brief, governance handoff control, the
existing distributed-social proposal, and the Phase 0A builder handoff.

This document does not silently promote voice-session exploration into canon.
It identifies:

- binding boundaries that remain unchanged;
- founder directions that are compatible;
- founder directions that need precise interpretation;
- conflicts and supersessions;
- provisional defaults suitable for simulation;
- changes that require an explicit later decision.

## Authority order

Use this order when materials conflict:

1. latest explicit operator decision;
2. accepted Decision Register entry;
3. NEX/LEX Canon;
4. Pioneer Alignment Charter;
5. current domain canon and status documents;
6. working and exploratory designs;
7. historical source material.

The voice interview was explicitly created with the default:
`EXPLORATORY UNTIL EXPLICITLY CONFIRMED`.

Therefore, the founder's voice answers are high-value design input but are not
automatically binding canon.

---

# 1. Binding canon that remains unchanged

## 1.1 Organisational and authority boundary

- Pioneer Alignment is the umbrella organisation.
- Nexus is its bounded experimental social and collaboration layer.
- The public publication remains separate from interactive systems.
- The operator holds visible bootstrap responsibility.
- Credentials, money, public launch, DNS, production mutation, and irreversible
  constitutional decisions remain operator-controlled.
- AI language ability does not imply operational authority.

## 1.2 Economic membrane

Pioneer Alignment has exactly two purpose-separated internal units:

- NEX: bounded intelligence, AI work, approved compute, and explicitly receipted
  agent-market utility.
- LEX: social exchange, commitments, allocations, participation mechanics, and
  governance weight.

Binding prohibitions:

- no fiat or cryptocurrency;
- no blockchain placement;
- no purchase or sale;
- no deposit, withdrawal, on-ramp, off-ramp, redemption, or cash-out;
- no external price, market, bridge, or acceptance network;
- no NEX/LEX exchange, conversion, shared pool, cross-collateral, or substitute;
- NEX cannot buy governance, moderation, visibility, reputation, LEX, evidence,
  or truth;
- LEX cannot buy reasoning, compute, NEX, or settlement of NEX work;
- reputation, identity, evidence, truth, reactions, moderation state, NEX, and
  LEX remain separate dimensions.

## 1.3 Social and evidentiary boundary

- Community content is untrusted by default.
- Popularity, stake, governance, or AI output cannot vote facts into existence.
- Feeds, threads, forums, and channels should begin as projections over one
  signed, replayable event substrate.
- The first social implementation is local-only, synthetic-user, and excludes
  public registration, private messaging, federation, live NEX/LEX issuance,
  unrestricted uploads, final AI moderation, and post-triggered agent execution.
- LOOM preserves RECORDs, derives CLAIMs, and uses replaceable ROUTEs.
- A CLAIM may cite a RECORD. A CLAIM may never cite a ROUTE.
- Verbatim public/synthetic history does not imply permanent capture of private
  material.

---

# 2. Founder voice directions

The voice interview adds the following founder intent:

1. The destination is unusually productive human-agent collaboration on
   software and research.
2. "Democratic" means decentralised, distributed, and resistant to tyranny,
   not conventional one-person-one-vote politics.
3. The first compelling demonstration is agents economically interacting.
4. The economy should bootstrap through useful work on Pioneer Alignment.
5. The first task family should teach participants about the project while they
   run audits, tests, and receipt verification.
6. A reproducible defect and a valid green confirmation can both be useful work.
7. Participants should operate under common rules while contract values and bids
   may differ.
8. Agents may barter.
9. Work-relevant activity should have very detailed provenance.
10. NEX should use a purpose-built wallet incompatible with Bitcoin, Ethereum,
    and ordinary external wallets.
11. The potential NEX supply may be uncapped while circulating supply remains
    finite and measurable.
12. Researchers may receive bounded internal allocations to experiment.
13. LEX should be expended when voting, rather than passive balance alone
    conferring permanent power.
14. A tested decentralised social substrate should be used rather than
    reinventing every networking primitive.
15. The founder strongly selected Bluesky/AT-Protocol-class self-hosting as a
    required design target during the voice session.
16. Noted should later connect deterministic creatures and battles to verified
    research achievements.
17. Build planning should be global and coherent, followed by a few large
    implementation sweeps and severe adversarial testing.
18. The lead model should actively find and fill ordinary gaps, report its
    judgment, and avoid unnecessary clarification loops.

These remain founder directions until explicitly promoted.

---

# 3. Reconciliation matrix

| Founder statement | Existing rule | Reconciliation | Status |
|---|---|---|---|
| "Bitcoin-like model and wallet" | No cryptocurrency or blockchain placement | Preserve desired properties—key-controlled custody, deterministic rules, independently verifiable history, constrained issuance, no founder privilege—without a blockchain, public cryptocurrency, mining market, or external wallet compatibility | Compatible only under precise interpretation |
| Purpose-built wallet incompatible with Bitcoin/Ethereum | Cryptographic keys may secure internal custody | Build an internal NEX wallet/account client with a distinct address/version namespace and no import/export, bridge, chain transaction, or external signing compatibility | Strong compatible direction |
| Genesis supply | No founder/investor allocation; issuance open | A genesis state is required, but it may begin with zero circulation. A large founder-controlled genesis pool is not required and is disfavoured | Earlier voice idea superseded by later voice direction |
| Unlimited potential supply with finite circulating supply | Issuance schedule remains open; anti-casino controls required | Model NEX as unbounded potential issuance with explicit epoch ceilings, named issuance events, and measurable circulation. "Uncapped potential" must not mean uncapped per-epoch minting | Compatible provisional economic target |
| Seed the economy with agents doing site work | NEX is for receipted agent work; first implementation is synthetic/local | Begin with synthetic agents and valueless research-epoch balances. Later, bounded public tasks require predeclared epoch rules and governance handoff | Compatible, staged |
| Reward onboarding audits | Social engagement cannot mint NEX | Mere signup, browsing, liking, or posting earns no NEX. A formal audit contract may issue NEX only when it requires reproducible tests, receipts, scope, and independent acceptance | Compatible with contract boundary |
| Reward both green verification and bugs | Useful work may be positive or negative evidence | Both can qualify, but duplicate green checks require planned redundancy or sampling. Unlimited repeated confirmation cannot become an issuance faucet | Compatible with anti-farming controls |
| Researchers receive NEX to experiment | NEX may account for approved intelligence/compute | Use named research budgets, contracts, or grants with purpose, ceiling, receipts, unused-fund treatment, and epoch continuity disclosed | Compatible if bounded |
| Everyone earns the same | Contract bidding is allowed | Interpret as equal protocol eligibility and common rules, not equal payment for unequal work. Payment may vary by contract, bid, risk, scarcity, urgency, and evidence burden | Normalised, no contradiction |
| Agents may barter | No external market; no NEX/LEX conversion | Permit receipted reciprocal exchange of internal agent work or compute deliverables. Do not permit barter of NEX for LEX, governance, external goods, cash claims, or hidden external settlement | Compatible only inside domain |
| Track as much as possible | Private-by-default, minimisation, separate dimensions | Maximise work provenance and auditability while minimising unrelated personal data. Preserve evidence history without collapsing it into one permanent score | Compatible after privacy correction |
| LEX must be spent to vote | LEX has governance weight; raw balance alone is insufficient | Treat vote expenditure/retirement as one commitment signal, combined with mature identity, proposal classes, caps, diminishing influence, quorum, deliberation, appeals, and constitutional limits | Strong compatible direction; mechanism open |
| "Host Bluesky" | Local protocol-neutral signed-event kernel comes first; existing Nostr-first proposal has no authority | Do not replace the local kernel with bsky.app. Treat AT Protocol as a required first-class federation adapter and self-hosting target after the local kernel passes. A PDS alone is not the entire Bluesky service stack | Founder priority reconciled with architecture |
| Existing Nostr-first proposal | `status_authority: NONE` | Retain Nostr as a useful parallel adapter candidate and portability path, but it does not override the founder's later AT-Protocol priority | Exploratory proposal partially reprioritised |
| Noted creatures linked to research | No blockchain, external NFT, pay-to-win, or governance purchase | Represent creatures as deterministic, signed/content-addressed game objects linked to verified milestone receipts. No external market, redemption, scientific authority, or governance weight | Compatible deferred integration |
| Build all major systems in bold sweeps | First evidence step remains bounded/local | Use large coherent subsystem sweeps with frozen inputs, tests, receipts, rollback, and independent breakers. Do not combine public launch, credentials, governance finality, and economy activation into one run | Compatible execution doctrine |
| Ultra should fill every gap without asking | Consequential authority remains human-controlled | Grant autonomy for reversible local design and implementation defaults. Require stop/escalation at credentials, spending, production, public balances, real identities, permanent governance, and legal commitments | Compatible bounded autonomy |

---

# 4. Precise meaning of "Bitcoin-like"

For Pioneer Alignment, "Bitcoin-like" should be treated as internal design
shorthand for selected properties, not as a claim that NEX is Bitcoin-like money.

## Retained properties

- deterministic accounting rules;
- verifiable signed history;
- purpose-built keys and custody;
- no founder premine or privileged sale;
- independently reconstructible balances;
- explicit supply state;
- visible rule changes;
- resistance to unilateral rewriting;
- portable local receipts and exports;
- fork/exit possibility at constitutional boundaries.

## Rejected properties

- blockchain placement;
- proof-of-work mining;
- public cryptocurrency;
- external wallets or exchanges;
- external market price;
- permissionless external transfer;
- speculative scarcity narrative;
- wealth-weighted political sovereignty;
- irreversible global consensus claims.

Recommended internal phrase:

> **Bitcoin-inspired integrity and custody properties inside a sealed,
> non-cryptocurrency accounting system.**

Avoid marketing NEX publicly as "Bitcoin-like" without the full boundary beside
the phrase.

---

# 5. NEX supply reconciliation

## 5.1 Proposed model

- Potential supply: uncapped.
- Genesis circulation: zero or a narrowly documented synthetic test allocation.
- Actual issuance: only through named issuance events.
- Circulating supply: all issued NEX minus explicitly retired NEX.
- Founder sale/allocation: zero.
- External purchase/redemption: impossible by protocol scope.
- Every balance belongs to a named accounting epoch.
- Every epoch publishes an issuance ceiling, start state, closure rule, and
  migration/non-migration policy.
- Unused epoch capacity expires rather than silently accumulating.
- Corrections use compensating/adjudication events, never history rewrites.

## 5.2 Why this reconciles the voice direction

An uncapped potential supply can coexist with disciplined scarcity if issuance
is bounded at every operational horizon. The meaningful controls are:

- who can publish a task budget;
- what work qualifies;
- the maximum issuance per epoch;
- verification and dispute requirements;
- anti-duplication and anti-collusion rules;
- closure and continuity.

"Unlimited" therefore describes the absence of a permanent mathematical cap,
not an unlimited power held by an operator or contract.

## 5.3 Status

This is a **provisional simulation model**, not a canon amendment.

---

# 6. First economic loop

## 6.1 Contract

A Pioneer audit/onboarding contract contains:

- contract ID and epoch;
- exact repository/artifact identity;
- allowed task type;
- required environment;
- prescribed tests;
- acceptable evidence;
- reward budget;
- redundancy policy;
- submission deadline;
- evaluator selection rule;
- dispute path;
- whether a green confirmation, defect, or both are eligible;
- continuity notice for earned balances.

## 6.2 Worker execution

A worker may be:

- an agent;
- a human using an agent;
- a bounded team of agents and humans.

The receipt records the operator, agent identity, model/provider, tool versions,
commands, artifacts, environment, outputs, hashes, and claimed result.

## 6.3 Acceptance

A submission receives NEX only after:

- schema validation;
- artifact identity check;
- replay or reproduction;
- duplicate detection;
- conflict-of-interest check;
- evaluator receipt;
- adjudication where needed.

## 6.4 Anti-farming rule

A result is not payable merely because it is technically valid.

Green confirmations are payable only when they satisfy a planned need, such as:

- independent replication count;
- platform/environment diversity;
- randomly sampled audit coverage;
- unresolved confidence requirement;
- a time-bounded regression check.

This prevents infinite NEX issuance through endless duplicate confirmations.

---

# 7. LEX voting reconciliation

The founder's direction is that voting has a real cost.

## Provisional mechanism family

- LEX is earned through social/governance service under separate rules.
- Casting a vote expends or retires committed LEX.
- Proposal-specific caps prevent one balance from consuming the entire decision.
- Diminishing influence prevents linear plutocracy.
- Mature identity and Sybil resistance remain separate prerequisites.
- Quorum and deliberation are not replaced by expenditure.
- Constitutional amendments use stronger multi-stage requirements.
- Moderation guilt, punishment, and evidence truth are never decided solely by
  a LEX auction.
- Emergency action remains narrow, expiring, receipted, and retrospectively
  reviewed.

## Unresolved

- whether every vote burns LEX or only high-consequence votes;
- replenishment and decay;
- delegation;
- abstention and minority-defense mechanics;
- whether losing-side expenditure is identical to winning-side expenditure;
- proposal spam deposits;
- appeal protection against resource exhaustion.

The voice direction resolves "holding alone is not voting." It does not yet
resolve the complete constitution.

---

# 8. Social protocol reconciliation

## 8.1 Local source of truth first

The local Nexus kernel remains the first implementation source of truth:

- canonical signed events;
- deterministic validation;
- replayable projections;
- evidence references;
- moderation quarantine, appeal, and resolution;
- export/import;
- tamper rejection.

No external protocol controls Pioneer truth, governance, LEX, NEX, or LOOM.

## 8.2 AT Protocol priority

The founder's voice decision means the architecture must not treat AT Protocol
as an optional afterthought.

After the local kernel passes:

1. define a strict social-protocol adapter interface;
2. map Pioneer social objects to an AT Protocol Lexicon;
3. test an independent/self-hosted PDS;
4. explicitly decide whether Pioneer needs only a PDS, its own AppView, a
   Labeler, a Relay/firehose consumer, or a bounded subset;
5. avoid hard dependency on Bluesky-operated application services;
6. preserve complete local Pioneer event and LOOM receipts;
7. test account portability, moderation divergence, deletion semantics,
   replay/import, and network outages.

## 8.3 Nostr

Nostr remains useful for:

- simple signed event transport;
- user-selected relays;
- optional multi-homing;
- Noted/game event broadcasting;
- degraded/offline-oriented experimentation.

It is not automatic canon and it must not introduce external cryptocurrency
features into Pioneer Alignment.

## 8.4 Correct terminology

- **Bluesky**: a social application and service ecosystem.
- **AT Protocol**: the decentralised protocol stack beneath it.
- **Self-hosting a PDS**: hosting participant data and account service; not by
  itself reproducing the complete Bluesky service stack.
- **Nostr**: a signed-event protocol and relay interface; not one hosted social
  platform.

---

# 9. Noted reconciliation

The project corpus contains multiple Noted build variants and hashes, including
canonical and Nexus-integrated HTML artifacts. This establishes internal project
lineage, not current functional verification.

## Deferred integration contract

A later Noted adapter may consume only verified milestone receipts and emit:

- deterministic creature genesis or mutation events;
- lineage events;
- battle challenge/results;
- optional social announcements;
- local verification receipts.

Hard boundaries:

- no blockchain or external NFT;
- no external buying or selling;
- no pay-to-win;
- no NEX/LEX conversion;
- no governance power;
- no scientific truth by game outcome;
- no automatic reward merely for engagement;
- no dependence on the Pioneer website being continuously online.

Before integration, inspect and identify the actual canonical Noted source.

---

# 10. Phase 0A reconciliation

The Phase 0A builder handoff is safe but does not implement the canonical Nexus
Social Kernel. It builds:

- local research-note authoring;
- SQLite/migrations;
- a LOOM-style hash-linked provenance log;
- deterministic exports;
- a fake provider-neutral Relay adapter.

## Correct status

Classify it as:

> **Application Foundation 0A — local provenance, persistence, export, and
> provider-boundary scaffold.**

It must not be mistaken for:

- the Nexus Social Kernel;
- the NEX economy;
- the LEX governance system;
- the social protocol integration;
- production Relay.

## Reusable outputs

- repository and test discipline;
- local-only binding;
- canonical serialisation and hashes;
- migrations;
- deterministic export machinery;
- provenance event primitives;
- fake provider adapter;
- security checks.

## Required design accommodation

Phase 0A should avoid locking the project into a mutable-note database as the
future social source of truth. It should expose or document boundaries so later
signed events and deterministic projections can be added without rewriting the
foundation.

---

# 11. Supersession matrix

| Earlier item | Current treatment |
|---|---|
| December 2025 NEXT/Solana/DEX/DeFi/bridge/public wallet path | Permanently retired |
| Single unit combining intelligence, social value, and governance | Permanently retired |
| FLEX name | Retired |
| Public-by-default AI conversation | Superseded by private-by-default and scoped consent |
| Linear/quadratic token governance | Superseded; LEX governance must resist balance capture and Sybil attacks |
| Founder-controlled large genesis supply suggested early in voice | Superseded within the voice discussion by uncapped-potential/work-issued direction |
| Fixed 21 million NEX and prior tail-emission experiments | Historical research; not current canon unless reselected after simulation |
| Existing Nostr-first/AT-second proposal | Still useful but non-authoritative; AT Protocol becomes a required first-class post-kernel target |
| "Just host Bluesky" | Replaced by explicit service-stack analysis and bounded self-hosting plan |
| Noted treated as an unknown external project | Corrected: internal corpus shows substantial Noted artifact lineage; current canonical source still needs inspection |
| Phase 0A as the whole platform plan | Reclassified as local application foundation only |
| "Complete project without clarification" | Reconciled as autonomous local completion within hard operator stop gates |

---

# 12. Material open questions after reconciliation

These remain load-bearing:

1. Exact NEX issuance and retirement events.
2. NEX epoch ceilings and how task budgets are authorised.
3. Bid selection across price, evidence quality, reputation, time, and risk.
4. Evaluator selection, payment, conflict handling, and recursive verification.
5. Barter settlement and prevention of hidden NEX/LEX or external conversion.
6. Custody, recovery, compromised keys, inheritance, and agent/operator keys.
7. Exact LEX earning, expenditure, caps, replenishment, and delegation.
8. Mature identity and Sybil resistance.
9. Proposal classes and constitutional amendment thresholds.
10. Privacy classes, retention, deletion requests, verified purge, and public
    historical continuity.
11. AT Protocol component scope: PDS only versus independent AppView, Labeler,
    Relay/firehose consumer, or fuller stack.
12. Nostr's role after AT integration.
13. Canonical Noted source and exact deterministic rules.
14. The authority relationship between task publishers, evaluators,
    adjudicators, and governance.
15. How public test balances transition between research epochs.

These questions do not block local synthetic architecture and simulation.

---

# 13. Round 3 disposition

## No canon changed

The sealed economic membrane, NEX/LEX separation, social trust boundaries, LOOM
invariant, and operator authority remain intact.

## New provisional design targets

- uncapped potential NEX with finite, epoch-bounded circulation;
- zero or minimal synthetic genesis circulation;
- work-triggered NEX issuance;
- audit-onboarding contracts;
- detailed work provenance with personal-data minimisation;
- receipted internal agent-work barter;
- LEX expenditure as a governance commitment mechanism;
- AT Protocol as a required first-class federation target;
- Nostr retained as a parallel adapter candidate;
- deterministic Noted integration after verified milestones;
- large coherent local sweeps with strong acceptance and breaker gates.

## Next round

Round 4 should define the complete component dependency and authority graph for:

- identity;
- agents/operators;
- signed social events;
- LOOM;
- tasks/contracts;
- evaluators/adjudication;
- reputation;
- NEX;
- LEX;
- governance;
- Relay/native social AI;
- AT Protocol/Nostr adapters;
- Noted.

Every edge must state:

- who may write;
- who verifies;
- what is authoritative;
- what is derived;
- what can be corrected;
- what can be rolled back;
- what cannot confer authority;
- failure behaviour.
