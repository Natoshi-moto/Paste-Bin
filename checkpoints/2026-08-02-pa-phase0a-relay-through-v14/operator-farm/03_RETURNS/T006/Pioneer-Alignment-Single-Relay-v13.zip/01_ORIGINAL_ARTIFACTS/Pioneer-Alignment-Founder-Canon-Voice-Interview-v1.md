# Pioneer Alignment — Founder Canon Voice Interview
Version: v1
Status: LIVE INTERVIEW SCAFFOLD
Default classification: EXPLORATORY UNTIL EXPLICITLY CONFIRMED

## Purpose

Capture the founder's intent in their own words while preserving the difference between:

- durable canon;
- exploratory ideas;
- emotional or intuitive signals;
- unresolved decisions;
- contradictions;
- implementation consequences;
- material that should be excluded from the final project pack.

## Voice-call protocol

The interviewer asks one question at a time.

The founder may answer in any style: concise, rambling, emotional, technical, nonlinear, contradictory, or unfinished.

Useful spoken controls:

- **"Make that canon."**  
  Mark the preceding point as an explicit binding decision.

- **"Exploratory."**  
  Preserve the idea without treating it as a decision.

- **"Hold that."**  
  Pause the current thread and return to it later.

- **"Challenge me."**  
  Ask for the strongest objection, tradeoff, or failure mode.

- **"Translate that."**  
  Restate the idea in clearer technical or institutional language.

- **"Exclude from the project pack."**  
  Omit the preceding material from the final packaged document.

- **"Next."**  
  Move to the next question.

- **"Stop interview."**  
  End the question sequence and begin packaging.

Nothing becomes project canon merely because it was said during the call.

## Capture format for each answer

### Question

### Raw answer
Preserve the founder's wording as closely as the available transcript permits.

### Extracted durable intent

### Exploratory ideas

### Explicit canon declarations

### Anti-goals / prohibited outcomes

### Unresolved choices

### Contradictions or tensions

### Implementation implications

### Governance / authority implications

### Security / privacy implications

### Terminology notes

### Follow-up question, if necessary

---

# Interview sequence

## 1. The real destination

Imagine Pioneer Alignment works spectacularly well three years from now.

- What actually exists?
- What are people doing there every day?
- What can they do that they cannot do elsewhere?
- What would make you personally think: "Yes, this is the thing I meant"?

## 2. The anti-destination

What could Pioneer Alignment become that would make you shut it down, even if it were popular or profitable?

## 3. The founder's intended role

What role do you want during bootstrap and after maturity?

What powers should you never retain permanently?

## 4. What distributed intelligence means

What exactly should be distributed:

- ownership;
- access;
- compute;
- decision-making;
- agenda-setting;
- publication authority;
- funding;
- reputation;
- challenge power;
- the ability to operate independent reasoning systems?

## 5. The first hundred serious users

Who are they?

Why would they come?

What would make them stay?

## 6. The intended social culture

Describe the social layer emotionally and behaviourally.

- fast or slow;
- formal or informal;
- combative or collegial;
- anonymous, pseudonymous, or identity-linked;
- visible popularity metrics or not;
- editable or permanent posts;
- tolerance for profanity, aggression, satire, and memes.

## 7. Moderation and appeals

Who may restrict whom?

What evidence is required?

What must be public?

What can be appealed?

Who may overturn staff?

## 8. Identity and Sybil resistance

How important is one-human-one-identity?

How should pseudonyms, linked identities, agents, organisations, and voting duplication be handled?

## 9. NEX in plain English

What should NEX let someone do?

What must NEX never buy?

## 10. LEX in plain English

What behaviour should produce LEX?

Should it be transferable, delegable, spendable, losable, capped, or expiring?

## 11. Agent status

What is an AI agent inside Pioneer Alignment?

May it speak, earn, own, vote, govern, moderate, publish, contract, or operate independently?

Who is responsible for its actions?

## 12. LOOM's truth standard

Should LOOM preserve:

- what was said;
- what was believed;
- what was later proven;
- all competing accounts;
- decisions;
- private working history;
- public history only?

Should contradictions be resolved or preserved as unresolved structures?

## 13. Public versus private history

Which of these may become permanent and public:

- deleted posts;
- edits;
- moderation actions;
- appeals;
- prompts;
- model outputs;
- governance deliberations;
- private messages used as evidence;
- security incidents;
- failed experiments;
- founder reversals?

## 14. How agents should treat the founder

When should an agent:

- follow immediately;
- push back;
- slow down;
- demand evidence;
- refuse implementation but preserve the proposal;
- recognise brainstorming rather than instruction?

What behaviour is useful during high-energy or flow states?

## 15. Risk hierarchy

Rank or discuss tensions among:

- shipping speed;
- security;
- reversibility;
- transparency;
- privacy;
- decentralisation;
- usability;
- legal defensibility;
- scientific credibility;
- low cost;
- resistance to capture;
- participant freedom.

## 16. Money and sustainability

How should Pioneer Alignment survive financially?

What funding sources or business models are unacceptable regardless of amount?

## 17. Failure, holds, and shutdown

What conditions should trigger:

- a temporary hold;
- incident disclosure;
- disabling NEX or LEX;
- freezing accounts;
- reverting to a checkpoint;
- removing an agent;
- dissolving a governing body;
- shutting down the system?

## 18. Language and presentation

Which terms should be used, avoided, or defined carefully?

Examples:

- token;
- currency;
- credits;
- governance;
- democracy;
- alignment;
- marketplace;
- autonomous;
- decentralised;
- intelligence;
- insurance;
- reputation.

## 19. Intellectual influences and rejected comparisons

Which projects, thinkers, protocols, communities, games, institutions, or historical examples feel closest?

Which comparisons are misleading or offensive to the actual intent?

## 20. The sentence underneath everything

Complete this without polishing it:

> Pioneer Alignment has to exist because...

---

# Packaging plan after the call

Produce a sealed handoff containing:

1. raw interview transcript;
2. cleaned transcript;
3. founder-canon document;
4. exploratory-ideas appendix;
5. unresolved-decisions register;
6. contradictions and tensions register;
7. anti-goals and prohibited outcomes;
8. terminology dictionary;
9. implementation implications for LOOM, Relay, NEX, LEX, social, marketplace, and governance;
10. exact follow-up prompts for builder and reviewer agents;
11. SHA-256 hashes for every packaged artifact.

The final package must not silently convert exploratory speech into binding canon.
