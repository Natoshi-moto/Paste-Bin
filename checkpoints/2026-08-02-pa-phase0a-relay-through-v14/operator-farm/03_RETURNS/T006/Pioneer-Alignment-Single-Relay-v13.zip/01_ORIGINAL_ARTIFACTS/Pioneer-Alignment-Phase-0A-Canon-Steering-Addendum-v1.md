# Pioneer Alignment — Phase 0A Canon Steering Addendum
Version: v1
Date: 2026-08-01
Status: BOUNDED STEERING NOTE
Applies to: `Pioneer-Alignment-Phase-0A-Builder-Handoff-v1.md`

## Purpose

Preserve the value of the active Phase 0A build while preventing it from
accidentally becoming the architecture for the later Nexus social, NEX, LEX, or
federation systems.

## Classification

Treat the current build as:

> **Application Foundation 0A — local provenance, persistence, deterministic
> export, and provider-boundary scaffold.**

It is not yet:

- the Nexus Social Kernel;
- the NEX ledger or wallet;
- the LEX governance system;
- the agent marketplace;
- AT Protocol or Nostr integration;
- Noted integration;
- production Pioneer Relay.

## Continue current scope

Continue implementing the existing handoff exactly within its local-only
authority:

- research-note workflow;
- local persistence and migrations;
- LOOM-style provenance;
- deterministic export and receipts;
- fake/offline provider adapter;
- security and test gates.

Do not expand into live social, economy, federation, credentials, remote
providers, or production.

## Architectural accommodation

Without redesigning or restarting the build:

1. Keep canonical hashing and serialisation independent of UI and database row
   order.
2. Document the boundary between mutable note state and append-only provenance
   events.
3. Avoid claiming that the note table will be the future social source of truth.
4. Make deterministic export code reusable for future event-log and receipt
   bundles.
5. Keep identity fields extensible enough to distinguish a local operator,
   human participant, agent, and agent operator later, but implement only the
   local operator now.
6. Keep provider interfaces independent of DeepSeek and independent of the
   future native Nexus social AI authority domain.
7. Do not introduce NEX, LEX, wallets, bidding, social accounts, federation, or
   Noted code in Phase 0A.
8. Record this addendum in project documentation and the final handoff.
9. Do not rewrite already preserved failure evidence.
10. Do not pause ordinary local work unless an actual conflict is found.

## Final report addition

Add one section titled:

`Future Nexus Compatibility`

State:

- which primitives are reusable by a later signed-event social kernel;
- which Phase 0A components are deliberately temporary;
- where event-sourced social state would connect;
- what must not be inferred from this build.

This addendum grants no new external or production authority.
