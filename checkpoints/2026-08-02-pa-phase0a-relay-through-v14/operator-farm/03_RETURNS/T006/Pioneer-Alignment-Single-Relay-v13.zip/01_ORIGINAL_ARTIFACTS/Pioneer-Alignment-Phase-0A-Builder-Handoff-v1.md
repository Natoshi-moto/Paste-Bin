# Pioneer Alignment — Phase 0A Builder Handoff v1

## Mission

Build the first **local-only, sealed application vertical slice** for Pioneer Alignment while the production static publication remains frozen and DNSSEC completes separately.

This phase is not a redesign of the public site. It creates a new application workspace that proves a safe end-to-end flow:

1. create a local research note;
2. store it in a local database;
3. append a provenance event to a LOOM-style log;
4. preview the rendered note;
5. export a deterministic publication bundle with SHA-256 receipts;
6. exercise a provider-neutral Pioneer Relay interface through a fake/offline adapter.

## Authority and boundaries

The current public repository is:

- `Natoshi-moto/pioneer-alignment-public`
- accepted production checkpoint: `7c77c63c1f5648d0ee5001e22be7afab7dbd7d9a`
- live production: `https://pioneeralignment.com`

Treat that repository and production deployment as **read-only reference material**.

Do not:

- modify, commit to, push to, or deploy `pioneer-alignment-public`;
- change Cloudflare, DNS, DNSSEC, routes, nameservers, redirects, or Workers settings;
- create or request credentials;
- call DeepSeek or any external model;
- create public registration, participant accounts, wallets, NEX/LEX issuance, transfers, governance, payments, or marketplaces;
- connect GitHub deployment automation;
- create a public GitHub repository;
- silently redesign the accepted public visual system;
- copy licences or provenance claims without preserving their boundaries.

The human operator retains authority over credentials, spending, public publication, domain changes, and irreversible actions.

## New workspace

Create a **separate local Git repository** at:

```text
/home/anon/Projects/Pioneer-Alignment-App
```

Suggested local identifier:

```text
PA-APP-P0A
```

Bind the development server only to:

```text
127.0.0.1
```

No public tunnel, remote preview, hosted deployment, or LAN binding.

## Phase 0A functional scope

Implement the smallest coherent vertical slice with these capabilities:

### 1. Operator dashboard

A local-only page showing:

- application state;
- number of draft notes;
- latest provenance events;
- export status;
- prominent `LOCAL-ONLY / NO LIVE AUTHORITY` banner.

### 2. Research-note workflow

Allow the operator to:

- create a note with title, slug, summary, body, status, and timestamps;
- edit an existing draft;
- preview the rendered note;
- reject duplicate or unsafe slugs;
- keep all note data local.

Use a restricted Markdown subset or an equally bounded renderer. Raw HTML must not execute.

### 3. Local persistence

Use a local SQLite database or an equivalently simple embedded store.

Requirements:

- schema migrations are explicit and testable;
- database files are excluded from Git;
- no external database service;
- deterministic fixtures for tests;
- no personal data beyond content deliberately entered by the operator.

### 4. LOOM-style provenance log

Create an append-only local event ledger for meaningful actions, including:

- note created;
- note edited;
- preview generated;
- export generated;
- export verification passed or failed.

Each event should include:

- event ID;
- timestamp;
- actor (`local-operator` for Phase 0A);
- action;
- subject identifier;
- previous-event hash;
- canonical event hash;
- schema version.

Do not claim blockchain, consensus, immutability, or cryptographic non-repudiation. This is a local hash-linked provenance experiment.

### 5. Deterministic export

Export one selected note into a clean directory containing:

- rendered HTML;
- source Markdown or canonical source JSON;
- metadata JSON;
- provenance excerpt;
- `SHA256SUMS.txt`;
- export receipt JSON.

Two exports from identical canonical input must produce identical content hashes. Handle timestamps so they do not destroy deterministic identity.

The export must not write into `pioneer-alignment-public`.

### 6. Pioneer Relay boundary

Define a provider-neutral interface such as:

```text
RelayProvider.complete(request) -> response
```

Implement only:

- a deterministic fake/offline provider;
- typed request/response schemas;
- timeout/error categories;
- provenance fields showing provider, model identifier, request hash, response hash, and whether output was synthetic.

Do not add API keys, network calls, provider SDKs, or DeepSeek integration in Phase 0A.

### 7. Tests and security checks

Minimum gates:

- unit tests for slug validation and canonical hashing;
- database migration test;
- append-only log chain verification;
- deterministic export test;
- Markdown/raw-HTML safety test;
- fake Relay adapter test;
- server binds to `127.0.0.1`;
- secrets scan over tracked files;
- dependency audit with findings recorded rather than silently ignored;
- path traversal tests for preview/export;
- no writes outside the new workspace and temporary test directories.

## Architecture posture

Prefer a boring, inspectable TypeScript stack with minimal dependencies.

Before choosing packages:

1. inspect the installed Node.js/npm versions;
2. verify package choices against official documentation;
3. state why each dependency is necessary;
4. pin exact versions in the lockfile;
5. reject unnecessary frameworks or services.

Do not inherit the public static repository's zero-JavaScript restriction into this separate local application. Do preserve its visual identity carefully and locally where practical.

## Required repository files

At minimum create:

```text
README.md
AUTHORITY.md
THREAT_MODEL.md
ARCHITECTURE.md
DECISIONS.md
STATUS.json
package.json
package-lock.json
.gitignore
src/
tests/
scripts/
docs/
receipts/
```

`AUTHORITY.md` must explicitly state what Phase 0A cannot do.

`STATUS.json` must be machine-readable and include:

- phase;
- posture;
- current commit;
- tests;
- known limitations;
- live authority;
- next gate.

## Git discipline

- Initialize a new local repository.
- Use branch `phase-0a/local-vertical-slice`.
- Make small commits with descriptive messages.
- Do not configure a remote.
- Do not push.
- Do not amend or rewrite evidence after reporting it.
- Preserve failing outputs in `receipts/` before repair.
- End with a clean working tree or explain every remaining path.

## Execution order

1. Read the public repository's `README.md`, `AGENT_HANDOFF.md`, `LICENSING.md`, `TRADEMARKS.md`, and visual sources as read-only references.
2. Inventory the local environment.
3. Write `AUTHORITY.md`, `THREAT_MODEL.md`, `ARCHITECTURE.md`, and an implementation plan before application code.
4. Scaffold the new repository.
5. Implement the thin end-to-end slice.
6. Run all tests and security checks.
7. Produce receipts and hashes.
8. Stop before any remote, credential, provider, deployment, or production action.

## Required final report

Return:

1. exact local path;
2. branch and commit SHA;
3. complete file inventory;
4. architecture summary in layman's terms;
5. every command run;
6. tests passed/failed with exact counts;
7. dependency inventory and reason for each package;
8. security findings;
9. known limitations;
10. `git status --short`;
11. SHA-256 hashes of the principal receipts;
12. exact next recommended bounded task;
13. a ZIP handoff excluding secrets, database contents, `node_modules`, build caches, and temporary files.

## Initial response format

Before modifying anything, report:

1. repository/artifact inventory received;
2. authority you believe you have;
3. explicit prohibitions;
4. local environment facts;
5. proposed architecture and dependency budget;
6. exact bounded execution plan;
7. anything genuinely blocking safe local work.

Then proceed without pausing for routine read-only inspection or ordinary local file creation inside `/home/anon/Projects/Pioneer-Alignment-App`.

Stop and ask before any action involving credentials, money, public GitHub state, Cloudflare, DNS, remote deployment, or production.
