#!/usr/bin/env python3
from __future__ import annotations

from fnmatch import fnmatchcase
from pathlib import Path, PurePosixPath
import hashlib
import json
import sys

sys.dont_write_bytecode = True

root = Path(__file__).resolve().parents[1]
manifest = root / "05_MANIFESTS/INPUT_SHA256SUMS.txt"
state = json.loads((root / "00_CONTROL/CURRENT_STATE.json").read_text(encoding="utf-8"))
mutable_patterns = state.get("allowed_mutations", [])
bad: list[str] = []
listed: dict[str, str] = {}


def ignored_bytecode(path: Path) -> bool:
    return "__pycache__" in path.parts or path.suffix == ".pyc"


for path in sorted(root.rglob("*")):
    if path.is_symlink():
        bad.append("SYMLINK " + path.relative_to(root).as_posix())

for line_number, line in enumerate(manifest.read_text(encoding="utf-8").splitlines(), 1):
    if not line.strip():
        continue
    try:
        digest, relative = line.split("  ", 1)
    except ValueError:
        bad.append(f"MALFORMED line {line_number}")
        continue
    pure = PurePosixPath(relative)
    if pure.is_absolute() or ".." in pure.parts:
        bad.append("UNSAFE " + relative)
        continue
    if relative in listed:
        bad.append("DUPLICATE " + relative)
        continue
    listed[relative] = digest
    path = root / relative
    if ignored_bytecode(path):
        bad.append("FORBIDDEN_BYTECODE_MANIFEST_ENTRY " + relative)
        continue
    if not path.is_file():
        bad.append("MISSING " + relative)
    elif hashlib.sha256(path.read_bytes()).hexdigest() != digest:
        bad.append("MISMATCH " + relative)
    if any(fnmatchcase(relative, pattern) for pattern in mutable_patterns):
        bad.append("MUTABLE_PATH_LISTED " + relative)

expected = {
    path.relative_to(root).as_posix()
    for path in root.rglob("*")
    if path.is_file()
    and not ignored_bytecode(path)
    and not any(
        fnmatchcase(path.relative_to(root).as_posix(), pattern)
        for pattern in mutable_patterns
    )
}
for relative in sorted(expected - set(listed)):
    bad.append("IMMUTABLE_PATH_UNLISTED " + relative)
for relative in sorted(set(listed) - expected):
    bad.append("UNEXPECTED_INPUT_PATH " + relative)

if bad:
    print("\n".join(bad))
    sys.exit(1)
print(f"PASS: verified complete immutable input set ({len(listed)} files)")
