# Pioneer Alignment — Round 7 LEX and Constitutional Governance Closure

**Version:** v1  
**Date:** 2026-08-01  
**Status:** Provisional governance architecture and simulation contract — not a canon amendment  
**Scope:** LEX, governance, emergency authority, founder transition, exit, and fork  
**Explicitly excluded:** public launch, real governance authority, production credentials, legal incorporation, public issuance, and irreversible constitutional adoption

---

# 0. Result

This round closes the LEX and governance mechanism sufficiently to implement and attack it with synthetic identities.

The proposed system is:

> **A mature-human governance system in which every binding ballot requires LEX expenditure, but neither raw wealth nor transferred LEX can buy unlimited political power. Equal civic allocations, capped conviction, identity quorum, source-aware LEX eligibility, append-only decisions, protected constitutional boundaries, narrow emergency powers, appeal rights, and fork/exit prevent the unit from becoming either plutocracy or governance theatre.**

The design deliberately separates:

- possession of LEX;
- eligibility to use LEX for binding governance;
- human identity maturity;
- reputation;
- proposal rights;
- voting;
- enactment;
- emergency containment;
- adjudication;
- constitutional authority.

No one of these silently implies the others.

---

# 1. Binding perimeter preserved

The following rules remain binding:

- LEX is the internal social and governance unit.
- LEX cannot account for reasoning, compute, NEX jobs, external money, evidential strength, or truth.
- LEX and NEX are non-convertible.
- NEX has no governance weight.
- LEX balance alone is not legitimate authority.
- LEX cannot be bought, sold, redeemed, externally priced, bridged, or placed on a blockchain.
- Social engagement alone cannot become an issuance machine.
- Reputation, identity maturity, contribution history, evidence, attestations, moderation state, NEX, and LEX remain separate dimensions.
- Governance cannot vote facts into existence.
- Governance cannot confiscate, mint, inflate, or redirect NEX for political advantage.
- Crossing the external membrane or NEX–LEX membrane requires a different fork outside this canon; it is not an ordinary amendment.
- Canonical balances may exist inside named epochs, but continuity into later epochs must be predeclared and receipted.
- Founder and operator interventions must be explicit, narrow, expiring, and preserved.

---

# 2. LEX is one unit with visible provenance states

The design does not create hidden third currencies.

One LEX always remains one LEX in accounting.

However, its current **state and provenance** determine which actions it may support, just as restricted or locked balances remain the same underlying unit.

## 2.1 Balance states

- `SOCIAL_AVAILABLE`
- `CIVIC_AVAILABLE`
- `GOVERNANCE_MATURE`
- `DELEGATED_LOCK`
- `PROPOSAL_BOND_LOCK`
- `APPEAL_BOND_LOCK`
- `DISPUTED`
- `RESTRICTED`
- `SPENT_RETIRED`
- `EXPIRED_RETIRED`

## 2.2 Provenance classes

### `CIVIC_ALLOCATION`

Equal cycle allocation to each mature human-controlled identity.

Properties:

- non-transferable;
- usable for binding ballots and ordinary proposal sponsorship;
- expires at the end of its governance cycle;
- cannot be sold, pooled, inherited, or converted;
- creates no automatic right in a later epoch.

### `GOVERNANCE_SERVICE`

Award for independently verified social or governance service.

Examples:

- completing a moderation or appeal duty;
- serving on a selected adjudication panel;
- producing an accepted procedural review;
- identifying a confirmed governance defect;
- completing declared community stewardship;
- maintaining accessibility, translation, onboarding, or public-process infrastructure under an authorised programme.

Properties:

- matures before binding use;
- governance-eligible only up to a per-cycle cap;
- may also be used for social allocations;
- awards do not depend on supporting the winning side.

### `SOCIAL_SERVICE`

Award for verified social-public-goods work that does not itself justify governance influence.

Properties:

- transferable under LEX rules;
- usable for social allocations, bonds, and declared community commitments;
- not binding-vote eligible merely because it was earned.

### `TRANSFERRED`

LEX received from another holder.

Properties:

- social-use eligible;
- not binding-vote eligible;
- may fund proposal bonds;
- cannot become governance-eligible merely through waiting, pooling, or cycling through accounts.

### `REMEDIATION`

Compensating LEX ordered by an adjudication or protocol-remediation process.

Its governance eligibility inherits the exact provenance it replaces; remediation cannot create new political power.

## 2.3 Why transferred LEX does not buy votes

Transfer remains meaningful inside the social economy.

But binding governance eligibility follows civic allocation or directly verified governance service—not merely possession.

This prevents:

```text
LEX transfer → purchased voting power
```

without pretending that transfers are impossible.

The interface must always show:

- total LEX;
- social-available LEX;
- governance-eligible LEX;
- locked/delegated LEX;
- expiry;
- exact provenance.

No pooled “LEX power” number may conceal these distinctions.

---

# 3. Supply and epoch model

## 3.1 General model

LEX has:

- uncapped potential supply across future epochs;
- finite issuance ceilings in each named epoch;
- finite civic and service budgets in each cycle;
- zero founder or investor allocation;
- append-only issuance, transfer, lock, expenditure, retirement, and correction;
- no automatic balance continuity between epochs.

## 3.2 Recommended synthetic baseline

```text
Epoch:                    LEX-R001-SIM
Initial issued supply:    0 LEX
Founder allocation:       0 LEX
Cycle count:              4
Cycle length:             simulation-defined
Denomination:             1 LEX = 1,000 milliLEX
```

Use integer `milliLEX` internally.

The visibly different precision from NEX helps prevent implied convertibility.

## 3.3 Per-cycle synthetic ceilings

Assuming 100 mature synthetic humans:

| Category | Ceiling per cycle |
|---|---:|
| Equal civic allocation | 2,000 LEX |
| Governance-service awards | 10,000 LEX |
| Social-service awards | 12,000 LEX |
| Moderation and appeal service | 4,000 LEX |
| Protocol remediation | 2,000 LEX |
| **Maximum gross issuance** | **30,000 LEX** |

Provisional civic allocation:

```text
20 LEX per mature human per cycle
```

These are simulation parameters, not founder promises or public policy.

## 3.4 Retirement

LEX is retired by:

- final ballot expenditure;
- invalid proposal-bond penalty under predeclared rules;
- adjudicated penalty from a declared locked amount;
- voluntary retirement;
- expired civic allocation;
- expired restricted programme allocation;
- predeclared epoch-transition treatment.

Ordinary transfer is not retirement.

Service-earned social LEX does not decay in the first synthetic model.

Civic LEX expires at cycle close because it is a current-cycle participation capacity, not an accumulating political fortune.

---

# 4. Eligible LEX earning events

## 4.1 Allowed earning families

- equal civic allocation to a mature human identity;
- independently completed moderation duty;
- independently completed appeal duty;
- selected adjudication or jury service;
- accepted governance-process audit;
- confirmed challenge to a defective tally, rule application, or authority claim;
- declared community stewardship programme;
- participant onboarding or mentorship under a published programme;
- accessibility or translation service under a published programme;
- public-process documentation and provenance service;
- narrow protocol remediation.

## 4.2 Explicitly non-earning activity

The following do not automatically issue LEX:

- posting;
- replying;
- liking;
- following;
- receiving reactions;
- follower count;
- time spent online;
- popularity;
- winning a Noted battle;
- owning NEX;
- completing NEX work;
- model output;
- voting for the winning side;
- moderator severity;
- finding reasons to punish people.

## 4.3 Award rules

Every service award requires:

- authorised programme and cycle budget;
- declared scope;
- deliverable or duty;
- evidence;
- independent verification or outcome-independent service receipt;
- conflict disclosure;
- exact provenance class;
- award cap;
- appeal path.

No actor may approve its own LEX award.

Moderators, adjudicators, and reviewers receive the same declared service reward whether they uphold, reverse, approve, or reject—provided they perform the method correctly.

---

# 5. LEX event taxonomy

## 5.1 Epoch and cycle

- `LEX_EPOCH_OPEN`
- `LEX_CYCLE_OPEN`
- `LEX_BUDGET_AUTHORISE`
- `LEX_BUDGET_REALLOCATE`
- `LEX_EPOCH_HOLD`
- `LEX_EPOCH_RESUME`
- `LEX_CYCLE_CLOSE`
- `LEX_EPOCH_CLOSE`
- `LEX_EPOCH_TRANSITION_DECLARE`

## 5.2 Issuance and balances

- `LEX_ISSUE_CIVIC`
- `LEX_ISSUE_GOVERNANCE_SERVICE`
- `LEX_ISSUE_SOCIAL_SERVICE`
- `LEX_ISSUE_MODERATION_SERVICE`
- `LEX_TRANSFER`
- `LEX_ALLOCATE`
- `LEX_LOCK`
- `LEX_UNLOCK`
- `LEX_FREEZE`
- `LEX_UNFREEZE`
- `LEX_EXPIRE`
- `LEX_RETIRE`
- `LEX_COMPENSATE`
- `LEX_PROTOCOL_REMEDIATION`

## 5.3 Proposals and sponsorship

- `LEX_DISCUSSION_OPEN`
- `LEX_PROPOSAL_DRAFT`
- `LEX_PROPOSAL_SPONSOR`
- `LEX_PROPOSAL_BOND_LOCK`
- `LEX_PROPOSAL_SUBMIT`
- `LEX_PROPOSAL_AMEND`
- `LEX_PROPOSAL_WITHDRAW`
- `LEX_PROPOSAL_ACCEPT_FOR_REVIEW`
- `LEX_PROPOSAL_REJECT_PROCEDURAL`
- `LEX_PROPOSAL_BOND_RELEASE`
- `LEX_PROPOSAL_BOND_RETIRE`

## 5.4 Deliberation and voting

- `LEX_CONFLICT_DISCLOSE`
- `LEX_DELIBERATION_RECORD`
- `LEX_BALLOT_LOCK`
- `LEX_BALLOT_AMEND`
- `LEX_BALLOT_REVOKE`
- `LEX_BALLOT_FINALISE`
- `LEX_BALLOT_RETIRE`
- `LEX_TALLY_COMPUTE`
- `LEX_TALLY_CHALLENGE`
- `LEX_TALLY_VERIFY`

## 5.5 Delegation

- `LEX_DELEGATION_DECLARE`
- `LEX_DELEGATION_OVERRIDE`
- `LEX_DELEGATION_REVOKE`
- `LEX_DELEGATION_EXPIRE`

## 5.6 Enactment and review

- `GOV_ENACTMENT_PROPOSE`
- `GOV_CONSTITUTIONAL_CHECK`
- `GOV_ENACTMENT_ACTIVATE`
- `GOV_ENACTMENT_SUSPEND`
- `GOV_ENACTMENT_SUPERSEDE`
- `GOV_IMPLEMENTATION_RECEIPT`
- `GOV_POST_IMPLEMENTATION_REVIEW`

## 5.7 Emergency

- `GOV_EMERGENCY_DECLARE`
- `GOV_EMERGENCY_CONTAIN`
- `GOV_EMERGENCY_NARROW`
- `GOV_EMERGENCY_EXTEND`
- `GOV_EMERGENCY_END`
- `GOV_EMERGENCY_RESTART`
- `GOV_EMERGENCY_REVIEW`
- `GOV_EMERGENCY_REMEDY`

## 5.8 Founder transition, exit, and fork

- `GOV_FOUNDER_POWER_DECLARE`
- `GOV_FOUNDER_POWER_EXPIRE`
- `GOV_FOUNDER_VETO_SUSPEND`
- `GOV_HANDOFF_GATE_PASS`
- `GOV_HANDOFF_PHASE_ADVANCE`
- `GOV_EXIT_DECLARE`
- `GOV_EXPORT_RECEIPT`
- `GOV_FORK_DECLARE`
- `GOV_FORK_BUNDLE_RECEIPT`
- `GOV_DISSENT_RECORD`

---

# 6. Mature human-controlled identity interface

The exact identity mechanism is deferred to Round 8.

Governance depends on a strict interface rather than selecting an accidental implementation now.

## 6.1 Required governance credential

A binding voter must present a valid:

```text
MATURE_HUMAN_GOVERNANCE_CREDENTIAL
```

It must establish, under the eventual privacy-preserving identity system:

- one governance credential per human per epoch;
- current liveness;
- completed probation/maturation;
- no active disqualifying adjudication;
- scope and expiry;
- challenge and appeal path;
- pseudonym compatibility where safe;
- no requirement that public voters expose legal names.

## 6.2 Identity types

| Identity type | Propose | Deliberate | Hold social LEX | Receive civic LEX | Cast binding ballot |
|---|---:|---:|---:|---:|---:|
| Mature human-controlled identity | Yes | Yes | Yes | Yes | Yes |
| Probationary human identity | Limited | Yes | Yes | No | No |
| Agent identity | Yes, through declared proposal rules | Yes | Restricted | No | No |
| Organisation | Yes | Yes | Yes | No | No direct human ballot |
| Anonymous external observer | No | Read/public comment only where allowed | No | No | No |
| Constitutional service role | Within role | Yes | As underlying human | As underlying human | No extra ballot |

Role status never creates an additional vote.

An individual operating multiple pseudonyms may use them socially, but only one governance credential may cast a binding ballot in an epoch.

## 6.3 Reputation boundary

Reputation may inform:

- probation;
- panel eligibility;
- conflict/risk review;
- service-programme qualification.

It cannot:

- multiply ballot weight;
- replace the human credential;
- create permanent office;
- bypass a conflict;
- prove truth.

---

# 7. Ballot expenditure and capped conviction

The founder direction is implemented literally:

> **A binding vote consumes LEX. Merely holding it does not vote.**

## 7.1 Ballot model

Each mature human may cast one ballot per proposal.

The voter chooses:

- `SUPPORT`
- `OPPOSE`
- `ABSTAIN_RECORDED`

For support or opposition, the voter selects a capped conviction level:

| Conviction weight | LEX locked and finally retired |
|---:|---:|
| 1 | 1 LEX |
| 2 | 4 LEX |
| 3 | 9 LEX |

Formula:

```text
cost = weight²
maximum weight per human per proposal = 3
```

This is a provisional synthetic mechanism.

It gives LEX expenditure real consequence while making ten times more LEX incapable of creating ten times more voting power.

## 7.2 Ballot lifecycle

1. Voter locks eligible LEX.
2. Voter may change direction or conviction during the open period.
3. Increasing conviction requires more eligible LEX.
4. Decreasing conviction releases the difference while the ballot is open.
5. Revoking the ballot releases the lock before close.
6. At ballot close, the final locked amount is retired.
7. A tally receipt references the final ballot events.

No one loses LEX merely for changing their mind before the deadline.

## 7.3 Eligible source

Binding ballots may use only:

- current-cycle `CIVIC_ALLOCATION`;
- matured `GOVERNANCE_SERVICE` LEX within the per-cycle cap;
- the delegator’s own eligible LEX where a valid delegation exists.

Transferred and social-service LEX cannot increase binding ballot weight.

## 7.4 Dual-majority rule

A binding proposal must satisfy both:

1. **Identity majority** — one person, one direction, ignoring conviction level.
2. **Capped conviction majority** — using weights 1–3.

This prevents a small highly resourced minority from passing a proposal purely by expenditure.

Quorum is measured by mature eligible identities, not by LEX supply.

---

# 8. Delegation

Delegation transfers ballot execution authority, not identity, LEX ownership, or a second vote.

## 8.1 Rules

- scoped to a proposal, proposal class, or named topic;
- expires at cycle end or earlier;
- revocable at any time before ballot close;
- no re-delegation;
- delegator may override with a direct ballot;
- ballot cost is charged to the delegator’s eligible LEX;
- each underlying identity remains separately visible in the tally;
- delegate conflicts must be disclosed;
- no delegate may control more than the lower of:
  - 20 mature identities; or
  - 5% of the eligible electorate.

These are provisional simulation caps.

## 8.2 Why this does not create super-voters

A delegate submits multiple independently attributable ballots.

The delegate does not aggregate delegated LEX into its own account and receives no extra personal weight.

---

# 9. Proposal access and anti-spam

## 9.1 Discussion is cheap

Any admitted participant may open a non-binding discussion without burning LEX, subject to ordinary anti-spam limits.

## 9.2 Binding proposal gateway

A mature human may submit a binding proposal through either path:

### Sponsor path

- obtain five mature human sponsors;
- each sponsor locks 1 civic LEX until procedural acceptance;
- lock is released after acceptance.

### Bond path

- lock 10 social-available or governance-eligible LEX;
- bond is released if the proposal:
  - satisfies procedural rules; and
  - reaches 5% preliminary support or receives a formal committee review.

A procedurally abusive or deceptive proposal may retire up to 50% of the bond after an appealable decision.

## 9.3 No wealth veto

Participants without 10 LEX retain the sponsor path.

Constitutional challenges, moderation appeals, and emergency reports never require a proposal bond.

---

# 10. Proposal classes

All numbers below are provisional simulation parameters.

## `P0 — Signal and deliberation`

Purpose:

- opinion polling;
- agenda discovery;
- non-binding advice.

Rules:

- no enactment;
- no LEX required for ordinary participation;
- may use optional non-binding LEX commitment displays;
- cannot alter balances, roles, or policy.

## `P1 — Ordinary operational policy`

Examples:

- channel policy;
- non-constitutional process detail;
- ordinary programme configuration.

Minimums:

- review period: 7 days;
- quorum: 20% of mature electorate;
- identity threshold: >50% support among support/opposition ballots;
- conviction threshold: 55% support;
- activation delay: 48 hours;
- one implementation receipt.

## `P2 — Programme and bounded resource allocation`

Examples:

- future LEX service programme budget;
- selection of a research or moderation programme;
- recommendation for future NEX programme authority inside already adopted NEX rules.

Minimums:

- review period: 14 days;
- quorum: 25%;
- identity threshold: 55%;
- conviction threshold: 55%;
- conflict disclosure;
- budget source and ceiling;
- no retroactive balance redistribution;
- post-programme audit.

P2 may authorise future general programme rules where constitutionally permitted.

It may not confiscate existing NEX, mint NEX outside its epoch rules, or convert NEX and LEX.

## `P3 — Protocol and institutional rule`

Examples:

- LEX earning formula;
- delegation cap;
- moderation procedure;
- identity admission rule;
- non-protected protocol parameters.

Minimums:

- review period: 21 days;
- quorum: 33%;
- identity threshold: 60%;
- conviction threshold: 60%;
- independent impact review;
- deterministic implementation test;
- activation delay: 7 days;
- rollback condition;
- post-implementation review.

## `P4 — Constitutional amendment`

Examples:

- founder-power transition;
- creation or removal of an institutional role;
- amendment to non-protected constitutional clauses;
- change to amendment procedure.

Minimums:

- first review period: 30 days;
- quorum: 50%;
- identity threshold: two-thirds;
- conviction threshold: two-thirds;
- at least two independent constitutional reviews;
- frozen proposal text for final 7 days;
- second ratification after a 14-day cooling period;
- same thresholds at both stages;
- activation delay: 14 days;
- complete migration and rollback statement.

## `P5 — Protected boundary`

Includes:

- external NEX/LEX membrane;
- NEX–LEX non-convertibility;
- NEX’s lack of governance power;
- evidence/truth non-purchasability;
- append-only correction requirement;
- right to exit and export;
- prohibition on secret permanent authority.

P5 boundaries cannot be amended by ordinary Pioneer governance.

A system intentionally removing them is a declared fork outside this canon and may not claim seamless constitutional continuity.

## `P6 — Emergency containment and restart`

Emergency power contains damage. It does not legislate permanent rules.

Emergency events follow Section 14.

---

# 11. Tally and enactment

## 11.1 Tally inputs

A tally uses:

- frozen proposal version;
- eligible electorate snapshot;
- credential status at the declared cutoff;
- final ballots;
- delegations and overrides;
- locked/retired LEX;
- conflict exclusions where predeclared;
- quorum and thresholds;
- exact tally implementation version.

## 11.2 Independent verification

P2–P4 tallies require an independent replay.

P4 requires two independent tally implementations or one implementation plus a formal proof/checking method defined before the vote.

Any divergence means:

```text
NO ENACTMENT — TALLY HOLD
```

## 11.3 Enactment is separate

A passing tally does not mutate the system directly.

It authorises an enactment proposal that must pass:

- proposal-class check;
- protected-boundary check;
- implementation identity check;
- effective-date check;
- migration/rollback check;
- final signature/capability check.

The enactment event cites the tally and exact rule artifact.

---

# 12. Moderation appeals are not token auctions

Individual punishment, guilt, and evidence disputes are outside ordinary LEX voting.

## 12.1 First appeal

Every affected participant receives one no-cost substantive appeal for a moderation restriction.

No LEX balance is required.

## 12.2 Appeal panel

A panel is selected from mature eligible humans under:

- conflict exclusion;
- random or deterministic sortition;
- competence requirement where necessary;
- limited prior involvement;
- signed reasoning and evidence references;
- outcome-independent service reward.

## 12.3 Repeat appeals

After a completed substantive appeal:

- materially new evidence permits another no-cost reopening;
- repetitive appeals without new evidence may require a small refundable bond;
- inability to afford a bond must have a public-defender or sponsored route;
- bond loss requires an appealable abuse finding.

## 12.4 Community oversight

LEX governance may amend moderation policy, appoint oversight institutions, or fund appeal infrastructure.

It may not conduct a popularity vote on an individual’s guilt.

---

# 13. Constitutional service bodies

No body receives sovereign authority merely from its name.

The synthetic model includes these role classes:

## 13.1 Constitutional Review Panel

Purpose:

- check P4 proposals;
- check protected-boundary conflicts;
- review founder vetoes;
- review long emergencies.

Constraints:

- cannot initiate balance changes;
- cannot substitute its preference for a valid vote;
- must publish cited reasoning;
- recusals and minority reports preserved;
- membership term-limited.

## 13.2 Tally Verifiers

Purpose:

- independently replay binding tallies.

Constraints:

- no proposal advocacy role during the same decision;
- outcome-independent reward;
- no enactment power.

## 13.3 Emergency Review Panel

Purpose:

- review continuation, scope, and restart.

Constraints:

- independent of the emergency declarer;
- may narrow or end containment;
- cannot make permanent constitutional law.

## 13.4 Public Process Auditor

Purpose:

- reconstruct decisions, role use, LEX flows, conflicts, and exceptions.

Constraints:

- reports evidence;
- has no veto or moderation power;
- may trigger a formal challenge process.

The independent adversarial reporter remains a separate evidence-bound publication role with no vote, veto, moderation, or deployment authority.

---

# 14. Emergency powers

## 14.1 Valid grounds

Emergency containment may address:

- ledger invariant failure;
- signing-key compromise;
- active exploit;
- private-data or secret exposure;
- event-validation divergence;
- tally divergence;
- corrupted LOOM RECORD integrity;
- inability to identify authoritative head;
- acute safety or legal containment;
- protocol behaviour causing ongoing material internal harm.

Political disagreement, criticism, embarrassment, or likely electoral loss are not emergency grounds.

## 14.2 Narrowest-scope rule

Emergency action must identify:

- affected component;
- prohibited writes;
- permitted read/export functions;
- affected identities or events;
- reason and evidence;
- start;
- automatic expiry;
- reviewer;
- restart conditions.

A NEX failure does not automatically freeze social discussion.

A moderation incident does not automatically freeze balances.

## 14.3 Bootstrap timing

Provisional simulation rule:

- founder or named bootstrap operator may impose a unilateral hold for at most 24 hours;
- continuation to 72 hours requires two independent authorised co-signers;
- continuation beyond 72 hours requires the Emergency Review Panel;
- each extension may last at most 7 days;
- any emergency exceeding 7 days requires public participant ratification where the participant system remains functional;
- every extension narrows or re-justifies scope.

## 14.4 Prohibited emergency actions

Emergency authority may not:

- rewrite accepted history;
- erase criticism;
- transfer or confiscate unrelated balances;
- mint NEX or LEX;
- alter protected boundaries;
- cancel elections merely because an outcome is disliked;
- extend itself without new receipts;
- hide the existence of the emergency, except narrow redaction of active exploit or private details;
- silently become permanent ordinary authority.

## 14.5 Restart

Restart requires:

- containment evidence;
- invariant checks;
- independent verification;
- exact restored head/state hash;
- unresolved-risk register;
- scoped restart event;
- mandatory postmortem.

---

# 15. Founder transition

The existing north star is preserved:

> **Founder-sovereign → constitutional nuisance.**

This means the founder becomes a highly informed participant who can propose, argue, criticise, and preserve historical context, but cannot automatically command implementation.

## 15.1 Phase A — Founder-bound bootstrap

Permitted while:

- synthetic/local work dominates;
- no third-party durable canonical public balances exist;
- all founder powers are enumerated;
- every exceptional intervention is receipted.

Founder may:

- set local architecture direction;
- appoint temporary roles;
- declare narrow emergency holds;
- reject production activation;
- protect credentials and external systems.

Founder may not:

- rewrite event or balance history;
- self-award NEX or LEX;
- remove the economic membranes;
- secretly create permanent authority;
- claim AI recommendations as binding decisions.

## 15.2 Phase B — Shared constitutional control

Mandatory before third parties receive canonical balances in a public epoch.

Required conditions:

- published constitution candidate;
- named independent constitutional reviewers;
- independent tally verification;
- working disputes and appeal process;
- published founder/operator powers;
- emergency expiry and review;
- epoch continuity rule;
- exit and fork bundle;
- successful synthetic breaker suite.

Founder changes:

- unilateral ordinary enactment ends;
- unilateral emergency action is limited to the first 24 hours;
- founder veto becomes a temporary suspensive veto only;
- founder receives no extra ballot weight;
- participant representation enters constitutional roles.

## 15.3 Suspensive founder veto

During Phase B only, the founder may suspend a proposed enactment for at most 14 days where it plausibly:

- crosses a protected boundary;
- exceeds declared authority;
- creates an irreversible unsafe external action;
- lacks required evidence or migration rules.

The veto must cite exact clauses and evidence.

It cannot permanently defeat a valid proposal.

The Constitutional Review Panel may:

- uphold the suspension;
- narrow it;
- reject it;
- require corrected enactment.

A rejected founder veto is preserved publicly.

## 15.4 Phase C — Founder as ordinary high-context participant

Entry gate, provisionally:

- at least two consecutive governance epochs close with reconstructible state;
- independent audits pass;
- emergency review and appeals have been exercised successfully;
- at least three independent non-founder constitutional role-holders are functioning;
- no unresolved material authority ambiguity remains;
- a P4 transition proposal passes.

Founder retains:

- one ordinary human ballot;
- proposal and deliberation rights;
- public argument;
- historical context;
- software contribution rights;
- ordinary eligibility for roles under the same rules.

Founder loses:

- automatic implementation authority;
- suspensive veto;
- automatic governance weight;
- unilateral canon promotion;
- unilateral balance control;
- unilateral continuation of emergencies;
- permanent appointment power.

External credentials, legal obligations, domain control, and infrastructure custody may still require separate operational transition plans. Governance rhetoric does not transfer credentials by magic.

---

# 16. Exit, dissent, and fork

## 16.1 Exit right

A participant may exit without:

- confiscation of unrelated balances;
- retaliation;
- negative reputation merely for dissent;
- suppression of lawful criticism;
- loss of access to their permitted export.

Exit does not erase public archival actions.

Private-data deletion and purge follow the retention policy.

## 16.2 Export bundle

A participant may export, subject to other people’s privacy rights:

- identity and key-rotation records;
- their public posts and claims;
- their private records;
- NEX/LEX event history affecting them;
- balance and epoch receipts;
- contracts and work receipts;
- moderation and appeal records;
- delegations;
- proposal and ballot receipts;
- social graph;
- protocol mappings;
- machine-readable schemas.

## 16.3 Fork bundle

A declared fork receives the public/releasable materials needed to reproduce the system:

- source and licences;
- constitution and rule history;
- event schemas;
- public event log;
- epoch closures and balance snapshots;
- deterministic state and tally implementations;
- unresolved-dispute register;
- migration and divergence declaration;
- public LOOM RECORDs and CLAIMs;
- federation mapping specifications.

Private or restricted data does not become public merely because a fork exists.

## 16.4 Fork identity

A fork must declare:

- the exact source head;
- inherited and rejected rules;
- balance treatment;
- continuity claims;
- governance identity;
- protected-boundary divergence;
- new name or clear differentiation where required.

A fork removing the external membrane or NEX–LEX membrane is outside Pioneer canon and cannot claim ordinary constitutional continuity.

## 16.5 Abandoned balances

Abandoned balances remain canonical history in their epoch.

They are not silently seized.

Future custody, inheritance, dormancy, recovery, or retirement rules must be predeclared in the identity/security and epoch contracts.

---

# 17. Governance communications contract

Before any real participant enters a balance-bearing epoch, the interface and public rules must define:

- `test`;
- `simulation`;
- `canonical within epoch`;
- `future entitlement`;
- `earned`;
- `allocated`;
- `transferred`;
- `governance-eligible`;
- `social-only LEX`;
- `retired`;
- `expired`;
- `delegated`;
- `binding vote`;
- `signal`;
- `enacted`;
- `emergency hold`;
- `fork`.

Required warnings:

- LEX has no external price or redemption.
- LEX does not establish truth.
- Not all LEX is eligible for binding governance.
- A canonical epoch balance may have no continuity into another epoch.
- A passed tally is not active until a valid enactment event.
- External protocol popularity does not create Pioneer authority.

---

# 18. Governance attack programme

Required scenarios:

1. founder attempts permanent unilateral control;
2. founder vetoes a proposal without protected-boundary grounds;
3. founder emergency hold never expires;
4. operator hides an intervention;
5. NEX whale attempts to buy LEX influence;
6. transferred LEX is laundered through accounts for voting;
7. related identities claim multiple civic allocations;
8. agent identities attempt human ballots;
9. organisation attempts multiple ballots through office roles;
10. service-award cartel issues itself governance LEX;
11. moderators earn more by punishing more people;
12. adjudicators earn more for a preferred outcome;
13. delegate controls excessive electorate share;
14. delegation chain hides ultimate authority;
15. delegate votes against delegator after override;
16. proposal spam drains civic LEX;
17. wealthy participant suppresses poorer proposal access;
18. conviction spending passes despite identity rejection;
19. low-turnout minority changes protocol;
20. tally implementation diverges;
21. enacted artifact differs from voted proposal;
22. last-minute constitutional text changes;
23. governance redirects existing NEX balances;
24. governance creates a NEX–LEX swap;
25. governance votes a factual claim true;
26. majority conducts popularity trial of an individual;
27. appeal requires unaffordable LEX;
28. emergency hides criticism;
29. emergency freeze spreads beyond affected component;
30. emergency restart uses an unverified state head;
31. external AT/Nostr popularity influences tally;
32. Noted creature prestige creates political weight;
33. expired civic LEX remains spendable;
34. epoch continuity invented after results;
35. closed epoch history rewritten;
36. fork export omits dissent or unresolved disputes;
37. participant punished for exit;
38. constitutional reviewers conceal conflicts;
39. remediation creates extra governance power;
40. independent implementation yields a different final state.

---

# 19. Hard acceptance properties

The synthetic implementation passes only if:

```text
NEX-derived governance weight:                        0
Transferred-LEX binding ballot weight:                0
Agent binding ballots:                                0
Multiple civic allocations per human per cycle:       0
Ballot weight above 3 per human per proposal:          0
Proposal passing without identity threshold:          0
Proposal passing without conviction threshold:        0
Proposal passing below quorum:                        0
P4 enactment without two-stage ratification:           0
Protected-boundary ordinary amendments:               0
Passed tally directly mutating system without enactment:0
Tally divergence producing enactment:                 0
Final punishment decided by public LEX vote:           0
First substantive appeal blocked for lack of LEX:      0
Expired emergency remaining active:                   0
Emergency rewriting accepted history:                 0
Unreceipted founder/operator interventions:            0
Silent epoch continuity changes:                      0
Exit retaliation events accepted as valid policy:      0
Fork bundle omitting required public state:            0
Valid-log state divergence across implementations:     0
```

Required demonstrations:

- civic LEX expires exactly at cycle closure;
- service awards are outcome-independent;
- transferred LEX remains socially usable;
- delegation preserves separate underlying identities;
- direct override defeats delegated ballot before close;
- dual-majority calculation is deterministic;
- founder suspensive veto expires or receives review;
- emergency scope can be narrowed without halting unrelated systems;
- exit export respects other participants’ privacy;
- fork history includes dissent, interventions, and unresolved disputes;
- no UI presents total LEX as automatic political power.

---

# 20. Required implementation artifacts

The eventual LEX/governance sweep must return:

- `LEX_EPOCH_SPEC.md`
- `LEX_EVENT_SCHEMA.json`
- `LEX_PROVENANCE_AND_STATE.md`
- `LEX_R001_SIM_PARAMETERS.json`
- `GOVERNANCE_PROPOSAL_CLASSES.md`
- `GOVERNANCE_BALLOT_STATE_MACHINE.md`
- `GOVERNANCE_TALLY_SPEC.md`
- `GOVERNANCE_ENACTMENT_SPEC.md`
- `DELEGATION_SPEC.md`
- `MODERATION_APPEAL_GOVERNANCE_BOUNDARY.md`
- `EMERGENCY_AUTHORITY_STATE_MACHINE.md`
- `FOUNDER_TRANSITION_SPEC.md`
- `EXIT_AND_FORK_SPEC.md`
- deterministic ledger;
- independent tally and replay implementation;
- attack fixtures;
- synthetic identity fixtures;
- exact test report;
- epoch closure receipt;
- known-limitations register;
- sealed ZIP and SHA-256 manifest.

No public remote, credential, provider, Cloudflare, DNS, or production action.

---

# 21. Provisional choices versus protected rules

## Protected and already binding

- LEX social/governance domain;
- NEX/LEX non-convertibility;
- no NEX governance power;
- no external value rail;
- mature human identity matters;
- balance alone is insufficient;
- governance must resist capture;
- appeals, dissent, exit, fork, emergency review;
- append-only accounting and explicit epoch continuity.

## Provisional choices introduced here

- provenance-state model;
- civic allocation;
- 20 LEX per cycle;
- service-award categories;
- integer milliLEX denomination;
- conviction levels and squared costs;
- dual-majority rule;
- proposal thresholds and timing;
- delegation caps;
- proposal sponsor/bond paths;
- emergency durations;
- founder handoff gates;
- synthetic epoch ceilings.

These must be tested and independently criticised before adoption.

---

# 22. Round 7 disposition

```text
LEX mechanical domain closed for simulation:      YES
LEX earning and provenance rules specified:       YES
Vote expenditure implemented literally:           YES
Raw balance plutocracy prevented:                 YES
Transferred LEX vote buying prevented:             YES
Delegation bounded:                               YES
Proposal classes and thresholds defined:          YES
Moderation appeals protected from token auction:  YES
Constitutional amendment path defined:             YES
Protected boundaries identified:                  YES
Emergency powers bounded and expiring:            YES
Founder transition defined:                       YES
Exit and fork defined:                            YES
Governance attack suite defined:                  YES
Exact identity mechanism finalised:               NO — Round 8
Public LEX/governance authorised:                  NO
Canon amended:                                    NO
Ready for identity/security/responsibility round: YES
```

## Next round

**Round 8 — Identity, Custody, Sybil Resistance and Agent Responsibility**

Resolve:

- human, pseudonym, organisation, agent, and operator identities;
- mature-human credential interface;
- privacy-preserving uniqueness;
- admission and probation;
- key custody and rotation;
- recovery, compromise, inheritance, and loss;
- agent capability grants;
- responsibility and liability inside the platform;
- panel selection eligibility;
- cross-protocol identity binding;
- post-quantum migration;
- identity and custody attack simulations.
