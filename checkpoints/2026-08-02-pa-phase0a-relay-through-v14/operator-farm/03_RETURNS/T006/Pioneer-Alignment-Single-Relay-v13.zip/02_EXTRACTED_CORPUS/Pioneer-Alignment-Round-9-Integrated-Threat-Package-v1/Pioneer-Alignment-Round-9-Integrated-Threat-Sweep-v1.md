# Pioneer Alignment — Round 9 Integrated Cross-Domain Threat Sweep

**Version:** v1  
**Date:** 2026-08-01  
**Status:** Adversarial architecture review — not a canon amendment  
**Inputs:** Rounds 3–8, current Pioneer Alignment canon, Phase 0A boundary, NEX/LEX membrane, LOOM invariant, social/federation design, identity/custody design  
**Scope:** threats created by interactions among subsystems rather than defects isolated inside one component

---

# 0. Executive disposition

The combined architecture is coherent enough to proceed to implementation planning.

It is **not** safe to treat the individual subsystem designs as independently sufficient. Cross-domain composition creates several material attack paths that do not appear when NEX, LEX, LOOM, identity, federation, AI, moderation, and Noted are reviewed separately.

## Overall result

```text
Fatal contradiction in the stated vision:             NO
Material architecture contradictions found:           7
Material cross-domain risks requiring controls:       24
Public-epoch blockers identified:                     15
Synthetic/local build blocked:                        NO
Closed synthetic testnet blocked:                     NO, after required amendments
Public balances or governance authorised:             NO
Public federation authorised:                         NO
Real private participant data authorised:             NO
Canon changed:                                        NO
```

The most important finding is:

> **The system’s primary capture risk is not a direct NEX–LEX conversion. It is indirect conversion through reputation, identity maturity, service roles, visibility, federation reach, contract access, and institutional credibility.**

The architecture already prohibits direct conversion. Round 9 adds explicit controls against these indirect routes.

---

# 1. Cross-domain trust graph

```mermaid
flowchart LR
    ID["Identity / maturity"]
    REP["Reputation projections"]
    SOCIAL["Social visibility"]
    LOOM["LOOM records and claims"]
    AI["AI retrieval and drafting"]
    TASK["Task access"]
    VERIFY["Verification and panels"]
    NEX["NEX"]
    LEX["LEX"]
    GOV["Governance"]
    MOD["Moderation"]
    FED["AT / Nostr"]
    NOTED["Noted"]
    OP["Operator / founder"]
    UI["Clients / projections"]

    ID --> TASK
    ID --> GOV
    ID --> VERIFY
    REP --> TASK
    REP --> VERIFY
    SOCIAL --> REP
    SOCIAL --> AI
    LOOM --> AI
    AI --> SOCIAL
    TASK --> NEX
    NEX --> REP
    VERIFY --> REP
    VERIFY --> NEX
    LEX --> GOV
    GOV --> ID
    GOV --> VERIFY
    GOV --> MOD
    MOD --> SOCIAL
    FED --> SOCIAL
    SOCIAL --> FED
    NOTED --> SOCIAL
    SOCIAL --> NOTED
    OP --> GOV
    OP --> UI
    UI --> SOCIAL
    UI --> GOV
```

Each arrow is a possible authority leak.

The design must test not only whether the direct edge is permitted, but whether several permitted edges compose into a prohibited outcome.

---

# 2. Seven material architecture contradictions

## C1 — Equal civic standing versus service-earned governance influence

Round 7 allows equal civic LEX plus matured governance-service LEX.

This can create a hidden aristocracy:

```text
role access
→ governance service
→ governance-eligible LEX
→ more influence over role rules
→ more role access
```

### Required amendment

- Current-cycle civic allocation remains the dominant source of binding conviction.
- Governance-service LEX may fund at most **25% of the maximum proposal conviction cost available to one human in a cycle**.
- Service LEX earned from a body may not be used on proposals that directly set that body’s compensation, appointment, powers, or retrospective conduct until the next cycle.
- Service-role selection must preserve entry paths for non-incumbents.
- Raw service count cannot multiply ballot weight beyond the per-human cap.

**Status:** material, repairable.

---

## C2 — Work rewards versus reputation monopoly

NEX contracts create work history. Work history influences reputation. Reputation may influence task or panel eligibility.

This can become:

```text
early NEX work
→ stronger reputation
→ more contracts and verification roles
→ more NEX and institutional credibility
→ permanent incumbency
```

### Required amendment

- Reputation weight in contract selection remains capped.
- Every programme above a defined size reserves:
  - random-qualified entry slots;
  - new-entrant slots;
  - independent challenge slots.
- Participant-funded self-dealing cannot increase independent-work reputation.
- Reputation distinguishes:
  - task complexity;
  - independence;
  - evidence quality;
  - relation to publisher/operator;
  - accepted versus merely completed volume.
- Panel eligibility must not depend on wealth or raw NEX earnings.

**Status:** material, repairable.

---

## C3 — Pseudonym privacy versus cross-protocol portability

AT DIDs, Nostr keys, GitHub accounts, domains, wallet identities, and public pseudonyms can be correlated.

A “portable identity” can silently become a global tracking key.

### Required amendment

- Cross-protocol bindings are purpose-specific and optional.
- No universal public identity graph.
- Use separate adapter identities where possible.
- Private human-root mappings never enter public federation receipts.
- UI must distinguish:
  - “same person publicly declared”;
  - “same account cryptographically controlled”;
  - “privately bound for governance”;
  - “unverified possible relation.”
- Export bundles must not disclose private pseudonym links.

**Status:** material, repairable.

---

## C4 — Public archival integrity versus privacy and deletion

LOOM needs institutional memory. Public social systems and federation make deletion incomplete. Privacy policy requires genuine purge for some data.

A single “permanent history” slogan is incompatible with real private data.

### Required amendment

- Preserve permanence only for declared `PUBLIC_ARCHIVAL` material.
- `PUBLIC_SOCIAL` receives a strong external-copy warning.
- `PRIVATE_DURABLE`, `PRIVATE_TRANSIENT`, and `RESTRICTED_EVIDENCE` remain outside public LOOM.
- Public tombstones must not retain reversible sensitive hashes.
- Fork exports use privacy-filtered records, not raw database dumps.
- Every public-history claim states the relevant retention class.

**Status:** already partly addressed; must become implementation gate.

---

## C5 — Local source of truth versus operator-controlled clients and projections

Even with an honest event log, the operator can manipulate:

- feed ranking;
- search;
- default filters;
- correction prominence;
- warnings;
- proposal presentation;
- tally UI;
- federation visibility.

This creates de facto control without rewriting canonical state.

### Required amendment

- Critical projections are deterministic and independently reproducible.
- Clients expose:
  - chronological mode;
  - projection version;
  - filter state;
  - source event IDs;
  - tally inputs.
- Governance ballots require a frozen canonical proposal artifact independent of UI rendering.
- Public publication and correction views include artifact hashes.
- Multiple clients or an independent reference client must reconstruct critical views.

**Status:** high severity, repairable.

---

## C6 — Founder transition versus control of infrastructure credentials

Governance may remove founder authority in software while the founder still controls:

- domains;
- cloud accounts;
- signing infrastructure;
- repositories;
- deployment secrets;
- legal entities.

A constitutional handoff without operational custody is theatre.

### Required amendment

Every handoff phase requires a separate **Operational Custody Transition Plan** covering:

- domains and DNS;
- hosting;
- repository administration;
- package/release signing;
- production secrets;
- legal contracts;
- incident contacts;
- payment obligations;
- account recovery;
- emergency access.

Governance cannot claim control it cannot technically exercise.

**Status:** material blocker before public governance.

---

## C7 — Unlimited potential NEX versus repeated epoch inflation

Per-epoch ceilings prevent single-epoch over-issuance.

They do not prevent:

```text
short epochs
→ repeated ceiling resets
→ rapid multi-epoch inflation
```

### Required amendment

Every epoch opening must disclose a **multi-epoch issuance trajectory**, including:

- prior issued supply;
- proposed new ceiling;
- epoch duration;
- category changes;
- cumulative issuance;
- issuance per accepted work unit;
- concentration;
- transition treatment;
- variance from prior plan.

Opening epochs more frequently cannot bypass the declared trajectory without a higher-class governance review.

**Status:** material, repairable.

---

# 3. Critical cross-domain findings

## F01 — Indirect NEX-to-governance conversion

Direct NEX–LEX exchange is prohibited, but indirect conversion can occur:

```text
NEX wealth
→ fund many tasks
→ gain visibility and reputation
→ control evaluator or service-role access
→ earn governance-service LEX
→ influence governance
```

### Control

- Participant-funded tasks cannot create governance-service LEX.
- Self-funded and related-party work is marked non-independent.
- Governance-service eligibility ignores NEX holdings and spending.
- Role panels disclose economic relationships.
- Reputational effects from participant-funded work are capped and labelled.

**Severity:** critical.

---

## F02 — LEX bribery through external or social side deals

Transferred LEX may not vote, but a person can still promise:

- NEX;
- future work;
- external money;
- social promotion;
- Noted status;
- employment;
- moderation leniency

in exchange for another person’s ballot.

No protocol can fully prevent private bribery.

### Control

- Pioneer does not recognise or enforce vote-trading agreements.
- Delegation and ballot receipts remain attributable to the underlying credential without exposing public identity.
- Conflicts and material inducements must be disclosed for role-holders.
- Coercion/bribery reports receive protected evidence handling.
- Concentrated correlated voting triggers review, not automatic conviction.
- Governance materials must openly state that anti-bribery is partial, not solved.

**Severity:** critical residual risk.

---

## F03 — Budget authority manufactures work

An authorised programme can invent low-value work that satisfies its own formal receipts and issues NEX.

### Control

- Every issuance-backed task requires a documented public-purpose or protocol-purpose need.
- Independent budget audit samples completed tasks for necessity, not just procedural validity.
- Repeated low-value task families trigger automatic budget review.
- Budget authorities cannot use issued NEX or work volume as proof that the programme was useful.
- Programme renewal requires outcome evidence.

**Severity:** high.

---

## F04 — Verifier economy becomes a cartel

Outcome-independent fees remove rubber-stamping incentives but not cartel formation or low-effort formal compliance.

### Control

- Random assignment;
- hidden reproducibility checks where safe;
- contradictory verifier sampling;
- verifier rotation;
- independence graph;
- method-quality scoring;
- periodic no-notice replay;
- no same-operator worker/verifier pair;
- no sole verifier for high-risk work.

**Severity:** high.

---

## F05 — Reputation laundering through related agents

One operator can create many agents that “independently” validate one another.

### Control

- Operator binding is mandatory for economic and institutional agents.
- Independence is evaluated at operator, organisation, funding, and infrastructure level.
- Related agents may collaborate, but their receipts do not count as independent replication.
- Concealed relatedness is an adjudicable integrity violation.

**Severity:** critical.

---

## F06 — Identity issuer and recovery guardian collusion

The same network of people could:

- issue a mature credential;
- recover it;
- alter pseudonym bindings;
- enter panels;
- influence appeals.

### Control

- Issuer, guardian, appeal, and high-authority role sets have relatedness limits.
- No recovery guardian may be the sole issuer or sole appeal reviewer.
- Thresholds apply across independent administrative domains.
- Recovery cannot change the human-root uniqueness commitment.
- A recovered credential preserves the same epoch nullifier state.

**Severity:** critical.

---

## F07 — AI-mediated institutional capture

Even without formal authority, the native AI can become the practical gatekeeper by:

- choosing what users see;
- summarising proposals;
- recommending tasks;
- ranking claims;
- drafting moderation;
- deciding when to escalate.

### Control

- AI outputs are versioned projections.
- Critical workflows offer non-AI/manual routes.
- Proposal and evidence views expose exact sources.
- Model/provider comparisons are periodically run.
- Recommendation systems cannot hide eligible tasks or proposals without an inspectable filter.
- AI influence metrics are measured.
- Users may select chronological/raw modes.
- No single provider becomes mandatory.

**Severity:** critical.

---

## F08 — Route poisoning plus repetition creates synthetic consensus

Even when CLAIMs cite RECORDs, AI may repeatedly select a narrow subset of records.

### Control

- Citation diversity and contradiction retrieval;
- source-independence analysis;
- duplicate-origin collapse;
- explicit unknown and disagreement views;
- route-level adversarial benchmarks;
- no “consensus” label from raw repetition count;
- claim aggregation distinguishes many copies of one source from independent evidence.

**Severity:** high.

---

## F09 — External moderation labels bias local decisions

Imported AT labels or Nostr reports may remain “claims” formally while AI and UI treat them as high-weight risk signals.

### Control

- External labels have explicit origin weighting.
- No automatic sanction.
- Model features and ranking rules are auditable.
- Local moderators see underlying evidence availability and source reliability.
- External label disagreement is visible.
- Repeated labels from mirrored sources collapse to one origin family.

**Severity:** high.

---

## F10 — Federation deanonymises governance participants

Public social accounts, timing, delegation, proposal activity, and external handles may correlate with anonymous governance credentials.

### Control

- Ballot submission uses a separate channel and timing protection where practical.
- Governance nullifiers are proposal-specific.
- Public ballot data minimises metadata.
- Federation accounts are not required for voting.
- Clients avoid publishing exact cross-domain timing links.
- Privacy analysis precedes public governance.

**Severity:** critical.

---

## F11 — Noted gamifies milestone manipulation

Even without economic conversion, rare creatures may create enough status to motivate:

- weak milestone inflation;
- collusive verification;
- fragmentation of research into rewardable units;
- withholding results for rarity timing.

### Control

- Noted eligibility is downstream of already justified research/work milestones.
- Creature rarity is not proportional to scientific importance, severity, reward size, or social popularity.
- Eligibility slots are capped and non-rerollable.
- Verifiers are not rewarded by creature outcome.
- Noted is omitted from research-evaluation interfaces by default.
- Institutions cannot require Noted status for roles or funding.

**Severity:** high.

---

## F12 — Grey markets arise despite sealed official boundaries

People may privately value:

- NEX;
- LEX;
- rare Noted creatures;
- reputation;
- identities;
- contracts.

The project cannot guarantee that no unofficial external market ever appears.

### Control

- Do not enable, quote, settle, arbitrate, advertise, or integrate grey-market trades.
- Exclude official external rails builders under the current canon.
- Do not design anti-user confiscation around unverifiable rumours.
- Treat proven external side deals as conflicts where relevant.
- Publish the distinction between protocol prohibition and inability to control all human behaviour.

**Severity:** critical residual risk.

---

## F13 — Epoch transition becomes covert confiscation

A governance majority can preserve the formal right to epoch closure while choosing a later transition that destroys opponents’ balances or political capacity.

### Control

- Transition rules are published before reliance.
- Material balance-recognition changes are P4 or protected-fork class, not ordinary P2.
- No retrospective continuity rule.
- Transition impact is simulated across identity and balance distributions.
- Dissenting minority receives export and fork material.
- Closed history remains intact even when recognition changes.

**Severity:** critical.

---

## F14 — Emergency power becomes de facto governance

Repeated narrow emergencies can serially avoid ordinary deliberation.

### Control

- Cumulative emergency duration per component and per authority is reported.
- Repeated emergencies with the same root cause trigger mandatory P3/P4 review.
- An emergency cannot re-open substantially identical scope immediately after expiry without stronger approval.
- Restart requires independent state verification.
- Emergency reviewers cannot be the sole architects of the affected system.

**Severity:** critical.

---

## F15 — Founder transition gate is self-certified

The founder or founder-appointed agents could declare that handoff conditions passed.

### Control

- Every transition condition maps to objective artifacts and independent receipts.
- Non-founder reviewers verify the gate.
- A failed or disputed gate remains unresolved.
- The founder cannot count as the required independent reviewer.
- Operational custody transfer is checked separately from constitutional text.

**Severity:** critical.

---

## F16 — Fork rights leak restricted or private data

A “complete reproducible fork bundle” can accidentally include:

- moderation evidence;
- private pseudonym mappings;
- access logs;
- deleted payload hashes;
- secrets;
- external data without redistribution rights.

### Control

- Fork bundles are schema-generated from explicitly exportable classes.
- Restricted/private references become non-resolving tombstones or locally controlled placeholders.
- Licence and redistribution checks run.
- Privacy attack fixtures test re-identification.
- Dissent and unresolved disputes are preserved without exposing restricted evidence.

**Severity:** critical.

---

## F17 — Static publication becomes stale institutional truth

The public site may preserve an old claim after LOOM contains a correction.

### Control

- Every publication has source and supersession metadata.
- Material corrections trigger a publication update SLA.
- The static site exposes current status and correction history.
- Publication builds fail when cited CLAIMs are retracted or superseded without explicit treatment.
- Last verified artifact remains recoverable.

**Severity:** high.

---

## F18 — Public security transparency exposes active exploits

Full provenance and adversarial reporting may disclose weaponisable details before containment.

### Control

- `RESTRICTED_EVIDENCE` class;
- embargo receipts;
- minimal public incident notice;
- explicit containment criteria;
- timed review;
- later disclosure or justified continued redaction;
- no permanent secret incident process.

**Severity:** critical.

---

## F19 — Large coherent sweeps increase blast radius

The founder prefers large coherent implementation runs. That improves internal consistency but can create broad mutation before review.

### Control

Every large sweep requires:

- frozen input bundle and hashes;
- isolated branch/worktree/repository;
- one writer per checkout;
- no production credentials;
- snapshot and rollback;
- staged checkpoints;
- test receipts after each internal milestone;
- explicit “no public activation” gate;
- independent breaker before merge.

**Severity:** high operational risk.

---

## F20 — Supply-chain compromise bypasses protocol correctness

A correct design can be undermined by:

- dependency takeover;
- malicious package;
- compromised CI;
- forged release;
- browser extension;
- Noted block injection;
- model/tool plugin compromise.

### Control

- lockfiles;
- dependency allowlist;
- SBOM;
- provenance;
- signed release artifacts;
- reproducible builds where practical;
- isolated browser origins and sandboxing;
- CSP;
- no dynamic remote code in high-authority clients;
- dependency audit receipts;
- minimal plugins.

**Severity:** critical.

---

## F21 — Model-provider data retention violates private scope

Provider-neutral adapters do not automatically ensure private data stays private.

### Control

Before real private data:

- provider retention and training policy review;
- contractual/data-processing review where applicable;
- region and subprocessors review;
- request-level no-retention controls where supported;
- private-data allowlist by provider;
- local/fake provider fallback;
- redaction;
- explicit user selection.

**Severity:** critical public-data blocker.

---

## F22 — Social Sybils remain harmful even without governance votes

Multiple public pseudonyms can:

- flood feeds;
- manufacture apparent agreement;
- harass;
- game reactions;
- overwhelm moderation;
- bias AI routing.

### Control

- rate limits and resource quotas;
- duplicate-origin analysis;
- user-selected feeds;
- reaction non-authority;
- provenance-aware aggregation;
- moderation tools;
- no automatic reputation from raw engagement;
- optional accountable-participant spaces.

**Severity:** high.

---

## F23 — Proposal cloning exhausts civic attention and LEX

Attackers can submit many near-identical proposals, forcing repeated defensive voting.

### Control

- duplicate-topic detection;
- proposal consolidation;
- per-topic cycle limits;
- minority objection path;
- no automatic LEX cost for recorded abstention;
- defensive appeal/challenge protections;
- procedural rejection without requiring full electorate spend.

**Severity:** high.

---

## F24 — Deadlock invites emergency overreach

Dual majorities, strong quorum, constitutional review, and independent replay can produce persistent deadlock.

### Control

Deadlock is not an emergency by default.

Use:

- status quo continuation;
- mediation;
- revised proposal;
- non-binding signal;
- sunset/review clauses;
- bounded pilot;
- fork/exit.

No authority may lower thresholds retroactively because a preferred proposal failed.

**Severity:** high.

---

# 4. Required amendments to prior provisional rounds

These amendments refine the provisional architecture. They do not alter binding canon.

## A1 — Governance-service conviction cap

Add to Round 7:

```text
Governance-service LEX may supply no more than 25% of one human's
maximum binding-ballot expenditure capacity in a cycle.
```

Civic allocation remains the primary binding-governance source.

## A2 — Same-body conflict delay

LEX earned from a governance or moderation body cannot be used in the same cycle on proposals directly affecting that body’s:

- compensation;
- powers;
- appointment;
- discipline;
- retrospective review.

## A3 — Multi-epoch NEX trajectory

Add to Round 5 epoch opening:

- cumulative issuance trajectory;
- minimum planned epoch duration;
- no ceiling reset by rapid epoch churn;
- variance review.

## A4 — Independent-work reputation

Reputation must label work as:

- independent;
- related-party;
- self-funded;
- synthetic;
- participant-funded;
- issuance-backed;
- verifier-confirmed;
- disputed.

Only independent categories count fully toward verifier, panel, or high-trust eligibility.

## A5 — Cross-protocol privacy firewall

Add to Round 8:

- no universal identity graph;
- purpose-specific bindings;
- export exclusion for private root links;
- governance/federation timing analysis.

## A6 — Critical projection reproducibility

Add to Round 4 and Round 6:

- open reference client;
- chronological mode;
- projection version disclosure;
- source-event drill-down;
- deterministic tally/proposal rendering.

## A7 — Operational custody transition

Add to Round 7 founder handoff:

- domain;
- hosting;
- repositories;
- release keys;
- production credentials;
- legal contracts;
- recovery;
- incident authority.

## A8 — Emergency repetition threshold

Repeated substantially similar emergencies trigger mandatory institutional review and cannot be chained indefinitely through expiry/restart.

## A9 — Fork privacy compiler

Fork/export bundles must be generated through a tested policy engine, not filesystem copying.

## A10 — Noted status firewall

Noted rarity or possession may not be used in:

- task eligibility;
- identity maturity;
- reputation;
- moderation;
- LEX earning;
- governance;
- research assessment.

## A11 — AI influence measurement

Track:

- percentage of feed impressions from AI ranking;
- proposal-summary usage;
- model/provider distribution;
- citation diversity;
- escalations;
- user overrides;
- correction rates.

These metrics remain descriptive and cannot become authority.

## A12 — One-writer operational rule

No two agents may write the same checkout concurrently.

Large sweeps use isolated branches/worktrees and explicit integration.

---

# 5. Public-epoch blockers

The following must be closed before any third party receives canonical public NEX/LEX balances or binding governance rights.

| Blocker | Why it blocks public activation |
|---|---|
| B1. No integrated canonical signed-event kernel with independent replay | All later state depends on it |
| B2. No implemented epoch ledger with independent reconstruction | Balances cannot be trusted |
| B3. No mature-human credential implementation | Civic allocation and one-person voting cannot operate |
| B4. No proven privacy and purge system | Real participant data would be exposed |
| B5. No production key, recovery, and compromise implementation | Identity and balances could be unrecoverable or stolen |
| B6. No hybrid/PQ benchmark and selected policy | High-authority continuity remains unresolved |
| B7. No integrated authority/capability enforcement | AI, agents, and services could exceed scope |
| B8. No operational custody handoff plan | Governance would not control infrastructure |
| B9. No emergency/restart implementation and drill | Holds could become arbitrary or unrecoverable |
| B10. No independent security and economic audit | Cross-domain exploit risk remains untested |
| B11. No legal/privacy/regulatory review for the intended jurisdiction and public representations | “Internal” does not remove every legal issue |
| B12. No federation privacy/deletion evidence | Public export may create irreversible exposure |
| B13. No canonical Noted source/provenance/licensing determination | Integration could be non-reproducible or legally contaminated |
| B14. No communications and continuity disclosure tested with users | Users could misunderstand “earned,” “canonical,” or future entitlement |
| B15. No fork/export privacy compiler and test | Exit rights could leak other people’s data |

These blockers do **not** prevent a local synthetic build.

---

# 6. Integrated breaker campaigns

The final closed testnet must run campaigns, not isolated unit tests.

## Campaign T1 — Identity-to-governance capture

Combine:

- multiple pseudonyms;
- credential issuer cartel;
- guardian recovery;
- delegation;
- civic allocation;
- service-earned LEX;
- founder transition.

Pass only if one human produces one binding identity and no colluding role set silently creates extra governance power.

## Campaign T2 — NEX-to-LEX indirect conversion

Combine:

- participant-funded tasks;
- wash contracts;
- related agents;
- reputation;
- verifier roles;
- service awards;
- governance.

Pass only if NEX wealth cannot create governance-eligible influence through related-party work or role capture.

## Campaign T3 — AI-mediated reality distortion

Combine:

- route poisoning;
- duplicated source families;
- social Sybils;
- external labels;
- feed ranking;
- proposal summaries;
- moderation drafting.

Pass only if exact contradictory RECORDs remain discoverable and no AI projection becomes hidden institutional authority.

## Campaign T4 — Federation privacy collapse

Combine:

- AT migration;
- Nostr relays;
- pseudonym bindings;
- public timing;
- deletion requests;
- fork export;
- private LOOM.

Pass only if private root links and restricted payloads remain undisclosed and external-copy uncertainty is explicit.

## Campaign T5 — Emergency founder recapture

Combine:

- active exploit;
- founder hold;
- infrastructure credentials;
- emergency extension;
- restart;
- veto;
- handoff gate.

Pass only if scope expires, independent review occurs, custody matches authority, and the founder cannot convert incident response into permanent rule.

## Campaign T6 — Epoch inflation and transition abuse

Combine:

- repeated NEX epochs;
- rapid ceiling resets;
- LEX cycle expiry;
- migration formulas;
- unresolved disputes;
- majority hostility to a minority.

Pass only if trajectories, closures, continuity, dissent, and fork receipts remain predeclared and reconstructible.

## Campaign T7 — Noted prestige capture

Combine:

- weak research milestone;
- collusive verification;
- rare creature generation;
- social ranking;
- identity maturity;
- role eligibility.

Pass only if Noted produces no economic, governance, moderation, identity, or research-authority effect.

## Campaign T8 — Supply-chain authority bypass

Combine:

- compromised dependency;
- forged release;
- manipulated client projection;
- correct event log;
- user ballot.

Pass only if release provenance, reference clients, artifact hashes, and independent tally prevent UI or build compromise from creating valid authority.

## Campaign T9 — Private-provider leakage

Combine:

- user-selected private context;
- AI escalation;
- provider routing;
- logging;
- moderation evidence;
- correction claim.

Pass only if provider and context scopes remain explicit, receipts exclude secrets, and private data never enters public LOOM or federation.

## Campaign T10 — Exit and fork under conflict

Combine:

- disputed moderation;
- locked balances;
- open governance proposal;
- private evidence;
- public dissent;
- fork declaration.

Pass only if exit is non-retaliatory, public history is reproducible, restricted evidence remains protected, and unresolved state is disclosed.

---

# 7. Acceptance criteria for Round 9 closure

Round 9 is considered complete when:

- every direct prohibited conversion has an indirect-conversion test;
- role relatedness is evaluated above the individual account level;
- public-history and privacy rules no longer rely on one universal retention promise;
- governance transition includes operational custody;
- multi-epoch inflation is addressed;
- critical projections are independently reconstructible;
- AI influence is measured and bypassable;
- federation cannot silently define identity or moderation;
- Noted cannot influence institutional authority;
- fork and exit can occur without privacy collapse;
- all public blockers are explicit rather than buried as “future work.”

These conditions are now met at the architecture level.

---

# 8. Residual risks that cannot be honestly solved by protocol alone

The project must preserve these as explicit unknowns rather than claiming victory.

1. Private bribery and coercion.
2. Grey markets outside official systems.
3. Perfect one-person uniqueness.
4. Collusion among socially trusted humans.
5. Legal interpretation across jurisdictions.
6. Provider or infrastructure coercion.
7. Correlation attacks using public timing and behaviour.
8. User devices compromised below the application layer.
9. Long-term cryptographic change.
10. Cultural capture despite formally correct rules.
11. Manipulation through rhetoric and social pressure.
12. Governance apathy and low participation.
13. Fork fragmentation.
14. Security vulnerabilities not represented in the threat model.
15. Founder influence that persists socially after formal authority is removed.

These risks require measurement, institutional design, pluralism, dissent, exit, and continuing red-team work.

---

# 9. Round 9 disposition

```text
Integrated architecture remains coherent:          YES
Fatal contradiction found:                         NO
Indirect NEX→governance routes identified:          YES
Indirect LEX/bribery residual risk acknowledged:    YES
Identity/federation privacy conflict addressed:     YES
Public history/privacy conflict addressed:          YES
Projection/UI authority leak addressed:             YES
Operational custody handoff added:                  YES
Multi-epoch inflation control added:                YES
Emergency chaining control added:                   YES
Noted prestige firewall strengthened:               YES
Fork privacy treatment strengthened:                YES
Public blockers enumerated:                         YES
Synthetic implementation planning may proceed:      YES
Public activation authorised:                       NO
Canon amended:                                      NO
```

## Next round

**Round 10 — Build Sweep Architecture and Execution Package Design**

Convert the reconciled and attacked architecture into a small number of large coherent implementation sweeps with:

- exact repositories and branch boundaries;
- frozen inputs and hashes;
- one-writer rules;
- deliverables;
- internal milestones;
- acceptance tests;
- breaker gates;
- rollback;
- progress-update format;
- authority stops;
- handoff bundles;
- exact Ultra prompt structure.
