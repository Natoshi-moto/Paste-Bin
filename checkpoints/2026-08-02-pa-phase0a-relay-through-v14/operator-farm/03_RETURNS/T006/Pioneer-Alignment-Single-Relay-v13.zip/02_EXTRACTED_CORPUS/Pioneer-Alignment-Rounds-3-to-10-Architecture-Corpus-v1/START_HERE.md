# Pioneer Alignment — Rounds 3–10 Architecture Review Corpus

Status: ARCHITECTURE CRITIQUE INPUT — NOT IMPLEMENTATION AUTHORITY

1. Attach or extract this corpus in the independent high-reasoning chat.
2. Read `CORPUS_MANIFEST.json`.
3. Read `PROMPT_TO_PASTE.md`.
4. Paste `PROMPT_TO_PASTE.md` in full.
5. Return the critic's complete response and any generated files to the controlling ChatGPT chat.

The critic must review architecture only. It must not code, mutate repositories,
deploy, request credentials, create public balances, or promote provisional
choices into canon.
