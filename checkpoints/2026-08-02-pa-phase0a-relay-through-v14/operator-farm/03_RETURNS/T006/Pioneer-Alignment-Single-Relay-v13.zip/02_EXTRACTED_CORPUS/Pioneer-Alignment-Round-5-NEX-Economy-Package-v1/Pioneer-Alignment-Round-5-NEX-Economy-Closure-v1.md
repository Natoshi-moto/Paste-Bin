# Pioneer Alignment — Round 5 NEX Economy Closure

**Version:** v1  
**Date:** 2026-08-01  
**Status:** Provisional architecture and simulation contract — not a canon amendment  
**Scope:** NEX only  
**Explicitly excluded:** LEX design, public issuance, external value, blockchain placement, credentials, production deployment

---

## 0. Disposition

This round closes the **mechanical design** of a synthetic and epoch-scoped NEX economy sufficiently to implement and attack it.

It does not declare final public monetary policy.

The binding perimeter remains:

- NEX accounts for bounded reasoning, AI work, approved compute, and explicitly receipted agent-market utility.
- NEX has no governance, moderation, visibility, reputation, evidential, or truth authority.
- NEX cannot be bought, sold, redeemed, externally priced, placed on a blockchain, bridged, or converted to LEX.
- Internal balances may be canonical within a named epoch without creating automatic entitlement in later epochs.
- Corrections are append-only.
- A model, worker, task publisher, verifier, adjudicator, or operator cannot directly write balances.

The proposed system is therefore:

> **An append-only internal work-and-compute accounting economy with uncapped potential supply, bounded issuance in every named epoch, zero founder allocation, and payment only through predeclared task, verification, research, or remediation rules.**

---

# 1. Core economic model

## 1.1 Supply

NEX has:

- **uncapped potential supply** across indefinite future epochs;
- **finite authorised issuance capacity** inside every epoch;
- **finite issued supply** at every moment;
- **explicit live, locked, disputed, and retired quantities**;
- **no permanent founder, investor, or treasury premine**.

“Uncapped” means no permanent mathematical maximum.

It does not mean:

- an operator can issue at will;
- budgets can exceed the epoch ceiling;
- unused capacity silently rolls forward;
- an agent can mint through activity;
- social engagement can create NEX;
- a future epoch must honour all prior balances.

## 1.2 Genesis

Recommended genesis for the first synthetic research epoch:

```text
Epoch:                NEX-R001-SIM
Initial issued NEX:   0
Founder allocation:   0
Investor allocation:  0
Participant balances: 0
Authorised capacity:  declared by epoch-open event
```

Budget authorisation is **not issuance**.

NEX comes into existence only at a valid settlement or allocation event.

## 1.3 Three ways work may be coordinated

### A. Issuance-backed programme task

Pioneer Alignment authorises an epoch budget for useful work.

```text
epoch capacity → programme budget → task reservation → accepted work → NEX issuance
```

No NEX exists in a treasury before settlement.

### B. Participant-funded task

A participant already holding NEX locks existing NEX into contract escrow.

```text
participant balance → escrow lock → accepted work → transfer
```

This changes ownership but does not increase supply.

### C. Receipted barter

Two parties exchange permitted NEX-domain work or compute deliverables without transferring NEX.

```text
reciprocal deliverables → receipts → verification/status
```

Barter creates no NEX and no LEX. It cannot create an external debt or Pioneer-enforced claim outside the internal work domain.

---

# 2. Epoch contract

Every NEX epoch must publish an immutable opening contract before writes begin.

## 2.1 Required epoch fields

- epoch ID and version;
- event schema version;
- start condition;
- closure condition;
- maximum gross issuance;
- programme/category ceilings;
- permitted issuance event types;
- transfer and lock rules;
- settlement finality rule;
- dispute and correction rules;
- operator and emergency powers;
- role-separation requirements;
- wallet/account namespace;
- continuity or non-continuity rule;
- unresolved-dispute treatment at closure;
- exact canonical serialisation and hash rules.

## 2.2 Epoch invariants

For any valid state:

```text
gross_issued <= authorised_capacity <= epoch_issuance_ceiling
reserved_unissued <= authorised_capacity - gross_issued
sum(all live balances) = gross_issued - retired
available + locked + disputed + restricted = live_supply
```

Transfers, locks, unlocks, and freezes conserve live supply.

Only issuance increases supply.

Only retirement decreases supply.

## 2.3 No implicit carryover

Unused issuance capacity expires at epoch closure unless the opening contract explicitly defines a carryover function.

Balances migrate only under the predeclared continuity rule.

The closed epoch remains canonical history regardless of migration.

---

# 3. Recommended synthetic baseline: NEX-R001-SIM

These numbers exist to make simulation concrete. They are not founder promises and must not be reused publicly without a new decision.

## 3.1 Denomination

- Internal integer unit: `microNEX`
- Display precision: 6 decimal places
- `1 NEX = 1,000,000 microNEX`
- All ledger arithmetic uses signed-safe integers; no binary floating point

## 3.2 Epoch capacity

```text
Maximum gross issuance: 1,000,000 NEX
Duration:                simulation-defined; close by event count or scenario completion
Genesis issued supply:   0 NEX
Carryover:               none
```

## 3.3 Category ceilings

| Category | Ceiling | Purpose |
|---|---:|---|
| Direct task execution | 500,000 NEX | Audits, code, tests, research work and bounded agent labour |
| Independent verification | 200,000 NEX | Reproduction, confirmation, contradiction and release checks |
| Research allocations | 150,000 NEX | Restricted experimental compute/reasoning budgets |
| Adjudication and safety work | 75,000 NEX | Dispute panels, incident analysis and recovery work |
| Protocol remediation reserve | 75,000 NEX | Bounded correction for proven protocol-caused accounting harm |

No category may borrow from another category unless the epoch contract contains a predeclared reallocation rule and the reallocation occurs before reliance.

## 3.4 Why the baseline separates verification funding

Verifier payment must not depend on the worker paying or bribing the verifier.

Verification has its own authorised capacity.

A valid verifier receipt receives the declared fee whether it confirms or rejects the worker’s claim.

---

# 4. NEX event taxonomy

All accepted events are append-only and canonically serialised.

## 4.1 Epoch and budget events

- `NEX_EPOCH_OPEN`
- `NEX_BUDGET_AUTHORISE`
- `NEX_BUDGET_REALLOCATE`
- `NEX_BUDGET_REDUCE`
- `NEX_BUDGET_CLOSE`
- `NEX_EPOCH_HOLD`
- `NEX_EPOCH_RESUME`
- `NEX_EPOCH_CLOSE`
- `NEX_EPOCH_TRANSITION_DECLARE`

## 4.2 Task-market events

- `NEX_TASK_PUBLISH`
- `NEX_TASK_AMEND`
- `NEX_TASK_CANCEL`
- `NEX_BID_SUBMIT`
- `NEX_BID_WITHDRAW`
- `NEX_BID_REJECT`
- `NEX_CONTRACT_AWARD`
- `NEX_CONTRACT_AMEND`
- `NEX_CONTRACT_CANCEL`
- `NEX_CONTRACT_EXPIRE`

## 4.3 Work and verification events

- `NEX_WORK_RECEIPT_SUBMIT`
- `NEX_WORK_RECEIPT_SUPPLEMENT`
- `NEX_WORK_RECEIPT_RETRACT`
- `NEX_VERIFIER_ASSIGN`
- `NEX_VERIFICATION_RECEIPT`
- `NEX_VERIFICATION_CONTRADICTION`
- `NEX_DISPUTE_OPEN`
- `NEX_ADJUDICATION_DECISION`
- `NEX_APPEAL_OPEN`
- `NEX_APPEAL_DECISION`

## 4.4 Accounting events

- `NEX_ISSUE_SETTLEMENT`
- `NEX_ISSUE_RESEARCH_ALLOCATION`
- `NEX_TRANSFER`
- `NEX_ESCROW_LOCK`
- `NEX_ESCROW_RELEASE`
- `NEX_LOCK`
- `NEX_UNLOCK`
- `NEX_FREEZE`
- `NEX_UNFREEZE`
- `NEX_RETIRE`
- `NEX_PENALTY_SETTLEMENT`
- `NEX_COMPENSATION`
- `NEX_PROTOCOL_REMEDIATION`

## 4.5 Barter events

- `NEX_BARTER_CONTRACT`
- `NEX_BARTER_RECEIPT`
- `NEX_BARTER_VERIFY`
- `NEX_BARTER_DISPUTE`
- `NEX_BARTER_CLOSE`

“`NEX_`” in barter event names identifies the domain, not a NEX transfer.

---

# 5. Account and wallet model

## 5.1 Purpose-built internal wallet

The wallet is an account client for the Pioneer NEX ledger, not a cryptocurrency wallet.

Required properties:

- distinct address/network namespace;
- checksum and epoch/network indicator;
- no Bitcoin, Ethereum, Solana, seed-phrase, token-contract, chain, bridge, or exchange compatibility;
- signed NEX-domain intents;
- independently reconstructible balance from the event log;
- explicit available, locked, restricted, disputed, and retired views;
- exact receipt export;
- no market-price display;
- no fiat-equivalent display;
- no LEX pooled balance.

## 5.2 Provisional identifier shape

Example only:

```text
nex-r001:<key-hash>:<checksum>
```

The final cryptographic algorithm and recovery process remain for the identity/security round.

## 5.3 Agent and operator separation

An agent account and its human/organisation operator are distinct identities.

The operator binding is visible where required.

An agent’s NEX balance does not automatically belong to the operator unless the epoch rules explicitly define custody.

No agent may:

- issue its own reward;
- verify its own work;
- adjudicate its own dispute;
- use its NEX to obtain LEX or human voting rights.

---

# 6. Budget authority and role separation

## 6.1 Required roles

- **Epoch authority:** opens/closes the epoch under constitutional authority.
- **Budget authority:** authorises programme ceilings.
- **Task publisher:** publishes tasks inside an authorised budget.
- **Allocator:** awards contracts under the declared selection rule.
- **Worker:** performs the task.
- **Verifier:** independently checks the receipt.
- **Adjudicator:** resolves defined disputes.
- **Ledger service:** deterministically applies valid accounting events.
- **Auditor:** reconstructs and checks the whole ledger.

## 6.2 Public-epoch separation rule

For any issuance-backed contract, no single identity may occupy all of:

```text
budget authority
task publisher
worker
sole verifier
adjudicator
ledger signer
```

At minimum:

- worker must be independent of task budget authority;
- sole verifier must be independent of worker and publisher;
- adjudicator must be independent of all parties;
- ledger service cannot invent or alter the decision.

Synthetic simulations may deliberately violate these constraints only in labelled attack scenarios.

## 6.3 Operator exceptions

Any bootstrap exception must state:

- scope;
- reason;
- start;
- expiry;
- affected events;
- independent review requirement.

An exception does not become precedent automatically.

---

# 7. Task contract

A task must contain enough information that acceptance cannot be invented after submission.

## 7.1 Required fields

- task ID and version;
- epoch and budget category;
- publisher;
- exact subject/repository/artifact identity;
- work type;
- allowed and forbidden actions;
- required environment;
- deliverables;
- acceptance tests;
- evidence schema;
- duplication/novelty class;
- redundancy target;
- verification tier;
- maximum worker reward;
- verifier and adjudication budgets;
- award mode;
- deadline;
- cancellation and partial-work rules;
- secrets/privacy handling;
- continuity disclosure;
- dispute and appeal process.

## 7.2 Work classes

- deterministic verification;
- exploratory audit;
- reproducible defect discovery;
- repair implementation;
- independent repair verification;
- research experiment;
- documentation/provenance work;
- approved compute provision;
- bounded model evaluation;
- incident or recovery work.

Social participation by itself is not a work class.

---

# 8. Award and bidding modes

One universal auction is rejected.

Each task declares one of these modes before bids open.

## 8.1 `FIXED_OPEN`

A fixed reward is available to any eligible worker until the declared quota is filled.

Best for:

- onboarding audits;
- planned environment diversity;
- regression confirmations;
- deterministic test receipts.

No race-to-the-bottom bidding.

## 8.2 `RANDOM_QUALIFIED`

All bids passing objective gates enter a deterministic public draw.

Best for:

- reducing incumbent capture;
- giving new participants access;
- preventing allocator favouritism.

The seed and candidate set must be published before selection.

## 8.3 `SEALED_LOWEST_QUALIFIED`

Select the lowest price only after:

- evidence-plan threshold;
- independence checks;
- capability checks;
- risk threshold;
- delivery feasibility.

Best for well-specified commodity work.

The lowest bid cannot win by omitting required evidence.

## 8.4 `DECLARED_SCORECARD`

Weights and tie-breaking rules are frozen before bids.

Recommended constraints:

- price weight: no more than 35%;
- prior reputation/projection weight: no more than 20%;
- evidence and reproducibility plan: at least 25%;
- capability and risk: remaining weight;
- entry path for new participants must exist.

Best for complex research or implementation work.

## 8.5 `MILESTONE_NEGOTIATED`

A bounded negotiation for complex work with predeclared milestones and maximum budget.

Every amendment is signed and versioned.

Best for large coherent build sweeps.

---

# 9. Contract funding and escrow

## 9.1 Issuance-backed contract

At award:

- reserve authorised unissued capacity;
- do not issue NEX;
- reserve verifier/adjudication capacity separately;
- release unused reservation on cancellation or expiry.

At settlement:

- issue only the amount authorised by the valid decision;
- release remaining reservation;
- append exact settlement reference.

## 9.2 Participant-funded contract

At award:

- lock existing NEX from the sponsor;
- lock verifier fee where required;
- settlement transfers from escrow;
- cancellation follows the predeclared reliance rule.

## 9.3 No partial hidden funding

The interface must show separately:

- issuance-backed reward;
- participant-funded escrow;
- verifier funding;
- adjudication reserve;
- barter-only obligations.

These may not be collapsed into one “pot.”

---

# 10. Verification tiers

## Tier 0 — Deterministic machine gate

- schema, hash, build, test, static analysis or exact replay;
- not independent human/agent judgment;
- may reject malformed work;
- cannot alone settle a task where the contract requires independent verification.

## Tier 1 — Single independent verification

For low-risk, deterministic, easily replayed work.

Requires one independent signed verifier receipt.

## Tier 2 — Dual independent verification

For:

- defect bounties;
- security findings;
- non-deterministic environments;
- meaningful NEX issuance;
- contradiction between automated and submitted evidence.

Requires two independent verifiers or one verifier plus an independently reproduced automated environment.

## Tier 3 — Panel and adjudication

For:

- high-budget work;
- disputed defects;
- protocol changes;
- accounting corrections;
- safety incidents;
- claims that could create broad follow-on costs.

Requires a declared panel and appeal route.

## 10.1 Verifier payment rule

Verifier payment depends on:

- completing the required method;
- disclosing conflicts;
- supplying reproducible evidence;
- meeting the receipt schema.

It does **not** depend on approving the worker.

This removes a direct incentive to rubber-stamp.

---

# 11. Audit-onboarding reward model

The first participant task family should combine learning and useful assurance.

## 11.1 Coverage cell

Every audit reward is attached to a unique coverage cell such as:

```text
candidate hash
test suite/version
operating environment
toolchain version
threat category
time window
replication slot
```

A submission outside an open coverage cell may still be stored as evidence but does not automatically earn NEX.

## 11.2 Green confirmation

A green receipt is payable only when it fills:

- an open replication slot;
- a required environment diversity slot;
- a scheduled regression slot;
- a random audit sample;
- an unresolved confidence target.

After the quota is met, further identical confirmations earn zero unless a new task opens.

## 11.3 Defect discovery

A defect reward requires:

- exact affected artifact;
- reproducible steps;
- expected versus actual result;
- impact classification;
- evidence;
- independent reproduction;
- duplicate-family check.

The first accepted defect family receives the declared primary reward.

A later submission receives additional reward only for a materially new:

- root cause;
- affected surface;
- exploitation path;
- reproduction environment;
- repair-blocking fact.

## 11.4 No engagement faucet

Reading the project, signing up, following accounts, posting reactions, or asking an agent for a summary does not issue NEX.

The reward is for the accepted audit contract and evidence.

---

# 12. Partial work, failure, cancellation and lateness

## 12.1 Partial settlement

Partial payment exists only if milestones were declared before award.

A vague “effort was made” claim does not create an automatic balance.

## 12.2 Failed work

A failed task may produce:

- zero settlement;
- payment for a previously accepted milestone;
- a separately authorised research/failure-analysis receipt;
- a dispute.

It does not permit retrospective reward invention.

## 12.3 Publisher cancellation

Where the publisher cancels after reliance:

- predeclared cancellation compensation may transfer or issue;
- submitted artifacts remain attributable;
- unused reservation is released;
- reason is recorded.

## 12.4 Worker withdrawal

- accepted milestones may settle;
- unaccepted work does not;
- locked performance bond, if any, follows the contract;
- no unrelated balance confiscation.

## 12.5 Performance bonds

Not required for ordinary onboarding or new participants.

Permitted only for high-risk/high-budget work where:

- the amount is capped;
- the reason is explicit;
- an appeal exists;
- loss requires adjudication;
- lack of wealth is not used to permanently exclude entrants.

---

# 13. Research allocations

Researchers may receive bounded NEX-domain support without creating a founder patronage faucet.

## 13.1 Preferred mechanism

Use a restricted research allocation:

- named programme;
- objective;
- maximum amount;
- permitted NEX-domain uses;
- expiry;
- milestone/reporting requirements;
- unused-balance rule;
- conflict disclosure;
- final receipt.

## 13.2 Two forms

### Restricted issued allocation

NEX is issued into a restricted balance and may only fund approved compute or agent work.

Unused balance is retired or returned under the predeclared rule.

### Claim-based allocation

No balance is issued upfront.

Verified eligible work or compute claims settle against the programme budget.

This is preferred where custody or misuse risk is high.

## 13.3 Prohibited forms

- personal gifts without a published programme;
- founder-selected permanent allocations;
- external expense reimbursement represented as NEX;
- LEX/governance rewards disguised as research;
- retroactive grants created after outcomes are known.

---

# 14. Barter

## 14.1 Permitted barter

Permitted examples:

- code review for test development;
- model evaluation for documentation;
- compute execution for a research analysis;
- agent orchestration for independent verification.

## 14.2 Required record

A barter contract records:

- parties and operators;
- deliverables;
- deadlines;
- evidence;
- verification;
- dispute path;
- completion status.

## 14.3 Hard limits

Barter cannot:

- exchange NEX for LEX;
- exchange work for votes, moderation, reputation, visibility, or truth;
- create an official external price;
- create Pioneer-enforced fiat or crypto debt;
- disguise an external sale;
- mint NEX merely because parties traded.

Where an external side-deal is alleged, Pioneer records the allegation and evidence but does not recognise or enforce the external consideration.

---

# 15. Transfers and internal freedom

## 15.1 Permitted transfers

NEX holders may transfer within the NEX domain under the epoch rules.

Transfers may be:

- contract settlement;
- agent-work payment;
- approved compute payment;
- research allocation;
- unconditional internal transfer;
- adjudicated compensation;
- voluntary retirement.

## 15.2 Transfer metadata

Every transfer records:

- sender;
- recipient;
- amount;
- epoch;
- purpose code;
- optional contract/receipt;
- sequence/nonce;
- signature;
- fee, if any;
- policy result.

Large or automated transfers may require a contract or declared purpose.

## 15.3 No market interface

The system must not provide:

- order books;
- exchange charts;
- fiat/crypto equivalents;
- implied prices against LEX;
- external payment addresses;
- bridge or withdrawal controls.

---

# 16. Retirement and sinks

NEX does not need artificial destruction merely to create speculative scarcity.

Permitted retirement events:

- approved platform compute consumed from a system allocation;
- expired restricted research allocation under a predeclared rule;
- voluntary retirement;
- adjudicated penalty from a locked performance bond;
- protocol remediation correction;
- epoch transition where the predeclared rule retires non-migrating balances while preserving history.

Ordinary agent-to-agent payment is a transfer, not retirement.

Inactivity alone does not retire NEX in the initial model.

No arbitrary demurrage or surprise expiry.

---

# 17. Penalties and remediation

## 17.1 Objective penalty grounds

Possible grounds:

- forged receipt;
- deliberate artifact substitution;
- duplicate identity fraud under a rule that forbids it;
- verifier conflict concealment;
- collusive self-settlement;
- malicious task sabotage;
- repeated contract breach under explicit terms.

## 17.2 Remedy order

Prefer the narrowest remedy:

1. reject or withhold unsettled reward;
2. freeze disputed settlement;
3. release or return escrow;
4. lose a declared performance bond;
5. suspend task eligibility;
6. append reputation/evidence consequences;
7. compensate proven victims from a defined remediation reserve.

Unrelated balances are not confiscated by default.

## 17.3 Protocol remediation reserve

The reserve is not insurance and creates no guarantee.

It may address only proven protocol-caused internal accounting harm under:

- published eligibility;
- a capped epoch budget;
- independent adjudication;
- transparent receipts;
- no external-value claim.

---

# 18. Anti-abuse architecture

## 18.1 Wash work

Attack:

```text
publisher creates fake task
→ related worker completes it
→ related verifier approves
→ new NEX is issued
```

Controls:

- only authorised programmes can create issuance-backed budgets;
- worker independence from budget authority;
- verifier independence;
- declared conflict graph;
- coverage/need test;
- issuance category ceiling;
- random audit;
- no self-settlement;
- adjudication for anomalies.

Participant-funded self-dealing merely moves existing NEX and cannot increase supply.

## 18.2 Duplicate audit farming

Controls:

- coverage-cell quotas;
- duplicate-family detection;
- reward closure after target redundancy;
- random assignment;
- no retroactive expansion of quotas.

## 18.3 Sybil worker farming

Controls:

- task-specific eligibility;
- operator-agent binding;
- per-operator or related-identity quotas where justified;
- randomized assignment;
- environment diversity;
- no NEX reward for mere identity count.

Identity/Sybil design is completed in a later round.

## 18.4 Bid cartel

Controls:

- sealed bids where appropriate;
- deterministic random-qualified mode;
- public award receipts;
- concentration metrics;
- periodic reserve-price experiments;
- new-entrant allocation path.

## 18.5 Verifier cartel

Controls:

- random verifier assignment;
- outcome-independent verifier fees;
- dual verification for material tasks;
- hidden test cases where safe;
- verifier contradiction tracking;
- periodic independent audit;
- recusal and conflict rules.

## 18.6 False bug bounty extortion

Controls:

- evidence embargo for active vulnerabilities;
- independent reproduction;
- severity rubric;
- no payment merely for threatening disclosure;
- bounded disclosure and containment process;
- dispute route.

## 18.7 Cheap-bid quality collapse

Controls:

- lowest price only after quality gates;
- declared evidence requirements;
- milestone acceptance;
- failure-rate monitoring;
- capped reputation weight rather than no quality signal.

## 18.8 Budget capture

Controls:

- category ceilings;
- concentration metrics;
- programme diversity;
- public budget events;
- no silent reallocation;
- epoch closure analysis.

---

# 19. Supply and concentration metrics

The system reports accounting metrics, not a market price.

## 19.1 Supply metrics

- `authorised_capacity`
- `reserved_unissued`
- `gross_issued`
- `retired`
- `live_supply`
- `available_supply`
- `locked_supply`
- `restricted_supply`
- `disputed_supply`
- `unsettled_contract_exposure`

## 19.2 Distribution metrics

- balances by identity type;
- top-1, top-5, top-10 concentration;
- Gini coefficient as a descriptive metric only;
- issuance by programme;
- issuance by work type;
- issuance by operator relationship;
- new-entrant share;
- verifier share;
- task-publisher concentration;
- transfer graph concentration.

No one metric becomes automatic authority.

## 19.3 Productivity metrics

- accepted work per issued NEX;
- verification cost per settled task;
- defect reproduction rate;
- green-confirmation redundancy efficiency;
- dispute rate;
- reversal rate;
- time to settlement;
- incomplete-contract rate;
- duplicate-submission rate;
- protocol-remediation usage.

---

# 20. Ledger and state-machine rules

## 20.1 Balance states

Each account balance is partitioned into:

- `available`
- `locked`
- `restricted`
- `disputed`

Retired NEX is not a balance.

## 20.2 Contract states

```text
DRAFT
→ OPEN
→ AWARD_PENDING
→ ACTIVE
→ SUBMITTED
→ VERIFYING
→ ACCEPTED | REJECTED | DISPUTED
→ SETTLED | CANCELLED | EXPIRED
```

No transition skips required verification.

## 20.3 Settlement finality

A settlement becomes final for the epoch after:

- required verification;
- appeal window or explicit waiver;
- valid settlement event;
- ledger inclusion;
- checkpoint.

A later correction uses a compensating event.

## 20.4 Narrow freeze

A dispute freezes only:

- the disputed contract;
- the related escrow/reservation;
- directly affected identities or events.

A local dispute does not halt unrelated NEX activity unless an invariant failure exists.

---

# 21. Simulation programme

## 21.1 Baseline population

Provisional synthetic population:

- 100 human-operator identities;
- 300 agent identities;
- 20 task publishers;
- 40 verifiers;
- 10 adjudicators;
- 5 budget programmes.

These numbers are simulation fixtures only.

## 21.2 Required scenarios

1. honest baseline;
2. duplicate-audit flood;
3. low-price/low-quality bidding;
4. related publisher-worker-verifier wash ring;
5. 30% Sybil worker identities;
6. 33% verifier cartel;
7. defect-bounty duplicate race;
8. task cancellation after reliance;
9. worker abandonment;
10. key compromise during settlement;
11. budget exhaustion;
12. category reallocation attempt;
13. research-allocation misuse;
14. barter disguised as NEX–LEX conversion;
15. protocol accounting bug and remediation;
16. epoch closure with unresolved disputes;
17. no-migration transition;
18. capped/formula transition;
19. network partition and deterministic replay;
20. independent implementation reconstruction.

## 21.3 Hard acceptance properties

The simulator must prove:

- no event creates NEX outside authorised issuance types;
- gross issuance never exceeds the epoch ceiling;
- category issuance never exceeds category ceiling;
- participant-funded tasks never increase supply;
- transfers and locks conserve supply;
- retirement is the only supply-decreasing event;
- no NEX–LEX event or conversion exists;
- no social event issues NEX;
- no contract settles without its required verification tier;
- duplicate confirmations cannot exceed their open reward quota;
- a related-role wash ring cannot create valid issuance;
- corrections preserve original events;
- every balance reconstructs from genesis;
- two independent implementations produce the same state hash;
- epoch closure freezes events, balances, unresolved disputes, and transition rules.

## 21.4 Provisional performance thresholds

These are targets for simulation, not constitutional rules.

- unauthorised issuance: exactly `0`;
- overspend beyond any ceiling: exactly `0`;
- state-hash divergence on valid log: exactly `0`;
- duplicate-confirmation leakage beyond declared quota: exactly `0`;
- settlement without required verifier: exactly `0`;
- known related-role wash settlement: exactly `0`;
- lost accounting events after crash/replay: exactly `0`;
- high-risk false acceptance under 33% verifier cartel: below `1%` across repeated seeded runs;
- honest low-risk median settlement latency: within declared scenario SLA;
- new-entrant contract share: at least `15%` where qualified new entrants comprise at least `25%` of bidders;
- top-5 share of issuance: report and investigate above `50%`; not an automatic failure without task-demand context;
- remediation reserve use: never exceeds its ceiling and never compensates external value.

---

# 22. Required implementation artifacts

The NEX sweep must produce:

- `NEX_EPOCH_SPEC.md`
- `NEX_EVENT_SCHEMA.json`
- `NEX_INVARIANTS.md`
- `NEX_STATE_MACHINE.md`
- `NEX_R001_SIM_PARAMETERS.json`
- deterministic ledger implementation;
- independent replay implementation;
- wallet/account fixture;
- task, bid, contract, receipt, verifier and adjudication fixtures;
- attack-scenario fixtures;
- exact test report;
- balance and supply receipt;
- epoch closure receipt;
- known-limitations register;
- sealed ZIP and SHA-256 manifest.

No public remote, credential, provider, Cloudflare, DNS, or production action.

---

# 23. Provisional choices versus protected boundaries

## Protected and already binding

- NEX domain;
- sealed external membrane;
- NEX–LEX non-convertibility;
- no NEX governance authority;
- no engagement issuance;
- append-only accounting;
- explicit epoch continuity;
- no founder/investor sale or allocation.

## Provisional choices introduced here

- uncapped potential supply;
- zero-issued genesis;
- microNEX precision;
- `1,000,000 NEX` synthetic ceiling;
- category percentages;
- award modes;
- verification tiers;
- research-allocation forms;
- retirement events;
- simulation thresholds.

These provisional choices must be tested, challenged, and explicitly adopted or replaced before a public epoch.

---

# 24. Round 5 disposition

```text
NEX mechanical domain closed for simulation: YES
Supply model specified:                      YES
Epoch budget model specified:                YES
Issuance and event taxonomy specified:        YES
Bidding modes specified:                     YES
Verification incentives specified:           YES
Audit-onboarding anti-farming specified:      YES
Partial/failure/cancellation rules specified: YES
Research allocation specified:               YES
Barter boundary specified:                   YES
Transfer and retirement rules specified:      YES
Anti-wash controls specified:                YES
Custody cryptography finalised:               NO — later identity/security round
Public NEX authorised:                        NO
Canon amended:                               NO
Ready for social/LOOM/Noted round:            YES
```

## Next round

**Round 6 — Social, LOOM, AT Protocol/Nostr and Noted Integration**

Close:

- signed social event types;
- public/private/retention classes;
- edit, deletion, correction and purge semantics;
- moderation, appeals and evidence;
- LOOM ingestion and claim/route contracts;
- native AI context permissions;
- AT Protocol service-stack scope;
- Nostr multi-homing scope;
- Noted milestone and battle event adapter;
- offline/degraded operation;
- integrated acceptance and adversarial tests.
