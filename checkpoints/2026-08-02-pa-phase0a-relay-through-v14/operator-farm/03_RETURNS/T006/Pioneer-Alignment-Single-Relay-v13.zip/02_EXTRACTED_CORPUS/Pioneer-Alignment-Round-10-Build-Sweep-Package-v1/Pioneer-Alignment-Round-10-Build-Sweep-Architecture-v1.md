# Pioneer Alignment — Round 10 Build Sweep Architecture

**Version:** v1  
**Date:** 2026-08-01  
**Status:** Implementation architecture — not a canon amendment  
**Target:** A complete local synthetic Pioneer Alignment system, independently replayable and adversarially tested  
**Primary repository:** `/home/anon/Projects/Pioneer-Alignment-App`  
**Public publication repository:** frozen and out of scope  
**Production authority:** none

---

# 0. Objective

Turn the reconciled Pioneer Alignment architecture into a working local system through a small number of large coherent sweeps.

The final local system must demonstrate:

- signed identities and bounded capabilities;
- canonical append-only events;
- deterministic replay;
- LOOM RECORD/CLAIM/ROUTE separation;
- social posts, replies, edits, moderation and appeals;
- provider-neutral fake/local AI;
- NEX task market and synthetic economy;
- LEX and synthetic constitutional governance;
- agent/operator attribution;
- local AT Protocol and Nostr laboratories;
- Noted milestone, creature and battle adapter;
- offline operation;
- epoch closure;
- fork/export;
- independent replay;
- cross-domain breaker campaigns.

The build is successful only when another implementation can reconstruct the same valid state from the same event log.

---

# 1. Repository decision

## 1.1 Use one private local monorepo

Continue from:

```text
/home/anon/Projects/Pioneer-Alignment-App
```

Do not create competing application repositories unless a verified technical constraint requires it.

Reason:

- the system’s main risks are cross-domain;
- schemas and event semantics must remain coherent;
- deterministic replay is easier to enforce across shared packages;
- one integration history is easier to audit;
- the user prefers large coherent sweeps.

The public static website remains a separate frozen publication surface.

Noted, AT Protocol, Nostr, and future provider code enter through adapters or provenance-preserved source snapshots. Do not use unreviewed Git submodules or unresolved gitlinks.

## 1.2 Recommended monorepo shape

```text
Pioneer-Alignment-App/
├── apps/
│   ├── operator-console/
│   ├── local-social/
│   ├── replay-inspector/
│   └── federation-lab/
├── services/
│   ├── event-kernel/
│   ├── loom/
│   ├── identity/
│   ├── task-market/
│   ├── nex-ledger/
│   ├── lex-ledger/
│   ├── governance/
│   ├── moderation/
│   └── ai-router/
├── adapters/
│   ├── atproto/
│   ├── nostr/
│   ├── noted/
│   └── relay-provider/
├── packages/
│   ├── canonical/
│   ├── schemas/
│   ├── capabilities/
│   ├── crypto-registry/
│   ├── event-types/
│   ├── replay/
│   ├── receipts/
│   ├── privacy-policy/
│   ├── projection-reference/
│   └── testkit/
├── fixtures/
│   ├── identities/
│   ├── social/
│   ├── nex/
│   ├── lex/
│   ├── federation/
│   ├── noted/
│   └── attacks/
├── docs/
├── decisions/
├── threat-models/
├── receipts/
├── handoffs/
├── scripts/
└── STATUS.json
```

This is a target architecture, not a requirement to rename valid Phase 0A files immediately.

The builder should migrate toward it incrementally and document every temporary compatibility layer.

---

# 2. Branch, worktree, and writer rules

## 2.1 Protected integration branch

Use:

```text
main
```

Rules:

- no direct development;
- no force push;
- no history rewrite;
- no automatic merge;
- merge only after sweep acceptance;
- unresolved failures remain on their sweep branch.

## 2.2 Sweep branches

```text
sweep/01-foundation-kernel
sweep/02-nex-economy
sweep/03-social-loom-federation-noted
sweep/04-lex-governance-identity
sweep/05-integrated-testnet
repair/06-breaker-findings
release/07-local-candidate
```

## 2.3 Worktrees

Recommended:

```text
/home/anon/Projects/PA-worktrees/sweep-01-foundation-kernel
/home/anon/Projects/PA-worktrees/sweep-02-nex-economy
/home/anon/Projects/PA-worktrees/sweep-03-social-loom-federation-noted
/home/anon/Projects/PA-worktrees/sweep-04-lex-governance-identity
/home/anon/Projects/PA-worktrees/sweep-05-integrated-testnet
/home/anon/Projects/PA-worktrees/repair-06-breaker-findings
```

## 2.4 One-writer invariant

For each active worktree:

```text
exactly one authorised writer
zero concurrent secondary writers
unlimited read-only reviewers
```

A review agent may inspect the same commit through a separate clean clone or read-only worktree.

Two agents must never mutate the same checkout concurrently.

Parallel work is permitted only where:

- branches are isolated;
- schemas are frozen;
- integration ownership is explicit;
- generated artifacts have independent paths;
- no shared mutable database or lockfile is edited concurrently.

## 2.5 Agent roles

Recommended:

- **Sol Ultra / lead builder:** sole writer for the active sweep.
- **Codex:** bounded repository engineering, tests, packaging, and repairs when explicitly handed a branch.
- **Grok:** adversarial architecture and exploit review.
- **Claude Code:** narrowly scoped repair or independent implementation.
- **ChatGPT:** evidence integration, canon checking, sweep adjudication, and operator handoff.
- **Local/fake models:** deterministic fixtures only until provider activation is separately authorised.

No role label grants repository or operational authority.

---

# 3. Sweep lifecycle

Every sweep follows the same state machine:

```text
PLANNED
→ INPUTS_FROZEN
→ WORKTREE_READY
→ IMPLEMENTING
→ INTERNAL_CHECKPOINTS
→ SELF_TESTING
→ HANDOFF_READY
→ INDEPENDENT_REVIEW
→ ACCEPTED | REPAIR_REQUIRED | HELD | REJECTED
→ MERGED
→ SEALED
```

No sweep skips `INDEPENDENT_REVIEW`.

## 3.1 Frozen input bundle

Before writing:

- current accepted commit;
- clean/dirty status;
- branch and worktree path;
- architecture input files;
- exact SHA-256 manifest;
- role and authority statement;
- secrets scan;
- dependency snapshot;
- open findings;
- expected outputs;
- stop conditions.

Write this to:

```text
receipts/<SWEEP-ID>/INPUT_FREEZE.md
receipts/<SWEEP-ID>/INPUT_SHA256SUMS.txt
```

## 3.2 Pre-sweep recovery artifact

Create at least one:

- Git bundle of the accepted input state;
- source ZIP with manifest;
- verified tag or immutable commit reference.

No destructive cleanup before the recovery artifact exists.

## 3.3 Internal checkpoints

A large coherent sweep may use internal commits.

Recommended pattern:

```text
<SWEEP-ID>.1 schemas and invariants
<SWEEP-ID>.2 core implementation
<SWEEP-ID>.3 projections and UI
<SWEEP-ID>.4 tests and attack fixtures
<SWEEP-ID>.5 documentation and packaging
```

The lead builder should continue without asking for ordinary implementation preferences.

It must stop at an authority gate.

## 3.4 Sweep output bundle

Every sweep returns:

- source commit;
- branch;
- file inventory;
- manifest;
- test report;
- deterministic state hash;
- known limitations;
- unresolved findings;
- failure evidence;
- exact run commands;
- exact review prompt;
- source ZIP or Git bundle;
- SHA-256 receipts.

---

# 4. Sweep 01 — Foundation and Canonical Kernel

**Goal:** Build the substrate that every other subsystem must trust.

**Writer branch:** `sweep/01-foundation-kernel`

## 4.1 Scope

Build:

- canonical serialisation;
- content hashing;
- event IDs;
- schema registry;
- capability envelopes;
- synthetic identity types;
- key fixtures;
- signed-event validation;
- parent/head rules;
- append-only event store;
- deterministic checkpoints;
- replay;
- export/import;
- receipt framework;
- local-only database abstraction;
- reference projection framework;
- source and dependency provenance;
- local operator console;
- Phase 0A compatibility boundary.

## 4.2 Reuse from Phase 0A

Preserve and adapt:

- local-only binding;
- SQLite/migration discipline;
- deterministic export;
- provenance log;
- fake provider interface;
- tests and security checks.

Do not mistake mutable research-note rows for the future canonical social source of truth.

## 4.3 Internal milestones

### S01.1 — Schemas

- canonical event envelope;
- identity objects;
- capability grant;
- access and retention classes;
- receipt schema;
- checkpoint schema;
- algorithm registry.

### S01.2 — Event kernel

- validate;
- accept/reject;
- append;
- sequence;
- checkpoint;
- replay;
- import/export.

### S01.3 — Independent replay

Implement a second replay path that does not call the primary state reducer.

### S01.4 — Operator tools

- inspect log;
- inspect heads;
- verify signatures;
- compare projection hashes;
- export sealed bundle.

### S01.5 — Breakers

- altered bytes;
- duplicate replay;
- orphan parents;
- schema downgrade;
- capability escalation;
- signature mismatch;
- checkpoint divergence;
- malformed oversized inputs.

## 4.4 Acceptance gate

Required:

```text
valid log replay divergence:          0
tampered accepted event admission:    0
self-expanded capabilities:           0
history rewrite:                      0
import/export state mismatch:         0
independent state-hash mismatch:      0
external network listeners:           0
secrets in repository:                0
```

## 4.5 Stop conditions

Stop and report if:

- canonicalisation is ambiguous;
- two independent replays disagree;
- the event store can mutate accepted bytes;
- a capability can grant itself;
- Phase 0A migration would destroy preserved failure evidence;
- public or external infrastructure becomes necessary.

---

# 5. Sweep 02 — NEX Economy and Agent Work Market

**Goal:** Build the full synthetic NEX economy in one coherent run.

**Writer branch:** `sweep/02-nex-economy`

**Input dependency:** accepted Sweep 01.

## 5.1 Scope

Build:

- NEX epoch contract;
- category budgets;
- tasks;
- bids;
- award modes;
- contracts;
- execution receipts;
- verifier assignment;
- verification tiers;
- disputes and adjudication;
- issuance-backed settlement;
- participant-funded escrow;
- barter contracts;
- research allocations;
- retirement and remediation;
- wallet/account UI;
- operator/agent attribution;
- detailed work reputation projections;
- multi-epoch issuance trajectory;
- economic simulations.

## 5.2 Required amendments from Round 9

Include:

- related-party and self-funded work labels;
- independent-work reputation;
- operator-level independence graph;
- budget-necessity review;
- multi-epoch issuance trajectory;
- no rapid epoch reset;
- no participant-funded path to governance-service eligibility;
- no Noted effect on eligibility or reward.

## 5.3 Internal milestones

### S02.1 — Ledger and supply invariants

- integer arithmetic;
- balances;
- issuance;
- transfers;
- locks;
- disputes;
- retirement;
- closure.

### S02.2 — Task market

- publish;
- bid;
- award;
- escrow/reservation;
- cancellation;
- milestones;
- partial work.

### S02.3 — Verification and adjudication

- assignment;
- conflict graph;
- outcome-independent fees;
- contradictions;
- appeals;
- compensating events.

### S02.4 — Audit onboarding

- coverage cells;
- green quotas;
- defect families;
- duplicate prevention;
- environment diversity.

### S02.5 — Simulation

Run all Round 5 and Round 9 NEX campaigns.

## 5.4 Acceptance gate

Required:

```text
unauthorised issuance:                        0
epoch/category overspend:                     0
participant-funded supply increase:           0
settlement without required verification:     0
related-role wash issuance:                   0
duplicate green leakage beyond quota:         0
NEX→LEX event or authority effect:             0
NEX→governance indirect eligibility path:      0
multi-epoch trajectory bypass:                0
independent balance reconstruction mismatch:  0
```

## 5.5 Stop conditions

Stop if:

- a balance cannot reconstruct from genesis;
- the same operator counts as independent worker and verifier;
- supply changes without an authorised event;
- task-market features require an external payment rail;
- the wallet resembles a public cryptocurrency wallet;
- governance or social ranking depends on NEX.

---

# 6. Sweep 03 — Social, LOOM, Native AI, Federation, and Noted

**Goal:** Build the whole social and evidentiary side coherently.

**Writer branch:** `sweep/03-social-loom-federation-noted`

**Input dependency:** accepted Sweep 01. Sweep 02 may remain separate until integration.

## 6.1 Scope

Build:

- social event catalogue;
- profiles, posts, replies, edits, retractions, reactions;
- channels and membership;
- evidence references;
- CLAIM states;
- LOOM RECORD ingestion;
- ROUTE interface;
- source-bound fake AI;
- moderation, quarantine, appeal, remedy;
- privacy and retention classes;
- synthetic verified purge;
- offline queues;
- deterministic feeds/threads;
- chronological and raw views;
- AI influence metrics;
- local AT Protocol laboratory;
- local Nostr laboratory;
- Noted typed bridge;
- deterministic creature and battle fixtures;
- federation and privacy attack tests.

## 6.2 Required amendments from Round 9

Include:

- no universal public identity graph;
- purpose-specific external bindings;
- critical projection reproducibility;
- source-event drill-down;
- contradiction retrieval;
- external-label source-family collapse;
- federation/governance timing separation;
- fork privacy compiler primitives;
- Noted status firewall;
- AI influence measurement;
- static-publication supersession metadata.

## 6.3 AT Protocol boundary

Closed test only:

- synthetic local PDS;
- provisional Lexicons;
- bounded AppView/indexer;
- label adapter;
- migration and backup fixture.

No public federation.

No NEX, LEX, canonical governance, or private evidence in AT records.

## 6.4 Nostr boundary

Closed local relays only:

- posts;
- replies;
- reactions;
- Noted announcements;
- relay divergence;
- deletion uncertainty;
- unknown-kind quarantine.

Reject wallet, zap, ecash, market, and external-payment extensions from Pioneer authority.

## 6.5 Noted boundary

Before implementation:

- locate canonical source candidate;
- verify hashes and provenance;
- inspect licensing and third-party naming;
- freeze ruleset;
- build typed bridge;
- keep renderers outside deterministic game math.

## 6.6 Internal milestones

### S03.1 — Social and LOOM

### S03.2 — Moderation and privacy

### S03.3 — Fake AI and route breakers

### S03.4 — AT Protocol lab

### S03.5 — Nostr lab

### S03.6 — Noted bridge and replay

## 6.7 Acceptance gate

Required:

```text
CLAIM citing ROUTE:                         0
private-to-public leakage:                 0
secret-bearing federation export:         0
AI context expansion without grant:       0
AI final moderation action:               0
external label automatic enactment:       0
adapter outage blocking local state:       0
federation identity becoming Pioneer root:0
Noted invalid milestone genesis:           0
Noted economic/governance effect:          0
projection replay mismatch:                0
```

## 6.8 Stop conditions

Stop if:

- real participant private data becomes necessary;
- public federation or credentials are required;
- external protocol state becomes canonical Pioneer state;
- purge cannot distinguish controlled and external copies;
- Noted source cannot be identified or legally/provenance-cleanly used;
- AI output mutates state without a separate authorised event.

---

# 7. Sweep 04 — LEX, Governance, Identity Maturity, and Emergency Authority

**Goal:** Build the synthetic constitutional system and mature-human interface in one coherent run.

**Writer branch:** `sweep/04-lex-governance-identity`

**Input dependency:** accepted Sweep 01. Uses social and LOOM schemas from frozen Sweep 03 interfaces.

## 7.1 Scope

Build:

- human roots and pseudonyms;
- organisations, agents, service identities, and roles;
- assurance ladder;
- synthetic maturation;
- credential issuer threshold;
- governance nullifiers;
- civic LEX;
- governance-service and social-service LEX;
- source-aware LEX eligibility;
- ballot lock and retirement;
- conviction levels;
- dual majority;
- delegation;
- proposal gateways;
- proposal classes P0–P6;
- tally and independent replay;
- enactment;
- moderation-appeal boundary;
- emergency holds and restart;
- founder transition;
- operational custody transition schema;
- exit and fork;
- guardian recovery;
- compromise handling;
- panel sortition;
- hybrid/PQ algorithm registry and synthetic fixtures.

## 7.2 Required amendments from Round 9

Include:

- governance-service conviction cap;
- same-body conflict delay;
- independent non-incumbent entry paths;
- repeated-emergency controls;
- operational custody transition;
- privacy-safe fork compiler;
- separate federation and governance metadata;
- no Noted or NEX effect on maturity or voting.

## 7.3 Identity scope

Synthetic identities only.

Do not:

- collect real government identity;
- enroll real voters;
- issue real mature-human credentials;
- connect production authenticators;
- make legal identity claims.

## 7.4 Internal milestones

### S04.1 — Identity and credential simulator

### S04.2 — LEX ledger

### S04.3 — Proposal, ballot, tally, enactment

### S04.4 — Delegation, appeals, panels

### S04.5 — Emergency and founder transition

### S04.6 — Recovery, hybrid/PQ, exit and fork

## 7.5 Acceptance gate

Required:

```text
multiple civic credentials per synthetic human:   0
agent/organisation human ballots:                 0
transferred-LEX binding weight:                   0
NEX-derived governance weight:                    0
ballot weight above cap:                          0
proposal passing one majority only:               0
tally divergence producing enactment:             0
protected-boundary ordinary amendment:            0
first appeal blocked for LEX:                      0
expired emergency still active:                   0
unreceipted founder action:                        0
fork privacy violation:                           0
algorithm downgrade acceptance:                   0
independent governance replay mismatch:            0
```

## 7.6 Stop conditions

Stop if:

- identity design requires real identity data;
- issuer or guardian roles collapse into one authority;
- a role creates extra ballot weight;
- the founder can self-certify transition;
- operational custody is treated as transferred without technical evidence;
- governance can alter the NEX/LEX membranes;
- hybrid signatures do not bind identical canonical bytes.

---

# 8. Sweep 05 — Integrated Closed Synthetic Testnet

**Goal:** Combine all accepted subsystems into one local system and run cross-domain scenarios.

**Writer branch:** `sweep/05-integrated-testnet`

**Input dependency:** accepted Sweeps 01–04.

## 8.1 Integration rules

- merge only accepted commits;
- resolve schema conflicts explicitly;
- preserve per-sweep receipts;
- no feature may widen another subsystem’s authority;
- no adapters write canonical balances;
- no AI writes canonical decisions directly;
- no public listeners;
- no real users or secrets.

## 8.2 Synthetic population

At minimum:

- 100 human-root fixtures;
- 200 public pseudonyms;
- 300 agents;
- 20 organisations;
- 20 task publishers;
- 40 verifiers;
- 10 adjudicators;
- 20 moderators;
- 5 identity issuers;
- 5 recovery guardians;
- 10 constitutional/service roles;
- local AT accounts;
- local Nostr keys and relays;
- deterministic Noted creatures.

## 8.3 Campaigns

Run the ten Round 9 campaigns:

1. identity-to-governance capture;
2. indirect NEX-to-LEX conversion;
3. AI-mediated reality distortion;
4. federation privacy collapse;
5. emergency founder recapture;
6. epoch inflation and transition abuse;
7. Noted prestige capture;
8. supply-chain/client authority bypass;
9. private-provider leakage using synthetic secrets;
10. exit and fork during active conflict.

## 8.4 Reference clients

Provide:

- primary operator/social client;
- independent replay inspector;
- minimal raw chronological client;
- deterministic tally checker.

Critical state must remain inspectable without AI ranking.

## 8.5 Acceptance gate

Required:

```text
cross-domain protected-boundary violations:   0
state-hash divergence:                        0
private synthetic data in public export:      0
NEX→governance indirect conversion:           0
Noted→institutional authority conversion:     0
external-adapter sovereignty:                 0
unexpired capability bypass:                  0
fork bundle omission of public dissent:       0
fork bundle inclusion of restricted payload:  0
operator UI able to alter canonical outcome:  0
```

## 8.6 Stop conditions

Stop on any material protected-boundary violation.

Do not “fix forward” while continuing unrelated integrated tests unless the affected scope can be safely frozen and all evidence preserved.

---

# 9. Sweep 06 — Independent Breaker, Repair, and Adjudication

**Branch:** `repair/06-breaker-findings`

This is not a builder self-review.

## 9.1 Independent reviewers

Use at least:

- one architecture critic;
- one implementation/security critic;
- one economic/governance critic;
- one replay/determinism critic.

They must review exact commits and artifacts.

## 9.2 Breaker output

Every finding records:

- ID;
- severity;
- claim;
- exact evidence;
- affected invariant;
- reproduction;
- exploitability;
- proposed repair class;
- whether repair belongs to builder or constitutional review;
- acceptance test.

## 9.3 Repair rule

The original builder may repair implementation defects.

It may not silently resolve:

- constitutional ambiguity;
- public authority;
- legal claims;
- external value;
- identity policy;
- permanent privacy changes;
- founder powers.

Those remain operator decisions or later explicit canon work.

## 9.4 Closure

A finding closes only with:

- repair commit;
- independent reproduction;
- regression test;
- updated risk register;
- no contradictory open finding.

Severity downgrade requires evidence.

---

# 10. Sweep 07 — Local Candidate and Sealed Handoff

**Branch:** `release/07-local-candidate`

## 10.1 Deliverable

A complete local-only candidate that can be reproduced by a fresh operator without secrets.

Include:

- source bundle;
- lockfiles;
- dependency manifest and SBOM;
- run instructions;
- test instructions;
- architecture;
- event schemas;
- synthetic fixtures;
- receipts;
- independent replay;
- known limitations;
- unresolved public blockers;
- hashes;
- explicit no-production status.

## 10.2 Candidate status

Allowed wording:

```text
LOCAL SYNTHETIC CANDIDATE
NO REAL BALANCES
NO PUBLIC GOVERNANCE
NO PUBLIC FEDERATION
NO REAL IDENTITY ENROLLMENT
NO PRODUCTION AUTHORITY
```

Do not use:

- launched;
- decentralised;
- production-ready;
- secure;
- trustless;
- post-quantum secure;
- public economy;
- live governance

unless a later evidence package independently justifies the exact claim.

---

# 11. Progress update protocol

The lead builder sends updates at:

- sweep start;
- each internal checkpoint;
- first material failure;
- self-test completion;
- handoff completion.

Use this exact structure:

```text
SWEEP:
STATE:
COMMIT:
WORKTREE:
AUTHORITY:
WHAT CHANGED:
WHY:
EVIDENCE:
TESTS:
FAILURES PRESERVED:
RISKS / ASSUMPTIONS:
DECISIONS FILLED AUTONOMOUSLY:
OPERATOR DECISION REQUIRED:
NEXT ACTION:
```

Rules:

- ordinary implementation choices are reported, not asked;
- unresolved authority choices are not guessed;
- failures are prominent;
- no optimistic “done” without receipts;
- no hidden branch or filesystem mutation.

---

# 12. Autonomous gap-filling authority

The lead builder may choose and document:

- language and local framework where not already fixed;
- internal package boundaries;
- database and migration implementation;
- UI component details;
- test harnesses;
- ordinary schema field names;
- local port;
- error classes;
- pagination;
- fixture quantities;
- simulation seeds;
- non-security-sensitive thresholds;
- performance optimisations;
- temporary compatibility layers.

The lead builder must not choose autonomously:

- real identity proofing vendor or real identity intake;
- final cryptographic parameter sets;
- production credentials;
- public provider keys;
- public federation;
- public balances;
- public governance;
- legal structure;
- public monetary representations;
- DNS or deployment;
- external value rails;
- permanent founder powers;
- irreversible retention policy;
- a claim that public regulatory obligations do not apply;
- deletion of preserved evidence;
- destructive repository cleanup;
- unresolved submodule/gitlink behaviour.

---

# 13. Global authority stop list

Immediately stop the affected action and continue only unaffected local work when encountering:

- credentials or recovery codes;
- API keys;
- production secrets;
- payment or purchase;
- DNS, registrar, Cloudflare, hosting, or domain change;
- public network exposure or tunnel;
- remote repository creation or push not already authorised;
- public AT/Nostr federation;
- real user account creation;
- real identity documents;
- real private participant data;
- real NEX/LEX balances or migration promises;
- real governance vote;
- external wallet or blockchain integration;
- legal filing or agreement;
- destructive delete/reset/clean;
- force push or history rewrite;
- unreviewed dependency executing remote code;
- requirement to disable an existing security boundary;
- conflict with binding canon;
- inability to preserve failure evidence.

State the exact blocker, evidence, narrowest safe continuation, and required operator choice.

---

# 14. Quality and security gates across all sweeps

Every sweep must run:

- deterministic tests;
- invalid-input tests;
- property/invariant tests;
- migration/replay tests;
- secret scan;
- dependency audit;
- licence/provenance inventory;
- static analysis;
- localhost-only binding check;
- filesystem traversal tests;
- raw HTML/injection tests;
- concurrency/race tests where applicable;
- backup/restore test;
- crash/restart test;
- independent replay where applicable;
- exact artifact manifest.

No claim of success based solely on one green test command.

---

# 15. Handoff package standard

Every handoff ZIP contains:

```text
START_HERE.md
AUTHORITY.md
STATUS.json
SOURCE_IDENTITY.txt
FILE_INVENTORY.txt
SHA256SUMS.txt
TEST_REPORT.md
FAILURES.md
KNOWN_LIMITATIONS.md
DECISIONS.md
RISK_REGISTER.md
RUN_COMMANDS.md
REVIEW_PROMPT.md
source bundle or git bundle
receipts/
```

`START_HERE.md` must state the exact next action.

The review prompt must be pasted separately in the operator-facing message as well as included in the package.

---

# 16. Ultra execution-control structure

The eventual final Sol Ultra prompt must contain, in this order:

1. role;
2. end state;
3. source-of-truth hierarchy;
4. binding prohibitions;
5. repository and branch;
6. one-writer rule;
7. frozen input inventory;
8. sweep scope;
9. exact required artifacts;
10. invariants;
11. tests and breaker cases;
12. autonomous gap-filling permission;
13. authority stop list;
14. progress-update contract;
15. failure-preservation rule;
16. acceptance criteria;
17. final packaging;
18. explicit “do not claim completion without evidence.”

The model should be told:

> Complete the bounded local sweep. Do not wait for clarification on ordinary reversible implementation choices. Identify gaps, choose defensible defaults, record them, and continue. Stop only at an explicit authority boundary or a contradiction that prevents safe progress.

It should not be told simply:

> Finish the whole project no matter what.

That wording would erase the authority model.

---

# 17. Round 10 disposition

```text
Primary local repository selected:          YES
Public repository isolation preserved:      YES
Monorepo target structure defined:           YES
Large coherent sweeps defined:               YES
One-writer rule defined:                     YES
Branch/worktree boundaries defined:          YES
Input freeze and recovery artifacts defined: YES
Progress update contract defined:            YES
Autonomous gap-filling bounded:              YES
Authority stop list defined:                 YES
Acceptance and breaker gates defined:        YES
Handoff standard defined:                    YES
Ultra prompt structure defined:              YES
Implementation authorised by this document:  NO
Public activation authorised:                NO
Canon amended:                               NO
Ready for independent architecture critique: YES
```

## Next step

Send the Round 10 package and Rounds 3–9 packages to an independent high-reasoning model using the included critic prompt.

That model must critique architecture only.

It must not code, mutate repositories, deploy, create credentials, or convert provisional choices into canon.
