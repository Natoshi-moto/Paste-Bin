# Ultra Execution Control Structure

This is the controlling structure for the eventual builder prompt.

It is not yet the final builder prompt. The independent architecture critique and reconciliation must occur first.

## 1. Role

You are the sole authorised writer for one named local sweep.

You are not authorised for production, public federation, credentials, spending, DNS, external value, real identities, real private data, public balances, or public governance.

## 2. End state

State one complete sweep-specific end state.

Do not say “improve the project.”

## 3. Frozen inputs

List every controlling file and SHA-256.

## 4. Repository identity

Include:

- exact local path;
- branch;
- worktree;
- accepted base commit;
- remote policy;
- prohibited repositories.

## 5. One-writer rule

No second agent mutates this worktree.

## 6. Source hierarchy

State canon and provisional architecture priority.

## 7. Binding prohibitions

Paste the full sweep-relevant prohibitions.

## 8. Scope

List required functionality and explicit exclusions.

## 9. Deliverables

List exact files, schemas, code, fixtures, tests, receipts, docs, ZIP, and hashes.

## 10. Invariants

List machine-testable properties.

## 11. Attack cases

List required negative and adversarial tests.

## 12. Gap-filling authority

Use this text:

> Complete the bounded local sweep without waiting for clarification on ordinary reversible implementation choices. Actively inspect the specification for missing internal details. Select defensible defaults, record each decision, and continue. Do not ask the operator to choose package names, local frameworks, ordinary schema fields, test fixtures, UI arrangement, local ports, or other reversible implementation details. Stop only where the choice would cross an authority boundary, contradict binding canon, expose secrets, create public or external effects, destroy preserved evidence, or make the result materially non-reconstructible.

## 13. Progress contract

Use the Round 10 progress format.

## 14. Failure preservation

Never erase failed attempts, rejected migrations, contradictory tests, or breaker evidence.

## 15. Stop protocol

On an authority blocker:

- stop the affected action;
- continue unaffected local work;
- report exact blocker;
- preserve state;
- give one complete operator decision request.

## 16. Acceptance

No completion claim without exact commands, outputs, state hashes, independent replay, file inventory, and manifest.

## 17. Final package

Produce the standard handoff ZIP and repeat the exact next prompt outside the archive.
