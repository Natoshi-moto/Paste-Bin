# Known limitations

## Prominent preserved limitations

**Complete independent R002 verification remains incomplete. Gitlink presence
remains deferred. Historical attribute limitations remain.** The clean status
of this fresh public clone does not independently prove raw-byte equality,
attribute-independent cleanliness, absence of clean/process filter execution,
or universal absence of every external side effect.

**Local build verification does not prove provider-side artifact identity.**
Local verification does not prove live DNS, TLS, caching, MIME types, redirects,
method handling, cookies, headers, or any other provider behavior. Browser and
live network verification remain required against the eventual bounded staging
hostname and again after controlled activation.

**This result is not a universal security guarantee.** It is a bounded result
for one public commit, one inspected reachable history, two local rebuilds, and
the generated static tree.

**No accounts, APIs, databases, submissions, LOOM runtime, Pioneer Relay
runtime, DeepSeek integration, or other model-provider integration are
authorised.** None may be inferred from this release preparation.

## Additional non-blocking limitations and imperfections

- `sitemap.xml` is absent, and `robots.txt` has no Sitemap directive. This is a
  discoverability imperfection, not a hidden pass and not a security stop under
  the governing materiality rule.
- The repository pins `.node-version` to Node 22.16.0, while the local machine
  had Node 24.14.0 and npm 11.9.0. Node 24.14.0 is inside the declared engine
  range `>=22.13.0 <25`; the two byte-identical builds used that same
  toolchain. Cross-version reproducibility was not established here.
- The repository receipt intentionally omits itself. This package independently
  hashes the receipt and provides a complete 21-file manifest aggregate.
- High-confidence credential scans are pattern- and scope-bounded. They are not
  proof that no secret could exist in an encoding or location outside the
  inspected reachable public repository.
- The build emits `dist/server` for the preserved local fallback response-gate
  tests. That directory is not deployable under this candidate. Only
  `dist/client` is authorised, and the production configuration has no Worker
  `main` entrypoint.
- Local method/header/cookie tests exercise the repository's preserved fallback
  gate. The production assets-only host can behave differently; staging must
  independently test every required route, method, MIME type, cache rule, and
  header.
- `verify:live` and `verify:mirror` were read but not executed because no live
  target was authorised. The broader checks in `AGENT_TEST_SCOPE.md` remain
  mandatory; the live verifier alone does not establish every property in that
  scope.
- Full desktop/mobile visual inspection and accessibility review were not
  performed. The bundled hero image was inspected locally, but that is not a
  browser acceptance test.
- No Fasthosts, Cloudflare, DNS, nameserver, provider setting, credential,
  GitHub repository setting, or live deployment was accessed or changed. The
  provider state in the task is operator-supplied and was not independently
  verified.

## Preserved correction record

An auxiliary shell manifest command initially hashed filenames from the wrong
working directory. It printed 21 `No such file or directory` errors and the
SHA-256 of an empty stream while the later commands in the compound shell still
made its overall exit status zero. That result is invalid and was not used.

The first successful independent Node aggregate then used locale-aware sort,
producing `416f564f6cae42cf36ead29559f4ea84ce6cb2a7db9c7dcd0ec170763bffe553`.
The evidence manifest is explicitly defined with `LC_ALL=C` bytewise path
ordering, so the authoritative aggregate is
`77c327bba6263da32570c2b5b1e132fdc1f588ea1750dbfcad95195e81e1cbb0`.
No per-file byte, size, path, or hash changed; only manifest line order differed.

