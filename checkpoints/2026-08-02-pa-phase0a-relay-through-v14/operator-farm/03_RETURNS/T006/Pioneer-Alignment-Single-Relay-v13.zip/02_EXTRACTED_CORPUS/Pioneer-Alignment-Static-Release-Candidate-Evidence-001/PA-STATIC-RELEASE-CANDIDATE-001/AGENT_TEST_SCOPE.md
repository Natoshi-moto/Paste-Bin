# Bounded agent test scope

This scope applies only to an eventual staging hostname explicitly supplied by
the Human Operator for this candidate. It does not authorise provider access,
discovery of other hosts, or testing `lab.pioneeralignment.com`.

## Allowed

- Low-rate `GET`, `HEAD`, and `OPTIONS` requests.
- One request for each of `POST`, `PUT`, `PATCH`, and `DELETE` solely to verify
  rejection, using inert non-personal test bytes.
- Headers, TLS, certificate, protocol, MIME, and cache inspection.
- Homepage, every declared publication route, the licensing route, receipt,
  security record, robots record, static assets, 404, directory-shaped paths,
  and malformed but non-destructive path testing.
- Desktop and mobile rendering.
- Accessibility review.
- Static-artifact comparison against `ARTIFACT_SHA256SUMS.txt` and the public
  site receipt.
- CSP inspection, browser-console review, and remote-resource inspection.

Keep the rate at or below one request per second, avoid concurrency, and stop
after the bounded route/method matrix is complete. Preserve response evidence
without collecting real personal data.

## Required acceptance checks

- Exact receipt bytes and homepage bytes match the reviewed local candidate.
- Every publication and legal route returns the intended static HTML.
- `GET` and `HEAD` behave correctly; `HEAD` is bodyless.
- Mutation methods are refused; record exact status and `Allow` behavior.
- Unknown and directory-shaped paths fail closed without listing.
- No response sets a cookie or contains a browser challenge/injected script.
- CSP includes `script-src 'none'`; the complete declared header envelope is
  present on HTML, errors, refused methods, receipts, and assets as intended.
- MIME types are correct and `nosniff` is present.
- HTML revalidates and fingerprinted assets are immutable.
- TLS and canonical redirects are correct and bounded; no wildcard or unrelated
  host appears.
- Desktop/mobile rendering and accessibility have no release-stopping failure.

## Prohibited

- Denial-of-service or resource exhaustion.
- Load testing, concurrency testing, or high-rate fuzzing.
- Credential attacks, password guessing, token testing, or authentication
  probing.
- Provider-dashboard interaction or provider API calls.
- Origin scanning, port scanning, IP-range scanning, or discovery of unrelated
  infrastructure.
- Persistence, file creation, state creation, or destructive mutation.
- Testing unrelated hosts or following the scope onto linked GitHub or other
  domains.
- Real personal data.
- Testing `lab.pioneeralignment.com`.
- Attempting to bypass Cloudflare, identify an origin, or weaken the configured
  security controls.

Stop immediately and preserve evidence if any rollback trigger in
`ROLLBACK_PLAN.md` is observed.

