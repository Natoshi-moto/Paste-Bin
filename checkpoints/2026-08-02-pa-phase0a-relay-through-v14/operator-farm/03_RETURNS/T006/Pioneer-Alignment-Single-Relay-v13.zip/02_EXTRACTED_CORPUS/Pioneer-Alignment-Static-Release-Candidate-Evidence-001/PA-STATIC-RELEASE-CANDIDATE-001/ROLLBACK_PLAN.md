# Rollback plan

This plan applies only after a later human-authorised deployment or domain
activation. Containment outranks diagnosis.

## Immediate rollback triggers

- artifact-receipt mismatch;
- unexpected script;
- unexpected cookie;
- missing or weakened CSP;
- wrong content;
- MIME error;
- broken TLS;
- broken mail;
- unexpected redirect;
- unexpected Worker code;
- provider-side artifact drift;
- unexplained DNS-record loss.

## Rollback order

1. Detach or disable the custom domain or deployment.
2. Restore the recorded prior DNS/nameserver state.
3. Preserve evidence.
4. Investigate after containment.

## Operational detail

- Record the exact active deployment/version, DNS zone export, nameserver set,
  certificate state, timestamps, and failing response before changing them when
  doing so does not delay containment.
- Prefer detaching the apex from the new deployment before changing source or
  rebuilding. Do not repair live bytes in place.
- Restore the recorded prior nameservers exactly if the cutover itself caused
  the failure. The operator-supplied prior set is `ns1.livedns.co.uk`,
  `ns2.livedns.co.uk`, and `ns3.livedns.co.uk`; it must be independently
  re-read from the operator's cutover record before use.
- Preserve the failing response headers and bodies, release receipt, deployment
  identifier, DNS answers, TLS evidence, screenshots, and UTC/local times.
- Do not delete the failed deployment or evidence until the cause and recovery
  path are understood.
- Re-activate only from the exact reviewed artifact after the complete staging
  and live acceptance suite passes again.

