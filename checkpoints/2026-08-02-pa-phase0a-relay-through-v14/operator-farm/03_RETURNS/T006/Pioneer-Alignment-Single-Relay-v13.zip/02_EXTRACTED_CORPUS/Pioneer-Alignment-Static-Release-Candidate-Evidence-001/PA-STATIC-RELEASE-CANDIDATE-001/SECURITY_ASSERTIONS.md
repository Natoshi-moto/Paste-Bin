# Security assertions

Candidate: `PA-STATIC-RELEASE-CANDIDATE-001`

Classification: **STATIC RELEASE CANDIDATE VERIFIED WITH DECLARED NON-BLOCKING LIMITATIONS**

These are bounded assertions about commit
`7c77c63c1f5648d0ee5001e22be7afab7dbd7d9a`, its locally generated
`dist/client` tree, and the repository's local response model. They are not a
claim of complete security and are not claims about a Cloudflare or other live
response.

## Observed present

- 21 files and 273,343 bytes in the complete deployable `dist/client` tree.
- Seven static HTML pages, one fingerprinted CSS file, two fingerprinted local
  font files, one fingerprinted local WebP image, a local SVG favicon, four
  fingerprinted licensing/provenance records, `robots.txt`, `_headers`,
  `.nojekyll`, `security.txt`, and the public site receipt.
- `Content-Security-Policy` contains `script-src 'none'`, `default-src 'none'`,
  `form-action 'none'`, `frame-ancestors 'none'`, `object-src 'none'`,
  `connect-src 'none'`, and `worker-src 'none'`.
- The declared response envelope contains COOP `same-origin`, CORP
  `same-origin`, `Origin-Agent-Cluster: ?1`, restrictive Permissions Policy,
  `Referrer-Policy: no-referrer`, HSTS `max-age=31536000`, `nosniff`, frame
  denial, DNS-prefetch denial, and cross-domain-policy denial.
- HTML/revalidation and fingerprinted-asset/immutable cache policies are
  declared in `_headers`.
- A source-level local fallback gate exists at `worker/index.js` and the normal
  build copies it to `dist/server` for local contract testing. It is outside
  `dist/client` and is not referenced by the production assets-only Wrangler
  configuration.
- `.openai/hosting.json` contains a project identifier, not a credential, and
  is outside the deployable `dist/client` tree.

## Observed absent within inspected scope

- Browser JavaScript, JavaScript-family output files, WebAssembly, source maps,
  service workers, forms, iframes, objects, embeds, inline event handlers,
  inline styles, active URL schemes, meta refresh, and framework hydration
  markers in `dist/client`.
- Remote browser scripts, stylesheets, fonts, images, media, frames, manifests,
  or other remote subresources. External HTTPS navigation links are present and
  are not browser subresources.
- Analytics code or identifiers, advertising, tracking pixels, application
  cookies, accounts, authentication, database clients, write APIs, submission
  endpoints, browser storage, runtime model calls, DeepSeek integration, LOOM
  runtime, or Pioneer Relay runtime.
- Runtime dependencies, development dependencies, package lifecycle scripts,
  and credential requirements in the committed lockfile/install.
- High-confidence private-key, cloud-token, GitHub-token, model-key,
  credential-bearing URL, or similar credential patterns across all three
  reachable commits and current binary printable strings.
- Symlinks in content or output, submodule declarations, and mode-160000
  gitlink entries in the fresh public clone's current index.
- Any production `main` entrypoint, provider environment variable, provider
  secret, wildcard route, application subdomain, or `lab.pioneeralignment.com`
  deployment scope in `wrangler.assets-only.json`.
- `Set-Cookie` behavior in the repository's local response model.
- Directory listing in the repository's local response model.
- `sitemap.xml`. This absence is recorded as a non-blocking imperfection, not
  misreported as a pass.

## Local behavior verified

- `GET` returned 200 for `/`, four publication routes, and the licensing route.
- `HEAD` returned 200 with no body for the same routes.
- Unknown, traversal-shaped, and directory paths returned 404 without a
  directory listing or diagnostic disclosure.
- `POST`, `PUT`, `PATCH`, `DELETE`, and `OPTIONS` returned 405 with
  `Allow: GET, HEAD` in the preserved local response model.
- All local responses checked carried the declared security envelope and no
  `Set-Cookie` header.
- All eight files under `/assets/` have a filename hash prefix equal to the
  first 16 hex characters of the complete file SHA-256 and received the local
  immutable-cache policy.
- `robots.txt` is exactly `User-agent: *` plus `Allow: /`.
- Seven canonical links resolve under `https://pioneeralignment.com`.

## Integrity and reproducibility

- The repository receipt covers every deployable file except the receipt
  itself and verifies all 20 listed byte lengths and hashes.
- The receipt itself is independently SHA-256 hashed as
  `9ffb620a08185c2189e44289eba92c1d5a87deb6bebb422045c3ad9bf847b221`.
- `ARTIFACT_SHA256SUMS.txt` covers all 21 files. Its SHA-256, used as the
  complete-tree aggregate, is
  `77c327bba6263da32570c2b5b1e132fdc1f588ea1750dbfcad95195e81e1cbb0`.
- Two archive-derived, isolated builds had identical paths, counts, byte
  lengths, file hashes, receipts, `_headers`, and canonical URLs.
- The canonical clone's final `dist/client` matched isolated build A.

## Workflow review

- `verify.yml` has workflow-level `contents: read`; checkout credentials are
  not persisted; it references no secret; it does not use
  `pull_request_target`; and its current-commit public check completed
  successfully.
- `pages.yml` is not triggered by pull requests. Its build job has read-only
  contents authority and uploads a tar created only from `dist/client`. The
  deploy job alone receives the necessary `pages: write` and `id-token: write`
  permissions.
- All four external action references are full 40-hex commit SHAs. Public
  upstream tag refs resolved to those same SHAs for checkout v7.0.1,
  setup-node v6.4.0, upload-artifact v7.0.1, and deploy-pages v5.0.0.
- No Dependabot or Renovate configuration is committed, the package graph is
  empty, and public repository metadata reported Dependabot security updates
  disabled. Repository-private administrative state was not independently
  audited.

## Not established

- Live DNS, nameserver, DNSSEC, TLS, certificate, HTTP/2 or HTTP/3, provider
  routing, cache behavior, MIME behavior, security headers, cookie absence,
  byte identity, redirects, method handling, 404 handling, or rollback.
- Browser rendering, mobile behavior, accessibility, CSP enforcement in a real
  browser, or absence of provider-injected content.
- Universal absence of secrets or compromise outside the inspected reachable
  history and pattern scope.
- Complete independent R002 verification or resolution of the preserved
  historical attribute/gitlink caveats.

