# Controlled Cloudflare UI checklist

This is a human-operator checklist for a later authorised change window. It is
not evidence that any provider action occurred. Dashboard labels may change;
if a control cannot be mapped unambiguously, stop rather than infer authority.

## Before opening or changing a provider

- [ ] Record candidate commit
  `7c77c63c1f5648d0ee5001e22be7afab7dbd7d9a`, complete-tree aggregate
  `77c327bba6263da32570c2b5b1e132fdc1f588ea1750dbfcad95195e81e1cbb0`,
  and receipt hash
  `9ffb620a08185c2189e44289eba92c1d5a87deb6bebb422045c3ad9bf847b221`.
- [ ] Select, independently review, and record one exact Wrangler version. Do
  not use `latest`. Replace `<REVIEWED_WRANGLER_VERSION>` below only after that
  review. This unresolved pin is an activation precondition, not a source
  repair.
- [ ] Reconfirm the complete prior DNS/nameserver record and whether domain mail
  exists. A zero-row exported table does not by itself prove mail is unused.
- [ ] Preserve screenshots/exports of the pending Cloudflare zone and the prior
  registrar state. Confirm that unexplained DNS-record loss triggers rollback.
- [ ] Do not press **I updated my nameservers** and do not change Fasthosts
  nameservers yet.

## Create the assets-only deployment without the apex domain

- [ ] In Cloudflare **Workers & Pages**, create exactly one project/Worker named
  `pioneer-alignment-public` using the GitHub repository
  `Natoshi-moto/pioneer-alignment-public` only.
- [ ] Scope the GitHub connection to that repository only.
- [ ] Set the production branch to `main`.
- [ ] Set the build command exactly to:

  `npm ci --ignore-scripts --no-audit --no-fund && npm run build`

- [ ] Set the deployment command to the reviewed pinned form:

  `npx wrangler@<REVIEWED_WRANGLER_VERSION> deploy --config wrangler.assets-only.json`

- [ ] Add no environment variables, secrets, KV, D1, R2, service bindings,
  queues, durable objects, analytics, model bindings, or credentials.
- [ ] Confirm the effective assets directory is exactly `./dist/client`.
- [ ] Confirm there is no Worker `main` entrypoint and no server bundle in the
  uploaded/deployed asset set.
- [ ] Confirm `workers_dev` is false and preview URLs are false. Do not enable a
  public side URL merely for convenience.
- [ ] Do not add a route, wildcard, custom domain, application subdomain,
  `www`, or `lab.pioneeralignment.com` yet.
- [ ] Disable or leave disabled any feature that injects scripts, challenges,
  analytics, cookies, HTML rewriting, or remote browser resources.

## Controlled staging gate

- [ ] Obtain only an operator-controlled staging endpoint compatible with the
  disabled public-side-URL posture. If Cloudflare offers no such bounded
  endpoint, stop; do not weaken the config or attach the apex as a substitute.
- [ ] Run the complete `AGENT_TEST_SCOPE.md` matrix at low rate.
- [ ] Compare every retrievable static artifact with the public receipt and this
  evidence manifest.
- [ ] Confirm no script, cookie, provider challenge, wrong MIME type, weakened
  header, redirect drift, or unexpected Worker behavior.
- [ ] Record the exact Cloudflare deployment/version identifier and staging
  evidence. Do not continue on a partial pass.

## DNS and custom-domain activation

- [ ] Recompare every Fasthosts record with the pending Cloudflare zone and
  resolve mail, MX, SPF, DKIM, DMARC, verification TXT, CAA, and DNSSEC/DS
  questions before changing nameservers.
- [ ] Confirm the pending Cloudflare zone contains exactly the intended records;
  introduce no wildcard and no `lab` record.
- [ ] In the Fasthosts registrar UI, replace the recorded prior nameservers only
  during the authorised change window with exactly:
  `julissa.ns.cloudflare.com` and `rommy.ns.cloudflare.com`.
- [ ] Return to Cloudflare and press **I updated my nameservers** only after the
  registrar change is saved and independently recorded.
- [ ] Wait until Cloudflare reports the zone active and independently check
  public delegation. Do not infer activation from the button press.
- [ ] Add only `pioneeralignment.com` as the Worker Custom Domain.
- [ ] After the apex passes, add one controlled permanent redirect from
  `www.pioneeralignment.com` to the apex if explicitly approved. Do not use a
  wildcard.
- [ ] Do not add `lab.pioneeralignment.com`.
- [ ] Enable DNSSEC only after the new zone is stable; record the DS material and
  install it at the registrar through a separate deliberate step.
- [ ] Keep HSTS at the artifact-declared `max-age=31536000`; do not add
  `includeSubDomains` or preload.

## Acceptance and observation

- [ ] Run the bounded staging matrix again against
  `https://pioneeralignment.com`.
- [ ] Run `npm run verify:live -- https://pioneeralignment.com` from the exact
  reviewed local build, then supplement it with the full route/method/MIME/cache
  and browser scope in `AGENT_TEST_SCOPE.md`.
- [ ] Confirm the live receipt and every checked byte identify this candidate.
- [ ] Confirm mail, TLS, redirects, DNS answers, headers, MIME types, cache
  policies, cookies, and browser behavior.
- [ ] Begin a deliberate observation window with the prior nameserver and
  deployment rollback record immediately available.
- [ ] On any trigger in `ROLLBACK_PLAN.md`, contain first using the recorded
  rollback order.

