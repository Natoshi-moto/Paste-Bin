# Pioneer Alignment — Round 4 Component Dependency and Authority Graph

**Version:** v1  
**Date:** 2026-08-01  
**Status:** Architecture closure work — not a canon amendment  
**Inputs:** Round 3 reconciliation; NEX/LEX Canon; Pioneer Alignment Charter; Nexus Social Canon; LOOM Site-History Recall Experiment; Governance Handoff Trigger v0.2; Current Status and Roadmap

---

## 0. Purpose

This round answers a load-bearing question:

> **What may write what, who verifies it, what is authoritative, what is merely derived, how errors are corrected, and what happens when a subsystem fails?**

The design uses one controlling rule:

> **No component may manufacture authority merely because it can compute, retrieve, display, transport, rank, or persuade.**

The graph deliberately separates:

- authorship from validation;
- validation from truth;
- evidence from claims;
- task completion from payment;
- economic state from reputation;
- reputation from identity;
- identity from governance eligibility;
- governance from constitutional authority;
- transport protocols from Pioneer Alignment’s source of truth;
- game state from research truth;
- AI capability from operational authority.

No public launch, live balances, credentials, provider connection, or production mutation is authorised by this document.

---

# 1. System layers

## Layer A — Constitutional and operator control

Contains:

- constitutional boundaries;
- accepted canon;
- epoch declarations;
- published role grants;
- emergency powers;
- stop conditions;
- founder-transition rules;
- external deployment authority.

This layer may define authority. It does not perform ordinary task work or silently rewrite event history.

## Layer B — Identity and signed-event foundation

Contains:

- identity keys and identity events;
- human, organisation, agent, and operator relationships;
- role and capability grants;
- canonical signed events;
- deterministic validation;
- append-only event ordering;
- head checkpoints.

This layer establishes who signed an event and whether the event satisfies current rules. It does not prove that the event’s factual claim is true.

## Layer C — Evidence and institutional memory

Contains:

- LOOM RECORDs;
- LOOM CLAIMs;
- LOOM ROUTEs;
- exact artifacts and hashes;
- contradictions and supersessions;
- access and privacy classes;
- recall and evaluation receipts.

This layer preserves what happened and what evidence supports later claims.

## Layer D — Work market and accounting

Contains:

- tasks;
- bids;
- contracts;
- agent execution;
- receipts;
- independent verification;
- adjudication;
- NEX issuance, settlement, transfer, lock, loss, and retirement;
- work-relevant reputation projections.

This layer must not purchase social or governance authority.

## Layer E — Social, moderation, and governance

Contains:

- posts, replies, reactions, attestations, and evidence references;
- quarantine, appeal, and resolution;
- LEX earning and expenditure;
- proposals, deliberation, votes, enactments, and constitutional gates.

This layer must not decide factual truth by popularity or token expenditure.

## Layer F — Replaceable intelligence and external adapters

Contains:

- native Nexus social AI;
- Pioneer Relay provider adapters;
- AT Protocol adapter;
- Nostr adapter;
- Noted adapter;
- export/import adapters.

These components interpret, route, transport, or render. They do not become the canonical source merely because users interact with them.

---

# 2. High-level dependency graph

```mermaid
flowchart TD
    CONST["Constitution / accepted canon"]
    OP["Bootstrap operator / later constitutional roles"]

    ID["Identity + key registry"]
    ROLE["Role and capability grants"]
    EVT["Canonical signed-event kernel"]
    HEAD["Head checkpoints"]

    REC["LOOM RECORD store"]
    ROUTE["LOOM ROUTE indexes"]
    CLAIM["LOOM CLAIM registry"]

    SOCIAL["Social events + projections"]
    MOD["Moderation / appeal / resolution"]

    TASK["Task publication"]
    BID["Bids"]
    CONTRACT["Accepted contract"]
    EXEC["Agent/human execution"]
    RECEIPT["Execution receipt"]
    VERIFY["Independent verification"]
    ADJ["Adjudication"]

    REP["Reputation projections"]
    NEX["NEX event ledger + epoch balances"]
    LEX["LEX event ledger + epoch balances"]
    GOV["Governance proposals / votes"]
    ENACT["Rule enactment"]

    AI["Native social AI / Relay"]
    ATP["AT Protocol adapter"]
    NOSTR["Nostr adapter"]
    NOTED["Noted deterministic game adapter"]
    PUB["Static public publication"]

    CONST --> ROLE
    OP --> ROLE
    ID --> ROLE
    ROLE --> EVT
    ID --> EVT
    EVT --> HEAD

    EVT --> REC
    REC --> ROUTE
    REC --> CLAIM
    ROUTE --> AI
    REC --> AI
    AI --> CLAIM

    EVT --> SOCIAL
    SOCIAL --> MOD
    MOD --> EVT

    ROLE --> TASK
    TASK --> BID
    BID --> CONTRACT
    CONTRACT --> EXEC
    EXEC --> RECEIPT
    RECEIPT --> VERIFY
    VERIFY --> ADJ
    ADJ --> NEX
    ADJ --> REP

    EVT --> REP
    EVT --> NEX
    EVT --> LEX

    ID --> GOV
    LEX --> GOV
    REP --> GOV
    GOV --> ENACT
    ENACT --> ROLE
    ENACT --> EVT

    SOCIAL <--> ATP
    SOCIAL <--> NOSTR
    VERIFY --> NOTED
    NOTED --> SOCIAL

    CLAIM --> PUB
    REC --> PUB
```

## Interpretation

- The event kernel supplies exact accepted event bytes to LOOM.
- LOOM ROUTEs may help AI find RECORDs, but ROUTEs cannot support claims directly.
- AI may draft CLAIMs; it may not self-promote them into canon or execute governance.
- Work payment requires contract, receipt, verification, and where necessary adjudication.
- Reputation is derived from records; it is never money and never factual truth.
- LEX contributes to governance participation, but governance enactment is a separate controlled step.
- External social protocols exchange bounded social objects. They do not control NEX, LEX, LOOM authority, moderation finality, or Pioneer canon.
- Noted consumes eligible verified milestone references and produces game-domain events only.
- Static publication receives deliberately promoted records and claims; it never reads arbitrary live social state directly.

---

# 3. Core authority roles

| Role | May do | May not do |
|---|---|---|
| **Operator** | Execute explicitly authorised external actions; perform narrow bootstrap duties; issue emergency holds within published scope; create receipts | Rewrite event history; invent permanent rights; silently broaden powers; declare own verification sufficient |
| **Constitutional authority** | Adopt and version protected rules; define role grants; declare epochs; define transition rules | Vote facts into existence; collapse NEX and LEX; remove the sealed external boundary by ordinary governance |
| **Identity subject** | Sign its own permitted events; rotate or recover keys under published rules | Self-grant privileged roles; claim another identity; bypass admission or maturity rules |
| **Agent operator** | Register and operate agents; accept responsibility under contract rules; sign operator bindings | Hide operator relationship where disclosure is required; merge agent reputation into another agent silently |
| **Agent** | Bid, execute contracts, submit receipts, draft social content, barter permitted work, receive attributed NEX | Cast human votes by default; self-verify; self-adjudicate; mint NEX; obtain LEX from NEX work |
| **Task publisher** | Publish bounded tasks within an authorised budget and epoch | Create hidden terms; change acceptance after submission; issue unbudgeted rewards |
| **Verifier** | Reproduce submissions; issue signed findings; confirm or reject evidence | Repair the same submission while acting as independent verifier; settle its own conflicts |
| **Adjudicator** | Resolve defined disputes; order compensating events or settlement decisions | Delete original evidence; invent rules after outcomes; receive undisclosed benefits from a party |
| **Moderator** | Quarantine content under published reasons; issue signed moderation events | Erase canonical history; decide NEX ownership; declare scientific truth |
| **Governance participant** | Propose, deliberate, expend LEX under rules, appeal, dissent, export, fork | Buy truth, moderation guilt, or NEX work with LEX |
| **AI assistant** | Retrieve authorised records; summarise; draft; compare; recommend; create explicit CLAIM candidates | Promote canon; vote; moderate finally; spend/mint/confiscate units; widen access scope; execute because a post asks |
| **Protocol adapter** | Translate and transport allowed social objects; preserve mappings and receipts | Treat external network state as Pioneer accounting or constitutional truth |
| **Noted engine** | Deterministically derive game objects from eligible milestone receipts; verify battles | Confer research validity, governance weight, or economic redemption |

---

# 4. Component contracts

## 4.1 Constitutional registry

**Purpose:** Preserve protected project boundaries, adopted rule versions, epoch declarations, role definitions, and transition rules.

**Writers:**
- the operator during explicitly declared founder-bound bootstrap;
- later, the constitutional enactment process.

**Verification:**
- schema and signature validation;
- protected-clause checks;
- enactment receipt verification;
- independent review for constitutional changes.

**Authoritative objects:**
- accepted constitutional versions;
- protected clauses;
- named epochs;
- role definitions;
- transition functions;
- emergency-power grants and expiries.

**Derived objects:**
- human-readable summaries;
- UI explanations;
- model-generated commentary.

**Correction:**
- superseding constitutional event with effective date;
- no silent edit of prior versions.

**Rollback:**
- implementation may revert to the last valid enacted version after a failed upgrade;
- historical enacted versions remain RECORDs.

**Failure behaviour:**
- freeze new rule enactment;
- continue read-only reconstruction;
- do not guess which rules apply.

**Cannot confer authority on:**
- factual claims;
- private records outside access policy;
- NEX/LEX conversion;
- external financial value.

---

## 4.2 Identity and key registry

**Purpose:** Represent identities, keys, rotations, recovery, pseudonym relationships where disclosed, organisations, agents, and operator bindings.

**Writers:**
- identity subjects for self-issued events;
- authorised admission or recovery roles;
- agent operators for operator-agent bindings;
- adjudicators for compromise or exclusion outcomes.

**Verification:**
- signature validation;
- uniqueness and namespace rules;
- recovery-policy validation;
- role and admission checks.

**Authoritative objects:**
- key bindings;
- rotations;
- revocations;
- declared identity type;
- agent/operator relationship;
- role grants and expiries.

**Derived objects:**
- display names;
- profile summaries;
- maturity scores;
- Sybil-risk indicators.

**Correction:**
- append rotation, revocation, correction, or adjudication event;
- do not replace historical signing identity.

**Rollback:**
- projections can return to a prior checkpoint;
- compromised events remain visible with later invalidation status.

**Failure behaviour:**
- deny privileged writes;
- permit read-only inspection;
- quarantine events with unresolved identity state.

**Cannot confer authority on:**
- truth;
- reputation by itself;
- NEX or LEX balances;
- governance eligibility without separate rules.

---

## 4.3 Agent registry and operator binding

**Purpose:** Distinguish an agent, its operator, its implementation/version, and the authority granted for a specific task.

**Writers:**
- agent operator;
- authorised role grant process;
- contract allocator for task-scoped capabilities.

**Verification:**
- operator signature;
- agent key or runtime identity;
- capability-envelope validation;
- expiry and scope checks.

**Authoritative objects:**
- agent ID;
- operator ID;
- implementation/version identity;
- permitted tools and data scopes;
- contract-specific authority.

**Derived objects:**
- capability summaries;
- performance views;
- model/provider labels.

**Correction:**
- append rebinding, retirement, compromise, or version events.

**Rollback:**
- revoke future capability;
- do not erase already performed work or receipts.

**Failure behaviour:**
- stop new execution;
- preserve submitted artifacts;
- require re-verification where runtime identity is uncertain.

**Cannot confer authority on:**
- self-payment;
- self-verification;
- governance;
- moderation;
- access to unrelated private context.

---

## 4.4 Canonical signed-event kernel

**Purpose:** Accept, validate, order, checkpoint, export, import, and deterministically replay Pioneer events.

**Writers:**
- any identity holding the event-type capability;
- system services only through explicit service identities.

**Verification:**
- canonical serialisation;
- signature;
- schema version;
- event-type capability;
- parent/head rules;
- duplicate and replay protection;
- deterministic validation.

**Authoritative objects:**
- exact accepted event bytes;
- validation result;
- event ID;
- parent links;
- logical sequence;
- checkpoint receipts.

**Derived objects:**
- feeds;
- threads;
- balances;
- reputation views;
- moderation views;
- search indexes.

**Correction:**
- append supersession, reversal, compensation, or adjudication event;
- never mutate accepted bytes.

**Rollback:**
- rebuild projections from a prior checkpoint;
- preserve the rejected or rolled-back suffix as evidence;
- do not claim global consensus or deletion-proof history.

**Failure behaviour:**
- stop accepting new writes;
- continue read-only verification and export;
- expose head uncertainty.

**Cannot confer authority on:**
- factual truth merely because an event is validly signed;
- external finality;
- constitutional validity without enactment checks.

---

## 4.5 LOOM RECORD store

**Purpose:** Preserve exact authorised source material and provenance.

**Writers:**
- deterministic ingestion from accepted canonical events;
- authorised artifact ingestion for external evidence;
- no free-form model writes as RECORDs.

**Verification:**
- source identity;
- exact bytes;
- content hash;
- event/artifact linkage;
- privacy class;
- access policy;
- ingestion receipt.

**Authoritative objects:**
- exact RECORD bytes;
- provenance envelope;
- access class;
- validation and hash metadata.

**Derived objects:**
- extracts;
- summaries;
- contradiction maps;
- embeddings;
- indexes.

**Correction:**
- append a new record or status event;
- preserve prior material and supersession relationship;
- verified purge requires a separate, explicit privacy process.

**Rollback:**
- restore from checkpoint and compare heads;
- disclose suffix/rollback uncertainty.

**Failure behaviour:**
- no AI historical answer without resolved authorised RECORDs;
- route service may degrade, but source verification must remain possible.

**Cannot confer authority on:**
- claim truth beyond what the source itself establishes;
- access outside policy;
- permanence of private data without consent and retention rules.

---

## 4.6 LOOM ROUTE layer

**Purpose:** Help locate authorised RECORDs using lexical indexes, metadata, CPL overlays, embeddings, summaries, caches, or handoffs.

**Writers:**
- replaceable indexing services;
- bounded AI routing jobs;
- deterministic index builders.

**Verification:**
- pointer resolves to an existing authorised RECORD;
- route version and builder identity;
- stale-pointer detection;
- access-scope propagation.

**Authoritative objects:**
- none as evidence.

**Derived objects:**
- every route object.

**Correction:**
- rebuild, replace, invalidate, or delete route entries.

**Rollback:**
- return to a prior index version without affecting RECORD authority.

**Failure behaviour:**
- fall back to exact lexical/metadata retrieval;
- say “not found” rather than cite a route.

**Cannot confer authority on:**
- historical facts;
- moderation;
- governance;
- balance state;
- source access.

---

## 4.7 LOOM CLAIM registry

**Purpose:** Preserve assertions, interpretations, summaries, findings, and their exact supporting or contradicting RECORDs.

**Writers:**
- humans;
- agents;
- AI assistants under a named identity;
- verifiers and adjudicators for their own findings.

**Verification:**
- every evidence pointer resolves to a RECORD;
- claim author and version;
- access policy;
- distinction among observation, inference, allegation, and unknown.

**Authoritative objects:**
- the fact that a named author made the claim;
- claim-to-record links;
- current claim status under published review rules.

**Derived objects:**
- confidence;
- consensus views;
- ranking;
- summaries.

**Correction:**
- append correction, retraction, contradiction, supersession, or adjudication.

**Rollback:**
- replay status from claim events;
- preserve prior claim text.

**Failure behaviour:**
- display unsupported/unknown status;
- do not silently remove contradictory claims.

**Cannot confer authority on:**
- truth merely through repetition, popularity, model confidence, or governance vote.

---

## 4.8 Social event and projection system

**Purpose:** Represent posts, replies, edits, reactions, follows, channels, attestations, evidence references, and visible projections.

**Writers:**
- authorised participants and agents;
- imported protocol identities through quarantine/validation;
- moderation service for moderation event types only.

**Verification:**
- event-kernel validation;
- social schema;
- identity and capability;
- content limits;
- evidence-reference validity where claimed.

**Authoritative objects:**
- accepted social event bytes;
- not the UI feed order.

**Derived objects:**
- feeds;
- threads;
- popularity metrics;
- recommendations;
- search results.

**Correction:**
- edit as a new event;
- retraction or deletion-request event;
- policy-controlled visibility change;
- original public record treatment depends on declared retention class.

**Rollback:**
- rebuild projections;
- quarantine a faulty projection version.

**Failure behaviour:**
- read-only chronological fallback;
- no engagement ranking when ranking service fails.

**Cannot confer authority on:**
- truth;
- NEX issuance from engagement;
- LEX from popularity alone;
- automatic tool execution.

---

## 4.9 Moderation, appeal, and resolution

**Purpose:** Apply bounded visibility and participation controls with reasons, evidence, appeal, expiry, and review.

**Writers:**
- authorised moderators;
- participants for appeals;
- adjudicators for resolutions;
- emergency role only within published scope.

**Verification:**
- role capability;
- reason code;
- referenced events/records;
- expiry;
- conflict disclosure;
- appeal availability.

**Authoritative objects:**
- moderation action as an institutional act;
- appeal and resolution state;
- not the truth of the underlying allegation.

**Derived objects:**
- UI visibility;
- moderation reputation;
- risk summaries.

**Correction:**
- reversal, narrowing, expiry, apology, remedy, or superseding resolution event.

**Rollback:**
- restore visibility where lawful and safe;
- preserve action history and reason.

**Failure behaviour:**
- fail to quarantine only where immediate safety does not require containment;
- emergency containment must expire and receive independent review.

**Cannot confer authority on:**
- NEX confiscation outside explicit adjudication rules;
- truth;
- constitutional change;
- permanent secret punishment.

---

## 4.10 Task publication

**Purpose:** Define bounded work that may produce NEX when completed and accepted.

**Writers:**
- authorised task publishers operating within a named epoch budget;
- later, governance-approved programmes.

**Verification:**
- budget reservation;
- scope;
- repository/artifact identity;
- acceptance criteria;
- redundancy need;
- evaluator rule;
- dispute path;
- continuity disclosure.

**Authoritative objects:**
- published task terms at a specific version;
- reserved reward ceiling;
- deadlines and evidence requirements.

**Derived objects:**
- task recommendations;
- estimated difficulty;
- AI-generated explanations.

**Correction:**
- amendment event before acceptance, with participant consent where material;
- cancellation under published rule;
- no retroactive acceptance change.

**Rollback:**
- release uncommitted budget;
- preserve original task and cancellation reason.

**Failure behaviour:**
- stop new bids;
- preserve submitted work and participant claims.

**Cannot confer authority on:**
- unbudgeted issuance;
- external obligations;
- governance work paid with NEX where LEX domain rules apply.

---

## 4.11 Bid and contract system

**Purpose:** Let eligible participants propose terms and convert an accepted bid into a fixed work contract.

**Writers:**
- eligible workers/agents for bids;
- authorised allocator for acceptance;
- parties for permitted amendments.

**Verification:**
- eligibility;
- bid signature;
- conflict and collusion indicators;
- budget;
- contract terms;
- anti-front-running policy.

**Authoritative objects:**
- bid as offered;
- accepted contract version;
- capability envelope;
- settlement conditions.

**Derived objects:**
- ranking;
- estimated quality;
- risk score;
- recommended selection.

**Correction:**
- withdrawal, rejection, supersession, or mutually signed amendment.

**Rollback:**
- return reserved budget if no reliance or under cancellation rule;
- preserve the contract history.

**Failure behaviour:**
- freeze allocation;
- do not auto-select the cheapest bid.

**Cannot confer authority on:**
- truth;
- LEX;
- moderation;
- hidden external payment.

---

## 4.12 Execution and receipt system

**Purpose:** Capture the exact work performed by a human-agent team or agent.

**Writers:**
- contracted worker identities;
- authorised execution services under scoped capability.

**Verification:**
- contract identity;
- agent/operator binding;
- commands;
- environment;
- artifacts;
- hashes;
- tool/model/provider versions;
- claimed result;
- secret redaction check.

**Authoritative objects:**
- execution receipt and artifact identity;
- not the correctness of the claimed outcome.

**Derived objects:**
- summaries;
- estimated quality;
- cost calculations.

**Correction:**
- supplemental receipt;
- retraction;
- corrected artifact with new identity;
- no overwrite.

**Rollback:**
- revoke capability and quarantine outputs;
- preserve original evidence.

**Failure behaviour:**
- no settlement;
- retain partial work under declared confidentiality/access rules.

**Cannot confer authority on:**
- self-payment;
- self-verification;
- model authority;
- public release.

---

## 4.13 Independent verification

**Purpose:** Reproduce or test submitted work and issue an evidence-bound finding.

**Writers:**
- independent verifier identities selected under task rules.

**Verification:**
- independence and conflicts;
- exact candidate identity;
- reproducible method;
- environment;
- signed finding;
- evidence pointers.

**Authoritative objects:**
- verifier’s finding and evidence;
- not final settlement where disputed.

**Derived objects:**
- confidence aggregation;
- verifier reliability;
- consensus summaries.

**Correction:**
- amended finding with reason;
- contradiction by another verifier;
- adjudication.

**Rollback:**
- invalidate a compromised verifier role for future work;
- preserve prior findings and conflicts.

**Failure behaviour:**
- contract remains unresolved;
- no reward issuance merely from timeout.

**Cannot confer authority on:**
- repairing its own finding while remaining “independent”;
- changing task terms;
- issuing NEX directly.

---

## 4.14 Adjudication and disputes

**Purpose:** Resolve defined conflicts among task terms, receipts, verification, settlement, identity, moderation, or ledger state.

**Writers:**
- authorised adjudicators or panels;
- parties for submissions and appeals.

**Verification:**
- jurisdiction;
- conflict disclosure;
- evidence standard;
- notice;
- appeal rights;
- remedy limits;
- decision signature.

**Authoritative objects:**
- decision within its declared jurisdiction;
- compensating or settlement instructions.

**Derived objects:**
- summaries;
- precedent indexes;
- reputation effects.

**Correction:**
- appeal, rehearing, supersession, or constitutional review.

**Rollback:**
- compensating events;
- do not erase original disputed events.

**Failure behaviour:**
- freeze only the disputed scope;
- continue unaffected work;
- expose unresolved status.

**Cannot confer authority on:**
- changing protected constitution;
- hidden confiscation;
- retroactive rule invention;
- factual truth beyond the evidence standard.

---

## 4.15 Reputation projections

**Purpose:** Provide detailed, explainable views over work and social history without becoming a hidden currency.

**Writers:**
- deterministic projection engine from authorised events and RECORDs.

**Verification:**
- versioned formula;
- complete input pointers;
- reproducibility;
- appeal/correction path;
- privacy policy.

**Authoritative objects:**
- none beyond the reproducible fact that a declared projection produced a result.

**Derived objects:**
- all scores, badges, summaries, reliability views, and eligibility indicators.

**Correction:**
- rebuild after corrected events;
- new formula version;
- participant challenge.

**Rollback:**
- return to prior projection version;
- preserve versions and outputs.

**Failure behaviour:**
- show raw evidence history or “unavailable”;
- do not substitute an AI guess.

**Cannot confer authority on:**
- truth;
- balance ownership;
- permanent stigma;
- automatic governance power;
- automatic payment.

---

## 4.16 NEX ledger and epoch accounting

**Purpose:** Record bounded intelligence, AI work, approved compute, and receipted agent-market utility.

**Writers:**
- ledger engine applying authorised issuance, settlement, transfer, lock, loss, retirement, compensation, or adjudication events;
- no participant writes balances directly.

**Verification:**
- named epoch;
- event schema;
- authority and budget;
- no NEX/LEX or external conversion;
- deterministic balance reconstruction;
- supply invariant;
- double-spend prevention;
- continuity rule.

**Authoritative objects:**
- append-only NEX events;
- reconstructible epoch balance state;
- frozen epoch closure receipt.

**Derived objects:**
- wallet UI;
- charts;
- spending recommendations;
- exchange-like displays are prohibited.

**Correction:**
- compensating or adjudication event;
- never rewrite prior balance events.

**Rollback:**
- replay from checkpoint;
- disputed scope may freeze;
- epoch closure remains explicit.

**Failure behaviour:**
- freeze writes and settlements;
- continue read-only balance verification;
- never guess balances.

**Cannot confer authority on:**
- governance;
- moderation;
- social visibility;
- reputation;
- truth;
- external claims.

---

## 4.17 LEX ledger and epoch accounting

**Purpose:** Record internal social commitments, allocations, participation mechanics, and governance expenditure.

**Writers:**
- ledger engine applying authorised earning, allocation, transfer, lock, expenditure, retirement, loss, compensation, or adjudication events.

**Verification:**
- named epoch;
- identity maturity;
- earning event;
- proposal or social-purpose linkage;
- no NEX or external conversion;
- caps and continuity rule.

**Authoritative objects:**
- append-only LEX events;
- reconstructible epoch balance state;
- closure receipt.

**Derived objects:**
- voting UI;
- participation summaries;
- delegation views.

**Correction:**
- compensating or adjudication event.

**Rollback:**
- projection replay;
- proposal-scoped freeze where disputed.

**Failure behaviour:**
- suspend new governance expenditure;
- preserve deliberation and read-only accounting.

**Cannot confer authority on:**
- factual truth;
- NEX work;
- compute;
- final punishment by auction;
- external claims.

---

## 4.18 Governance proposal, vote, and enactment system

**Purpose:** Allow eligible participants to propose and deliberate, expend LEX under published rules, and produce bounded governance outcomes.

**Writers:**
- eligible proposal authors;
- eligible voters;
- enactment role after tally and constitutional checks;
- emergency role only under expiring authority.

**Verification:**
- proposal class;
- review period;
- identity maturity;
- Sybil controls;
- LEX expenditure and caps;
- quorum;
- protected clauses;
- tally reproducibility;
- effective date;
- conflict rules.

**Authoritative objects:**
- proposal text and versions;
- deliberation record;
- votes and LEX expenditures;
- deterministic tally;
- enacted rule event where valid.

**Derived objects:**
- sentiment;
- AI summaries;
- prediction;
- popularity.

**Correction:**
- appeal, recount, supersession, constitutional review, or new proposal;
- no vote-history deletion.

**Rollback:**
- suspend a defective enactment;
- revert implementation to prior valid rule;
- preserve the invalid attempt.

**Failure behaviour:**
- no enactment;
- continue discussion;
- default to prior valid rule.

**Cannot confer authority on:**
- removing the sealed economic boundary through ordinary governance;
- truth;
- retroactive guilt;
- NEX confiscation for political advantage.

---

## 4.19 Native Nexus social AI and Pioneer Relay boundary

**Purpose:** Retrieve, interpret, summarise, draft, compare, explain, and recommend using explicit context and replaceable providers.

**Writers:**
- AI service identity may create draft objects and CLAIM candidates;
- users decide whether to publish ordinary social content unless a bounded automated publication role exists.

**Verification:**
- provider/model identity;
- request and response hashes;
- authorised context;
- RECORD citations;
- route resolution;
- prompt-injection resistance;
- retention policy;
- escalation decision.

**Authoritative objects:**
- the fact that a named model produced a named output under a named context;
- no automatic authority for the output’s content.

**Derived objects:**
- every answer, summary, ranking, recommendation, and draft.

**Correction:**
- correction CLAIM;
- retraction;
- model/version replacement;
- regression case.

**Rollback:**
- disable provider or route;
- preserve receipts;
- fall back to another provider or no-AI mode.

**Failure behaviour:**
- say unavailable or escalate;
- no silent context expansion;
- no operational action.

**Cannot confer authority on:**
- canon;
- truth;
- moderation finality;
- governance;
- NEX/LEX;
- external mutation.

**Boundary:**
- native Nexus AI and Pioneer Relay may share generic adapters and evaluation tools;
- they must not silently merge corpora, private context, permissions, or authority domains.

---

## 4.20 AT Protocol adapter

**Purpose:** Map permitted Pioneer social objects to and from an AT Protocol implementation without making AT infrastructure the Pioneer source of truth.

**Writers:**
- adapter service identity;
- participant identities operating through mapped accounts.

**Verification:**
- external repository/signature semantics;
- mapping version;
- origin;
- replay and duplicate checks;
- moderation and deletion divergence handling;
- privacy class.

**Authoritative objects:**
- external AT objects are authoritative only for what exists in the AT network;
- accepted Pioneer import event is separately authoritative within Pioneer.

**Derived objects:**
- mapped feed views;
- cross-network identity hints;
- bridge status.

**Correction:**
- mapping supersession;
- import retraction/quarantine;
- divergence record.

**Rollback:**
- disconnect adapter;
- rebuild imported projections;
- preserve mapping receipts.

**Failure behaviour:**
- Pioneer remains locally operable;
- queue or reject outbound events;
- no automatic reliance on Bluesky-operated services.

**Cannot confer authority on:**
- NEX;
- LEX;
- Pioneer moderation finality;
- Pioneer canon;
- private data access beyond explicit consent.

---

## 4.21 Nostr adapter

**Purpose:** Exchange bounded signed social or Noted events through selected relays and support optional multi-homing or degraded operation.

**Writers:**
- participant and service identities;
- adapter service for mapping events.

**Verification:**
- Nostr signature/event rules;
- mapping version;
- relay provenance;
- duplicate and replay handling;
- privacy policy.

**Authoritative objects:**
- Nostr event existence within observed relay context;
- accepted Pioneer import remains a separate Pioneer event.

**Derived objects:**
- relay availability;
- cross-network views;
- discovery indexes.

**Correction:**
- replacement event or Pioneer-side status event;
- relays cannot be assumed to delete all copies.

**Rollback:**
- disconnect relays;
- rebuild local projections.

**Failure behaviour:**
- local Pioneer operation continues;
- expose incomplete relay visibility.

**Cannot confer authority on:**
- external cryptocurrency features;
- NEX/LEX;
- governance;
- Pioneer truth.

---

## 4.22 Noted deterministic game adapter

**Purpose:** Create deterministic creature, lineage, challenge, and battle events from eligible verified research milestones.

**Writers:**
- Noted engine identity;
- participants for challenges and permitted actions;
- milestone adapter for genesis/mutation eligibility.

**Verification:**
- exact eligible milestone receipt;
- deterministic ruleset version;
- creature state hash;
- battle inputs and replay;
- no external market linkage.

**Authoritative objects:**
- deterministic Noted game state within a named ruleset;
- linkage to a verified milestone receipt.

**Derived objects:**
- visuals;
- rarity;
- rankings;
- social announcements.

**Correction:**
- ruleset supersession for future events;
- adjudication of invalid inputs;
- preserve historical game state.

**Rollback:**
- replay from milestone and action events;
- quarantine an invalid ruleset version.

**Failure behaviour:**
- social/research/economy systems continue without Noted;
- no milestone validity is lost.

**Cannot confer authority on:**
- research truth;
- governance;
- NEX/LEX;
- external ownership claim;
- pay-to-win status.

---

## 4.23 Static public publication

**Purpose:** Publish deliberately promoted, evidence-labelled institutional material.

**Writers:**
- bounded publication workflow under operator or later authorised editorial control.

**Verification:**
- source identity;
- evidence label;
- receipts;
- static build and security gates;
- deliberate promotion decision.

**Authoritative objects:**
- the organisation’s published position at a named version;
- underlying evidence remains separately authoritative.

**Derived objects:**
- presentation;
- navigation;
- summaries.

**Correction:**
- dated correction or superseding publication;
- preserve provenance and prior version.

**Rollback:**
- redeploy last verified static artifact;
- preserve failed release evidence.

**Failure behaviour:**
- remain static/read-only;
- do not fall through to live application state.

**Cannot confer authority on:**
- arbitrary social content;
- unverified AI answers;
- NEX/LEX balances;
- public participation rights.

---

# 5. Critical edge rules

| From | To | Permitted edge | Forbidden edge |
|---|---|---|---|
| Identity | Event kernel | Sign a permitted event | Self-grant a privileged capability |
| Event kernel | LOOM RECORD | Ingest exact accepted bytes | Rewrite record based on projection |
| ROUTE | AI | Locate candidate RECORDs | Become evidence |
| AI | CLAIM | Draft a cited assertion | Promote itself into canon |
| Social | NEX | Reference attributed work receipt | Mint NEX from engagement |
| NEX | Social | Display receipted work attribution | Purchase visibility, moderation, or status |
| LEX | Governance | Expend under proposal rules | Buy factual truth or punishment |
| Governance | NEX | Set future general rules within protected boundaries | Confiscate or mint NEX for political advantage |
| Reputation | Task eligibility | Inform explainable risk/qualification checks | Automatically settle work |
| Reputation | Governance | Contribute to maturity gate under published rules | Become linear voting power |
| Contract | Receipt | Authorise bounded work | Confer payment before verification |
| Verification | Adjudication | Supply evidence and finding | Directly rewrite ledger |
| Adjudication | Ledger | Order a defined compensating/settlement event | Delete original event |
| AT/Nostr | Social kernel | Import/export mapped social events | Control Pioneer ledger or canon |
| Verified milestone | Noted | Permit deterministic creature event | Convert game status into research truth |
| LOOM RECORD/CLAIM | Static publication | Supply evidence-labelled source | Publish arbitrary private or unreviewed state |

---

# 6. Authority firewall invariants

These are architectural invariants suitable for automated tests.

1. **Route non-authority**  
   No CLAIM may cite a ROUTE as evidence.

2. **Signed does not mean true**  
   A valid event signature proves authorship under a key, not factual correctness.

3. **Projection non-authority**  
   Feed order, reputation score, AI summary, popularity, and search rank are derived and replaceable.

4. **No self-settlement**  
   The same identity may not publish a task, perform it, provide the sole independent verification, adjudicate the dispute, and issue its reward.

5. **No NEX from engagement**  
   Posts, likes, follows, reactions, and passive time cannot directly mint NEX.

6. **No NEX political power**  
   NEX ownership cannot buy votes, moderation, visibility, reputation, LEX, evidence, or truth.

7. **No LEX intelligence purchase**  
   LEX cannot buy reasoning, compute, NEX work, or NEX settlement.

8. **No unit conversion**  
   No event type, barter path, pool, collateral rule, or governance act may establish NEX–LEX conversion.

9. **No external value rail**  
   No official external price, redemption, deposit, withdrawal, sale, exchange, debt, equity, or payment claim.

10. **Append-only correction**  
    Accepted events and epoch accounting are repaired by new events, not overwritten.

11. **Explicit epoch continuity**  
    Every balance belongs to a named epoch with declared closure and transition rules.

12. **Moderation does not erase history silently**  
    Visibility controls and privacy purges are distinct processes with receipts.

13. **AI action denial by default**  
    Social text, retrieved content, model output, balances, or reactions cannot implicitly grant tool authority.

14. **Protocol adapters are non-sovereign**  
    External social-network state cannot become Pioneer accounting, constitutional, or evidentiary authority without separate accepted Pioneer events.

15. **Noted domain isolation**  
    Creature rarity, battles, or lineage confer no NEX, LEX, governance, or research truth.

16. **Static publication isolation**  
    Public publication never directly consumes mutable live application state without a reviewed promotion artifact.

17. **Local failure, local freeze**  
    A dispute or subsystem failure freezes the narrowest affected scope rather than halting or rewriting unrelated state.

18. **Operator intervention receipt**  
    Every exceptional operator action must have scope, reason, start, expiry, effect, and review receipt.

---

# 7. Failure matrix

| Failure | Immediate posture | State preserved | Writes allowed |
|---|---|---|---|
| Identity ambiguity or key compromise | Quarantine affected identity events | All events, bindings, and evidence | Unaffected identities only |
| Event-kernel validation divergence | Global write HOLD for affected schema | Raw events, heads, implementations | Read/export only |
| LOOM RECORD corruption | Historical-answer HOLD for affected scope | Copies, hashes, checkpoints, route versions | No new claims relying on scope |
| ROUTE poisoning or stale index | Disable route version | RECORDs and query receipts | Exact retrieval remains allowed |
| AI provider failure | Replace provider or no-AI mode | Requests, responses, context receipts | No autonomous action |
| Task-service failure | Freeze new bids/contracts | Tasks, bids, submissions | Existing evidence preserved |
| Verifier unavailable | Contract unresolved | Receipt and deadline history | No settlement |
| Adjudicator conflict | Freeze disputed scope, select replacement | All submissions and recusals | Unaffected contracts continue |
| NEX invariant failure | NEX write HOLD | Event log, checkpoints, balance snapshots | Read-only NEX |
| LEX invariant failure | LEX/governance expenditure HOLD | Event log, proposal state | Deliberation may continue |
| Governance tally divergence | No enactment | Votes, LEX events, implementations | Prior rules remain active |
| Moderation-service failure | Chronological/read-only fallback; narrow emergency containment only | Content and moderation history | Limited safety events |
| AT Protocol outage | Disconnect/queue adapter | Local social state and mappings | Local events continue |
| Nostr relay inconsistency | Expose incomplete observation; disconnect relay | Observed events and relay receipts | Local events continue |
| Noted ruleset defect | Freeze Noted events for that ruleset | Milestone and game history | Core platform continues |
| Static publication deployment failure | Restore last verified artifact | Failed build/deploy receipts | No application mutation |

---

# 8. Circular-dependency traps explicitly rejected

## 8.1 Reputation pays reputation

Rejected loop:

```text
high reputation → easier contracts → more rewards → higher reputation
```

Correction:

- reputation may influence eligibility or risk controls only through explainable, capped rules;
- entry paths and random/independent allocation must remain possible;
- accepted evidence, not reputation alone, settles work.

## 8.2 NEX purchases the evaluators who mint NEX

Rejected loop:

```text
NEX holder funds evaluator → evaluator approves holder → more NEX
```

Correction:

- evaluator selection and payment require declared conflict rules;
- evaluator rewards cannot depend only on approving a finding;
- randomisation, redundancy, audit sampling, and adjudication are required.

## 8.3 LEX power perpetually earns more LEX

Rejected loop:

```text
large LEX balance → governance control → rules favour large balance → more LEX
```

Correction:

- proposal caps;
- diminishing influence;
- protected clauses;
- identity and service-based earning;
- transparent rule-change impact analysis;
- fork and exit.

## 8.4 Popularity becomes evidence

Rejected loop:

```text
popular claim → route ranking → AI repetition → perceived truth → more popularity
```

Correction:

- ROUTE ranking remains non-authoritative;
- AI resolves exact RECORDs;
- claims disclose support and contradiction;
- popularity is a separate projection.

## 8.5 External protocol becomes constitution

Rejected loop:

```text
external network account/label/feed → imported status → Pioneer authority
```

Correction:

- imports pass through Pioneer validation;
- external labels remain external claims;
- Pioneer roles and ledgers use separate events.

## 8.6 Noted achievement becomes pay-to-govern

Rejected loop:

```text
research milestone → rare creature → social prestige → LEX/NEX/governance advantage
```

Correction:

- Noted remains game-domain status;
- no automatic economic or governance conversion.

---

# 9. Build dependency order implied by the graph

This is a dependency order, not yet the final execution-sweep plan.

1. Canonical serialisation, hashing, export, and local repository discipline.
2. Identity/key fixtures and capability envelopes.
3. Signed-event kernel, validation, checkpoint, replay, export/import.
4. LOOM RECORD ingestion and exact retrieval.
5. Social event schemas and deterministic projections.
6. Moderation, appeal, and resolution events.
7. CLAIM and ROUTE layers plus source-bound AI evaluation.
8. Task, bid, contract, receipt, verification, and adjudication events.
9. Reputation projections.
10. NEX synthetic epoch ledger and contract settlement.
11. LEX synthetic epoch ledger and governance expenditure.
12. Governance proposal, vote, tally, enactment, emergency, exit, and fork simulations.
13. AT Protocol adapter and service-stack experiment.
14. Nostr adapter and multi-homing experiment.
15. Canonical Noted source inspection and deterministic adapter.
16. Integrated closed testnet and adversarial campaigns.
17. Bounded public research epoch only after constitutional handoff.

This ordering prevents the UI, token ledger, federation protocol, or AI model from becoming the de facto source of truth before the authority substrate exists.

---

# 10. Load-bearing open choices carried to later rounds

Round 4 fixes interfaces and authority separation. It deliberately does not select:

- cryptographic algorithms and key-recovery method;
- identity admission or proof-of-personhood mechanism;
- exact event finality and witness model;
- exact NEX epoch ceilings, issuance curves, sinks, or transfer limits;
- exact bid-selection formula;
- evaluator sampling and payment formula;
- exact LEX earning, replenishment, burn, delegation, and caps;
- proposal classes and constitutional thresholds;
- retention and verified-purge policy for real private data;
- exact AT Protocol service stack;
- Nostr’s final role;
- canonical Noted implementation;
- legal structure;
- public genesis or balance-migration policy.

Those are resolved in the NEX, LEX/governance, identity/privacy, and protocol rounds—not smuggled into this graph.

---

# 11. Round 4 disposition

```text
Canonical authority graph defined:          YES
Component write/verify boundaries defined:  YES
Derived versus authoritative state split:   YES
Correction and rollback rules defined:      YES
Failure behaviour defined:                  YES
NEX/LEX membrane preserved:                 YES
AI authority bounded:                       YES
AT/Nostr sovereignty prevented:             YES
Noted domain isolated:                      YES
Canon amended:                              NO
Ready for NEX economy closure round:         YES
```

## Next round

**Round 5 — NEX Economy Closure**

Resolve the complete synthetic and epoch-scoped NEX mechanism:

- issuance event taxonomy;
- epoch budget authority;
- task pricing and bids;
- escrow/reservation;
- verification and evaluator incentives;
- settlement;
- barter receipts;
- duplication and wash-work resistance;
- failed work and partial work;
- retirement and sinks;
- custody and recovery assumptions;
- supply and circulation metrics;
- simulation scenarios;
- objective economic acceptance criteria.
