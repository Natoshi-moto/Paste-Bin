# Pioneer Alignment — Round 6 Social, LOOM, Federation and Noted Closure

**Version:** v1  
**Date:** 2026-08-01  
**Status:** Provisional architecture and closed-test contract — not a canon amendment  
**Scope:** Nexus social event substrate, LOOM integration, native AI, AT Protocol, Nostr, and Noted  
**Explicitly excluded:** public registration, real private messaging, live NEX/LEX, credentials, public federation, production deployment

---

# 0. Result

This round closes the social and evidentiary architecture sufficiently to build a **local, synthetic, replayable social kernel** and then test bounded federation adapters.

The system is:

> **A local-first signed-event social network whose exact authorised history is preserved by LOOM, whose AI can retrieve and draft but cannot manufacture authority, whose AT Protocol and Nostr integrations are replaceable non-sovereign adapters, and whose Noted game layer consumes verified milestones without conferring economic, scientific, moderation, or governance power.**

No external protocol becomes Pioneer Alignment’s ledger, constitution, evidence authority, or identity authority merely by transporting content.

---

# 1. Protected boundaries

These remain binding:

- A valid signature proves authorship under a key, not factual truth.
- The canonical Pioneer event kernel is the local source of truth for Pioneer state.
- LOOM RECORDs preserve exact authorised source material.
- LOOM CLAIMs cite RECORDs.
- LOOM ROUTEs are disposable and have zero source authority.
- Popularity, ranking, AI output, AT labels, Nostr relay presence, Noted rarity, NEX, and LEX cannot vote facts into existence.
- Social engagement cannot issue NEX.
- NEX cannot buy social visibility, moderation, reputation, evidence, LEX, or governance.
- LEX cannot buy reasoning, compute, or NEX work.
- AT Protocol and Nostr do not carry canonical NEX/LEX events.
- Noted has no external NFT, market, redemption, pay-to-win, or automatic governance/economic effect.
- Private content does not enter permanent verbatim history merely because LOOM exists.
- Credentials and secrets are not valid social content or AI context.
- External writes, credentials, money, public launch, and production changes remain operator-controlled.

---

# 2. Canonical social event envelope

Every accepted Pioneer social event uses a canonically serialised envelope.

## 2.1 Required fields

```text
schema
event_type
event_version
event_id
actor_id
actor_kind
operator_id?            # required for attributed agents where policy demands
capability_grant_id
created_at_wall
created_at_logical
parent_event_ids[]
subject_id?
thread_root_id?
channel_id?
access_class
retention_class
origin
payload
payload_hash
attachment_refs[]
supersedes_event_ids[]
signature
```

## 2.2 Origin values

```text
PIONEER_LOCAL
ATPROTO_IMPORT
NOSTR_IMPORT
NOTED_ADAPTER
SYSTEM_DERIVED
```

Imported events also carry:

- external object identifier;
- external signer/identity;
- source service or relay;
- observation time;
- mapping version;
- exact external bytes or content-addressed reference;
- import validation result.

## 2.3 Event identity

The final cryptographic algorithm is deferred to the identity/security round.

The social kernel must already guarantee:

- deterministic canonical bytes;
- deterministic event ID from those bytes;
- schema validation;
- signature verification;
- capability verification;
- duplicate/replay rejection;
- parent/thread validation;
- access/retention validation;
- deterministic projection from the accepted log.

Wall-clock time is metadata. It does not override parentage, logical order, or conflict rules.

---

# 3. Social event taxonomy

## 3.1 Profile, channel, and membership

- `SOCIAL_PROFILE_DECLARE`
- `SOCIAL_PROFILE_UPDATE`
- `SOCIAL_PROFILE_RETRACT`
- `SOCIAL_CHANNEL_CREATE`
- `SOCIAL_CHANNEL_UPDATE`
- `SOCIAL_CHANNEL_ARCHIVE`
- `SOCIAL_MEMBERSHIP_GRANT`
- `SOCIAL_MEMBERSHIP_REVOKE`

## 3.2 Posts, replies, reactions, follows

- `SOCIAL_POST_CREATE`
- `SOCIAL_POST_EDIT`
- `SOCIAL_POST_RETRACT`
- `SOCIAL_REPLY_CREATE`
- `SOCIAL_REPLY_EDIT`
- `SOCIAL_REPLY_RETRACT`
- `SOCIAL_REACTION_SET`
- `SOCIAL_REACTION_REMOVE`
- `SOCIAL_FOLLOW_SET`
- `SOCIAL_FOLLOW_REMOVE`

An edit is a new event that supersedes a prior event. Accepted bytes are never overwritten.

A retraction changes the author’s current position and default presentation. It does not claim the earlier event never existed.

## 3.3 Evidence, claims, and attestations

- `SOCIAL_EVIDENCE_REFERENCE`
- `SOCIAL_CLAIM_CREATE`
- `SOCIAL_CLAIM_CORRECT`
- `SOCIAL_CLAIM_RETRACT`
- `SOCIAL_CLAIM_CONTRADICT`
- `SOCIAL_CLAIM_SUPERSEDE`
- `SOCIAL_ATTESTATION_CREATE`
- `SOCIAL_ATTESTATION_RETRACT`

A social evidence reference must resolve to a LOOM RECORD or a separately quarantined external evidence object awaiting ingestion.

A reaction is never evidence.

An attestation records that a named identity attested to something. It does not make the subject true.

## 3.4 Reporting, moderation, appeal, and remedy

- `SOCIAL_REPORT_CREATE`
- `SOCIAL_REPORT_SUPPLEMENT`
- `SOCIAL_MODERATION_QUARANTINE`
- `SOCIAL_MODERATION_NOTICE`
- `SOCIAL_MODERATION_LABEL`
- `SOCIAL_MODERATION_RESTRICT`
- `SOCIAL_MODERATION_RESTORE`
- `SOCIAL_MODERATION_EXPIRE`
- `SOCIAL_APPEAL_OPEN`
- `SOCIAL_APPEAL_EVIDENCE`
- `SOCIAL_APPEAL_DECISION`
- `SOCIAL_REMEDY_DECLARE`
- `SOCIAL_EMERGENCY_CONTAIN`
- `SOCIAL_EMERGENCY_REVIEW`

Moderation actions establish institutional action and visibility state, not factual truth.

## 3.5 Access, retention, deletion, and purge

- `SOCIAL_ACCESS_GRANT`
- `SOCIAL_ACCESS_REVOKE`
- `SOCIAL_VISIBILITY_WITHDRAW`
- `SOCIAL_DELETION_REQUEST`
- `SOCIAL_PURGE_REQUEST`
- `SOCIAL_PURGE_DECISION`
- `SOCIAL_PURGE_EXECUTE`
- `SOCIAL_PURGE_ATTESTATION`
- `SOCIAL_EXTERNAL_COPY_WARNING`

Deletion, retraction, quarantine, and verified purge are distinct operations.

## 3.6 AI provenance

- `SOCIAL_AI_CONTEXT_AUTHORISE`
- `SOCIAL_AI_QUERY_RECEIPT`
- `SOCIAL_AI_RESPONSE_RECEIPT`
- `SOCIAL_AI_ESCALATION_RECEIPT`
- `SOCIAL_AI_CLAIM_DRAFT`
- `SOCIAL_AI_PUBLICATION_PROPOSAL`
- `SOCIAL_AI_FEEDBACK`

A specifically chartered autonomous reporter may later receive a bounded direct-publication capability for evidence-grounded reports. That role is exceptional, schema-bound, conflict-disclosing, correction-preserving, and grants no vote, veto, moderation, secret access, or deployment authority.

## 3.7 Federation mapping

- `SOCIAL_FEDERATION_EXPORT_INTENT`
- `SOCIAL_FEDERATION_EXPORT_RESULT`
- `SOCIAL_FEDERATION_IMPORT_OBSERVE`
- `SOCIAL_FEDERATION_IMPORT_ACCEPT`
- `SOCIAL_FEDERATION_IMPORT_REJECT`
- `SOCIAL_FEDERATION_DIVERGENCE`
- `SOCIAL_FEDERATION_MAPPING_SUPERSEDE`
- `SOCIAL_FEDERATION_ACCOUNT_MIGRATION_OBSERVE`

## 3.8 Noted domain

- `NOTED_MILESTONE_ELIGIBLE`
- `NOTED_CREATURE_GENESIS`
- `NOTED_CREATURE_MUTATION`
- `NOTED_CREATURE_LINEAGE`
- `NOTED_BATTLE_CHALLENGE`
- `NOTED_BATTLE_COMMIT`
- `NOTED_BATTLE_REVEAL`
- `NOTED_BATTLE_RESULT`
- `NOTED_BATTLE_VERIFY`
- `NOTED_RULESET_RETIRE`

---

# 4. Access and retention classes

The system must require an explicit access class and retention class before accepting content.

## 4.1 `PUBLIC_ARCHIVAL`

Use for:

- constitutional and governance records;
- task, contract, verification, and adjudication records;
- published institutional claims;
- public moderation actions and appeals, with sensitive evidence separated;
- explicitly promoted research records;
- declared public Noted milestone and battle records.

Properties:

- exact accepted event retained;
- edits and corrections append;
- retraction does not erase history;
- default public history view may show supersession and correction;
- extraordinary legal/safety purge remains possible but requires a separately receipted authority path.

## 4.2 `PUBLIC_SOCIAL`

Use for ordinary public posts, replies, profiles, and reactions.

Properties:

- author receives an explicit warning that federation may create external copies;
- local exact event is retained for event-log integrity;
- retraction removes it from default views and marks the history;
- history access can be narrower than ordinary feed access;
- local extraordinary purge can remove payloads where policy requires;
- external deletion cannot be guaranteed.

## 4.3 `RESTRICTED_EVIDENCE`

Use for vulnerability details, moderation evidence, dispute evidence, incident material, and limited research records.

Properties:

- encrypted storage when real data begins;
- named access roles;
- every access receipted;
- no public AI context;
- public event contains only the minimum case metadata;
- expiry, review, and purge rules declared per case.

## 4.4 `PRIVATE_DURABLE`

Use for private notes, drafts, explicitly saved AI conversations, and private working material.

Properties:

- not ingested into public LOOM;
- user-scoped or explicitly shared;
- encrypted before any real-user deployment;
- deletable under a verified purge process;
- no federation;
- no model training use by project policy;
- not available to moderation or governance without a separate lawful/authorised process.

Private messaging is not part of the first implementation.

## 4.5 `PRIVATE_TRANSIENT`

Use for unsaved prompts, temporary context packets, typing state, previews, and ephemeral computation.

Properties:

- strict TTL;
- no content retention after expiry;
- only a minimal non-content operational receipt may remain;
- no federation;
- no automatic promotion into `PRIVATE_DURABLE`.

## 4.6 `SECRET_PROHIBITED`

Credentials, API keys, recovery codes, session cookies, private signing keys, and unrelated secrets are invalid content.

The system should:

- reject or redact before persistence where technically possible;
- stop federation/export;
- create a minimal incident receipt;
- avoid echoing the secret into logs or AI contexts.

---

# 5. Edit, deletion, retraction, and purge semantics

## 5.1 Edit

An edit:

- creates a new event;
- identifies the superseded event;
- preserves authorship and chronology;
- updates the current projection;
- does not overwrite accepted bytes.

## 5.2 Retraction

A retraction states:

> The author no longer presents this content as current.

It:

- removes the content from default feeds where policy permits;
- preserves the retraction event;
- preserves archival history according to retention class;
- cannot force external networks or users to forget copies.

## 5.3 Visibility withdrawal

A visibility withdrawal changes a projection without claiming the event is deleted.

Examples:

- user hides an old post from profile;
- moderator quarantines a post;
- channel archive removes ordinary discovery.

## 5.4 Deletion request

A deletion request asks all in-scope local services and adapters to remove or hide the content according to policy.

It may cause:

- local projection removal;
- AT record deletion request;
- Nostr deletion/request-to-vanish event where supported;
- blob deletion request;
- cache invalidation;
- route invalidation.

It is not proof that every external copy disappeared.

## 5.5 Verified purge

A verified purge is reserved for:

- private or restricted data under its policy;
- exposed secrets;
- unlawful content;
- acute safety cases;
- extraordinary public-data decisions under declared authority.

The purge process:

1. freezes further propagation;
2. identifies all known local payload, blob, cache, route, backup, and export locations;
3. deletes or cryptographically renders inaccessible the in-scope payload;
4. invalidates routes and AI caches;
5. records which locations were successfully purged;
6. records failures and unknown external copies;
7. leaves the minimum permissible tombstone showing that an authorised purge occurred.

For highly sensitive content, the tombstone must not retain a reversible quotation, raw payload, or guessable unsalted content hash.

A verified purge proves what the controlled Pioneer systems did. It cannot prove erasure from independent users, archives, AT services, or Nostr relays.

---

# 6. Moderation and appeals

## 6.1 Process

```text
report
→ triage
→ no action | temporary quarantine
→ notice
→ evidence submission
→ decision
→ appeal
→ independent appeal decision
→ remedy / restore / uphold
```

## 6.2 Temporary quarantine

Quarantine is preferred to silent deletion.

It must state:

- actor and role;
- subject;
- reason code;
- evidence references;
- visibility effect;
- start;
- expiry;
- appeal route;
- conflict disclosure.

A provisional closed-test default is a maximum emergency containment period of 72 hours without independent extension. This is a simulation parameter, not final constitutional law.

## 6.3 AI role

AI may:

- classify a report;
- locate policy and exact records;
- identify contradictions;
- propose labels;
- draft notices;
- recommend escalation.

AI may not:

- issue final punishment;
- decide factual guilt;
- secretly widen evidence access;
- expose restricted evidence;
- alter NEX/LEX;
- enact governance.

## 6.4 Transparency

Public moderation transparency should expose:

- action type;
- policy rule;
- scope;
- timing;
- appeal status;
- final result;
- correction or remedy.

Sensitive evidence remains separately access-controlled.

## 6.5 External labels

AT Protocol labels and Nostr reports/labels are imported as external claims.

They may influence a quarantined risk projection.

They do not automatically become Pioneer moderation decisions.

---

# 7. LOOM integration contract

The existing LOOM invariant remains:

> **A CLAIM may cite a RECORD. A CLAIM may never cite a ROUTE.**

## 7.1 RECORD ingestion

LOOM ingests:

- exact accepted public/institutional event bytes;
- validation result;
- signature and identity references;
- logical order and parent links;
- access and retention class;
- moderation/appeal transitions;
- origin and federation mapping;
- attachments by content-addressed reference;
- later correction, contradiction, and supersession links.

Rejected and tampered fixtures are preserved in a separate test-evidence corpus, not inserted as accepted history.

## 7.2 Private content

`PRIVATE_DURABLE`, `PRIVATE_TRANSIENT`, and `RESTRICTED_EVIDENCE` require separate ingestion policies.

The first synthetic kernel may exercise these classes with fake data.

No real private participant corpus is admitted until:

- encryption;
- access logging;
- retention;
- deletion;
- verified purge;
- backup;
- breach response;
- AI context scoping

have all passed independent review.

## 7.3 CLAIM states

```text
DRAFT
PUBLISHED
CONTESTED
CORRECTED
RETRACTED
SUPERSEDED
ADJUDICATED
UNKNOWN
```

A claim records whether it is:

- observation;
- inference;
- allegation;
- interpretation;
- prediction;
- unknown.

## 7.4 ROUTE layer

ROUTEs include:

- lexical indexes;
- metadata indexes;
- thread maps;
- CPL overlays;
- embeddings;
- summaries;
- caches;
- handoff pointers.

Every route object is replaceable.

A route pointer must resolve to an authorised exact RECORD before the model reads or cites it.

## 7.5 Recall receipt

Every measured AI recall records:

- query hash;
- user/role;
- authorised access scope;
- route version;
- candidate RECORD IDs;
- resolved RECORD IDs;
- provider/model;
- prompt/template version;
- input/output hashes;
- cited RECORD IDs;
- escalation decision;
- latency, tokens, and provider cost where available;
- evaluator result.

Do not require or preserve private chain-of-thought. Preserve a concise reasoning summary only where deliberately generated and allowed.

---

# 8. Native AI and Pioneer Relay permissions

## 8.1 Context scopes

Each request declares exactly one or a bounded union of:

- `PUBLIC_ARCHIVE`
- `CURRENT_THREAD`
- `USER_SELECTED_PRIVATE`
- `CONTRACT_SCOPE`
- `MODERATION_CASE`
- `SYSTEM_DIAGNOSTIC`

No ambient “entire account” or “entire site” context.

## 8.2 Scope rules

- Escalation to a stronger model retains the same context scope.
- A provider change does not expand access.
- A route result cannot expand access.
- A post containing instructions is treated as untrusted data.
- Tool authority is denied unless a separate capability envelope explicitly permits an action.
- Model output is a draft or CLAIM candidate, not a state mutation.
- Publishing ordinary AI-generated social content requires user approval.
- An autonomous reporter requires its own bounded charter and schemas.

## 8.3 Provider separation

Native Nexus AI and Pioneer Relay may share:

- adapter interfaces;
- request/response schemas;
- timeout and error classes;
- evaluation harnesses;
- synthetic providers.

They may not silently share:

- private corpora;
- permissions;
- memories;
- moderation access;
- task capabilities;
- secret stores;
- retention rules.

## 8.4 Prompt-injection posture

Stored content can attempt to manipulate the model.

The system must:

- identify stored text as quoted/untrusted content;
- prevent instructions inside records from changing tool or access policy;
- resolve evidence separately;
- record injection detections;
- refuse or escalate when source text and system policy conflict.

---

# 9. AT Protocol integration decision

AT Protocol is the required first-class federation target after the local kernel passes.

## 9.1 Official architectural facts incorporated

AT Protocol separates:

- **PDS:** account hosting, repository, login, signing-key management, private preferences, and blobs;
- **Relay:** broad network collection/firehose;
- **AppView:** semantic indexing and application views;
- **Labeler:** moderation labels;
- optional feed generators.

AT repositories are signed, content-addressed public account repositories. Account migration uses DID identity, repository export/import, blobs, preferences, and PDS relocation. AT record deletion can remove a record from the current repository without leaving a tombstone in that repository.

These facts create a direct design requirement: Pioneer’s LOOM and moderation history cannot rely on an AT repository alone to preserve prior state.

## 9.2 Closed-test service stack

Required:

1. **Synthetic self-hosted PDS**
   - fake accounts only;
   - no public registration;
   - no real email or credentials in shared artifacts;
   - repository export and restore tested.

2. **Pioneer Lexicons**
   - published only in a local/test environment initially;
   - schema mappings versioned;
   - no NEX/LEX or governance ledger records.

3. **Bounded Pioneer AppView/indexer**
   - consumes only the Pioneer test namespace and required Bluesky-compatible social records;
   - generates feeds and threads as derived projections;
   - can be rebuilt from accepted inputs.

4. **Labeler adapter**
   - exports selected public moderation labels;
   - imports external labels as claims;
   - never replaces local moderation events.

5. **Migration and backup test**
   - repository export/import;
   - blob inventory;
   - preference handling where applicable;
   - identity/PDS move;
   - service outage.

Deferred:

- full-network Relay;
- public Bluesky federation;
- real-user PDS hosting;
- full independent AppView of the entire network;
- production moderation Labeler;
- chat/DM integration.

A full Relay is not required for the initial closed test and is operationally heavier than a PDS or bounded AppView.

## 9.3 Provisional Pioneer Lexicons

Example namespace, subject to implementation review:

```text
com.pioneeralignment.social.profile
com.pioneeralignment.social.post
com.pioneeralignment.social.reply
com.pioneeralignment.social.evidenceRef
com.pioneeralignment.social.attestation
com.pioneeralignment.social.correction
com.pioneeralignment.noted.creature
com.pioneeralignment.noted.battle
```

Do not publish:

```text
com.pioneeralignment.nex.*
com.pioneeralignment.lex.*
com.pioneeralignment.governance.vote
```

Public governance summaries may be mirrored as ordinary social publications, but canonical proposals, votes, balances, and enactments remain Pioneer events.

## 9.4 Mapping receipt

Every export/import mapping records:

- Pioneer event ID;
- Lexicon and mapping version;
- AT URI;
- record CID;
- account DID;
- PDS;
- exact source and mapped hashes;
- export/import result;
- moderation and retention divergence;
- deletion status.

## 9.5 Identity portability

Pioneer must test AT account migration and local backups.

The final choice among `did:plc`, `did:web`, and other Pioneer identity bindings remains for the identity/security round.

An AT identity is not automatically a mature Pioneer governance identity.

---

# 10. Nostr integration decision

Nostr remains a secondary public-transport and multi-homing adapter.

## 10.1 Appropriate uses

- public post/reply/reaction mirroring;
- participant-selected relays;
- Noted creature and battle announcements;
- local/test relay experiments;
- optional degraded or server-light social transport;
- observation of signed external events.

## 10.2 First implementation scope

Use a synthetic local relay set.

Test mappings for:

- profile metadata;
- short public notes;
- replies/comments;
- reactions;
- public Noted announcements;
- deletion requests and expiration semantics;
- relay authentication where needed.

Private messaging is held.

## 10.3 Hard exclusions

The Pioneer adapter must not implement or expose Nostr features as Pioneer economic authority, including:

- wallet-connect flows;
- zaps;
- Cashu or ecash wallet records;
- external marketplace settlement;
- paid data-vending jobs;
- NEX/LEX representation;
- governance voting.

The existence of those Nostr extensions does not change Pioneer’s sealed boundary.

## 10.4 Dual-signing and PQ boundary

Nostr’s basic event format currently uses secp256k1 Schnorr signatures.

A Nostr signature proves the external Nostr event under that protocol.

It does not replace the Pioneer canonical event signature or satisfy future Pioneer post-quantum requirements.

Imported events are wrapped in separately accepted Pioneer events.

## 10.5 Deletion warning

Nostr relays can have independent storage and policy.

Deletion or vanish requests are best-effort interoperability signals, not proof that all relays and recipients erased the event.

The UI must disclose that before public export.

## 10.6 Mapping strategy

Prefer standard public kinds for ordinary interoperable social objects.

Use Pioneer-specific experimental mappings for Noted only on declared test relays until the schema and collision strategy have been independently reviewed.

Unknown custom kinds are quarantined rather than executed or interpreted as authority.

---

# 11. Noted integration decision

The project corpus establishes that Noted is a local-first outer host/archive and Nexus OS is an internal router for sovereign browser-native blocks. The current merge proves co-location and routing, not a unified data model. The planned event bridge is therefore the correct integration point.

The corpus also identifies deterministic creature, world, breeding, witness, and battle engines. Creature DNA maps to traits and visuals; seeds map to worlds; battle inputs and seeded randomness map to reproducible outcomes. These assets require exact source identification and licensing/naming review before public integration.

## 11.1 Do not merge Noted into the social kernel

Use an adapter and typed bridge.

Noted remains:

- a local knowledge and creative workspace;
- project and record context;
- deterministic game host;
- optional offline application.

The social kernel remains:

- identity;
- signed events;
- LOOM;
- moderation;
- federation;
- social projections.

## 11.2 Initial bridge channels

```text
noted.context.packet
noted.record.reference
noted.project.context
ai.response.complete
ai.agent.complete
milestone.verified
eidolon.creature.genesis
eidolon.creature.mutation
eidolon.battle.challenge
eidolon.battle.result
world.seed.created
```

Every channel declares:

- emitter;
- consumer;
- schema;
- access class;
- durability;
- replay semantics;
- side-effect capability.

## 11.3 Milestone eligibility

A Noted milestone requires:

- exact research/task subject;
- accepted work receipt;
- required independent verification;
- adjudication status;
- ruleset eligibility;
- unused milestone slot.

A social claim, reaction count, AI summary, or self-attestation cannot create a creature.

## 11.4 Deterministic creature genesis

Provisional seed derivation:

```text
seed = H(
  "PA-NOTED-CREATURE-V1"
  || milestone_receipt_hash
  || ruleset_id
  || allocated_slot
)
```

Properties:

- the slot is allocated once;
- the receipt and ruleset are fixed before generation;
- users cannot repeatedly reroll for rarity;
- identical inputs produce identical canonical creature state;
- visuals remain a derived rendering.

## 11.5 Mutation and lineage

Mutation events reference:

- current creature state hash;
- eligible new milestone or permitted game event;
- ruleset;
- deterministic mutation input;
- resulting state hash.

Lineage is a graph of exact predecessor references, not a mutable biography.

## 11.6 Battle protocol

A battle pins:

- creature state hashes;
- ruleset;
- arena/world seed;
- challenge ID;
- turn inputs;
- deterministic RNG derivation;
- optional witness set;
- complete replay transcript.

For simultaneous hidden choices, use a commit–reveal sequence.

A valid battle result must be reproducible from the pinned inputs.

## 11.7 Isolation

Noted outcomes do not:

- mint or transfer NEX;
- earn or spend LEX;
- change research validity;
- change moderation;
- grant governance power;
- create external property or redemption rights.

A separate NEX task may pay people to test or improve the Noted engine. The game result itself remains economically inert.

## 11.8 Naming and provenance hold

The current archive contains “Pokémon” shorthand in filenames and tests.

Before public packaging:

- identify the canonical Noted/Nexus source;
- verify hashes;
- preserve licences and provenance;
- replace third-party franchise terminology and assets with original project terminology where required;
- verify that renderers do not alter deterministic engine math.

---

# 12. Offline and degraded operation

## 12.1 Local queue

Clients may create locally signed events while disconnected.

Each queued event records:

- local sequence;
- parent/head observation;
- capability expiry;
- access class;
- intended adapters;
- conflict policy.

## 12.2 Sync

On reconnect:

1. validate capability and signature;
2. validate parents;
3. detect duplicates;
4. accept, reject, or quarantine;
5. rebuild projections;
6. update LOOM;
7. separately attempt AT/Nostr export.

External export failure does not invalidate a locally accepted Pioneer event.

## 12.3 Conflict rules

- ordinary posts can coexist;
- edits must identify the superseded event;
- profile conflicts use deterministic event rules and expose divergence;
- moderation actions use jurisdiction and logical order;
- Noted battles pin state before play;
- accounting and governance use their own stricter state machines and are not handled by the generic social offline queue.

## 12.4 Head uncertainty

A partitioned client must display:

```text
LOCAL VIEW — HEAD NOT CONFIRMED
```

It may not claim global finality.

---

# 13. Closed-test implementation sequence

## Stage S1 — Local signed-event kernel

Build:

- synthetic identities;
- canonical event envelope;
- schema validation;
- capability checks;
- posts, replies, edits, retractions, reactions;
- deterministic thread/feed projections;
- export/import;
- tamper rejection.

## Stage S2 — LOOM

Build:

- exact RECORD ingestion;
- CLAIM states;
- ROUTE interface;
- exact pointer resolution;
- synthetic recall benchmark;
- route-poisoning and prompt-injection cases.

## Stage S3 — Moderation and privacy

Build:

- reports;
- quarantine;
- notice;
- appeal;
- resolution;
- access classes;
- retention classes;
- synthetic purge;
- audit logs.

## Stage S4 — Native fake AI

Build:

- fake deterministic provider;
- context authorisation;
- source-linked answer;
- escalation receipt;
- no-action enforcement;
- reporter-role fixture without live publication.

## Stage S5 — AT Protocol laboratory

Build:

- local PDS;
- provisional Lexicons;
- bounded AppView/indexer;
- label mapping;
- import/export receipts;
- repository backup and migration fixture;
- deletion-divergence fixture.

## Stage S6 — Nostr laboratory

Build:

- local relays;
- signed public event mapping;
- multi-relay observation;
- deletion/expiration divergence;
- unknown-kind quarantine;
- economic-extension rejection.

## Stage S7 — Noted adapter

Build:

- inspect and freeze canonical source candidate;
- typed event bridge;
- deterministic creature fixture;
- lineage fixture;
- commit–reveal battle fixture;
- replay verifier;
- social announcement mapping.

## Stage S8 — Integrated breaker run

Combine synthetic identities, social events, LOOM, fake AI, moderation, federation, and Noted.

No real identities, credentials, providers, or public network writes.

---

# 14. Required adversarial scenarios

1. modified accepted event bytes;
2. forged signature;
3. valid signature with false claim;
4. duplicate event replay;
5. orphan reply;
6. conflicting edits;
7. deleted suffix and rollback;
8. route points to wrong RECORD;
9. route contains fabricated summary;
10. prompt injection inside a post;
11. AI attempts scope expansion during escalation;
12. AI attempts direct moderation;
13. AI attempts NEX/LEX action;
14. private record leaks into public answer;
15. private content enters public LOOM;
16. secret pasted into a post;
17. moderator acts outside jurisdiction;
18. moderator hides conflict;
19. emergency quarantine fails to expire;
20. appeal evidence is excluded;
21. public retraction still appears in default feed;
22. purge leaves retrievable local cache;
23. AT import lacks mapping receipt;
24. AT record deletion removes source but local history fails to disclose it;
25. PDS migration loses repository or blobs;
26. external label becomes automatic Pioneer punishment;
27. Nostr relay serves conflicting event observations;
28. Nostr deletion is falsely displayed as guaranteed erasure;
29. Nostr wallet/zap/market event attempts Pioneer import;
30. unknown Nostr kind attempts code execution;
31. adapter outage blocks local posting;
32. federation loop duplicates the same content repeatedly;
33. Noted milestone is created from an unverified claim;
34. creature seed reroll/grinding;
35. creature renderer changes canonical stats;
36. battle transcript does not replay;
37. battle result attempts to mint NEX or LEX;
38. copied rare creature attempts governance influence;
39. offline client claims confirmed head;
40. independent implementation produces a different projection hash.

---

# 15. Hard acceptance properties

The closed test passes only if:

```text
tampered accepted events admitted:                     0
claims citing ROUTEs as evidence:                     0
AI historical answers without resolved RECORDs:       0
AI context-scope expansions without new authorisation:0
private-to-public leakage:                            0
secret-bearing events federated:                      0
final moderation decisions made solely by AI:         0
expired emergency actions still active:               0
appeals without preserved evidence path:              0
NEX/LEX events exported through AT/Nostr:              0
external labels automatically enacted locally:        0
adapter outage causing local-state loss:               0
Noted genesis from ineligible milestone:               0
Noted deterministic replay divergence:                 0
Noted effect on NEX, LEX, truth, or governance:         0
valid-log projection divergence across implementations:0
```

Additional required demonstrations:

- edit and retraction projections rebuild exactly;
- public and private retention classes behave differently;
- verified purge reports controlled-system success and external unknowns honestly;
- route-only misinformation cannot be cited;
- fake AI can say “not answerable”;
- AT repository export/import and migration are receipted;
- AT deletion divergence is visible;
- Nostr relay observation differences are visible;
- Noted creature and battle states reproduce from frozen inputs;
- local posting works with both federation adapters disabled.

---

# 16. Required artifacts

The implementation sweep must return:

- `SOCIAL_EVENT_ENVELOPE.schema.json`
- `SOCIAL_EVENT_CATALOG.json`
- `SOCIAL_STATE_MACHINE.md`
- `ACCESS_RETENTION_POLICY.md`
- `MODERATION_APPEAL_STATE_MACHINE.md`
- `LOOM_RECORD_CLAIM_ROUTE_SPEC.md`
- `AI_CONTEXT_CAPABILITY_SPEC.md`
- `ATPROTO_MAPPING_SPEC.md`
- provisional Pioneer Lexicons;
- `NOSTR_MAPPING_SPEC.md`
- `NOTED_BRIDGE_SPEC.md`
- deterministic Noted fixtures;
- attack fixtures;
- independent replay implementation;
- exact test report;
- source/provenance inventory;
- known-limitations register;
- sealed ZIP and SHA-256 manifest.

---

# 17. External technical basis

This architecture was checked against current primary documentation.

## AT Protocol

Current official documentation distinguishes PDS, Relay, AppView, Labeler, and feed-generator roles; defines Lexicons for records and APIs; describes signed content-addressed account repositories; and documents account export, migration, recovery, and deletion behaviour.

Design consequence:

- use a local PDS, bounded AppView, mapping Lexicons, and Labeler adapter first;
- defer a full-network Relay;
- preserve Pioneer history separately because AT repositories support record deletion without an internal tombstone.

## Nostr

Current protocol documentation defines signed events exchanged between clients and independent relays, with standard and optional event kinds.

Design consequence:

- treat each relay as an observation source;
- validate signatures and mappings;
- quarantine unknown kinds;
- treat deletion/expiration as non-guaranteed external behaviour;
- explicitly reject wallet, zap, marketplace, and external-payment extensions from Pioneer authority.

## Noted/Nexus corpus

The internal technical manual defines Noted as the outer local-first host, Nexus OS as a sandboxed router/kernel, sovereign blocks, planned typed bridge channels, and deterministic creature/world/battle engines.

Design consequence:

- integrate by typed event bridge rather than monolithic merge;
- inspect and freeze the canonical source before implementation;
- keep renderers and social views outside deterministic game math;
- isolate game status from economic and institutional authority.

---

# 18. Provisional choices versus binding rules

## Binding rules preserved

- signed-event local source of truth;
- LOOM RECORD/CLAIM/ROUTE separation;
- AI non-authority;
- private-by-default treatment;
- append-only corrections;
- NEX/LEX membrane;
- protocol-adapter non-sovereignty;
- Noted domain isolation.

## Provisional choices introduced here

- event names and envelope fields;
- retention-class names;
- 72-hour emergency simulation default;
- closed-test AT service stack;
- provisional Lexicon namespace;
- Nostr mapping scope;
- Noted seed derivation;
- commit–reveal battle structure;
- implementation stages and attack thresholds.

These require implementation evidence and independent review before public adoption.

---

# 19. Round 6 disposition

```text
Social event taxonomy closed for synthetic build: YES
Access and retention classes defined:           YES
Edit/retraction/deletion/purge split defined:    YES
Moderation and appeal path defined:              YES
LOOM ingestion and recall contract defined:      YES
Native AI context authority bounded:             YES
AT Protocol service-stack scope selected:        YES
Nostr scope selected:                            YES
Noted bridge and deterministic domain defined:   YES
Offline/degraded behaviour defined:              YES
Integrated attack suite defined:                 YES
Real private data authorised:                    NO
Public federation authorised:                    NO
Canon amended:                                  NO
Ready for LEX/governance closure:                 YES
```

## Next round

**Round 7 — LEX and Constitutional Governance Closure**

Resolve:

- LEX earning events;
- vote expenditure and retirement;
- replenishment, caps, decay, and delegation;
- identity maturity and Sybil resistance inputs;
- proposal classes;
- quorum and deliberation;
- moderation appeal protection;
- constitutional amendments;
- emergency powers;
- founder transition;
- fork and exit;
- governance attack simulations and objective acceptance tests.
