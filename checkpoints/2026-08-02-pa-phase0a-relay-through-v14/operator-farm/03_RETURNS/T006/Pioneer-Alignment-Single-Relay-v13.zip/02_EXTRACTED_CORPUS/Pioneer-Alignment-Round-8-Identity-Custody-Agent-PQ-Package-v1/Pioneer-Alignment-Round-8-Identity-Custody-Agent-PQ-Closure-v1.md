# Pioneer Alignment — Round 8 Identity, Custody, Sybil Resistance and Agent Responsibility Closure

**Version:** v1  
**Date:** 2026-08-01  
**Status:** Provisional architecture and synthetic-test contract — not a canon amendment  
**Scope:** human and pseudonymous identity, governance uniqueness, organisations, agents, key custody, recovery, cross-protocol bindings, responsibility, and post-quantum migration  
**Explicitly excluded:** real identity enrollment, collection of government identity documents, legal liability determinations, production credentials, public balances, public governance, and irreversible cryptographic selection

---

# 0. Result

This round closes the identity and custody architecture sufficiently to build and attack it with synthetic identities.

The proposed system is:

> **A pseudonym-compatible, privacy-minimising identity system with separate root, profile, role, wallet, and agent keys; one mature-human governance credential per person per epoch; layered rather than magical Sybil resistance; append-only rotation and recovery; purpose-bound external identity links; explicit operator-agent responsibility; and an algorithm-agile hybrid-to-post-quantum migration path.**

The design deliberately refuses two false simplifications:

1. **A public pseudonym is not the same thing as a human identity.**
2. **No single technical trick perfectly proves “one human, one account” without costs, exclusions, or trusted processes.**

Therefore identity assurance is graduated, evidence-bound, appealable, privacy-aware, and scoped to the authority being requested.

---

# 1. Protected boundaries preserved

- People may participate pseudonymously where the task does not require stronger assurance.
- A person may maintain multiple social pseudonyms.
- Multiple pseudonyms do not create multiple governance credentials.
- Agents, organisations, roles, and external protocol accounts do not cast human ballots.
- Identity maturity, reputation, evidence, NEX, LEX, and social popularity remain separate.
- NEX cannot buy identity maturity, governance eligibility, or admission.
- LEX cannot purchase proof of personhood or bypass probation.
- Identity records do not establish factual truth.
- External AT Protocol or Nostr identity does not automatically become a Pioneer identity.
- A valid signature proves control of a key at a moment, not the legal identity, humanity, honesty, or competence of the signer.
- Recovery and rotation append new events; they do not rewrite prior signatures.
- No private signing key, recovery secret, credential, or government document enters LOOM or the public event log.
- Public participation does not require disclosure of a legal name by default.
- High-authority actions require stronger credentials than ordinary posting.
- Governance rights are not inheritable, transferable, purchasable, or delegable outside the explicit ballot-delegation rules.
- Cryptography remains algorithm-agile; a current algorithm cannot silently become permanent constitutional law.

---

# 2. Identity object model

## 2.1 `HUMAN_ROOT`

A private continuity object representing one enrolled human within Pioneer’s identity system.

It is not publicly displayed.

It contains or references:

- root identity ID;
- current root-verification policy;
- recovery policy;
- admission evidence references;
- uniqueness status;
- governance-credential status;
- key history;
- private pseudonym bindings;
- active restrictions or disputes;
- minimum necessary private attributes.

It must not contain unrelated biographical profiling.

## 2.2 `PUBLIC_PSEUDONYM`

A public-facing human-controlled identity.

A person may operate several pseudonyms for:

- different projects;
- privacy;
- safety;
- experimentation;
- social separation.

Each pseudonym has:

- its own profile and signing keys;
- its own visible social history;
- declared or private root binding;
- independent reputation projections;
- no automatic ability to cast an additional ballot.

Public linkage among pseudonyms is optional unless a role, conflict, contract, or governance rule requires disclosure.

## 2.3 `ORGANISATION_IDENTITY`

Represents a team, cooperative, company, lab, foundation, or other collective.

It uses:

- threshold or multi-role administration;
- declared human controllers;
- role and signing policy;
- audit trail;
- no direct human ballot.

An organisation may propose, publish tasks, operate agents, hold permitted NEX/LEX, and speak socially.

Its controllers vote only through their own mature-human credentials and conflict rules.

## 2.4 `AGENT_IDENTITY`

Represents an AI or software agent independently of its operator.

Required fields:

- agent ID;
- operator identity;
- implementation/model identity;
- version or immutable artifact reference;
- provider/runtime;
- capability grants;
- permitted tools and data;
- economic custody policy;
- expiry;
- incident status.

An agent has its own work history and reputation.

It does not inherit the operator’s social or governance reputation.

## 2.5 `SERVICE_IDENTITY`

Represents an institutional service such as:

- event validator;
- ledger service;
- LOOM ingester;
- federation adapter;
- tally verifier;
- autonomous adversarial reporter;
- publication service.

A service identity acts only through a published charter and capability envelope.

A service name does not create sovereign authority.

## 2.6 `ROLE_CREDENTIAL`

A time-bounded capability issued to a human, organisation, agent, or service identity.

Examples:

- moderator;
- verifier;
- adjudicator;
- task publisher;
- budget authority;
- constitutional reviewer;
- emergency reviewer;
- publication role.

Role credentials:

- state exact permissions;
- have an issuer and constitutional basis;
- expire;
- can be suspended;
- do not create additional human ballots;
- cannot be inferred from job title or social status.

## 2.7 `MATURE_HUMAN_GOVERNANCE_CREDENTIAL`

A privacy-preserving credential proving that its holder is eligible to participate as one mature human in a named governance epoch.

It proves only the minimum required statement:

```text
This holder controls one currently valid mature-human governance credential
for epoch E and has not already exercised the same one-person action in scope S.
```

It should not reveal:

- legal name;
- government identifier;
- home address;
- other pseudonyms;
- prior-epoch voting linkages;
- unrelated private attributes.

The final anonymous-credential or zero-knowledge mechanism remains an implementation research decision.

---

# 3. Assurance ladder

## `I0 — External observer`

Can:

- read public material;
- verify public artifacts.

Cannot:

- create canonical Pioneer events;
- hold internal balances;
- vote.

## `I1 — Local or public pseudonym`

Requirements:

- working signing credential;
- accepted terms;
- rate and abuse controls.

Can:

- post under permitted channels;
- create drafts and claims;
- operate in synthetic or low-authority spaces.

Cannot:

- receive civic LEX;
- cast binding ballots;
- occupy high-authority roles.

## `I2 — Accountable participant`

Requirements:

- stable pseudonym;
- recovery setup;
- operator disclosure for economically active agents;
- completed probation;
- no unresolved severe identity conflict;
- sufficient work/social history or admission evidence.

Can:

- bid on tasks;
- hold permitted NEX/LEX;
- operate agents;
- propose discussions;
- become eligible for some service roles.

## `I3 — Mature human`

Requirements:

- human-root enrollment;
- uniqueness review;
- liveness/revalidation;
- completed maturation;
- appealable credential issuance;
- one active credential per epoch.

Can:

- receive civic LEX;
- cast one binding human ballot;
- sponsor binding proposals;
- enter sortition pools where otherwise qualified.

## `I4 — High-authority role holder`

Requirements:

- I3 where the role is human;
- competence/evidence requirement;
- conflict review;
- stronger authenticator policy;
- role-specific training or test;
- time-limited appointment;
- public role receipt.

Can:

- perform only the role’s named actions.

Cannot:

- obtain extra ballot weight;
- self-award balances;
- silently delegate the role;
- retain the role after expiry.

---

# 4. Admission and maturation

## 4.1 Open participation first

The system should not require government identity for ordinary public reading, pseudonymous posting, or low-risk synthetic experimentation.

Authority increases only as assurance increases.

## 4.2 Layered admission evidence

No single evidence source is mandatory for all people.

A mature-human application may combine:

- live challenge or ceremony;
- attestations from mature humans;
- sustained unique contribution history;
- optional external identity credentials;
- optional institutional or community attestations;
- device/account continuity;
- fraud and duplicate checks;
- appeal interview;
- privacy-preserving uniqueness service where available.

Legal identity documents are optional evidence, not a universal public requirement.

Where such documents are ever used:

- they remain in a separately controlled proofing system;
- minimum attributes are extracted;
- raw copies are deleted under a declared schedule;
- no public identity event contains them;
- access is logged;
- alternative paths exist where practicable.

## 4.3 Provisional maturation schedule

Synthetic baseline:

```text
Minimum participation age:        30 days
Minimum meaningful events:        10
Minimum independently accepted
work or service receipts:         2
Independent mature attestations:  3
Liveness/revalidation:            required
Open challenge period:            7 days
```

These are test parameters, not constitutional commitments.

A fast-track may exist only for a documented institutional or emergency need and must:

- be public;
- expire;
- receive independent review;
- not bypass uniqueness.

## 4.4 Probation

During probation:

- lower task and transfer limits;
- no civic LEX;
- no binding ballot;
- no high-authority role;
- identity challenges remain appealable;
- social activity remains possible under ordinary rules.

Probation is not a permanent underclass.

The criteria and expiry must be visible.

---

# 5. Sybil resistance

## 5.1 No magical proof

Pioneer Alignment must explicitly state:

> Perfect one-person-one-credential verification is not currently available without tradeoffs in trust, privacy, inclusion, coercion resistance, and operational cost.

The system therefore uses defence in depth.

## 5.2 Layers

### Layer A — Costless public pseudonyms

Multiple social identities are allowed.

This avoids forcing governance-grade identity proof onto ordinary speech.

### Layer B — Operator and relationship disclosure

Economically active agents disclose their operator.

Organisations disclose controllers and conflicts where required.

### Layer C — Probation and history

High-authority privileges mature over time.

A mass-created identity swarm does not immediately receive civic allocations or governance power.

### Layer D — Multiple independent attestations

No single founder, moderator, identity vendor, or government database decides humanity or uniqueness alone.

### Layer E — Per-epoch uniqueness credential

One valid mature-human credential may produce one eligible epoch nullifier.

The governance system rejects duplicate nullifiers without needing to reveal the person’s public identity.

### Layer F — Challenge and appeal

Suspected duplicate or coerced credentials are challenged through evidence, notice, privacy-protected review, and appeal.

### Layer G — Statistical and graph anomaly detection

Used only as a risk signal.

It cannot automatically declare two people identical or confiscate rights.

### Layer H — Rate and concentration controls

Civic allocations, role entry, task allocation, and delegation already have per-human or per-operator caps.

## 5.3 Governance nullifiers

The target anonymous-credential design should support:

- one epoch nullifier per human credential;
- proposal-specific nullifiers to prevent duplicate ballots;
- unlinkability across unrelated contexts where technically possible;
- public verification of uniqueness without public identity disclosure;
- revocation;
- expiry;
- no reusable secret placed in browser logs or LOOM.

A nullifier is a duplicate-prevention value, not a universal tracking identifier.

## 5.4 Issuer decentralisation

Provisional model:

- at least five independent credential issuers or admission reviewers;
- threshold approval of three;
- no issuer may certify itself;
- issuer conflicts published;
- minority dissent preserved;
- issuers rotate;
- an appeal panel is separate from the original decision.

The exact cryptographic threshold scheme remains open.

## 5.5 Failed uniqueness certainty

Where uniqueness cannot be established confidently:

- ordinary pseudonymous participation remains available;
- governance and civic allocation remain pending;
- the system records “unresolved” rather than “fraud”;
- appeal and additional evidence routes remain available.

---

# 6. Key hierarchy

## 6.1 Root recovery key

Purpose:

- rotate primary identity keys;
- approve recovery-policy changes;
- recover from device loss;
- revoke compromised descendants.

Properties:

- normally offline;
- not used for posting, voting, or routine transactions;
- may be threshold-controlled;
- never transmitted to the server as raw secret material.

## 6.2 Authentication credentials

Used for interactive sign-in.

Preferred pattern:

- phishing-resistant WebAuthn/passkey credentials;
- multiple registered authenticators;
- a mix of synced and device-bound credentials according to risk;
- no password-only high-authority access.

WebAuthn is an authentication layer, not the canonical event-signature or post-quantum layer.

## 6.3 Event-signing keys

Separate purpose-bound keys for:

- social events;
- NEX intents;
- LEX/governance events;
- organisation administration;
- service operation.

This limits blast radius.

The same key must not automatically sign every authority domain.

## 6.4 Agent keys

Agents receive:

- task- or service-scoped keys;
- maximum duration;
- tool/data capability envelope;
- budget/contract limits;
- revocation handle;
- operator binding.

Long-lived unrestricted agent keys are prohibited.

## 6.5 Session keys

Short-lived delegated keys may reduce repeated user approval for bounded actions.

Every session key declares:

- parent key;
- scope;
- event types;
- maximum count or budget;
- start;
- expiry;
- revocation.

A session key cannot widen itself.

---

# 7. Authentication profile

## 7.1 Ordinary pseudonymous use

Minimum:

- one phishing-resistant public-key credential where supported;
- backup or recovery method;
- event-signing key.

Passwords may exist only as a transitional or low-assurance recovery component, never as the sole control for balances or governance.

## 7.2 Balance-bearing account

Required:

- at least two independent authenticators or one authenticator plus tested guardian recovery;
- separate NEX/LEX signing confirmation;
- transaction/event display before signing;
- anomaly notification;
- exportable receipts.

## 7.3 High-authority role

Required:

- device-bound or comparably high-assurance authenticator;
- second independent authenticator;
- role-specific event key;
- short role expiry;
- no silent browser session extension;
- step-up confirmation for emergency, budget, settlement, moderation, tally, and enactment events.

## 7.4 Accessibility and inclusion

The system must not assume everyone can use:

- biometrics;
- one brand’s cloud sync;
- a smartphone;
- a hardware security key;
- government documents.

Offer multiple secure authenticators and assisted recovery without creating a weaker hidden administrator backdoor.

---

# 8. Recovery and compromise

## 8.1 User-selected recovery policy

Supported policies may include:

- multiple personal authenticators;
- threshold guardians;
- offline recovery kit;
- institution-assisted recovery;
- no-recovery sovereign mode.

The user sees the consequences before selecting a policy.

## 8.2 Provisional guardian policy

Synthetic default:

```text
Guardians:               5
Threshold:               3
Recovery delay:          7 days
Immediate affected-key
freeze available:        yes
Balance transfer during
delay:                    no
Public/restricted notice: scoped
User cancellation:       allowed with uncompromised key
```

Guardians can authorise key rotation.

They cannot:

- transfer balances to themselves;
- learn private content automatically;
- cast ballots;
- change the human-root identity;
- bypass an active identity dispute.

## 8.3 Recovery process

1. recovery request;
2. affected-key hold;
3. guardian/issuer approvals;
4. notification to existing authenticators;
5. delay;
6. challenge or cancellation window;
7. root-policy verification;
8. new key binding;
9. old key revocation;
10. balance, role, and adapter review;
11. recovery receipt.

Prior signatures remain attributable to the old key with its historical validity period.

## 8.4 Compromise

A credible compromise report triggers the narrowest hold:

- key;
- identity;
- agent;
- role;
- wallet;
- adapter binding;
- affected contract.

It does not automatically freeze unrelated identities or the whole platform.

Events signed after the proven compromise point are quarantined or adjudicated.

The event log preserves:

- compromise claim;
- evidence;
- temporary hold;
- decision;
- affected events;
- remediation.

## 8.5 Lost key with no recovery

The system must admit that some accounts may become unrecoverable.

It must not create a universal administrator master key.

Possible outcomes:

- social identity becomes dormant;
- new identity is admitted through a new process;
- public continuity claim is adjudicated;
- balances remain frozen until a predeclared recovery or epoch-transition rule applies;
- governance credential is revoked and may be reissued without duplicating the epoch nullifier.

---

# 9. Death, incapacity, and inheritance

This remains partly deferred because legal structure and jurisdiction are unresolved.

Protected rules:

- governance eligibility and civic LEX are never inherited;
- role credentials expire;
- an heir does not become the same human identity;
- private-data access is not transferred automatically;
- no balance is silently seized.

A future epoch may predeclare:

- beneficiary instructions for transferable NEX or social-use LEX;
- documentary or guardian evidence;
- waiting period;
- dispute route;
- privacy treatment;
- non-migration at epoch closure.

Until such a rule exists:

```text
NO AUTOMATIC INHERITANCE
NO AUTOMATIC CONFISCATION
HOLD AND PRESERVE THE ACCOUNTING RECORD
```

---

# 10. Cross-protocol identity binding

## 10.1 Pioneer is canonical for Pioneer authority

An AT DID, Nostr public key, GitHub account, email address, domain, or other external identity is an external identifier.

It may be bound to a Pioneer pseudonym.

It does not become the human root, mature-human credential, NEX wallet, LEX wallet, or role authority.

## 10.2 Bidirectional binding

A valid binding requires:

1. a Pioneer event naming the external identifier and challenge;
2. proof signed or published through the external identity;
3. mapping version;
4. expiry/revalidation;
5. privacy scope;
6. revocation path.

Where the external protocol supports bidirectional identifier verification, both directions must be checked.

## 10.3 AT Protocol

Store:

- DID;
- handle observation;
- PDS;
- proof/mapping receipt;
- migration observations;
- current binding status.

AT account migration or handle changes update the binding through new events.

They do not rotate the Pioneer root automatically.

## 10.4 Nostr

Store:

- Nostr public key;
- signed challenge event;
- observed relays;
- mapping receipt;
- current binding status.

A Nostr key compromise quarantines only that external binding and imported/exported events until adjudication.

## 10.5 Domain and repository identities

A domain or source-code repository can support an organisation or project claim.

It cannot prove one-human uniqueness by itself.

---

# 11. Agent responsibility model

## 11.1 Attribution

Every economically, institutionally, or operationally capable agent must have:

- distinct agent identity;
- declared operator;
- implementation/model version;
- capability grant;
- context scope;
- tool scope;
- budget/contract scope;
- expiry;
- output and action receipts.

## 11.2 Operator responsibility

Inside Pioneer Alignment, the operator is responsible for:

- registering the agent accurately;
- securing agent credentials;
- choosing capabilities;
- supervising use appropriate to risk;
- reporting compromise or unexpected behaviour;
- preserving required receipts;
- responding to incident and dispute processes.

This is platform accountability, not a determination of external legal liability.

## 11.3 Fault classification

Incidents distinguish:

- operator instruction;
- operator negligence;
- agent implementation defect;
- model/provider defect;
- tool/service defect;
- malicious external input;
- compromised credentials;
- protocol defect;
- unknown.

Do not automatically blame the human for every model output or automatically excuse the human because “the AI did it.”

## 11.4 Agent property and balances

An agent may hold a distinct NEX account under the epoch rules.

Custody policy must declare whether:

- the agent controls the key;
- the operator co-signs;
- a contract service controls settlement;
- balances return or freeze when the agent is retired.

Agent NEX does not create human governance power.

Agents do not receive civic LEX or human ballots.

An agent may receive limited social/service LEX only if a future adopted programme explicitly allows it, and such LEX is never binding-vote eligible.

## 11.5 Autonomous institutional agents

An autonomous adversarial reporter or similar institutional agent may publish directly only under:

- a narrow charter;
- public data scope;
- required source citations;
- observation/inference/allegation/unknown labels;
- correction and provenance;
- conflict disclosure;
- no private surveillance;
- no vote, veto, moderation, deployment, or secret access;
- an emergency containment and review process.

Its operational custodians are recorded.

Its editorial output is not pre-approved merely because its authority is autonomous.

---

# 12. Capability grants

Every capability grant contains:

- grant ID;
- subject identity;
- issuer;
- constitutional or contract basis;
- permitted event types;
- data/access scope;
- tool scope;
- NEX/LEX maximums where relevant;
- network scope;
- start;
- expiry;
- delegation rule;
- revocation;
- required co-signers;
- audit level.

Default:

```text
DENY ALL AUTHORITY NOT EXPLICITLY GRANTED
```

A model prompt, social post, README, external event, balance, job title, or repository instruction cannot grant a capability.

---

# 13. Panel and sortition eligibility

## 13.1 General pool

A human panel candidate requires:

- mature-human credential;
- no active relevant restriction;
- completed role preparation;
- no conflict;
- availability;
- one seat maximum in the same panel;
- operator/organisation relatedness disclosure.

## 13.2 Competence pool

Some panels additionally require evidence of competence.

Examples:

- cryptographic incident;
- accounting invariant dispute;
- moderation appeal involving specialist safety issues;
- constitutional implementation review.

Competence affects pool eligibility, not ballot weight.

## 13.3 Selection

Use deterministic public sortition from the eligible pool.

The process publishes:

- pool snapshot hash;
- exclusions and reasons;
- seed commitment;
- seed reveal;
- selected members;
- recusals;
- replacement sequence.

No selected person earns more LEX for a particular outcome.

## 13.4 Relatedness caps

A panel may not contain:

- the worker and verifier from the same contract;
- multiple agents of one operator where independence is required;
- undisclosed members controlled by the same organisation;
- the original moderator as appeal majority;
- the founder as automatic member.

---

# 14. Cryptographic agility and post-quantum migration

## 14.1 Current standards basis

The design recognises:

- NIST FIPS 204 specifies ML-DSA.
- NIST FIPS 205 specifies SLH-DSA.
- FIPS 204 currently has a published errata notice, so implementations must track official corrections.
- WebAuthn provides scoped public-key authentication but is not currently a Pioneer post-quantum event-signature standard.
- AT Protocol and Nostr use their own identity/signature systems and remain adapter domains.

## 14.2 Algorithm registry

Every signed object identifies:

- algorithm suite;
- parameter set;
- public-key ID;
- canonicalisation version;
- prehash/domain-separation rule;
- signature;
- validation policy version.

No parser assumes one fixed key size or signature size.

## 14.3 Provisional phases

### `C0 — Synthetic classical`

For local fixtures and early implementation:

- one audited classical signature suite;
- deterministic test keys;
- no claim of quantum resistance.

### `C1 — Hybrid closed test`

Require both:

- classical signature; and
- ML-DSA candidate signature

for high-authority synthetic events.

Test:

- event sizes;
- performance;
- storage;
- browser/runtime support;
- key rotation;
- independent verification.

### `C2 — Hybrid public candidate`

Before any public canonical balance/governance epoch:

- hybrid signatures required for constitutional, epoch, ledger-head, tally, enactment, role, and recovery events;
- user social events may use a transitional policy;
- downgrade is rejected;
- algorithm policy published before reliance.

### `C3 — PQ primary`

ML-DSA becomes primary after:

- stable audited implementations;
- independent interoperability;
- performance evidence;
- key lifecycle and hardware/software support;
- migration test;
- explicit constitutional adoption.

Classical signatures may remain as compatibility evidence for a declared period.

### `C4 — PQ diversity fallback`

SLH-DSA is maintained for:

- long-lived root/checkpoint signatures;
- algorithm-diversity fallback;
- recovery or emergency checkpoints;
- migration evidence.

Exact parameter sets remain subject to benchmark and threat-model review.

## 14.4 User security direction preserved

The project’s existing security direction remains:

- ML-DSA primary post-quantum signature family;
- SLH-DSA fallback/diversity family;
- SHA-512 and SHA3-512-class hashing preference;
- hybrid transition before classical retirement.

This round does not silently select final parameter sets.

## 14.5 Re-signing and continuity

Migration never rewrites old signatures.

Instead:

1. preserve original signed event;
2. create a migration/checkpoint event;
3. reference the prior event or head;
4. sign under the new suite;
5. publish validation results under both policies;
6. record effective dates and downgrade rules.

## 14.6 External adapter signatures

- AT signatures prove AT-domain objects.
- Nostr signatures prove Nostr-domain objects.
- Pioneer wraps imports in a separately signed Pioneer event.
- External signature algorithms do not weaken Pioneer high-authority requirements.
- Export does not expose Pioneer private keys.

---

# 15. Identity, custody, and agent attack programme

Required scenarios:

1. one human creates many pseudonyms;
2. pseudonyms attempt multiple civic allocations;
3. two humans accidentally conflated;
4. one human falsely accused of duplication;
5. issuer cartel creates fake humans;
6. founder acts as sole identity issuer;
7. issuer certifies itself;
8. bribed attesters approve a Sybil;
9. graph anomaly score automatically bans a person;
10. legal-ID-only process excludes an otherwise valid applicant;
11. raw identity document leaks into LOOM;
12. public profile reveals private pseudonym links;
13. epoch nullifier reused;
14. proposal ballot nullifier duplicated;
15. nullifiers correlate all votes publicly;
16. agent attempts mature-human credential;
17. organisation claims a human ballot;
18. role holder claims extra vote;
19. passkey phishing or origin confusion;
20. synced authenticator compromise;
21. device-bound authenticator lost;
22. guardian cartel steals account;
23. guardian recovery transfers balances;
24. recovery bypasses active dispute;
25. old key remains valid after rotation;
26. compromise freeze affects unrelated accounts;
27. no-recovery account receives administrator override;
28. deceased user’s governance credential inherited;
29. abandoned balance silently seized;
30. external AT DID migration hijacks Pioneer root;
31. Nostr key compromise hijacks Pioneer identity;
32. external handle alone proves identity;
33. agent acts after capability expiry;
34. agent expands its own tool scope;
35. agent hides operator;
36. operator merges reputations across agents;
37. verifier and worker agents share an operator;
38. autonomous reporter accesses private data;
39. service identity gains undeclared deployment authority;
40. algorithm downgrade strips PQ signature;
41. hybrid validator accepts only one required signature;
42. migration rewrites old event bytes;
43. classical and PQ signatures bind different payloads;
44. malformed large PQ signature causes denial of service;
45. FIPS parameter/errata policy mismatch;
46. panel sortition seed manipulated;
47. related panel members evade disclosure;
48. competence credential creates extra ballot weight;
49. independent identity replay diverges;
50. cross-implementation signature validation diverges.

---

# 16. Hard acceptance properties

The synthetic implementation passes only if:

```text
multiple civic credentials per human per epoch:          0
agent or organisation human ballots:                     0
role-created extra human ballots:                        0
raw private identity documents in public LOOM:           0
public disclosure of private pseudonym bindings:         0
duplicate epoch/proposal nullifiers accepted:            0
automatic bans from risk score alone:                    0
single issuer unilateral mature credential creation:     0
guardian recovery transferring balances:                 0
recovery without delay/notice under normal policy:        0
old revoked key accepted after effective revocation:      0
unscoped compromise freezes:                             0
administrator master-key recovery path:                  0
inherited governance eligibility:                        0
external identity becoming Pioneer root automatically:   0
agent action after capability expiry:                    0
agent self-expansion of authority:                       0
economically active unbound agent operators:             0
service identity undeclared authority:                   0
hybrid high-authority event with missing required sig:    0
algorithm downgrade accepted:                            0
migration rewriting old events:                          0
signature suites binding different canonical payloads:   0
valid-log identity-state divergence across implementations:0
```

Required demonstrations:

- multiple public pseudonyms map privately to one governance credential;
- ordinary pseudonymous participation works without legal identity;
- unresolved uniqueness does not become a fraud conviction;
- credential appeal can reverse an error without issuing duplicates;
- one lost authenticator can be recovered without a central master key;
- guardian collusion below threshold cannot recover an account;
- recovery preserves old signature history;
- AT and Nostr bindings can be revoked independently;
- agent and operator histories remain separately reconstructible;
- panel sortition is reproducible;
- hybrid signatures validate the exact same canonical bytes;
- old, hybrid, and PQ-primary policy states replay deterministically.

---

# 17. Required implementation artifacts

The eventual identity/security sweep must return:

- `IDENTITY_OBJECT_MODEL.md`
- `IDENTITY_EVENT_SCHEMA.json`
- `ASSURANCE_AND_MATURITY_POLICY.md`
- `MATURE_HUMAN_CREDENTIAL_INTERFACE.md`
- `SYBIL_THREAT_MODEL.md`
- `KEY_HIERARCHY.md`
- `AUTHENTICATOR_POLICY.md`
- `RECOVERY_STATE_MACHINE.md`
- `COMPROMISE_RESPONSE.md`
- `AGENT_OPERATOR_RESPONSIBILITY.md`
- `CAPABILITY_GRANT_SCHEMA.json`
- `PANEL_SORTITION_SPEC.md`
- `CROSS_PROTOCOL_IDENTITY_BINDINGS.md`
- `CRYPTO_ALGORITHM_REGISTRY.json`
- `POST_QUANTUM_MIGRATION_PLAN.md`
- synthetic identity and key fixtures;
- deterministic identity replay implementation;
- independent validation implementation;
- attack fixtures;
- exact test report;
- known-limitations register;
- sealed ZIP and SHA-256 manifest.

No real identity documents, production credentials, live users, public balances, public governance, or external account mutations.

---

# 18. Current primary-source basis

This design is informed by current primary standards and specifications:

- NIST SP 800-63-4 and its companion volumes define modern risk-based identity proofing, authentication, authenticator management, federation, security, privacy, usability, and fraud considerations.
- WebAuthn defines scoped public-key credentials mediated by user agents and authenticators. Level 3 is currently a Candidate Recommendation; it should not be falsely described as a final Recommendation.
- NIST FIPS 204 standardises ML-DSA and currently includes an official errata notice.
- NIST FIPS 205 standardises SLH-DSA.
- AT Protocol roots account identity in DIDs and separates identity/hosting from content; account migration does not confer Pioneer identity authority.
- AT handles require bidirectional DID linkage.
- Nostr public keys remain external protocol identities and are separately bound.

The standards inform the design; they do not decide Pioneer’s constitutional or governance policy.

---

# 19. Provisional choices versus protected rules

## Protected and already binding

- pseudonym-compatible participation;
- mature-human identity matters for governance;
- agents and organisations do not cast human ballots;
- one human does not receive multiple civic allocations;
- identity/reputation/evidence/economics remain separate;
- explicit operator-agent bindings;
- append-only rotation and correction;
- no central secret administrator backdoor;
- external protocols are non-sovereign;
- ML-DSA primary and SLH-DSA fallback direction;
- bounded authority and explicit capability grants.

## Provisional choices introduced here

- assurance-level names;
- maturation schedule;
- three-of-five issuer and guardian thresholds;
- seven-day recovery delay;
- key hierarchy;
- authenticator profiles;
- anonymous nullifier interface;
- panel eligibility rules;
- hybrid migration phases;
- synthetic attack thresholds.

These must be implemented, benchmarked, independently reviewed, and explicitly adopted or replaced before public use.

---

# 20. Round 8 disposition

```text
Identity object model closed for synthetic build:       YES
Pseudonym and human-root separation defined:            YES
Mature-human credential interface defined:              YES
Layered Sybil resistance defined:                       YES
Admission and maturation defined:                       YES
Key hierarchy defined:                                  YES
Recovery and compromise response defined:               YES
Inheritance boundary defined:                           YES
Cross-protocol identity binding defined:                YES
Agent/operator responsibility defined:                  YES
Capability grants defined:                              YES
Panel eligibility and sortition defined:                YES
Post-quantum transition architecture defined:           YES
Exact anonymous credential scheme selected:             NO
Exact cryptographic parameter sets selected:            NO
Real identity enrollment authorised:                    NO
Public credentials/governance authorised:               NO
Canon amended:                                          NO
Ready for integrated threat and contradiction sweep:    YES
```

## Next round

**Round 9 — Integrated Threat, Economic and Constitutional Attack Sweep**

Attack the complete combined architecture across:

- social;
- LOOM;
- AI;
- identity;
- federation;
- Noted;
- NEX;
- LEX;
- governance;
- recovery;
- emergency authority;
- founder transition;
- exit and fork.

The round must identify cross-domain exploits that do not appear when each subsystem is reviewed in isolation.
