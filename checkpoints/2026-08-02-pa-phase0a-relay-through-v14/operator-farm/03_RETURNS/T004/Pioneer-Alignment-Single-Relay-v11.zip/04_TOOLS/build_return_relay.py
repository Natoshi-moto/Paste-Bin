#!/usr/bin/env python3
from __future__ import annotations

from fnmatch import fnmatchcase
from pathlib import Path
import hashlib
import json
import sys
import zipfile

sys.dont_write_bytecode = True

root = Path(__file__).resolve().parents[1]
state = json.loads((root / "00_CONTROL/CURRENT_STATE.json").read_text(encoding="utf-8"))
default_name = state.get("requested_return_filename", "Pioneer-Alignment-Single-Relay-v7.zip")
name = sys.argv[1] if len(sys.argv) == 2 else default_name
if len(sys.argv) > 2 or Path(name).name != name or not name.endswith(".zip"):
    raise SystemExit("usage: build_return_relay.py [safe-output-basename.zip]")

output = root.parent / name
input_manifest = root / "05_MANIFESTS/INPUT_SHA256SUMS.txt"
inventory_path = root / "05_MANIFESTS/FILE_INVENTORY.json"
current_manifest = root / "05_MANIFESTS/CURRENT_SHA256SUMS.txt"
mutable_patterns = state.get("allowed_mutations", [])


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rel(path: Path) -> str:
    return path.relative_to(root).as_posix()


def ignored_bytecode(path: Path) -> bool:
    return "__pycache__" in path.parts or path.suffix == ".pyc"


def files() -> list[Path]:
    result = sorted(
        path for path in root.rglob("*")
        if path.is_file() and not ignored_bytecode(path)
    )
    links = [rel(path) for path in result if path.is_symlink()]
    if links:
        raise SystemExit("symlinks prohibited: " + ", ".join(links))
    return result


def is_next_round_mutable(path: Path) -> bool:
    value = rel(path)
    return any(fnmatchcase(value, pattern) for pattern in mutable_patterns)


# 1. The next actor's immutable-input layer excludes every declared mutable path.
immutable = [path for path in files() if not is_next_round_mutable(path)]
input_manifest.write_text(
    "".join(f"{digest(path)}  {rel(path)}\n" for path in immutable),
    encoding="utf-8",
)

# 2. Inventory is cycle-free: it explicitly excludes itself and the current manifest.
inventory_exclusions = {inventory_path, current_manifest}
covered = [path for path in files() if path not in inventory_exclusions]
archive_count = len(files())
inventory = {
    "schema_version": f"pa.file_inventory.v{state.get('relay_version', 0)}",
    "relay_version": state.get("relay_version"),
    "generated_at": state.get("updated_at"),
    "coverage_rule": "all archive-root files except explicitly listed exclusions",
    "excluded_paths": sorted(rel(path) for path in inventory_exclusions),
    "archive_file_count": archive_count,
    "covered_file_count": len(covered),
    "covered_total_bytes": sum(path.stat().st_size for path in covered),
    "files": [
        {"path": rel(path), "bytes": path.stat().st_size, "sha256": digest(path)}
        for path in covered
    ],
}
inventory_path.write_text(
    json.dumps(inventory, indent=2, ensure_ascii=False) + "\n",
    encoding="utf-8",
)

# 3. Current manifest is generated last and covers every file except itself.
current_files = [path for path in files() if path != current_manifest]
current_manifest.write_text(
    "".join(f"{digest(path)}  {rel(path)}\n" for path in current_files),
    encoding="utf-8",
)

# 4. Verify both manifest layers before packaging.
for manifest in (input_manifest, current_manifest):
    for line in manifest.read_text(encoding="utf-8").splitlines():
        expected, relative = line.split("  ", 1)
        target = root / relative
        if not target.is_file() or digest(target) != expected:
            raise SystemExit(f"manifest verification failed: {relative}")

# 5. Build and reopen one archive with numbered directories at its root.
archive_files = files()
with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
    for path in archive_files:
        archive.write(path, arcname=rel(path))
with zipfile.ZipFile(output, "r") as archive:
    names = archive.namelist()
    if len(names) != len(set(names)):
        raise SystemExit("duplicate ZIP path")
    bad = archive.testzip()
    if bad:
        raise SystemExit("bad ZIP entry: " + bad)

print(output)
print(hashlib.sha256(output.read_bytes()).hexdigest())
print(f"archive_files={len(archive_files)} immutable_inputs={len(immutable)} current_covered={len(current_files)} inventory_covered={len(covered)}")
