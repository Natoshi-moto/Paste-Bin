# Round 021 independent Phase 0A specification re-review

Act as the independent reviewer, not the Round 020 controller and not the
application builder. Verify the v11 input manifest before running any other tool.

Read all Round 020 normative files, repair summary, closure mapping, receipts, and
source. Reproduce semantic/full validation, oracle, transition, export, closure,
and all 46 mutations under hash seeds 1 and 2 from a fresh unpack. Use
`PYTHONDONTWRITEBYTECODE=1 python3 -S` for every Python invocation.

Attempt novel coherently rebound probes. At minimum challenge:

- empty, partial, duplicated, renamed, and rewritten semantic case corpora;
- deferred candidate expectation/assertion rewrites;
- prohibited-authority text in JSON and Python normative members;
- raw-HTML payloads under arbitrary identifiers and operation labels;
- evidence byte/hash/missing/path/symlink/normative-membership failures;
- shared slug constant/schema coherent weakening;
- bytecode noise and bytecode manifest pollution;
- empty/rewritten transition declarations and HOLD-origin paths;
- N80 final-node, producer, reviewed binding/tree/source/evidence, remotes, bind,
  provider-adapter, and forbidden-untracked bypasses;
- coherent test/case/assertion/mutant graph removal or reassignment;
- deterministic export reproduction and hash-seed receipt identity.

Do not build an application, mutate a repository, perform host preflight, or take
external actions. Return exactly one of the authorized independent adjudications
and one complete `Pioneer-Alignment-Single-Relay-v12.zip`.
