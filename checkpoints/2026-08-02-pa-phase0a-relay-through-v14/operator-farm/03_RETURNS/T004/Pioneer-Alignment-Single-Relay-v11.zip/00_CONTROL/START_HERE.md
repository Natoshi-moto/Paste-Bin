# START HERE — Pioneer Alignment Single-ZIP Relay v11

Current state: `AWAITING_INDEPENDENT_PHASE0A_SPEC_REREVIEW`

Current actor: independent Round 021 Phase 0A specification/gate reviewer.

Round 020 reports `ROUND020_REPAIR_COMPLETE_AWAITING_INDEPENDENT_REREVIEW`.
That is a request for independent review, not builder release. No application
candidate exists and 35 candidate-required cases are explicitly deferred.

Read in order:

1. `00_CONTROL/CURRENT_STATE.json`
2. `00_CONTROL/AUTHORITY.md`
3. `00_CONTROL/PROMPT_TO_EXECUTE.md`
4. `03_EXCHANGE/ROUND_020_CONTROLLING_PHASE0A_REPAIR/RETURN_SUMMARY.md`
5. `03_EXCHANGE/ROUND_020_CONTROLLING_PHASE0A_REPAIR/REPAIR_SUMMARY.md`
6. `03_EXCHANGE/ROUND_020_CONTROLLING_PHASE0A_REPAIR/FINDING_CLOSURE.json`
7. `03_EXCHANGE/ROUND_020_CONTROLLING_PHASE0A_REPAIR/EXECUTION_RECEIPT.json`

First command on a fresh unpack:

```text
PYTHONDONTWRITEBYTECODE=1 python3 -S 04_TOOLS/verify_input_manifest.py
```

Then reproduce every command in the Round 020 request for re-review. All Python
entry points must use `PYTHONDONTWRITEBYTECODE=1 python3 -S`.

Return one full relay named `Pioneer-Alignment-Single-Relay-v12.zip`.
Do not build the application or expand authority.
