# Single-ZIP Relay Protocol — Round 021 independent re-review

## Immutable areas

The next actor must not modify:

- `01_ORIGINAL_ARTIFACTS/**`;
- `02_EXTRACTED_CORPUS/**`;
- `00_CONTROL/AUTHORITY.md`;
- every exchange directory through
  `03_EXCHANGE/ROUND_020_CONTROLLING_PHASE0A_REPAIR/**`.

Tests and mutations must use disposable complete copies beneath `/tmp`.

## Writable areas

- `03_EXCHANGE/ROUND_021_INDEPENDENT_PHASE0A_SPEC_REREVIEW/**`;
- only the exact control/tool/manifest paths listed in
  `00_CONTROL/CURRENT_STATE.json`.

## Required return archive

Return the complete relay as `Pioneer-Alignment-Single-Relay-v12.zip`, with the
numbered directories directly at archive root. Return no delta and no loose
companion files. Report the outer ZIP SHA-256 detached from the archive.

## Integrity order

1. Hash the new Round 021 files except their self-referential checksum file.
2. Regenerate `05_MANIFESTS/INPUT_SHA256SUMS.txt` over the next actor's immutable
   non-bytecode files.
3. Regenerate `05_MANIFESTS/FILE_INVENTORY.json` using its declared exclusions.
4. Regenerate `05_MANIFESTS/CURRENT_SHA256SUMS.txt` last.
5. Exclude every `__pycache__/**` and `*.pyc` from manifests and ZIP bytes.
6. Build, reopen, and validate the one ZIP; report its outer hash out of band.

Round 021 must adjudicate independently. A green shipped receipt is evidence to
reproduce and challenge, never authority to echo.
