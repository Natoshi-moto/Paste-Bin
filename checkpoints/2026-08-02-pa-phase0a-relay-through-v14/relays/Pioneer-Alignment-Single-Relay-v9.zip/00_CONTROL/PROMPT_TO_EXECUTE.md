# Execute Round 019 — Independent Phase 0A Specification Re-review

Use this complete relay as the only supplied corpus.

You are the independent Phase 0A specification re-reviewer. You are not the
controlling engineer who authored Round 018 and not the application builder.

Round 018 adjudication is `ROUND018_REPAIR_COMPLETE_AWAITING_INDEPENDENT_REREVIEW`.

## Controlling source and precedence

Functional and authority source remains:

`01_ORIGINAL_ARTIFACTS/Pioneer-Alignment-Phase-0A-Builder-Handoff-v1.md`

Read it completely. Then read every Round 018 output, especially:

- `REPAIR_SUMMARY.md`
- `PHASE0A_NORMATIVE_MANIFEST.v1.json`
- `PHASE0A_ACCEPTANCE_CONTRACT.v4.json`
- `meta_validate_round18.py`
- `independent_oracle.py`
- `run_round18_mutations.py`
- `MUTATION_RECEIPTS.json`
- `REQUEST_FOR_INDEPENDENT_REREVIEW.md`
- Round 017 `REVIEW.md` and the twenty adversarial probes

## Required re-review

1. Verify the received archive integrity and immutable input manifest.
2. Execute the Round 018 validator, oracle, transition evaluator, export tools and mutation suite.
3. Confirm mutation receipts are deterministic across at least two `PYTHONHASHSEED` values.
4. Import all twenty Round 017 adversarial classes (already in the Round 018 registry) and confirm each still rejects for its intended reason.
5. Attempt additional material mutations if the registry appears incomplete.
6. Verify HOLD is terminal and N80 cannot release non-reviewed bytes.
7. Verify concrete fixtures, applied schemas, acyclic evidence protocol, export identity formulas, raw-HTML rejection and handoff floor freeze.
8. Preserve all external blockers; do not manufacture host/application closure.

## Required output directory

Write only under:

`03_EXCHANGE/ROUND_019_INDEPENDENT_PHASE0A_SPEC_REREVIEW/`

Include `REVIEW.md`, `FINDING_CLOSURE.json`, `EXECUTION_RECEIPT.json`,
`RETURN_SUMMARY.md`, and `SHA256SUMS.txt`.

## Required adjudication

Choose exactly one:

- `PHASE0A_SPEC_RELEASED_TO_BOUNDED_LOCAL_BUILDER`
- `HOLD_FOR_FURTHER_PHASE0A_SPEC_REPAIR`
- `INSUFFICIENT_EVIDENCE`

## Prohibitions

Do not build or modify application code; initialise or mutate a Git repository;
create a branch or commit; push or create a GitHub repository; request or use
credentials; connect a provider; deploy; change DNS, Cloudflare, hosting, domain or
production; create public accounts, NEX, LEX, federation, governance or real
identities; spend money; approve operator decisions; promote provisional wider
architecture; or alter any prior round or original artifact.

## Return protocol

Update only the Round 019 directory and the exact control/tool/manifest paths
authorised by `CURRENT_STATE.json`.

Return one complete:

`Pioneer-Alignment-Single-Relay-v10.zip`

Report the detached outer ZIP SHA-256 beside the archive. Return no loose files.
