# START HERE — Pioneer Alignment Single-ZIP Relay v9

**Current state:** `AWAITING_INDEPENDENT_PHASE0A_SPEC_REREVIEW`  
**Current actor:** Independent Phase 0A specification re-reviewer  
**Authority:** Re-review Round 018 only; release to builder only if gates hold

This ZIP is the full evolving relay. Do not ask the operator to combine loose
files or reconstruct prior context.

## Round 018 result

```text
Adjudication:              ROUND018_REPAIR_COMPLETE_AWAITING_INDEPENDENT_REREVIEW
Round 018 validator:       SPEC_CONTRACT_VALID
Round 018 mutations:       31 rejected / 0 false-green / hashseed-stable
Independent oracle:        89/89 structural pure-fixture cases PASS
Application candidate:     NONE
Application tests:         NOT RUN
Host preflight:            NOT RUN
Repository mutation:       NONE
GitHub or remote action:    NONE
```

Round 018 closes the executable-gate defects identified in Round 017 at the
specification level. It does not claim host readiness or application existence.

The wider Rounds 3–10 architecture remains a separate HOLD.

## Read first

1. `00_CONTROL/CURRENT_STATE.json`
2. `00_CONTROL/PROMPT_TO_EXECUTE.md`
3. `03_EXCHANGE/ROUND_018_CONTROLLING_PHASE0A_REPAIR/START_HERE.md`
4. `03_EXCHANGE/ROUND_018_CONTROLLING_PHASE0A_REPAIR/REPAIR_SUMMARY.md`
5. `03_EXCHANGE/ROUND_018_CONTROLLING_PHASE0A_REPAIR/REQUEST_FOR_INDEPENDENT_REREVIEW.md`
6. `03_EXCHANGE/ROUND_018_CONTROLLING_PHASE0A_REPAIR/MUTATION_RECEIPTS.md`
7. `03_EXCHANGE/ROUND_017_INDEPENDENT_PHASE0A_BUILD_READINESS/REVIEW.md`

## Required action

Perform Round 019 independent re-review exactly as specified in `PROMPT_TO_EXECUTE.md`.

Return one complete:

`Pioneer-Alignment-Single-Relay-v10.zip`

Do not build the application, mutate a repository, create a branch or commit,
push to GitHub, deploy, request credentials, connect a provider, create public
state, or claim that the host path or an application candidate has been verified.
