# Round 027 independent Phase 0A specification rereview

Act as an independent adversarial reviewer of Round 026. Verify the relay input
manifest before any other tool and use `PYTHONDONTWRITEBYTECODE=1 python3 -S`
for all Python execution. Run mutations only in disposable complete relay
copies under `/tmp`.

Reproduce both validator modes, the independent oracle, transition evaluator,
deterministic export tools, all 94 permanent mutation classes, the 43-negative
legacy closure floor, the R026 mechanism-closure probes, full receipt replay,
and byte identity for mutation receipts under hash seeds 1 and 2.

Invent fresh probes outside the registry. Target Unicode Script-property edge
cases, unmapped lookalikes, control-prompt scan coverage, validator projection
and its external pin, malformed negative-context records, nested acceptance
records, and attempts to create a prose transition around terminal review
states. Score semantic catches under the coherent author model described in
Round 026 `METHOD_NOTE.md`; retain the sealed-manifest model as transit-tamper
evidence.

HOLD is terminal. Preserve honest deferral, the slug/export floors, N80
reviewed-byte identity, `NO_IMPLEMENTATION_CANDIDATE`, and all four external
blockers.

Do not implement or deploy an application, mutate a repository, access
credentials or wallets, make provider connections, modify name-service records,
publish, push, or take
any external action.

Return one v18 relay, one detached SHA-256, and one adjudication.
