# Single-ZIP Relay Protocol — Round 027 independent rereview

## Immutable areas

The independent reviewer must not modify:

- `01_ORIGINAL_ARTIFACTS/**`;
- `02_EXTRACTED_CORPUS/**`;
- `00_CONTROL/AUTHORITY.md`;
- every exchange directory through
  `03_EXCHANGE/ROUND_026_CONTROLLING_PHASE0A_REPAIR/**`.

All prior probe harnesses, gates, receipts, and the complete Round 026 repair
are immutable evidence. Round 027 must write new evidence only in its own
directory. Tests and mutations must use disposable complete copies beneath
`/tmp`.

## Writable areas

- `03_EXCHANGE/ROUND_027_INDEPENDENT_PHASE0A_SPEC_REREVIEW/**`;
- only the exact control/tool/manifest paths listed in
  `00_CONTROL/CURRENT_STATE.json`.

## Required return archive

Return the complete relay as `Pioneer-Alignment-Single-Relay-v18.zip`, with the
numbered directories directly at archive root. Return no delta and no loose
companion files. Report the outer ZIP SHA-256 detached from the archive.

## Integrity order

1. Finish the Round 027 rereview outputs and operational receipts.
2. Hash the new Round 027 files except their self-referential checksum file.
3. Transition state and `allowed_mutations` to the next actor.
4. Run the relay builder once to generate, in order, the next immutable-input
   manifest, cycle-free inventory, current manifest, and ZIP.
5. Treat any `__pycache__/**` or `*.pyc` source member as unshippable, retain
   archive exclusion as a backstop, and reject every symlink.
6. Reopen and verify the built ZIP, then validate a fresh extraction read-only.
7. Make no byte edit after the final builder run; rebuild if any byte changes.
8. Report the detached outer hash out of band.

## Scoring discipline

A mutation counts as rejected only when the documented tools fail on the
intended semantic reason code. An import crash, a
`SECURITY_CONSTANTS_DIGEST_MISMATCH`, an unrefreshed exact-hash lock or an
unconverged operational-receipt rebind is a harness failure, not a control.
Coherent rebind means: normative manifest, evidence envelope, round checksum
manifest, `SECURITY_CONSTANTS_SHA256` repin, the validator's exact-hash lock on
`lib_phase0a.py`, and full operational-receipt recoherence.

Round 027 independently adjudicates the Round 026 specification/gate repair. It
does not build the application or expand authority.
