# Round 028 controlling Phase 0A specification repair

Act as the controlling repairer of the Round 027 findings. Verify the relay
input manifest before any other tool and use `PYTHONDONTWRITEBYTECODE=1 python3
-S` for all Python execution. Run mutations only in disposable complete relay
copies under `/tmp`, and generate the mutation registry against a frozen
extraction — the runner re-reads the live relay once per class.

Close R27-F01 through R27-F05 at the mechanism level, not against the exact
demonstrations:

1. Constrain normative and control text to a declared script and character set
   instead of enumerating lookalikes; strip combining marks in the confusable
   skeleton and reject a leaf whose only non-common script is not Latin.
2. Remove the circularity that lets a self-generated input manifest decide what
   the relay-wide authority scan covers, and extend the always-scan set to the
   whole control directory.
3. Project the validator as one document like every other Python member, and
   flag every non-foldable static composition, not only one call shape.
4. Match the terminal-state rule on a stem rather than one exact token, and
   scope the machine-record exemption to full paths inside the current round.
5. Close the acceptance-contract key space at every nesting depth.

Add all ten material Round 027 probe classes to the permanent mutation registry
and preserve the existing 94-class floor and the 43-negative closure floor.

HOLD is terminal. Preserve honest deferral, the slug and export floors, N80
reviewed-byte identity, `NO_IMPLEMENTATION_CANDIDATE`, and all four external
blockers. Regenerate this round's own receipts; Round 026's counters describe
the v17 seal and are stale by construction.

Do not implement or deploy an application, mutate a repository, access
credentials or wallets, make provider connections, modify name-service records,
publish, push, or take
any external action.

Return one v19 relay, one detached SHA-256, and one adjudication.
