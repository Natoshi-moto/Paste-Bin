#!/usr/bin/env python3
"""Phase 0A Round 024 pure-spec library. No network. No candidate app."""
from __future__ import annotations

import hashlib
import json
import re
import sys
import unicodedata
import zipfile
from io import BytesIO
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True

SECURITY_CONSTANTS_PATH = Path(__file__).resolve().parent / "PHASE0A_SECURITY_CONSTANTS.v1.json"
SECURITY_CONSTANTS_SHA256 = "6d0ea2779c961dbf90dcf2204b9a938c08e55c0ee892595d14f2258cca2dce05"
_security_constants_bytes = SECURITY_CONSTANTS_PATH.read_bytes()
if hashlib.sha256(_security_constants_bytes).hexdigest() != SECURITY_CONSTANTS_SHA256:
    raise RuntimeError("SECURITY_CONSTANTS_DIGEST_MISMATCH")
SECURITY_CONSTANTS = json.loads(_security_constants_bytes.decode("utf-8"))

ZERO64 = "0" * 64
HEX64 = re.compile(r"^[a-f0-9]{64}$")
NOTE_ID_RE = re.compile(r"^note_[a-f0-9]{32}$")
EVENT_ID_RE = re.compile(r"^evt_[a-f0-9]{32}$")
TX_ID_RE = re.compile(r"^tx_[a-f0-9]{32}$")
TS_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")
SLUG_PATTERN = SECURITY_CONSTANTS["slug"]["pattern"]
SLUG_MAX_LENGTH = SECURITY_CONSTANTS["slug"]["max_length"]
SLUG_RE = re.compile(SLUG_PATTERN)
EXPORT_ID_RE = re.compile(r"^export_[a-f0-9]{32}$")

RESERVED_SLUGS = frozenset(SECURITY_CONSTANTS["slug"]["reserved"])
AUTHORITY_REJECT_SUBSTRINGS = tuple(SECURITY_CONSTANTS["authority"]["reject_substrings"])
AUTHORITY_VOCABULARY = tuple(SECURITY_CONSTANTS["authority"]["vocabulary"])
FORBIDDEN_REFLEXIVE_OPERATION_KINDS = frozenset(
    SECURITY_CONSTANTS["oracle"]["forbidden_reflexive_operation_kinds"]
)
DEFERRED_OPERATION_KIND = SECURITY_CONSTANTS["oracle"]["deferred_operation_kind"]
DEFERRED_REASON_CODE = SECURITY_CONSTANTS["oracle"]["deferred_reason_code"]
NOTE_STATUSES = frozenset(["draft", "review", "ready", "archived"])
ACTIONS = (
    "NOTE_CREATED",
    "NOTE_EDITED",
    "PREVIEW_GENERATED",
    "EXPORT_GENERATED",
    "EXPORT_VERIFICATION_PASSED",
    "EXPORT_VERIFICATION_FAILED",
)
ACTION_DETAIL_BRANCH = {
    "NOTE_CREATED": "note-transition",
    "NOTE_EDITED": "note-transition",
    "PREVIEW_GENERATED": "preview",
    "EXPORT_GENERATED": "export-generated",
    "EXPORT_VERIFICATION_PASSED": "export-verification",
    "EXPORT_VERIFICATION_FAILED": "export-verification",
}
DOMAIN_NOTE = "PA-P0A-NOTE-STATE-V1"
DOMAIN_EVENT = "PA-P0A-PROVENANCE-EVENT-V1"
DOMAIN_RECEIPT = "PA-P0A-EXPORT-RECEIPT-V2"
DOMAIN_CONTENT_SET = "PA-P0A-CONTENT-SET-V1"
DOMAIN_EXPORT_ID = "PA-P0A-EXPORT-ID-V1"
DOMAIN_RELAY_REQ = "PA-P0A-RELAY-REQUEST-V1"
DOMAIN_RELAY_RES = "PA-P0A-RELAY-RESPONSE-V1"
EXPORT_MEMBERS = [
    "index.html",
    "source.md",
    "metadata.json",
    "provenance.jsonl",
    "SHA256SUMS.txt",
    "export-receipt.json",
]
CONTENT_MEMBERS = ["index.html", "source.md", "metadata.json", "provenance.jsonl"]
WORKSPACE = "/home/anon/Projects/Pioneer-Alignment-App"
BRANCH = "phase-0a/local-vertical-slice"
BIND = "127.0.0.1"
PROHIBITED_AUTHORITY_KEYS = [
    "public_network",
    "lan_binding",
    "remote_preview",
    "external_provider",
    "provider_credentials",
    "identity_enrollment",
    "nex_or_lex",
    "federation",
    "governance",
    "deployment",
    "production_mutation",
    "dns_cloudflare_hosting_mutation",
    "public_repository_mutation",
    "github_remote_creation_or_push",
    "spending",
    "real_private_participant_data",
]
RAW_HTML_PATTERNS = [re.compile(value, re.I) for value in SECURITY_CONSTANTS["raw_html"]["patterns"]]


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def require_nfc(s: str, loc: str) -> None:
    if unicodedata.normalize("NFC", s) != s:
        raise ValueError(f"NON_NFC:{loc}")


def canonical_json_bytes(value: Any) -> bytes:
    def check(v: Any, path: str = "$") -> Any:
        if isinstance(v, float):
            raise ValueError(f"FLOAT_PROHIBITED:{path}")
        if isinstance(v, dict):
            out = {}
            for k in sorted(v.keys()):
                if not isinstance(k, str):
                    raise ValueError(f"NON_STRING_KEY:{path}")
                require_nfc(k, f"{path}.key")
                out[k] = check(v[k], f"{path}.{k}")
            return out
        if isinstance(v, list):
            return [check(x, f"{path}[]") for x in v]
        if isinstance(v, str):
            require_nfc(v, path)
            return v
        if isinstance(v, (int, bool)) or v is None:
            return v
        raise ValueError(f"UNSUPPORTED_TYPE:{path}:{type(v).__name__}")

    return json.dumps(check(value), sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def dumps_pretty(value: Any) -> str:
    return json.dumps(value, indent=2, ensure_ascii=False) + "\n"


def load_json_text(text: str) -> Any:
    """Load one JSON text while rejecting duplicate object keys."""
    def no_dup_object_pairs(pairs):
        out = {}
        for k, v in pairs:
            if k in out:
                raise ValueError(f"DUPLICATE_JSON_KEY:{k}")
            out[k] = v
        return out

    return json.loads(text, object_pairs_hook=no_dup_object_pairs)


def load_json(path: Path) -> Any:
    return load_json_text(path.read_text(encoding="utf-8"))


def domain_hash(domain: str, obj_without_hash: Any) -> str:
    return sha256_bytes(domain.encode("utf-8") + b"\x00" + canonical_json_bytes(obj_without_hash))


def note_state_hash(note: dict) -> str:
    body = {k: v for k, v in note.items() if k != "state_hash"}
    return domain_hash(DOMAIN_NOTE, body)


def event_hash(event: dict) -> str:
    body = {k: v for k, v in event.items() if k != "event_hash"}
    return domain_hash(DOMAIN_EVENT, body)


def receipt_hash(receipt: dict) -> str:
    body = {k: v for k, v in receipt.items() if k != "receipt_hash"}
    return domain_hash(DOMAIN_RECEIPT, body)


def content_set_sha256(member_hashes: dict[str, str]) -> str:
    ordered = [{"name": name, "sha256": member_hashes[name]} for name in CONTENT_MEMBERS]
    return domain_hash(DOMAIN_CONTENT_SET, ordered)


def export_id_from(
    note_id: str,
    note_version: int,
    note_state_hash_value: str,
    frozen_cut_event_hash: str,
    renderer_version: str,
    canonical_profile: str,
    content_set: str,
) -> str:
    payload = {
        "canonical_profile": canonical_profile,
        "content_set_sha256": content_set,
        "frozen_cut_event_hash": frozen_cut_event_hash,
        "note_id": note_id,
        "note_state_hash": note_state_hash_value,
        "note_version": note_version,
        "renderer_version": renderer_version,
    }
    return "export_" + domain_hash(DOMAIN_EXPORT_ID, payload)[:32]


def validate_slug(slug: str) -> str | None:
    if not isinstance(slug, str) or not slug:
        return "SLUG_EMPTY"
    if len(slug) > SLUG_MAX_LENGTH:
        return "SLUG_TOO_LONG"
    if not SLUG_RE.fullmatch(slug):
        if any(ord(c) > 127 for c in slug):
            return "NON_ASCII_SLUG"
        return "SLUG_PATTERN_INVALID"
    if slug in RESERVED_SLUGS:
        return "RESERVED_SLUG"
    return None


def detect_raw_html(text: str) -> str | None:
    for pat in RAW_HTML_PATTERNS:
        if pat.search(text):
            return "RAW_HTML_REJECTED"
    return None


def validate_note_state(note: dict, mode: str = "any") -> list[str]:
    errors: list[str] = []
    required = [
        "schema_version",
        "note_id",
        "version",
        "title",
        "slug",
        "summary",
        "body_markdown",
        "status",
        "created_at",
        "updated_at",
        "previous_state_hash",
        "state_hash",
    ]
    for k in required:
        if k not in note:
            errors.append(f"NOTE_MISSING_FIELD:{k}")
    if note.get("schema_version") != "pa.phase0a.note_state.v1":
        errors.append("NOTE_SCHEMA_VERSION")
    if not isinstance(note.get("note_id"), str) or not NOTE_ID_RE.match(note.get("note_id", "")):
        errors.append("NOTE_ID_INVALID")
    if not isinstance(note.get("version"), int) or isinstance(note.get("version"), bool) or note.get("version", 0) < 1:
        errors.append("NOTE_VERSION_INVALID")
    if note.get("status") not in NOTE_STATUSES:
        errors.append("NOTE_STATUS_INVALID")
    for ts in ("created_at", "updated_at"):
        if not isinstance(note.get(ts), str) or not TS_RE.match(note.get(ts, "")):
            errors.append(f"TIMESTAMP_INVALID:{ts}")
    slug_err = validate_slug(note.get("slug", ""))
    if slug_err:
        errors.append(slug_err)
    if not isinstance(note.get("title"), str) or not (1 <= len(note.get("title", "")) <= 200):
        errors.append("NOTE_TITLE_INVALID")
    if not isinstance(note.get("summary"), str) or len(note.get("summary", "")) > 500:
        errors.append("NOTE_SUMMARY_INVALID")
    body = note.get("body_markdown")
    if not isinstance(body, str) or len(body) > 1_000_000:
        errors.append("NOTE_BODY_INVALID")
    elif detect_raw_html(body):
        errors.append("RAW_HTML_REJECTED")
    for h in ("previous_state_hash", "state_hash"):
        if not isinstance(note.get(h), str) or not HEX64.match(note.get(h, "")):
            errors.append(f"NOTE_HASH_INVALID:{h}")
    extra = set(note) - set(required)
    if extra:
        errors.append("NOTE_EXTRA_FIELDS:" + ",".join(sorted(extra)))
    if errors:
        return errors
    if mode == "create":
        if note["version"] != 1:
            errors.append("NOTE_VERSION_NON_SEQUENTIAL")
        if note["previous_state_hash"] != ZERO64:
            errors.append("CREATE_SENTINEL_MISMATCH")
        if note["created_at"] != note["updated_at"]:
            errors.append("CREATE_TIMESTAMP_MISMATCH")
    expected = note_state_hash(note)
    if note["state_hash"] != expected:
        errors.append("STATE_HASH_MISMATCH")
    return errors


def _detail_branch_ok(action: str, details: dict) -> bool:
    branch = ACTION_DETAIL_BRANCH.get(action)
    if branch == "note-transition":
        return (
            set(details) == {"transaction_id", "source"}
            and isinstance(details.get("transaction_id"), str)
            and TX_ID_RE.match(details["transaction_id"] or "")
            and details.get("source") in ("operator-dashboard", "local-cli")
        )
    if branch == "preview":
        return (
            set(details) == {"renderer_version", "preview_sha256"}
            and isinstance(details.get("renderer_version"), str)
            and details["renderer_version"]
            and isinstance(details.get("preview_sha256"), str)
            and HEX64.match(details["preview_sha256"] or "")
        )
    if branch == "export-generated":
        return (
            set(details)
            >= {
                "export_id",
                "export_path",
                "content_set_sha256",
                "manifest_sha256",
                "zip_sha256_detached",
            }
            and isinstance(details.get("export_id"), str)
            and EXPORT_ID_RE.match(details.get("export_id", "") or "")
        )
    if branch == "export-verification":
        if action == "EXPORT_VERIFICATION_PASSED":
            return details.get("result") == "EXPORT_BYTES_VERIFIED"
        return "reason_code" in details and details.get("result") == "FAILED"
    return False


def validate_event(event: dict, prior_event_hash: str | None = None) -> list[str]:
    errors: list[str] = []
    required = [
        "schema_version",
        "event_id",
        "timestamp",
        "actor",
        "action",
        "subject",
        "previous_event_hash",
        "note_id",
        "note_version",
        "note_state_hash",
        "details",
        "event_hash",
    ]
    for k in required:
        if k not in event:
            errors.append(f"EVENT_MISSING_FIELD:{k}")
    if event.get("schema_version") != "pa.phase0a.provenance_event.v1":
        errors.append("EVENT_SCHEMA_VERSION")
    if not isinstance(event.get("event_id"), str) or not EVENT_ID_RE.match(event.get("event_id", "")):
        errors.append("EVENT_ID_INVALID")
    if not isinstance(event.get("timestamp"), str) or not TS_RE.match(event.get("timestamp", "")):
        errors.append("TIMESTAMP_INVALID")
    if event.get("actor") != "local-operator":
        errors.append("EVENT_ACTOR_INVALID")
    if event.get("action") not in ACTIONS:
        errors.append("EVENT_ACTION_INVALID")
    subj = event.get("subject")
    if not isinstance(subj, dict) or set(subj) != {"kind", "id"}:
        errors.append("EVENT_SUBJECT_INVALID")
    else:
        if subj.get("kind") not in ("note", "export"):
            errors.append("EVENT_SUBJECT_KIND")
        if event.get("action") in ("NOTE_CREATED", "NOTE_EDITED", "PREVIEW_GENERATED"):
            if subj.get("kind") != "note" or subj.get("id") != event.get("note_id"):
                errors.append("EVENT_SUBJECT_MISMATCH")
        if event.get("action", "").startswith("EXPORT_"):
            if subj.get("kind") != "export":
                errors.append("EVENT_SUBJECT_MISMATCH")
    for h in ("previous_event_hash", "note_state_hash", "event_hash"):
        if not isinstance(event.get(h), str) or not HEX64.match(event.get(h, "")):
            errors.append(f"EVENT_HASH_INVALID:{h}")
    if not isinstance(event.get("note_id"), str) or not NOTE_ID_RE.match(event.get("note_id", "")):
        errors.append("EVENT_NOTE_ID_INVALID")
    if not isinstance(event.get("note_version"), int) or isinstance(event.get("note_version"), bool) or event.get("note_version", 0) < 1:
        errors.append("EVENT_NOTE_VERSION_INVALID")
    details = event.get("details")
    if not isinstance(details, dict):
        errors.append("EVENT_DETAILS_INVALID")
    elif event.get("action") in ACTION_DETAIL_BRANCH and not _detail_branch_ok(event["action"], details):
        errors.append("EVENT_ACTION_DETAIL_MISMATCH")
    if prior_event_hash is not None and event.get("previous_event_hash") != prior_event_hash:
        errors.append("PREVIOUS_EVENT_HASH_MISMATCH")
    if errors:
        return errors
    if event["event_hash"] != event_hash(event):
        errors.append("EVENT_HASH_MISMATCH")
    return errors


def build_manifest_text(member_hashes: dict[str, str]) -> str:
    return "".join(f"{member_hashes[name]}  {name}\n" for name in CONTENT_MEMBERS)


def build_export_receipt(
    *,
    note_id: str,
    note_version: int,
    note_state_hash_value: str,
    frozen_cut_event_id: str,
    frozen_cut_event_hash: str,
    renderer_version: str,
    canonical_profile: str,
    member_bytes: dict[str, bytes],
) -> dict:
    member_hashes = {name: sha256_bytes(member_bytes[name]) for name in CONTENT_MEMBERS}
    manifest = build_manifest_text(member_hashes).encode("utf-8")
    member_hashes["SHA256SUMS.txt"] = sha256_bytes(manifest)
    css = content_set_sha256({k: member_hashes[k] for k in CONTENT_MEMBERS})
    eid = export_id_from(
        note_id,
        note_version,
        note_state_hash_value,
        frozen_cut_event_hash,
        renderer_version,
        canonical_profile,
        css,
    )
    receipt = {
        "schema_version": "pa.phase0a.export_receipt.v2",
        "export_id": eid,
        "note_id": note_id,
        "note_version": note_version,
        "note_state_hash": note_state_hash_value,
        "frozen_cut_event_id": frozen_cut_event_id,
        "frozen_cut_event_hash": frozen_cut_event_hash,
        "renderer_version": renderer_version,
        "canonical_profile": canonical_profile,
        "manifest_sha256": member_hashes["SHA256SUMS.txt"],
        "content_set_sha256": css,
        "receipt_hash": "",
    }
    receipt["receipt_hash"] = receipt_hash(receipt)
    return receipt, manifest


def build_export_zip(member_bytes: dict[str, bytes]) -> bytes:
    buf = BytesIO()
    # ZIP_STORED, fixed timestamp 1980-01-01
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_STORED) as zf:
        for name in EXPORT_MEMBERS:
            info = zipfile.ZipInfo(filename=name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_STORED
            info.create_system = 3
            info.external_attr = 0o644 << 16
            zf.writestr(info, member_bytes[name])
    return buf.getvalue()


def verify_export_bundle(member_bytes: dict[str, bytes]) -> list[str]:
    errors: list[str] = []
    if set(member_bytes) != set(EXPORT_MEMBERS):
        errors.append("EXPORT_MEMBER_SET_INVALID")
        return errors
    # order is implicit in dict construction for ZIP; check receipt/manifest
    try:
        receipt = json.loads(member_bytes["export-receipt.json"].decode("utf-8"))
    except Exception:
        return ["EXPORT_RECEIPT_INVALID"]
    if receipt.get("receipt_hash") != receipt_hash(receipt):
        errors.append("EXPORT_RECEIPT_HASH_MISMATCH")
    if "receipt_hash" not in receipt:
        errors.append("EXPORT_RECEIPT_INVALID")
    # receipt must not be in manifest
    manifest_text = member_bytes["SHA256SUMS.txt"].decode("utf-8")
    if "export-receipt.json" in manifest_text or "SHA256SUMS.txt" in [line.split()[-1] for line in manifest_text.splitlines() if line.strip()]:
        # SHA256SUMS must not list self
        for line in manifest_text.splitlines():
            if line.strip().endswith(" SHA256SUMS.txt") or line.strip().endswith("  SHA256SUMS.txt"):
                errors.append("EXPORT_MANIFEST_SELF_REF")
            if "export-receipt" in line:
                errors.append("EXPORT_MANIFEST_LISTS_RECEIPT")
    expected_lines = []
    for name in CONTENT_MEMBERS:
        h = sha256_bytes(member_bytes[name])
        expected_lines.append(f"{h}  {name}")
        if f"{h}  {name}" not in manifest_text:
            errors.append(f"EXPORT_HASH_MISMATCH:{name}")
    if manifest_text != "\n".join(expected_lines) + "\n":
        errors.append("EXPORT_MANIFEST_FORMAT")
    if receipt.get("manifest_sha256") != sha256_bytes(member_bytes["SHA256SUMS.txt"]):
        errors.append("EXPORT_MANIFEST_HASH_MISMATCH")
    css = content_set_sha256({name: sha256_bytes(member_bytes[name]) for name in CONTENT_MEMBERS})
    if receipt.get("content_set_sha256") != css:
        errors.append("EXPORT_CONTENT_SET_MISMATCH")
    expected_eid = export_id_from(
        receipt["note_id"],
        receipt["note_version"],
        receipt["note_state_hash"],
        receipt["frozen_cut_event_hash"],
        receipt["renderer_version"],
        receipt["canonical_profile"],
        css,
    )
    if receipt.get("export_id") != expected_eid:
        errors.append("EXPORT_ID_MISMATCH")
    return errors


# ---- minimal JSON Schema subset (draft 2020-12 features we use) ----

def validate_against_schema(instance: Any, schema: dict, path: str = "$") -> list[str]:
    errors: list[str] = []
    if not isinstance(schema, dict) or not schema:
        return [f"SCHEMA_EMPTY_OR_INVALID:{path}"]
    if "const" in schema:
        if instance != schema["const"]:
            errors.append(f"CONST_MISMATCH:{path}")
        return errors
    if "enum" in schema:
        if instance not in schema["enum"]:
            errors.append(f"ENUM_MISMATCH:{path}")
        return errors
    t = schema.get("type")
    if t == "object":
        if not isinstance(instance, dict):
            return [f"TYPE_OBJECT:{path}"]
        req = schema.get("required", [])
        for k in req:
            if k not in instance:
                errors.append(f"REQUIRED:{path}.{k}")
        props = schema.get("properties", {})
        addl = schema.get("additionalProperties", True)
        for k, v in instance.items():
            if k in props:
                errors.extend(validate_against_schema(v, props[k], f"{path}.{k}"))
            elif addl is False:
                errors.append(f"ADDITIONAL_PROPERTY:{path}.{k}")
            elif isinstance(addl, dict):
                errors.extend(validate_against_schema(v, addl, f"{path}.{k}"))
        return errors
    if t == "array":
        if not isinstance(instance, list):
            return [f"TYPE_ARRAY:{path}"]
        if "maxItems" in schema and len(instance) > schema["maxItems"]:
            errors.append(f"MAX_ITEMS:{path}")
        if "minItems" in schema and len(instance) < schema["minItems"]:
            errors.append(f"MIN_ITEMS:{path}")
        if "items" in schema:
            for i, item in enumerate(instance):
                errors.extend(validate_against_schema(item, schema["items"], f"{path}[{i}]"))
        return errors
    if t == "string":
        if not isinstance(instance, str):
            return [f"TYPE_STRING:{path}"]
        if "minLength" in schema and len(instance) < schema["minLength"]:
            errors.append(f"MIN_LENGTH:{path}")
        if "maxLength" in schema and len(instance) > schema["maxLength"]:
            errors.append(f"MAX_LENGTH:{path}")
        if "pattern" in schema and not re.search(schema["pattern"], instance):
            errors.append(f"PATTERN:{path}")
        return errors
    if t == "integer":
        if not isinstance(instance, int) or isinstance(instance, bool):
            return [f"TYPE_INTEGER:{path}"]
        if "minimum" in schema and instance < schema["minimum"]:
            errors.append(f"MINIMUM:{path}")
        if "maximum" in schema and instance > schema["maximum"]:
            errors.append(f"MAXIMUM:{path}")
        return errors
    if t == "boolean":
        if not isinstance(instance, bool):
            return [f"TYPE_BOOLEAN:{path}"]
        return errors
    if t == "null":
        if instance is not None:
            return [f"TYPE_NULL:{path}"]
        return errors
    if "oneOf" in schema:
        matches = 0
        for sub in schema["oneOf"]:
            if not validate_against_schema(instance, sub, path):
                matches += 1
        if matches != 1:
            errors.append(f"ONE_OF:{path}")
        return errors
    # untyped schema with only properties etc.
    if "properties" in schema and isinstance(instance, dict):
        return validate_against_schema(instance, {**schema, "type": "object"}, path)
    return errors


def schema_is_substantive(schema: Any) -> list[str]:
    """Reject empty/gutted schemas."""
    errors: list[str] = []
    if not isinstance(schema, dict) or not schema:
        return ["SCHEMA_EMPTY"]
    if schema.get("type") != "object" and "oneOf" not in schema and "$ref" not in schema:
        # allow meta docs; require either type or oneOf
        if "properties" not in schema and "required" not in schema:
            errors.append("SCHEMA_NOT_OBJECT")
    if schema.get("type") == "object":
        if not schema.get("required"):
            errors.append("SCHEMA_NO_REQUIRED")
        if not schema.get("properties"):
            errors.append("SCHEMA_NO_PROPERTIES")
        if schema.get("additionalProperties") is not False:
            # allow true only if explicitly open maps with max properties? We require closed.
            errors.append("SCHEMA_NOT_CLOSED")
    return errors


# ---- Fake Relay ----

def relay_request_hash(req: dict) -> str:
    body = {k: v for k, v in req.items() if k != "request_hash"}
    return domain_hash(DOMAIN_RELAY_REQ, body)


def relay_response_hash(resp: dict) -> str:
    body = {k: v for k, v in resp.items() if k != "response_hash"}
    return domain_hash(DOMAIN_RELAY_RES, body)


def fake_relay_complete(request: dict) -> dict:
    """Deterministic offline fake Relay. No network."""
    # validate request shape lightly
    required = ["schema_version", "request_id", "model", "prompt", "temperature", "max_tokens", "timeout_ms"]
    for k in required:
        if k not in request:
            raise ValueError(f"RELAY_REQUEST_INVALID:{k}")
    if request.get("schema_version") != "pa.phase0a.relay_request.v1":
        raise ValueError("RELAY_REQUEST_SCHEMA")
    if request.get("temperature") != 0:
        raise ValueError("RELAY_TEMPERATURE_MUST_BE_ZERO")
    if request.get("provider", "fake-offline") != "fake-offline":
        raise ValueError("RELAY_PROVIDER_MUST_BE_FAKE")
    prompt = request["prompt"]
    if prompt.startswith("ERROR:"):
        err = {
            "schema_version": "pa.phase0a.relay_error.v1",
            "request_id": request["request_id"],
            "category": "SYNTHETIC_ERROR",
            "message": prompt[6:] or "synthetic",
            "provider": "fake-offline",
            "model": request["model"],
            "synthetic": True,
            "request_hash": relay_request_hash({**request, "request_hash": ""}),
            "response_hash": "",
        }
        # attach request hash properly
        req_for_hash = dict(request)
        if "request_hash" in req_for_hash:
            pass
        rh = relay_request_hash(req_for_hash)
        err["request_hash"] = rh
        err["response_hash"] = relay_response_hash(err)
        return {"ok": False, "error": err, "reason_code": "RELAY_SYNTHETIC_ERROR"}
    if prompt.startswith("TIMEOUT:"):
        err = {
            "schema_version": "pa.phase0a.relay_error.v1",
            "request_id": request["request_id"],
            "category": "SYNTHETIC_TIMEOUT",
            "message": "timeout",
            "provider": "fake-offline",
            "model": request["model"],
            "synthetic": True,
            "request_hash": relay_request_hash(request),
            "response_hash": "",
        }
        err["response_hash"] = relay_response_hash(err)
        return {"ok": False, "error": err, "reason_code": "RELAY_SYNTHETIC_TIMEOUT"}
    # success
    content = "FAKE:" + sha256_bytes(prompt.encode("utf-8"))[:32]
    resp = {
        "schema_version": "pa.phase0a.relay_response.v1",
        "request_id": request["request_id"],
        "provider": "fake-offline",
        "model": request["model"],
        "content": content,
        "synthetic": True,
        "request_hash": relay_request_hash(request),
        "response_hash": "",
    }
    resp["response_hash"] = relay_response_hash(resp)
    return {"ok": True, "response": resp, "reason_code": "OK"}


# ---- DAG transition evaluator ----

N50_OUTCOMES = tuple(SECURITY_CONSTANTS["transition"]["n50_outcomes"])
N60_OUTCOMES = tuple(SECURITY_CONSTANTS["transition"]["n60_outcomes"])
N70_OUTCOMES = tuple(SECURITY_CONSTANTS["transition"]["n70_outcomes"])
ALLOWED_TRACES = [tuple(item) for item in SECURITY_CONSTANTS["transition"]["allowed_traces"]]

TERMINAL_HOLD = "HOLD"


def evaluate_review_trace(n50: str, n60: str, n70: str) -> dict:
    if n50 == TERMINAL_HOLD:
        return {
            "allowed": False,
            "n80_eligible": False,
            "reason_code": "HOLD_TERMINAL",
        }
    if (n50, n60, n70) in ALLOWED_TRACES:
        return {
            "allowed": True,
            "n80_eligible": True,
            "reason_code": "OK",
        }
    return {
        "allowed": False,
        "n80_eligible": False,
        "reason_code": "INVALID_REVIEW_TRACE",
    }


def n80_identity_check(
    reviewed_binding_sha256: str,
    reviewed_tree_sha: str,
    reviewed_source_manifest_sha256: str,
    reviewed_evidence_sha256: str,
    handoff_binding_sha256: str,
    handoff_tree_sha: str,
    handoff_source_manifest_sha256: str,
    handoff_evidence_sha256: str,
    remotes: list,
    bind: str,
    provider_adapters: list,
    untracked_forbidden: list,
) -> list[str]:
    errors = []
    if reviewed_binding_sha256 != handoff_binding_sha256:
        errors.append("N80_BINDING_MISMATCH")
    if reviewed_tree_sha != handoff_tree_sha:
        errors.append("N80_TREE_MISMATCH")
    if reviewed_source_manifest_sha256 != handoff_source_manifest_sha256:
        errors.append("N80_SOURCE_MANIFEST_MISMATCH")
    if reviewed_evidence_sha256 != handoff_evidence_sha256:
        errors.append("N80_EVIDENCE_MISMATCH")
    if remotes:
        errors.append("N80_REMOTES_PRESENT")
    if bind != BIND:
        errors.append("N80_BIND_INVALID")
    if provider_adapters:
        errors.append("N80_PROVIDER_ADAPTER_PRESENT")
    if untracked_forbidden:
        errors.append("N80_UNTRACKED_FORBIDDEN")
    return errors


# ---- host preflight matrix ----

HOST_STATES = [
    "ABSENT",
    "EMPTY_DIR",
    "GIT_REPO_CLEAN",
    "GIT_REPO_DIRTY",
    "NON_GIT_NONEMPTY",
    "SYMLINK",
    "UNWRITABLE",
    "STALE_LOCK",
    "LIVE_FOREIGN_LOCK",
]


def host_preflight_decision(state: str) -> dict:
    if state == "ABSENT":
        return {"decision": "BOOTSTRAP_NEW", "reason_code": "OK"}
    if state == "EMPTY_DIR":
        return {"decision": "BOOTSTRAP_NEW", "reason_code": "OK"}
    if state == "GIT_REPO_CLEAN":
        return {"decision": "RECOVER_EXISTING", "reason_code": "OK"}
    if state == "GIT_REPO_DIRTY":
        return {"decision": "RECOVER_EXISTING_WITH_DIRTY_INVENTORY", "reason_code": "OK"}
    if state == "NON_GIT_NONEMPTY":
        return {"decision": "REJECT", "reason_code": "HOST_NON_GIT_NONEMPTY"}
    if state == "SYMLINK":
        return {"decision": "REJECT", "reason_code": "HOST_SYMLINK"}
    if state == "UNWRITABLE":
        return {"decision": "REJECT", "reason_code": "HOST_UNWRITABLE"}
    if state == "STALE_LOCK":
        return {"decision": "REJECT", "reason_code": "HOST_STALE_LOCK"}
    if state == "LIVE_FOREIGN_LOCK":
        return {"decision": "REJECT", "reason_code": "HOST_LIVE_FOREIGN_LOCK"}
    return {"decision": "REJECT", "reason_code": "HOST_STATE_UNKNOWN"}


# ---- evidence protocol ----

def validate_evidence_paths(paths: list[str]) -> list[str]:
    errors = []
    for p in paths:
        if not isinstance(p, str) or not p:
            errors.append("EVIDENCE_PATH_EMPTY")
            continue
        if p.startswith("/") or p.startswith("\\"):
            errors.append("EVIDENCE_PATH_ABSOLUTE")
        if ".." in p.split("/"):
            errors.append("EVIDENCE_PATH_TRAVERSAL")
        if p.startswith("evidence/") is False and not p.startswith("receipts/"):
            # allow either prefix
            if not re.match(r"^[A-Za-z0-9._/-]+$", p):
                errors.append("EVIDENCE_PATH_CHARS")
    return errors


def sort_stable(items: list) -> list:
    """Deterministic sort for set-derived outputs."""
    try:
        return sorted(items, key=lambda x: canonical_json_bytes(x))
    except Exception:
        return sorted(items, key=lambda x: json.dumps(x, sort_keys=True, default=str))
