# Round 024 controlling Phase 0A repair summary

Adjudication: **`ROUND024_REPAIR_COMPLETE_AWAITING_INDEPENDENT_REREVIEW`**

Scope: specification and executable-gate repair only. No implementation
candidate exists. No application tests, host preflight, repository mutation,
deployment, credential, provider, DNS, Cloudflare, wallet, on-chain, economy,
federation, governance, or public-state action occurred.

## Repairs

- R23-F01: `meta_validate_round24.py` applies NFKC and an explicit pinned
  Greek/Cyrillic/Armenian confusable map, then rejects a leaf that combines
  Latin with any of those script families. NFKC alone is explicitly not
  treated as sufficient.
- R23-F02: authority matching now runs per leaf and on punctuation-collapsed
  sibling/document projections. The unlocked validator is parsed as Python;
  generator/comprehension joins are forbidden and static compositions are
  folded. Fragmented array, object, and table attacks reject semantically.
- R23-F03: every Round 024 member and the mutable relay control/tool/manifest
  surfaces are scanned. Earlier exchange/original bytes skipped by the content
  scan must match `05_MANIFESTS/INPUT_SHA256SUMS.txt`; any unpinned incoming
  exchange member is scanned.
- R23-F04: the acceptance contract has a closed 14-key top-level vocabulary.
  Release and deferral override language is included in the negative policy.
- R23-F05: review-bypass and HOLD-override language is included in the negative
  policy, and mutable control documents are within the scan surface.
- R23-F06: freshness counters are documented only as an anti-staleness control.
  They are not cited as evidence against a determined coherent author.
- R21-F01 and residual R19-F02 close by succession because the matcher,
  projection, and relay coverage repairs all close together.

## Permanent evidence

The registry contains 88 deterministic classes: 66 inherited, 14 adopted from
Round 023 without alteration of their attack intent, and eight additional
confusable/fragmentation/control-path variants. Every adopted class performs a
security-constant repin, library relock, operational counter/cross-hash
recoherence, and acyclic manifest rebind before scoring. A digest/import crash
or stale counter is never an intended rejection.

The 43 legacy closure negatives remain an independent compatibility floor.
Mutation and closure receipts must be byte-identical under `PYTHONHASHSEED=1`
and `PYTHONHASHSEED=2`.

## Bytecode and self-lock limits

The builder continues to exclude `__pycache__` and bytecode-suffixed members.
The gate also rejects their presence. Therefore a tree from which such members
would be excluded is unshippable; exclusion is not evidence that the source
tree and archive were equivalent.

The validator cannot exact-hash lock its own bytes. Its self-source is instead
pinned by the relay-level immutable-input manifest after packaging. This is a
structural limit, not a claimed self-verifying anchor.

## Preserved posture

Oracle arithmetic remains 54 decided / 35 deferred and candidate-ineligible.
The evaluator preserves terminal HOLD, and N80 cannot release non-reviewed
bytes. Export identity, evidence closure, archive containment, active-content
semantics, and hash-seed determinism remain required. All four external
blockers and the separate Rounds 3–10 architecture HOLD remain unchanged.

