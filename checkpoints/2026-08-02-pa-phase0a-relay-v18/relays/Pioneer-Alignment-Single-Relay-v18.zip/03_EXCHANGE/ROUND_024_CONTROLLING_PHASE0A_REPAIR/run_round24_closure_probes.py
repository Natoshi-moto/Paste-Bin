#!/usr/bin/env python3
"""Deterministic Round 024 closure probes for prior and current findings.

The suite is intentionally self-contained and offline.  Every filesystem mutation is
performed in a disposable copy of the complete relay.  Receipt content contains no
timestamps, random temporary paths, or hash-seed-dependent ordering.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from itertools import product
from pathlib import Path, PurePosixPath
from typing import Any, Callable

sys.dont_write_bytecode = True

ROUND_ROOT = Path(__file__).resolve().parent
RELAY_ROOT = ROUND_ROOT.parents[1]
ROUND_RELATIVE = ROUND_ROOT.relative_to(RELAY_ROOT)
CONTRACT_NAME = "PHASE0A_ACCEPTANCE_CONTRACT.v4.json"
META_NAME = "meta_validate_round24.py"

sys.path.insert(0, str(ROUND_ROOT))
from independent_oracle import evaluate_case, evaluate_contract  # noqa: E402
from run_round24_mutations import reason_codes, rebind_acyclic, repin_constants  # noqa: E402
from lib_phase0a import (  # noqa: E402
    ALLOWED_TRACES,
    AUTHORITY_REJECT_SUBSTRINGS,
    AUTHORITY_VOCABULARY,
    BIND,
    DEFERRED_OPERATION_KIND,
    DOMAIN_CONTENT_SET,
    DOMAIN_EXPORT_ID,
    DOMAIN_RECEIPT,
    FORBIDDEN_REFLEXIVE_OPERATION_KINDS,
    N50_OUTCOMES,
    N60_OUTCOMES,
    N70_OUTCOMES,
    RESERVED_SLUGS,
    SECURITY_CONSTANTS,
    SECURITY_CONSTANTS_PATH,
    SECURITY_CONSTANTS_SHA256,
    SLUG_MAX_LENGTH,
    detect_raw_html,
    evaluate_review_trace,
    n80_identity_check,
    validate_slug,
)


Mutation = Callable[[Path, Path], None]


def load_json(path: Path) -> Any:
    def reject_duplicates(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"DUPLICATE_JSON_KEY:{key}")
            result[key] = value
        return result

    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=reject_duplicates)


def save_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, sort_keys=False) + "\n",
        encoding="utf-8",
    )


def stable_json(value: Any) -> str:
    return json.dumps(value, indent=2, ensure_ascii=False, sort_keys=True) + "\n"


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def python_env(seed: str = "1") -> dict[str, str]:
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONHASHSEED"] = seed
    return env


def run_python(
    script: Path,
    args: list[str] | None = None,
    *,
    cwd: Path,
    seed: str = "1",
) -> subprocess.CompletedProcess[str]:
    env = python_env(seed)
    return subprocess.run(
        ["python3", "-S", str(script), *(args or [])],
        cwd=cwd,
        env=env,
        text=True,
        capture_output=True,
        timeout=120,
        check=False,
    )


def parse_json_output(completed: subprocess.CompletedProcess[str]) -> dict[str, Any]:
    try:
        value = json.loads(completed.stdout)
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def error_codes(receipt: dict[str, Any]) -> list[str]:
    return sorted({
        str(item).split(":", 1)[0]
        for item in receipt.get("errors", [])
    })


def copied_relay() -> tuple[tempfile.TemporaryDirectory[str], Path, Path]:
    temporary = tempfile.TemporaryDirectory(prefix="pa-r024-closure-")
    relay = Path(temporary.name) / "relay"
    shutil.copytree(
        RELAY_ROOT,
        relay,
        ignore=lambda _path, names: {
            name for name in names if name == "__pycache__" or name.endswith(".pyc")
        },
    )
    return temporary, relay, relay / ROUND_RELATIVE


def meta_mutation_probe(
    probe_id: str,
    mutation: Mutation,
    expected_codes: set[str],
) -> dict[str, Any]:
    temporary, relay, round_root = copied_relay()
    try:
        mutation(relay, round_root)
        rebind_acyclic(round_root)
        completed = run_python(
            round_root / META_NAME,
            ["--root", str(round_root), "--semantic-only"],
            cwd=round_root,
        )
        receipt = parse_json_output(completed)
        observed = error_codes(receipt)
        intended = completed.returncode != 0 and expected_codes <= set(observed)
        return {
            "probe_id": probe_id,
            "exit_code": completed.returncode,
            "expected_error_codes": sorted(expected_codes),
            "observed_error_codes": observed,
            "rejected": completed.returncode != 0,
            "rejected_for_intended_reason": intended,
        }
    except Exception as exc:
        return {
            "probe_id": probe_id,
            "exit_code": None,
            "expected_error_codes": sorted(expected_codes),
            "observed_error_codes": [],
            "rejected": False,
            "rejected_for_intended_reason": False,
            "harness_error_type": type(exc).__name__,
        }
    finally:
        temporary.cleanup()


def meta_acceptance_probe(probe_id: str, mutation: Mutation) -> dict[str, Any]:
    temporary, relay, round_root = copied_relay()
    try:
        mutation(relay, round_root)
        rebind_acyclic(round_root)
        completed = run_python(
            round_root / META_NAME,
            ["--root", str(round_root)],
            cwd=round_root,
        )
        receipt = parse_json_output(completed)
        return {
            "probe_id": probe_id,
            "exit_code": completed.returncode,
            "observed_error_codes": error_codes(receipt),
            "accepted": completed.returncode == 0,
        }
    except Exception as exc:
        return {
            "probe_id": probe_id,
            "exit_code": None,
            "observed_error_codes": [],
            "accepted": False,
            "harness_error_type": type(exc).__name__,
        }
    finally:
        temporary.cleanup()


def mutate_authority(phrase: str) -> Mutation:
    def apply(_relay: Path, round_root: Path) -> None:
        path = round_root / "PHASE0A_BUILD_DAG.v2.json"
        document = load_json(path)
        nodes = document.get("nodes") or []
        node = next(
            (item for item in nodes if item.get("node_id") == "P0A-N40-BUILD-CANDIDATE"),
            nodes[0],
        )
        node.setdefault("required_checks", []).append(phrase)
        save_json(path, document)

    return apply


def mutate_python_authority(phrase: str) -> Mutation:
    def apply(_relay: Path, round_root: Path) -> None:
        path = round_root / "transition_evaluator.py"
        path.write_text(
            path.read_text(encoding="utf-8") + f"\nROUND20_AUTHORITY_NEGATIVE_CONTROL = {phrase!r}\n",
            encoding="utf-8",
        )

    return apply


def mutate_authority_manifest_omission(phrase: str) -> Mutation:
    """Try to hide a poisoned required Python file by editing manifest membership."""
    def apply(_relay: Path, round_root: Path) -> None:
        manifest_path = round_root / "PHASE0A_NORMATIVE_MANIFEST.v1.json"
        manifest = load_json(manifest_path)
        manifest["members"] = [
            member for member in manifest["members"]
            if member.get("path") != "independent_oracle.py"
        ]
        library = next(
            member for member in manifest["members"]
            if member.get("path") == "lib_phase0a.py"
        )
        library["role"] = "oracle"
        save_json(manifest_path, manifest)
        oracle_path = round_root / "independent_oracle.py"
        oracle_path.write_text(
            oracle_path.read_text(encoding="utf-8")
            + f"\nROUND20_MANIFEST_OMISSION_BYPASS = {phrase!r}\n",
            encoding="utf-8",
        )

    return apply


def mutate_probe_script_unrelated_authority(phrase: str) -> Mutation:
    """Put an exact negative-control payload outside its declared container."""
    def apply(_relay: Path, round_root: Path) -> None:
        path = round_root / "run_round24_mutations.py"
        path.write_text(
            path.read_text(encoding="utf-8")
            + f"\nROUND20_UNRELATED_AUTHORITY = {phrase!r}\n",
            encoding="utf-8",
        )

    return apply


def mutate_authority_vocabulary_empty(_relay: Path, round_root: Path) -> None:
    constants_path = round_root / "PHASE0A_SECURITY_CONSTANTS.v1.json"
    old_digest = sha256_file(constants_path)
    constants = load_json(constants_path)
    constants["authority"]["vocabulary"] = []
    constants["authority"]["reject_substrings"] = []
    constants["authority"]["canonical_negative_policy_tokens"] = []
    constants["authority"]["probe_payloads"] = []
    save_json(constants_path, constants)
    new_digest = sha256_file(constants_path)
    library_path = round_root / "lib_phase0a.py"
    library_text = library_path.read_text(encoding="utf-8")
    if old_digest not in library_text:
        raise ValueError("SECURITY_CONSTANTS_PIN_NOT_FOUND")
    library_path.write_text(library_text.replace(old_digest, new_digest), encoding="utf-8")
    dag_path = round_root / "PHASE0A_BUILD_DAG.v2.json"
    dag = load_json(dag_path)
    dag["authority_scan"]["reject_substrings"] = []
    save_json(dag_path, dag)


def mutate_unsupported_normative_extension(phrase: str) -> Mutation:
    def apply(_relay: Path, round_root: Path) -> None:
        payload_path = round_root / "evil.yaml"
        payload_path.write_text(f"required_action: {phrase}\n", encoding="utf-8")
        manifest_path = round_root / "PHASE0A_NORMATIVE_MANIFEST.v1.json"
        manifest = load_json(manifest_path)
        manifest["members"].append({
            "path": "evil.yaml",
            "role": "normative_spec",
            "sha256": sha256_file(payload_path),
        })
        save_json(manifest_path, manifest)

    return apply


def mutate_r21_authority_undeclared(_relay: Path, round_root: Path) -> None:
    payload = SECURITY_CONSTANTS["authority"]["probe_payloads"][2]
    (round_root / "NOTES.md").write_text("# Notes\n\n" + payload + "\n", encoding="utf-8")


def mutate_r21_text_disguised_binary(_relay: Path, round_root: Path) -> None:
    payload = SECURITY_CONSTANTS["authority"]["probe_payloads"][3]
    (round_root / "notes.bin").write_text(payload + "\n", encoding="utf-8")


def mutate_r21_authority_exception_launder(_relay: Path, round_root: Path) -> None:
    constants_path = round_root / "PHASE0A_SECURITY_CONSTANTS.v1.json"
    constants = load_json(constants_path)
    constants["authority"]["probe_payloads"].append(
        constants["authority"]["probe_payloads"][3]
    )
    save_json(constants_path, constants)
    repin_constants(round_root)


def mutate_r21_authority_python_bytes_balanced(_relay: Path, round_root: Path) -> None:
    """Ship prohibited bytes while balancing the live string counter."""
    payload = SECURITY_CONSTANTS["authority"]["probe_payloads"][3]
    target = round_root / "scripts/operator_bytes.py"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(f"OPERATOR_STEP = {payload.encode('utf-8')!r}\n", encoding="utf-8")
    counter_balance = round_root / "transition_evaluator.py"
    text = counter_balance.read_text(encoding="utf-8")
    marker = "#!/usr/bin/env python3\n"
    if text.count(marker) != 1:
        raise ValueError("AUTHORITY_COUNTER_BALANCE_ANCHOR_NOT_FOUND")
    counter_balance.write_text(text.replace(marker, "", 1), encoding="utf-8")


def mutate_r21_authority_python_fstring_balanced(_relay: Path, round_root: Path) -> None:
    """Compose prohibited text from harmless-looking f-string leaves."""
    payload = SECURITY_CONSTANTS["authority"]["probe_payloads"][3]
    prefix, provider = payload.rsplit(" ", 1)
    target = round_root / "scripts/operator_fstring.py"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        "OPERATOR_STEP = f" + json.dumps(prefix + " {'" + provider + "'}") + "\n",
        encoding="utf-8",
    )
    for name in ("transition_evaluator.py", "export_generator.py", "export_verifier.py"):
        counter_balance = round_root / name
        text = counter_balance.read_text(encoding="utf-8")
        marker = "#!/usr/bin/env python3\n"
        if text.count(marker) != 1:
            raise ValueError(f"AUTHORITY_COUNTER_BALANCE_ANCHOR_NOT_FOUND:{name}")
        counter_balance.write_text(text.replace(marker, "", 1), encoding="utf-8")


def mutate_r21_authority_allowed_python_composition(expression: str) -> Mutation:
    """Place one static composition in an allowlisted script, count-balanced."""
    def apply(_relay: Path, round_root: Path) -> None:
        target = round_root / "export_generator.py"
        target.write_text(target.read_text(encoding="utf-8") + "\n" + expression, encoding="utf-8")
        for name in ("transition_evaluator.py", "independent_oracle.py", "export_verifier.py"):
            counter_balance = round_root / name
            text = counter_balance.read_text(encoding="utf-8")
            marker = "#!/usr/bin/env python3\n"
            if text.count(marker) != 1:
                raise ValueError(f"AUTHORITY_COUNTER_BALANCE_ANCHOR_NOT_FOUND:{name}")
            counter_balance.write_text(text.replace(marker, "", 1), encoding="utf-8")

    return apply


def mutate_r21_authority_locked_python_indirection(
    expression: str,
    balance_files: tuple[str, ...],
) -> Mutation:
    """Exercise runtime composition forms outside the static fold allowlist."""
    def apply(_relay: Path, round_root: Path) -> None:
        target = round_root / "export_generator.py"
        text = target.read_text(encoding="utf-8")
        marker = 'if __name__ == "__main__":\n'
        if text.count(marker) != 1:
            raise ValueError("PYTHON_INDIRECTION_INSERTION_ANCHOR_NOT_FOUND")
        target.write_text(text.replace(marker, expression + "\n" + marker), encoding="utf-8")
        for name in balance_files:
            counter_balance = round_root / name
            balanced_text = counter_balance.read_text(encoding="utf-8")
            shebang = "#!/usr/bin/env python3\n"
            if balanced_text.count(shebang) != 1:
                raise ValueError(f"AUTHORITY_COUNTER_BALANCE_ANCHOR_NOT_FOUND:{name}")
            counter_balance.write_text(balanced_text.replace(shebang, "", 1), encoding="utf-8")

    return apply


def mutate_r21_authority_zero_width_markdown(_relay: Path, round_root: Path) -> None:
    payload = SECURITY_CONSTANTS["authority"]["probe_payloads"][3]
    provider = "Cloudflare"
    smuggled = payload.replace(provider, provider[:5] + "\u200b" + provider[5:])
    target = round_root / "START_HERE.md"
    target.write_text(target.read_text(encoding="utf-8") + "\n" + smuggled + "\n", encoding="utf-8")


def mutate_r21_slug_maxlength(_relay: Path, round_root: Path) -> None:
    constants_path = round_root / "PHASE0A_SECURITY_CONSTANTS.v1.json"
    constants = load_json(constants_path)
    constants["slug"]["max_length"] = 100000
    save_json(constants_path, constants)
    repin_constants(round_root)
    schema_path = round_root / "PHASE0A_NOTE_STATE.schema.json"
    schema = load_json(schema_path)
    schema["properties"]["slug"]["maxLength"] = 100000
    save_json(schema_path, schema)


def mutate_r21_slug_overlength_removed(_relay: Path, round_root: Path) -> None:
    constants_path = round_root / "PHASE0A_SECURITY_CONSTANTS.v1.json"
    constants = load_json(constants_path)
    constants["slug"]["hostile_corpus"] = [
        value for value in constants["slug"]["hostile_corpus"]
        if len(value) <= 80
    ]
    save_json(constants_path, constants)
    repin_constants(round_root)


def mutate_r21_export_spec_domain(_relay: Path, round_root: Path) -> None:
    path = round_root / "PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v3.json"
    value = load_json(path)
    value["identity"]["export_id"]["domain"] = "PA-P0A-EXPORT-ID-V2"
    save_json(path, value)


def mutate_r21_export_runtime_domain(_relay: Path, round_root: Path) -> None:
    path = round_root / "lib_phase0a.py"
    text = path.read_text(encoding="utf-8")
    old = 'DOMAIN_EXPORT_ID = "PA-P0A-EXPORT-ID-V1"'
    new = 'DOMAIN_EXPORT_ID = "PA-P0A-EXPORT-ID-V2"'
    if text.count(old) != 1:
        raise ValueError("EXPORT_DOMAIN_RUNTIME_ANCHOR_NOT_FOUND")
    path.write_text(text.replace(old, new), encoding="utf-8")


def mutate_r21_export_domains_coherently(_relay: Path, round_root: Path) -> None:
    mutate_r21_export_runtime_domain(_relay, round_root)
    mutate_r21_export_spec_domain(_relay, round_root)


def mutate_r21_spec_receipt_counter(_relay: Path, round_root: Path) -> None:
    for name in ("SPEC_VALIDATION_RECEIPT.semantic.json", "SPEC_VALIDATION_RECEIPT.json"):
        path = round_root / name
        value = load_json(path)
        value["authority_strings_scanned"] = int(value["authority_strings_scanned"]) + 1
        save_json(path, value)


def mutate_r21_closure_receipt_counter(_relay: Path, round_root: Path) -> None:
    path = round_root / "CLOSURE_PROBE_RECEIPT.json"
    value = load_json(path)
    baseline = value.get("baseline_validation") or {}
    baseline["authority_strings_scanned"] = int(baseline.get("authority_strings_scanned", 0)) + 1
    save_json(path, value)


def mutate_raw_html_echo(_relay: Path, round_root: Path) -> None:
    path = round_root / CONTRACT_NAME
    contract = load_json(path)
    hostile = [
        item for item in contract["cases"]
        if item.get("fixture_inline", {}).get("operation", {}).get("kind") == "VALIDATE_RAW_HTML"
        and detect_raw_html(item.get("fixture_inline", {}).get("input", {}).get("body_markdown", ""))
    ]
    for index, case in enumerate(hostile):
        case["case_id"] = f"C-R20-RENAMED-ECHO-{index:03d}"
        case["fixture_inline"]["operation"] = {"kind": "RENAMED_ECHO_BEHAVIOUR"}
        case["fixture_inline"]["expected_observable"] = {
            "transition": "ACCEPT",
            "reason_code": "OK",
        }
        case["expected_transition"] = "ACCEPT"
        case["expected_reason_code"] = "OK"
    save_json(path, contract)


def mutate_runner_method_identifiers(_relay: Path, round_root: Path) -> None:
    contract_path = round_root / CONTRACT_NAME
    contract = load_json(contract_path)
    replacements = {}
    for index, test in enumerate(contract["tests"]):
        old = test["runner_method"]
        new = f"renamed.runner.capability.{index:03d}"
        replacements[old] = new
        test["runner_method"] = new
    for case in contract["cases"]:
        case["runner_method"] = replacements[case["runner_method"]]
    save_json(contract_path, contract)
    runner_path = round_root / "PHASE0A_RUNNER_INTERFACE.v2.json"
    runner = load_json(runner_path)
    runner["required_runner_methods"] = [
        replacements.get(value, value) for value in runner["required_runner_methods"]
    ]
    save_json(runner_path, runner)


def evidence_context(round_root: Path) -> tuple[Path, dict[str, Any], list[dict[str, Any]]]:
    protocol = load_json(round_root / "PHASE0A_EVIDENCE_PROTOCOL.v1.json")
    vectors = load_json(round_root / "PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json")
    evidence = vectors["positive_fixture"]["candidate_evidence"]
    results = [
        *evidence.get("case_results", []),
        *evidence.get("assertion_results", []),
        *evidence.get("mutant_results", []),
    ]
    evidence_root = round_root / protocol["synthetic_fixture_root"]
    return evidence_root, vectors, results


def mutate_evidence_tamper(_relay: Path, round_root: Path) -> None:
    evidence_root, _vectors, results = evidence_context(round_root)
    target = evidence_root / results[0]["evidence_path"]
    target.write_bytes(target.read_bytes() + b"\nround20-tamper\n")


def mutate_evidence_missing(_relay: Path, round_root: Path) -> None:
    evidence_root, _vectors, results = evidence_context(round_root)
    (evidence_root / results[0]["evidence_path"]).unlink()


def mutate_evidence_unsafe(_relay: Path, round_root: Path) -> None:
    path = round_root / "PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json"
    vectors = load_json(path)
    vectors["positive_fixture"]["candidate_evidence"]["case_results"][0]["evidence_path"] = "../escape.json"
    save_json(path, vectors)


def mutate_evidence_member_removed(_relay: Path, round_root: Path) -> None:
    path = round_root / "PHASE0A_NORMATIVE_MANIFEST.v1.json"
    manifest = load_json(path)
    members = manifest.get("members") or []
    evidence_root, _vectors, results = evidence_context(round_root)
    target = evidence_root / results[0]["evidence_path"]
    target_relative = target.relative_to(round_root).as_posix()
    manifest["members"] = [
        member for member in members
        if member.get("path") != target_relative
    ]
    members = manifest["members"]
    manifest["member_count"] = len(members)
    save_json(path, manifest)


def mutate_slug_pattern(_relay: Path, round_root: Path) -> None:
    path = round_root / "PHASE0A_NOTE_STATE.schema.json"
    schema = load_json(path)
    schema["properties"]["slug"]["pattern"] = "^[a-z0-9.\\-]{1,64}$"
    save_json(path, schema)


def mutate_slug_reserved_trimmed(_relay: Path, round_root: Path) -> None:
    path = round_root / "PHASE0A_NOTE_STATE.schema.json"
    schema = load_json(path)
    schema["x-phase0a-slug-reserved"] = ["admin"]
    save_json(path, schema)


def mutate_slug_reserved_empty(_relay: Path, round_root: Path) -> None:
    path = round_root / "PHASE0A_NOTE_STATE.schema.json"
    schema = load_json(path)
    schema["x-phase0a-slug-reserved"] = []
    save_json(path, schema)


def mutate_forbidden_examples_empty(_relay: Path, round_root: Path) -> None:
    path = round_root / "PHASE0A_TRANSITION_TABLE.v1.json"
    table = load_json(path)
    table["forbidden_examples"] = []
    save_json(path, table)


def mutate_transition_vocabulary_shrink(_relay: Path, round_root: Path) -> None:
    constants_path = round_root / "PHASE0A_SECURITY_CONSTANTS.v1.json"
    old_digest = sha256_file(constants_path)
    constants = load_json(constants_path)
    constants["transition"]["n50_outcomes"] = ["PASS", "REPAIR_REQUIRED"]
    save_json(constants_path, constants)
    new_digest = sha256_file(constants_path)
    library_path = round_root / "lib_phase0a.py"
    library_text = library_path.read_text(encoding="utf-8")
    if old_digest not in library_text:
        raise ValueError("SECURITY_CONSTANTS_PIN_NOT_FOUND")
    library_path.write_text(library_text.replace(old_digest, new_digest), encoding="utf-8")
    table_path = round_root / "PHASE0A_TRANSITION_TABLE.v1.json"
    table = load_json(table_path)
    table["n50_outcomes"] = ["PASS", "REPAIR_REQUIRED"]
    table["forbidden_examples"] = [
        row for row in table["forbidden_examples"] if row.get("n50") != "HOLD"
    ]
    save_json(table_path, table)


def mutate_final_node_bypass(_relay: Path, round_root: Path) -> None:
    path = round_root / "PHASE0A_BUILD_DAG.v2.json"
    dag = load_json(path)
    implementation = next(node for node in dag["nodes"] if node.get("kind") == "implementation")
    dag["final_node"] = implementation["node_id"]
    save_json(path, dag)


def add_cache_noise(_relay: Path, round_root: Path) -> None:
    cache = round_root / "__pycache__"
    cache.mkdir(parents=True, exist_ok=True)
    (cache / "round20_probe.cpython-999.pyc").write_bytes(b"cache-noise")
    (round_root / "round20_probe.pyc").write_bytes(b"cache-noise")


def mutate_operational_receipt_empty(_relay: Path, round_root: Path) -> None:
    save_json(round_root / "ORACLE_RECEIPT.json", {})


def mutate_operational_receipt_extra_claim(_relay: Path, round_root: Path) -> None:
    path = round_root / "CLOSURE_PROBE_RECEIPT.json"
    receipt = load_json(path)
    receipt["findings"]["R19-F01"]["nested_false_green_claim"] = {
        "application_candidate_exists": True,
        "candidate_pass_eligible": True,
    }
    save_json(path, receipt)


def finding_f01(contract: dict[str, Any]) -> dict[str, Any]:
    cases = contract["cases"]
    baseline = evaluate_contract(contract, ROUND_ROOT)

    empty_contract = copy.deepcopy(contract)
    empty_contract["cases"] = []
    empty_evaluation = evaluate_contract(empty_contract, ROUND_ROOT)
    partial_contract = copy.deepcopy(contract)
    partial_contract["cases"] = [copy.deepcopy(cases[0])]
    partial_evaluation = evaluate_contract(partial_contract, ROUND_ROOT)
    coverage_rejections = sum(
        evaluation.get("spec_oracle_valid") is False
        and evaluation.get("candidate_pass_eligible") is False
        for evaluation in (empty_evaluation, partial_evaluation)
    )

    runner_renamed_contract = copy.deepcopy(contract)
    for index, case in enumerate(runner_renamed_contract["cases"]):
        case["runner_method"] = f"renamed.runner.capability.{index:03d}"
    runner_rename_evaluation = evaluate_contract(runner_renamed_contract, ROUND_ROOT)
    runner_method_rename_invariant = (
        runner_rename_evaluation.get("semantic_corpus_valid") is True
        and runner_rename_evaluation.get("spec_oracle_valid") is True
    )
    runner_method_meta_probe = meta_acceptance_probe(
        "R20-F01-RUNNER-METHOD-RENAME-INVARIANCE",
        mutate_runner_method_identifiers,
    )
    deferred_requirement_flip = copy.deepcopy(contract)
    deferred_case = next(
        case for case in deferred_requirement_flip["cases"]
        if case.get("execution_policy") == "DEFERRED_TO_CANDIDATE_EXECUTION"
    )
    deferred_case["fixture_inline"]["candidate_expected_observable"] = {
        "transition": "ACCEPT",
        "reason_code": "ROUND20_INVENTED_DEFERRED_REQUIREMENT",
    }
    deferred_requirement_evaluation = evaluate_contract(deferred_requirement_flip, ROUND_ROOT)
    deferred_requirement_flip_rejected = (
        deferred_requirement_evaluation.get("semantic_corpus_valid") is False
        and deferred_requirement_evaluation.get("spec_oracle_valid") is False
    )
    fixture_immutability_flip = copy.deepcopy(contract)
    fixture_immutability_flip["cases"][0]["fixture_inline"]["immutable"] = False
    fixture_immutability_evaluation = evaluate_contract(fixture_immutability_flip, ROUND_ROOT)
    fixture_immutability_flip_rejected = (
        fixture_immutability_evaluation.get("semantic_corpus_valid") is False
        and fixture_immutability_evaluation.get("spec_oracle_valid") is False
    )

    garbage_results = []
    for case in cases:
        mutated = copy.deepcopy(case)
        mutated["fixture_inline"]["input"] = {"__garbage__": True}
        garbage_results.append(evaluate_case(mutated, ROUND_ROOT))

    invented_results = []
    for case in cases:
        mutated = copy.deepcopy(case)
        mutated["fixture_inline"]["expected_observable"]["reason_code"] = "ROUND20_INVENTED_REASON"
        mutated["expected_reason_code"] = "ROUND20_INVENTED_REASON"
        invented_results.append(evaluate_case(mutated, ROUND_ROOT))

    rename_semantic_keys = (
        "disposition", "transition", "reason_code", "observable", "pass",
        "counted_in_pass_total", "failure_code",
    )
    rename_mismatches = 0
    for index, case in enumerate(cases):
        original_result = evaluate_case(case, ROUND_ROOT)
        renamed = copy.deepcopy(case)
        renamed["case_id"] = f"C-R20-SEMANTIC-RENAME-{index:03d}"
        renamed_result = evaluate_case(renamed, ROUND_ROOT)
        if any(
            original_result.get(key) != renamed_result.get(key)
            for key in rename_semantic_keys
        ):
            rename_mismatches += 1

    exemplar = next(
        item for item in cases
        if item.get("oracle_disposition") == "DECIDED_NON_REFLEXIVELY"
    )
    reflexive_kinds = [*sorted(FORBIDDEN_REFLEXIVE_OPERATION_KINDS), "RENAMED_REFLEXIVE_BEHAVIOUR"]
    reflexive_results = []
    for kind in reflexive_kinds:
        mutated = copy.deepcopy(exemplar)
        mutated["fixture_inline"]["operation"] = {"kind": kind}
        reflexive_results.append(evaluate_case(mutated, ROUND_ROOT))

    nested_mutators: dict[str, Callable[[dict[str, Any]], None]] = {
        "VALIDATE_NOTE_STATE": lambda value: value.update({"note": {"__garbage__": True}}),
        "VALIDATE_VERSION_INCREMENT": lambda value: value.update({"prior": {}, "next": {}}),
        "FAKE_RELAY_COMPLETE": lambda value: value.update({"request": {"__garbage__": True}}),
        "VALIDATE_EVENT": lambda value: value.update({"event": {"__garbage__": True}}),
        "VALIDATE_EVENT_CHAIN": lambda value: value.update({"event": {"__garbage__": True}}),
        "VERIFY_EXPORT_GOLDEN": lambda value: value.update({"receipt": {"__garbage__": True}}),
    }
    nested_results = []
    for kind, mutate_input in nested_mutators.items():
        case = next(item for item in cases if item["fixture_inline"]["operation"]["kind"] == kind)
        mutated = copy.deepcopy(case)
        mutate_input(mutated["fixture_inline"]["input"])
        nested_results.append(evaluate_case(mutated, ROUND_ROOT))

    p01 = next(
        item for item in cases
        if item.get("runner_method") == "security.write_boundary.no_home_wide_write"
    )
    p01_mutated = copy.deepcopy(p01)
    p01_mutated["fixture_inline"]["expected_observable"] = {"transition": "ACCEPT", "reason_code": "OK"}
    p01_mutated["expected_transition"] = "ACCEPT"
    p01_mutated["expected_reason_code"] = "OK"
    p01_result = evaluate_case(p01_mutated, ROUND_ROOT)

    relay_case = next(
        item for item in cases
        if item["fixture_inline"]["operation"]["kind"] == "FAKE_RELAY_COMPLETE"
        and "result" in item["fixture_inline"]["expected_observable"]
    )
    relay_mutated = copy.deepcopy(relay_case)
    relay_mutated["fixture_inline"]["expected_observable"]["result"] = {"invented": True}
    relay_result = evaluate_case(relay_mutated, ROUND_ROOT)

    garbage_passes = sum(result.get("pass") is True for result in garbage_results)
    invented_passes = sum(result.get("pass") is True for result in invented_results)
    reflexive_passes = sum(result.get("pass") is True for result in reflexive_results)
    nested_passes = sum(result.get("pass") is True for result in nested_results)
    closed = all([
        baseline.get("spec_oracle_valid") is True,
        baseline.get("candidate_pass_eligible") is False,
        baseline.get("deferred", 0) > 0,
        baseline.get("aggregate_invariants_ok") is True,
        garbage_passes == 0,
        invented_passes == 0,
        reflexive_passes == 0,
        nested_passes == 0,
        p01_result.get("pass") is not True,
        relay_result.get("pass") is not True,
        coverage_rejections == 2,
        rename_mismatches == 0,
        runner_method_rename_invariant,
        runner_method_meta_probe.get("accepted") is True,
        deferred_requirement_flip_rejected,
        fixture_immutability_flip_rejected,
    ])
    return {
        "closed": closed,
        "baseline": {
            key: baseline.get(key)
            for key in (
                "total_cases", "decided_cases", "passed", "failed", "deferred",
                "invalid_cases", "candidate_pass_eligible", "aggregate_invariants_ok",
            )
        },
        "garbage": {
            "probes": len(garbage_results),
            "counted_passes": garbage_passes,
            "invalid": sum(result.get("disposition") not in {"DECIDED", "DEFERRED"} for result in garbage_results),
            "deferred_excluded": sum(result.get("disposition") == "DEFERRED" for result in garbage_results),
        },
        "nested_garbage": {"probes": len(nested_results), "counted_passes": nested_passes},
        "invented_reason": {"probes": len(invented_results), "counted_passes": invented_passes},
        "case_id_rename_invariance": {
            "probes": len(cases),
            "semantic_mismatches": rename_mismatches,
        },
        "runner_method_rename_invariance": {
            "oracle": runner_method_rename_invariant,
            "full_meta_validation": runner_method_meta_probe,
        },
        "deferred_candidate_requirement_flip_rejected": deferred_requirement_flip_rejected,
        "fixture_immutability_flip_rejected": fixture_immutability_flip_rejected,
        "reflexive_behaviour": {"probes": len(reflexive_results), "counted_passes": reflexive_passes},
        "p01_expectation_flip_rejected": p01_result.get("pass") is not True,
        "full_observable_tamper_rejected": relay_result.get("pass") is not True,
        "semantic_coverage_anchor": {
            "probes": 2,
            "empty_and_partial_contracts_rejected": coverage_rejections,
            "empty_candidate_pass_eligible": empty_evaluation.get("candidate_pass_eligible"),
            "partial_candidate_pass_eligible": partial_evaluation.get("candidate_pass_eligible"),
        },
    }


def finding_f02() -> tuple[dict[str, Any], list[dict[str, Any]]]:
    required_terms = [
        "github", "push", "deploy", "cloudflare", "dns", "public repository",
        "credentials", "provider", "0.0.0.0", "deepseek",
    ]
    authority_blob = "\n".join([*AUTHORITY_VOCABULARY, *AUTHORITY_REJECT_SUBSTRINGS]).casefold()
    missing_terms = sorted(term for term in required_terms if term not in authority_blob)
    payloads = SECURITY_CONSTANTS["authority"]["probe_payloads"]
    probes = [
        meta_mutation_probe(
            "R20-F02-PUBLIC-GITHUB-PUSH",
            mutate_authority(payloads[2]),
            {"AUTHORITY_PROHIBITED_TEXT"},
        ),
        meta_mutation_probe(
            "R20-F02-CLOUDFLARE-DEPLOY",
            mutate_authority(payloads[3]),
            {"AUTHORITY_PROHIBITED_TEXT"},
        ),
        meta_mutation_probe(
            "R20-F02-DNS-CREDENTIALS",
            mutate_authority(payloads[4]),
            {"AUTHORITY_PROHIBITED_TEXT"},
        ),
        meta_mutation_probe(
            "R20-F02-UNSAFE-BIND",
            mutate_authority(payloads[5]),
            {"AUTHORITY_PROHIBITED_TEXT"},
        ),
        meta_mutation_probe(
            "R20-F02-DEEPSEEK-PROVIDER",
            mutate_authority(payloads[6]),
            {"AUTHORITY_PROHIBITED_TEXT"},
        ),
        meta_mutation_probe(
            "R20-F02-NORMATIVE-PYTHON-LITERAL",
            mutate_python_authority(payloads[3]),
            {"AUTHORITY_PROHIBITED_TEXT"},
        ),
        meta_mutation_probe(
            "R20-F02-MANIFEST-OMISSION-RELABEL-BYPASS",
            mutate_authority_manifest_omission(payloads[3]),
            {"AUTHORITY_PROHIBITED_TEXT", "NORMATIVE_REQUIRED_MEMBER_MISSING"},
        ),
        meta_mutation_probe(
            "R20-F02-PROBE-PAYLOAD-UNRELATED-ASSIGNMENT",
            mutate_probe_script_unrelated_authority(payloads[3]),
            {"AUTHORITY_PROHIBITED_TEXT"},
        ),
        meta_mutation_probe(
            "R20-F02-COHERENT-EMPTY-AUTHORITY-VOCABULARY",
            mutate_authority_vocabulary_empty,
            {
                "AUTHORITY_VOCABULARY_MINIMUM_MISSING",
                "AUTHORITY_REJECT_MINIMUM_MISSING",
            },
        ),
        meta_mutation_probe(
            "R20-F02-UNSUPPORTED-NORMATIVE-EXTENSION",
            mutate_unsupported_normative_extension(payloads[3]),
            {"NORMATIVE_MEMBER_UNSUPPORTED_FORMAT"},
        ),
    ]
    closed = not missing_terms and all(item["rejected_for_intended_reason"] for item in probes)
    return ({
        "closed": closed,
        "required_vocabulary_terms": len(required_terms),
        "missing_vocabulary_terms": missing_terms,
        "phrase_mutations": len(probes),
        "phrase_mutations_rejected": sum(item["rejected_for_intended_reason"] for item in probes),
    }, probes)


def finding_f03(contract: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    vectors = load_json(ROUND_ROOT / "PHASE0A_WEB_SECURITY_VECTORS.v1.json")
    raw_vectors = vectors.get("raw_html_bodies") or []
    vector_rejections = sum(
        detect_raw_html(item.get("body_markdown", "")) == "RAW_HTML_REJECTED"
        for item in raw_vectors
    )
    raw_cases = [
        case for case in contract["cases"]
        if any(
            detect_raw_html(value)
            for value in _string_values(case.get("fixture_inline", {}).get("input"))
        )
    ]
    raw_case_semantics = sum(
        case.get("fixture_inline", {}).get("operation", {}).get("kind") == "VALIDATE_RAW_HTML"
        and evaluate_case(case, ROUND_ROOT).get("transition") == "REJECT"
        and evaluate_case(case, ROUND_ROOT).get("reason_code") == "RAW_HTML_REJECTED"
        for case in raw_cases
    )
    semantic_keys = ("disposition", "transition", "reason_code", "observable", "pass")
    rename_results = []
    for index, rename_case in enumerate(raw_cases):
        before = evaluate_case(rename_case, ROUND_ROOT)
        renamed = copy.deepcopy(rename_case)
        renamed["case_id"] = f"C-R20-PURE-RAW-RENAME-{index:03d}"
        after = evaluate_case(renamed, ROUND_ROOT)
        rename_results.append(all(before.get(key) == after.get(key) for key in semantic_keys))
    rename_invariant = all(rename_results)
    behavior_payloads = [
        "<script>alert(1)</script>",
        "<img src=x onclick=alert(1)>",
        "[x](javascript:alert(1))",
        "<iframe src=x></iframe>",
        "<object data=x></object>",
        "<embed src=x>",
        "<link rel=import href=x>",
        "<div>ordinary raw HTML</div>",
        "<b>bold raw HTML</b>",
        "<!-- raw HTML comment -->",
        "<svg><circle /></svg>",
        "<!DOCTYPE html>",
    ]
    behavioral_rejections = sum(detect_raw_html(value) == "RAW_HTML_REJECTED" for value in behavior_payloads)
    probe = meta_mutation_probe(
        "R20-F03-RAW-HTML-RENAMED-ECHO",
        mutate_raw_html_echo,
        {"RAW_HTML_ROUTE_REQUIRED", "RAW_HTML_EXPECTATION_MISMATCH"},
    )
    closed = all([
        bool(raw_vectors),
        vector_rejections == len(raw_vectors),
        bool(raw_cases),
        raw_case_semantics == len(raw_cases),
        rename_invariant,
        behavioral_rejections == len(behavior_payloads),
        probe["rejected_for_intended_reason"],
    ])
    return ({
        "closed": closed,
        "hostile_vectors": len(raw_vectors),
        "hostile_vectors_rejected": vector_rejections,
        "contract_raw_payloads": len(raw_cases),
        "contract_raw_payloads_semantically_rejected": raw_case_semantics,
        "pure_case_id_rename_invariant": rename_invariant,
        "pure_case_id_rename_probes": len(rename_results),
        "behavioral_classes": len(behavior_payloads),
        "behavioral_classes_rejected": behavioral_rejections,
        "renamed_echo_rejected": probe["rejected_for_intended_reason"],
    }, [probe])


def _string_values(value: Any):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for key in sorted(value):
            yield from _string_values(value[key])
    elif isinstance(value, list):
        for item in value:
            yield from _string_values(item)


def evidence_baseline() -> dict[str, Any]:
    evidence_root, _vectors, results = evidence_context(ROUND_ROOT)
    manifest = load_json(ROUND_ROOT / "PHASE0A_NORMATIVE_MANIFEST.v1.json")
    member_roles = {item.get("path"): item.get("role") for item in manifest.get("members", [])}
    resolved = 0
    hash_matches = 0
    safe = 0
    normative = 0
    for result in results:
        relative = result.get("evidence_path")
        if not isinstance(relative, str):
            continue
        pure = PurePosixPath(relative)
        is_safe = (
            not pure.is_absolute()
            and ".." not in pure.parts
            and "\\" not in relative
            and str(pure) == relative
        )
        safe += is_safe
        if not is_safe:
            continue
        target = evidence_root.joinpath(*pure.parts)
        if target.is_file():
            resolved += 1
            hash_matches += sha256_file(target) == result.get("evidence_sha256")
            round_relative = target.relative_to(ROUND_ROOT).as_posix()
            normative += member_roles.get(round_relative) == "evidence_fixture"
    return {
        "declared_results": len(results),
        "safe_paths": safe,
        "resolved_files": resolved,
        "matching_hashes": hash_matches,
        "normative_members": normative,
        "all_resolved": len(results) > 0 and all(
            count == len(results) for count in (safe, resolved, hash_matches, normative)
        ),
    }


def finding_f04() -> tuple[dict[str, Any], list[dict[str, Any]]]:
    baseline = evidence_baseline()
    probes = [
        meta_mutation_probe(
            "R20-F04-EVIDENCE-BYTES-TAMPER",
            mutate_evidence_tamper,
            {"EVIDENCE_BYTES_HASH_MISMATCH"},
        ),
        meta_mutation_probe(
            "R20-F04-EVIDENCE-BYTES-MISSING",
            mutate_evidence_missing,
            {"EVIDENCE_BYTES_MISSING"},
        ),
        meta_mutation_probe(
            "R20-F04-EVIDENCE-PATH-UNSAFE",
            mutate_evidence_unsafe,
            {"EVIDENCE_PATH_UNSAFE"},
        ),
        meta_mutation_probe(
            "R20-F04-EVIDENCE-NORMATIVE-MEMBER-REMOVED",
            mutate_evidence_member_removed,
            {"EVIDENCE_NOT_NORMATIVE_MEMBER"},
        ),
    ]
    closed = baseline["all_resolved"] and all(item["rejected_for_intended_reason"] for item in probes)
    return ({
        "closed": closed,
        "baseline_resolution": baseline,
        "negative_mutations": len(probes),
        "negative_mutations_rejected": sum(item["rejected_for_intended_reason"] for item in probes),
    }, probes)


def finding_f05() -> tuple[dict[str, Any], list[dict[str, Any]]]:
    slug = SECURITY_CONSTANTS["slug"]
    safe = slug["safe_corpus"]
    hostile = slug["hostile_corpus"]
    reserved = slug["reserved"]
    safe_ok = sum(validate_slug(value) is None for value in safe)
    hostile_ok = sum(validate_slug(value) is not None for value in hostile)
    reserved_ok = sum(validate_slug(value) == "RESERVED_SLUG" for value in reserved)
    constants_hash_ok = sha256_file(SECURITY_CONSTANTS_PATH) == SECURITY_CONSTANTS_SHA256
    probes = [
        meta_mutation_probe(
            "R20-F05-SLUG-PATTERN-WEAKEN",
            mutate_slug_pattern,
            {"SLUG_PATTERN_SOURCE_MISMATCH"},
        ),
        meta_mutation_probe(
            "R20-F05-SLUG-RESERVED-TRIMMED",
            mutate_slug_reserved_trimmed,
            {"SLUG_RESERVED_SOURCE_MISMATCH"},
        ),
        meta_mutation_probe(
            "R20-F05-SLUG-RESERVED-EMPTY",
            mutate_slug_reserved_empty,
            {"SLUG_RESERVED_SOURCE_MISMATCH"},
        ),
    ]
    closed = all([
        constants_hash_ok,
        set(reserved) == set(RESERVED_SLUGS),
        safe_ok == len(safe),
        hostile_ok == len(hostile),
        reserved_ok == len(reserved),
        all(item["rejected_for_intended_reason"] for item in probes),
    ])
    return ({
        "closed": closed,
        "locked_constants_hash_matches": constants_hash_ok,
        "safe_vectors": len(safe),
        "safe_vectors_accepted": safe_ok,
        "hostile_vectors": len(hostile),
        "hostile_vectors_rejected": hostile_ok,
        "reserved_vectors": len(reserved),
        "reserved_vectors_rejected": reserved_ok,
        "schema_mutations": len(probes),
        "schema_mutations_rejected": sum(item["rejected_for_intended_reason"] for item in probes),
    }, probes)


def finding_f06(cache_files_before: set[str]) -> tuple[dict[str, Any], dict[str, Any]]:
    manifest_entries = []
    checksum = ROUND_ROOT / "SHA256SUMS.txt"
    if checksum.is_file():
        manifest_entries.extend(
            line.split("  ", 1)[1]
            for line in checksum.read_text(encoding="utf-8").splitlines()
            if "  " in line
        )
    normative = load_json(ROUND_ROOT / "PHASE0A_NORMATIVE_MANIFEST.v1.json")
    manifest_entries.extend(
        str(item.get("path")) for item in normative.get("members", [])
    )
    forbidden_entries = sorted({
        item for item in manifest_entries
        if "__pycache__" in PurePosixPath(item).parts or item.endswith(".pyc")
    })
    cache_probe = meta_mutation_probe(
        "R24-F06-CACHE-NOISE-UNSHIPPABLE",
        add_cache_noise,
        {"FORBIDDEN_BYTECODE_PACKAGE_MEMBER"},
    )
    cache_files_after = {
        path.relative_to(ROUND_ROOT).as_posix()
        for path in ROUND_ROOT.rglob("*")
        if path.is_file() and ("__pycache__" in path.parts or path.suffix == ".pyc")
    }
    created = sorted(cache_files_after - cache_files_before)
    closed = (
        not forbidden_entries
        and cache_probe["rejected_for_intended_reason"]
        and not created
    )
    return ({
        "closed": closed,
        "manifest_entries_scanned": len(manifest_entries),
        "forbidden_bytecode_entries": forbidden_entries,
        "cache_noise_full_validation_rejected": cache_probe["rejected_for_intended_reason"],
        "bytecode_files_created_by_documented_commands": created,
    }, cache_probe)


def finding_f07() -> tuple[dict[str, Any], list[dict[str, Any]]]:
    rows = []
    for n50, n60, n70 in product(N50_OUTCOMES, N60_OUTCOMES, N70_OUTCOMES):
        rows.append({"n50": n50, "n60": n60, "n70": n70, **evaluate_review_trace(n50, n60, n70)})
    allowed = [item for item in rows if item["allowed"]]
    forbidden = [item for item in rows if not item["allowed"]]
    hold = [item for item in rows if item["n50"] == "HOLD"]
    allowed_set = {(item["n50"], item["n60"], item["n70"]) for item in allowed}
    exhaustive_ok = all([
        len(rows) == 36,
        allowed_set == set(ALLOWED_TRACES),
        len(forbidden) == 34,
        len(hold) == 12,
        all(not item["n80_eligible"] and item["reason_code"] == "HOLD_TERMINAL" for item in hold),
        all(
            not item["n80_eligible"] and item["reason_code"] == "INVALID_REVIEW_TRACE"
            for item in forbidden if item["n50"] != "HOLD"
        ),
    ])
    probes = [
        meta_mutation_probe(
            "R20-F07-FORBIDDEN-EXAMPLES-EMPTY",
            mutate_forbidden_examples_empty,
            {"FORBIDDEN_EXAMPLES_DERIVATION_MISMATCH"},
        ),
        meta_mutation_probe(
            "R20-PRESERVE-N80-FINAL-NODE-BYPASS",
            mutate_final_node_bypass,
            {"DAG_FINAL_NODE_NOT_LOCAL_HANDOFF"},
        ),
        meta_mutation_probe(
            "R20-PRESERVE-HOLD-VOCABULARY-SHRINK",
            mutate_transition_vocabulary_shrink,
            {"TRANSITION_N50_INDEPENDENT_ANCHOR_MISMATCH"},
        ),
    ]
    return ({
        "closed": exhaustive_ok and all(probe["rejected_for_intended_reason"] for probe in probes),
        "total_traces": len(rows),
        "allowed_traces": len(allowed),
        "forbidden_traces": len(forbidden),
        "hold_origin_traces": len(hold),
        "hold_origin_releases": sum(item["n80_eligible"] for item in hold),
        "empty_forbidden_examples_rejected": probes[0]["rejected_for_intended_reason"],
        "final_node_bypass_rejected": probes[1]["rejected_for_intended_reason"],
    }, probes)


def finding_r21_f01() -> tuple[dict[str, Any], list[dict[str, Any]]]:
    package_files = [
        path for path in ROUND_ROOT.rglob("*")
        if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc"
    ]
    binary_path = ROUND_ROOT / "fixtures/selected-note-golden.zip"
    probes = [
        meta_mutation_probe(
            "R22-F01-UNDECLARED-TEXT-MEMBER",
            mutate_r21_authority_undeclared,
            {"AUTHORITY_PROHIBITED_TEXT"},
        ),
        meta_mutation_probe(
            "R22-F01-TEXT-DISGUISED-AS-BINARY",
            mutate_r21_text_disguised_binary,
            {"PACKAGE_TEXT_SMUGGLING_AS_BINARY"},
        ),
        meta_mutation_probe(
            "R22-F01-NEGATIVE-CONTEXT-LAUNDER",
            mutate_r21_authority_exception_launder,
            {"AUTHORITY_PROBE_PAYLOADS_ABSOLUTE_MISMATCH", "AUTHORITY_PROHIBITED_TEXT"},
        ),
        meta_mutation_probe(
            "R22-F01-PYTHON-BYTES-LITERAL-COUNTER-BALANCED",
            mutate_r21_authority_python_bytes_balanced,
            {"AUTHORITY_PROHIBITED_TEXT"},
        ),
        meta_mutation_probe(
            "R22-F01-PYTHON-FSTRING-COMPOSITION-COUNTER-BALANCED",
            mutate_r21_authority_python_fstring_balanced,
            {"AUTHORITY_PROHIBITED_TEXT", "PACKAGE_PYTHON_MEMBER_UNCLASSIFIED"},
        ),
        meta_mutation_probe(
            "R22-F01-ALLOWLISTED-PYTHON-ADD-COMPOSITION",
            mutate_r21_authority_allowed_python_composition(
                'ROUND22_COMPOSED = "deploy to " + "Cloudflare"\n'
            ),
            {"AUTHORITY_PROHIBITED_TEXT"},
        ),
        meta_mutation_probe(
            "R22-F01-ALLOWLISTED-PYTHON-FORMAT-COMPOSITION",
            mutate_r21_authority_allowed_python_composition(
                'ROUND22_COMPOSED = "deploy to {}".format("Cloudflare")\n'
            ),
            {"AUTHORITY_PROHIBITED_TEXT"},
        ),
        meta_mutation_probe(
            "R22-F01-ALLOWLISTED-PYTHON-PERCENT-COMPOSITION",
            mutate_r21_authority_allowed_python_composition(
                'ROUND22_COMPOSED = "deploy to %s" % "Cloudflare"\n'
            ),
            {"AUTHORITY_PROHIBITED_TEXT"},
        ),
        meta_mutation_probe(
            "R22-F01-ALLOWLISTED-PYTHON-JOIN-COMPOSITION",
            mutate_r21_authority_allowed_python_composition(
                'ROUND22_COMPOSED = "".join(["deploy to ", "Cloudflare"])\n'
            ),
            {"AUTHORITY_PROHIBITED_TEXT"},
        ),
        meta_mutation_probe(
            "R22-F01-LOCKED-PYTHON-DUNDER-ADD-INDIRECTION",
            mutate_r21_authority_locked_python_indirection(
                'ROUND22_COMPOSED = "deploy to ".__add__("Cloudflare")',
                ("transition_evaluator.py", "independent_oracle.py"),
            ),
            {"PACKAGE_PYTHON_MEMBER_HASH_MISMATCH"},
        ),
        meta_mutation_probe(
            "R22-F01-LOCKED-PYTHON-NAME-INDIRECTION",
            mutate_r21_authority_locked_python_indirection(
                '_ROUND22_A = "deploy to "\n_ROUND22_B = "Cloudflare"\n'
                "ROUND22_COMPOSED = _ROUND22_A + _ROUND22_B",
                ("transition_evaluator.py", "independent_oracle.py"),
            ),
            {"PACKAGE_PYTHON_MEMBER_HASH_MISMATCH"},
        ),
        meta_mutation_probe(
            "R22-F01-LOCKED-PYTHON-FORMAT-MAP-INDIRECTION",
            mutate_r21_authority_locked_python_indirection(
                'ROUND22_COMPOSED = "deploy to {provider}".format_map({"provider": "Cloudflare"})',
                ("transition_evaluator.py", "independent_oracle.py", "export_verifier.py"),
            ),
            {"PACKAGE_PYTHON_MEMBER_HASH_MISMATCH"},
        ),
        meta_mutation_probe(
            "R22-F01-MARKDOWN-ZERO-WIDTH-AUTHORITY",
            mutate_r21_authority_zero_width_markdown,
            {"AUTHORITY_PROHIBITED_TEXT"},
        ),
    ]
    baseline = {
        "package_files_scanned": len(package_files),
        "closed_binary_allowlist_count": 1,
        "closed_binary_hash": sha256_file(binary_path),
        "closed_binary_hash_matches": (
            sha256_file(binary_path)
            == "9fbe23d06c8e99e48fc65270a93501041ab39840c54b28ac6760b6a446933bd9"
        ),
    }
    return ({
        "closed": baseline["closed_binary_hash_matches"]
        and all(probe["rejected_for_intended_reason"] for probe in probes),
        **baseline,
        "negative_mutations": len(probes),
        "negative_mutations_rejected": sum(
            probe["rejected_for_intended_reason"] for probe in probes
        ),
    }, probes)


def finding_r21_f02() -> tuple[dict[str, Any], list[dict[str, Any]]]:
    hostile = SECURITY_CONSTANTS["slug"]["hostile_corpus"]
    overlength = [value for value in hostile if len(value) > 80]
    probes = [
        meta_mutation_probe(
            "R22-F02-SLUG-MAXLENGTH-COHERENT-WIDEN",
            mutate_r21_slug_maxlength,
            {"SLUG_MAX_LENGTH_ABSOLUTE_MISMATCH"},
        ),
        meta_mutation_probe(
            "R22-F02-SLUG-OVERLENGTH-CORPUS-REMOVED",
            mutate_r21_slug_overlength_removed,
            {"SLUG_OVERLENGTH_HOSTILE_CORPUS_MISSING"},
        ),
    ]
    return ({
        "closed": SLUG_MAX_LENGTH == 80
        and any(len(value) == 81 for value in overlength)
        and all(validate_slug(value) == "SLUG_TOO_LONG" for value in overlength)
        and all(probe["rejected_for_intended_reason"] for probe in probes),
        "absolute_max_length": 80,
        "runtime_max_length": SLUG_MAX_LENGTH,
        "overlength_hostile_vectors": len(overlength),
        "boundary_plus_one_present": any(len(value) == 81 for value in overlength),
        "negative_mutations": len(probes),
        "negative_mutations_rejected": sum(
            probe["rejected_for_intended_reason"] for probe in probes
        ),
    }, probes)


def finding_r21_f03() -> tuple[dict[str, Any], list[dict[str, Any]]]:
    export_spec = load_json(ROUND_ROOT / "PHASE0A_SELECTED_NOTE_EXPORT_SPEC.v3.json")
    identity = export_spec.get("identity") or {}
    declared = {
        "content_set_sha256": (identity.get("content_set_sha256") or {}).get("domain"),
        "export_id": (identity.get("export_id") or {}).get("domain"),
        "receipt_hash": (identity.get("receipt_hash") or {}).get("domain"),
    }
    runtime = {
        "content_set_sha256": DOMAIN_CONTENT_SET,
        "export_id": DOMAIN_EXPORT_ID,
        "receipt_hash": DOMAIN_RECEIPT,
    }
    probes = [
        meta_mutation_probe(
            "R22-F03-EXPORT-SPEC-DOMAIN-REBIND",
            mutate_r21_export_spec_domain,
            {"EXPORT_SPEC_DOMAIN_MISMATCH"},
        ),
        meta_mutation_probe(
            "R22-F03-EXPORT-RUNTIME-DOMAIN-REBIND",
            mutate_r21_export_runtime_domain,
            {"EXPORT_RUNTIME_DOMAIN_ABSOLUTE_MISMATCH"},
        ),
        meta_mutation_probe(
            "R22-F03-EXPORT-SPEC-RUNTIME-COHERENT-REBIND",
            mutate_r21_export_domains_coherently,
            {"EXPORT_SPEC_DOMAIN_ABSOLUTE_MISMATCH", "EXPORT_RUNTIME_DOMAIN_ABSOLUTE_MISMATCH"},
        ),
    ]
    return ({
        "closed": declared == runtime
        and all(probe["rejected_for_intended_reason"] for probe in probes),
        "declared_domains": declared,
        "runtime_domains": runtime,
        "negative_mutations": len(probes),
        "negative_mutations_rejected": sum(
            probe["rejected_for_intended_reason"] for probe in probes
        ),
    }, probes)


def finding_r21_f04(
    live_baseline: dict[str, Any],
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    live_count = live_baseline.get("authority_strings_scanned", 0)
    semantic_count = load_json(
        ROUND_ROOT / "SPEC_VALIDATION_RECEIPT.semantic.json"
    ).get("authority_strings_scanned")
    full_count = load_json(
        ROUND_ROOT / "SPEC_VALIDATION_RECEIPT.json"
    ).get("authority_strings_scanned")
    closure_count = load_json(
        ROUND_ROOT / "CLOSURE_PROBE_RECEIPT.json"
    ).get("baseline_validation", {}).get("authority_strings_scanned")
    probes = [
        meta_mutation_probe(
            "R22-F04-SPEC-RECEIPT-COUNTER-STALE",
            mutate_r21_spec_receipt_counter,
            {"RECEIPT_AUTHORITY_COUNT_MISMATCH"},
        ),
        meta_mutation_probe(
            "R22-F04-CLOSURE-RECEIPT-COUNTER-STALE",
            mutate_r21_closure_receipt_counter,
            {"RECEIPT_AUTHORITY_COUNT_MISMATCH"},
        ),
    ]
    counts = [live_count, semantic_count, full_count, closure_count]
    return ({
        "closed": live_count > 0
        and len(set(counts)) == 1
        and all(probe["rejected_for_intended_reason"] for probe in probes),
        "live_authority_strings_scanned": live_count,
        "semantic_receipt_authority_strings_scanned": semantic_count,
        "full_receipt_authority_strings_scanned": full_count,
        "closure_receipt_authority_strings_scanned": closure_count,
        "all_counters_equal": live_count > 0 and len(set(counts)) == 1,
        "negative_mutations": len(probes),
        "negative_mutations_rejected": sum(
            probe["rejected_for_intended_reason"] for probe in probes
        ),
    }, probes)


def n80_preservation() -> dict[str, Any]:
    reviewed = ("binding", "tree", "source", "evidence")

    def check(
        handoff=reviewed,
        remotes=None,
        bind=BIND,
        providers=None,
        untracked=None,
    ):
        return n80_identity_check(
            *reviewed,
            *handoff,
            [] if remotes is None else remotes,
            bind,
            [] if providers is None else providers,
            [] if untracked is None else untracked,
        )

    dimensions = {
        "binding": "N80_BINDING_MISMATCH" in check(handoff=("other", *reviewed[1:])),
        "tree": "N80_TREE_MISMATCH" in check(handoff=(reviewed[0], "other", *reviewed[2:])),
        "source_manifest": "N80_SOURCE_MANIFEST_MISMATCH" in check(handoff=(*reviewed[:2], "other", reviewed[3])),
        "evidence": "N80_EVIDENCE_MISMATCH" in check(handoff=(*reviewed[:3], "other")),
        "remotes": "N80_REMOTES_PRESENT" in check(remotes=["origin"]),
        "bind": "N80_BIND_INVALID" in check(bind="0.0.0.0"),
        "provider": "N80_PROVIDER_ADAPTER_PRESENT" in check(providers=["external"]),
        "untracked": "N80_UNTRACKED_FORBIDDEN" in check(untracked=["secret.env"]),
    }
    dag = load_json(ROUND_ROOT / "PHASE0A_BUILD_DAG.v2.json")
    rereview = next(
        (node for node in dag.get("nodes", []) if node.get("kind") == "independent_rereview"),
        {},
    )
    handoff = next(
        (node for node in dag.get("nodes", []) if node.get("kind") == "local_handoff"),
        {},
    )
    source_outputs = [
        value for value in rereview.get("outputs", [])
        if all(token in str(value).upper() for token in ("REVIEWED", "SOURCE", "MANIFEST"))
    ]
    expected_links = {
        f"output:{rereview.get('node_id')}/{value}" for value in source_outputs
    }
    source_manifest_artifact_bound = bool(expected_links & set(handoff.get("consumes", [])))
    return {
        "matching_reviewed_identity_accepts": check() == [],
        "dimensions": dimensions,
        "dimensions_tested": len(dimensions),
        "dimensions_rejected": sum(dimensions.values()),
        "reviewed_source_manifest_outputs": len(source_outputs),
        "reviewed_source_manifest_consumed_by_handoff": source_manifest_artifact_bound,
        "ok": check() == [] and all(dimensions.values()) and source_manifest_artifact_bound,
    }


def command_preservation() -> dict[str, Any]:
    oracle_1 = run_python(ROUND_ROOT / "independent_oracle.py", [], cwd=ROUND_ROOT, seed="1")
    oracle_2 = run_python(ROUND_ROOT / "independent_oracle.py", [], cwd=ROUND_ROOT, seed="2")
    transition_1 = run_python(ROUND_ROOT / "transition_evaluator.py", [], cwd=ROUND_ROOT, seed="1")
    transition_2 = run_python(ROUND_ROOT / "transition_evaluator.py", [], cwd=ROUND_ROOT, seed="2")
    generator_1 = run_python(ROUND_ROOT / "export_generator.py", [], cwd=ROUND_ROOT, seed="1")
    generator_2 = run_python(ROUND_ROOT / "export_generator.py", [], cwd=ROUND_ROOT, seed="2")
    verifier = run_python(ROUND_ROOT / "export_verifier.py", [], cwd=ROUND_ROOT, seed="1")
    generated = parse_json_output(generator_1)
    verified = parse_json_output(verifier)
    golden = load_json(ROUND_ROOT / "PHASE0A_EXPORT_GOLDEN_VECTOR.v2.json")
    export_identity_dimensions = {
        "export_id": generated.get("export_id") == golden.get("receipt", {}).get("export_id"),
        "content_set_sha256": generated.get("content_set_sha256") == golden.get("receipt", {}).get("content_set_sha256"),
        "receipt_hash": generated.get("receipt_hash") == golden.get("receipt", {}).get("receipt_hash"),
        "zip_sha256": generated.get("zip_sha256") == golden.get("zip_sha256"),
    }
    export_fields_match = (
        generated.get("matches_golden") is True
        and verified.get("ok") is True
        and all(export_identity_dimensions.values())
    )
    checks = {
        "oracle_exit_zero": oracle_1.returncode == oracle_2.returncode == 0,
        "oracle_seed_receipts_identical": oracle_1.stdout == oracle_2.stdout,
        "transition_exit_zero": transition_1.returncode == transition_2.returncode == 0,
        "transition_seed_receipts_identical": transition_1.stdout == transition_2.stdout,
        "export_generator_exit_zero": generator_1.returncode == generator_2.returncode == 0,
        "export_generator_seed_receipts_identical": generator_1.stdout == generator_2.stdout,
        "export_verifier_exit_zero": verifier.returncode == 0,
        "export_identity_matches_golden": export_fields_match,
    }
    return {
        "checks": checks,
        "export_identity_dimensions": export_identity_dimensions,
        "export_identity_dimensions_tested": len(export_identity_dimensions),
        "export_identity_dimensions_matching": sum(export_identity_dimensions.values()),
        "ok": all(checks.values()),
    }


def baseline_validation() -> dict[str, Any]:
    semantic = run_python(
        ROUND_ROOT / META_NAME,
        ["--root", str(ROUND_ROOT), "--semantic-only"],
        cwd=ROUND_ROOT,
    )
    full = run_python(
        ROUND_ROOT / META_NAME,
        ["--root", str(ROUND_ROOT)],
        cwd=ROUND_ROOT,
    )
    semantic_receipt = parse_json_output(semantic)
    full_receipt = parse_json_output(full)
    return {
        "semantic_exit_code": semantic.returncode,
        "semantic_error_codes": error_codes(semantic_receipt),
        "full_exit_code": full.returncode,
        "full_error_codes": error_codes(full_receipt),
        "authority_strings_scanned": semantic_receipt.get("authority_strings_scanned", 0),
        "ok": semantic.returncode == 0 and full.returncode == 0,
    }


def mutation_harness_preservation() -> dict[str, Any]:
    payload = {
        "errors": ["GENERIC_REJECT:attacker detail ORACLE_EXPECTATION_MISMATCH"],
        "failures": [
            {"failure_code": "STRUCTURED_FAILURE"},
            {"failure_code": "GENERIC:RAW_HTML_ROUTE_REQUIRED"},
        ],
    }
    process = subprocess.CompletedProcess(
        args=["synthetic"],
        returncode=1,
        stdout=json.dumps(payload),
        stderr="AUTHORITY_PROHIBITED_TEXT",
    )
    observed = reason_codes({"synthetic": process}, ROUND_ROOT)
    expected = ["GENERIC_REJECT", "STRUCTURED_FAILURE"]
    return {
        "structured_codes": observed,
        "attacker_detail_tokens_excluded": observed == expected,
        "stderr_tokens_excluded": "AUTHORITY_PROHIBITED_TEXT" not in observed,
        "ok": observed == expected,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-json", type=Path)
    args = parser.parse_args()

    cache_files_before = {
        path.relative_to(ROUND_ROOT).as_posix()
        for path in ROUND_ROOT.rglob("*")
        if path.is_file() and ("__pycache__" in path.parts or path.suffix == ".pyc")
    }
    contract = load_json(ROUND_ROOT / CONTRACT_NAME)

    baseline = baseline_validation()
    f01 = finding_f01(contract)
    f02, f02_probes = finding_f02()
    f03, f03_probes = finding_f03(contract)
    f04, f04_probes = finding_f04()
    f05, f05_probes = finding_f05()
    f07, f07_probes = finding_f07()
    r21_f01, r21_f01_probes = finding_r21_f01()
    r21_f02, r21_f02_probes = finding_r21_f02()
    r21_f03, r21_f03_probes = finding_r21_f03()
    r21_f04, r21_f04_probes = finding_r21_f04(baseline)
    f02["successor_r21_f01_closed"] = r21_f01["closed"]
    f02["closed"] = f02["closed"] and r21_f01["closed"]
    f05["successor_r21_f02_closed"] = r21_f02["closed"]
    f05["closed"] = f05["closed"] and r21_f02["closed"]
    receipt_integrity_probe = meta_mutation_probe(
        "R20-RECEIPT-NONVACUOUS-CONTENT",
        mutate_operational_receipt_empty,
        {"ORACLE_RECEIPT_INVALID"},
    )
    receipt_extra_claim_probe = meta_mutation_probe(
        "R20-RECEIPT-EXTRA-POSITIVE-CLAIM",
        mutate_operational_receipt_extra_claim,
        {"OPERATIONAL_RECEIPT_POSITIVE_SCOPE_CLAIM"},
    )
    commands = command_preservation()
    mutation_harness = mutation_harness_preservation()
    f06, cache_probe = finding_f06(cache_files_before)
    n80 = n80_preservation()

    negative_mutations = [
        *f02_probes,
        *f03_probes,
        *f04_probes,
        *f05_probes,
        *f07_probes,
        *r21_f01_probes,
        *r21_f02_probes,
        *r21_f03_probes,
        *r21_f04_probes,
        receipt_integrity_probe,
        receipt_extra_claim_probe,
    ]
    rejected = sum(item.get("rejected_for_intended_reason") is True for item in negative_mutations)
    false_green = len(negative_mutations) - rejected
    findings = {
        "R19-F01": f01,
        "R19-F02": f02,
        "R19-F03": f03,
        "R19-F04": f04,
        "R19-F05": f05,
        "R19-F06": f06,
        "R19-F07": f07,
        "R21-F01": r21_f01,
        "R21-F02": r21_f02,
        "R21-F03": r21_f03,
        "R21-F04": r21_f04,
    }
    preservation = {
        "commands_and_export": commands,
        "n80_identity": n80,
        "hold_terminal": f07["hold_origin_releases"] == 0,
        "mutation_harness": mutation_harness,
        "operational_receipt_integrity": receipt_integrity_probe,
        "operational_receipt_extra_claim": receipt_extra_claim_probe,
        "ok": (
            commands["ok"]
            and n80["ok"]
            and mutation_harness["ok"]
            and receipt_integrity_probe["rejected_for_intended_reason"]
            and receipt_extra_claim_probe["rejected_for_intended_reason"]
            and f07["hold_origin_releases"] == 0
        ),
    }
    finding_checks = [value["closed"] for value in findings.values()]
    overall = baseline["ok"] and all(finding_checks) and preservation["ok"] and false_green == 0
    output = {
        "schema_version": "pa.phase0a.round24_closure_probe_receipt.v1",
        "round": "ROUND_024_CONTROLLING_PHASE0A_REPAIR",
        "status": "PASS" if overall else "FAIL",
        "baseline_validation": baseline,
        "findings": findings,
        "negative_mutation_results": negative_mutations,
        "cache_noise_probe": cache_probe,
        "preservation": preservation,
        "summary": {
            "findings_total": len(findings),
            "findings_closed": sum(finding_checks),
            "negative_mutations_run": len(negative_mutations),
            "negative_mutations_rejected_for_intended_reason": rejected,
            "false_green": false_green,
            "deterministic_fields_only": True,
        },
    }
    rendered = stable_json(output)
    if args.output_json:
        args.output_json.write_text(rendered, encoding="utf-8")
    sys.stdout.write(rendered)
    return 0 if overall else 1


if __name__ == "__main__":
    raise SystemExit(main())
