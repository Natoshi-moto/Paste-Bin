# Round 024 Phase 0A gate repair

Adjudication: `ROUND024_REPAIR_COMPLETE_AWAITING_INDEPENDENT_REREVIEW`

This directory supersedes Round 022 at the specification/gate layer. It is a
complete offline gate, not an application candidate. No application was built,
no host preflight was run, and no repository or external state was changed.

Run from relay root with bytecode disabled:

```text
PYTHONDONTWRITEBYTECODE=1 python3 -S 03_EXCHANGE/ROUND_024_CONTROLLING_PHASE0A_REPAIR/meta_validate_round24.py
PYTHONDONTWRITEBYTECODE=1 python3 -S 03_EXCHANGE/ROUND_024_CONTROLLING_PHASE0A_REPAIR/verify_round24_receipts.py --full
```

The permanent registry has 88 classes: the 66-class Round 022 floor, all 14
Round 023 probes, and eight Round 024 closure variants. The independent Round
025 reviewer must reapply all classes after a coherent rebind and invent new
attacks outside the registry.

`DEFERRED_TO_CANDIDATE_EXECUTION` remains honest and blocks candidate PASS.
HOLD remains terminal. N80 remains bound to independently reviewed bytes. The
next actor may review this repair but may not treat it as release authority.

