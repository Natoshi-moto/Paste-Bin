# Author-model rebind and determinism note

Round 026 carries forward Round 025's two-model finding. The relay-level input
manifest is an integrity boundary against transit changes. Because an acting
controlling-round author generates that manifest from the package and the
manifest path is mutable during the round, it is not semantic evidence against
that same author. Material mutation scoring therefore uses a coherent author
rebind; the sealed-manifest model remains a second transit-integrity layer.

A checksum mismatch alone is never credited as a semantic catch. Closure
probes record only structured reason codes and scan counts.

Set-derived reason codes and tool selections are sorted before serialization.
The mutation receipt claim is accepted only when seeds 1 and 2 produce the same
canonical bytes, not merely the same verdict summary.

