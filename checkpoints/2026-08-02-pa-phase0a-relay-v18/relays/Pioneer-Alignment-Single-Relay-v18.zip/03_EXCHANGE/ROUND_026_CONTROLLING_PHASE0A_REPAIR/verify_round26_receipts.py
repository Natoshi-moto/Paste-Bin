#!/usr/bin/env python3
"""Ephemeral Round 026 receipt replay verifier; writes only beneath /tmp."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(command: list[str], seed: str = "1") -> subprocess.CompletedProcess[bytes]:
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONHASHSEED"] = seed
    env.setdefault("LC_ALL", "C")
    env.setdefault("TZ", "UTC")
    return subprocess.run(
        ["python3", "-S", *command], cwd=ROOT, env=env,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False,
    )


def stdout_matches(command: list[str], receipt_name: str) -> bool:
    completed = run(command)
    return (
        completed.returncode == 0
        and completed.stderr == b""
        and completed.stdout == (ROOT / receipt_name).read_bytes()
    )


def checksum_manifest_ok() -> bool:
    manifest = ROOT / "SHA256SUMS.txt"
    listed: set[str] = set()
    for line in manifest.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            digest, relative = line.split("  ", 1)
        except ValueError:
            return False
        if relative in listed or relative == "SHA256SUMS.txt":
            return False
        listed.add(relative)
        target = ROOT / relative
        if not target.is_file() or target.is_symlink() or sha256_file(target) != digest:
            return False
    expected = {
        path.relative_to(ROOT).as_posix()
        for path in ROOT.rglob("*")
        if path.is_file()
        and path != manifest
        and "__pycache__" not in path.parts
        and path.suffix != ".pyc"
    }
    return listed == expected


def execution_cross_hashes_ok() -> bool:
    receipt = json.loads((ROOT / "EXECUTION_RECEIPT.json").read_text(encoding="utf-8"))
    hashes = receipt.get("receipt_sha256") or {}
    return bool(hashes) and all(
        (ROOT / name).is_file() and sha256_file(ROOT / name) == digest
        for name, digest in hashes.items()
    )


def determinism_cross_hashes_ok() -> bool:
    receipt = json.loads(
        (ROOT / "MUTATION_DETERMINISM_RECEIPT.json").read_text(encoding="utf-8")
    )
    mutation = receipt.get("mutation") or {}
    closure = receipt.get("closure") or {}
    return all([
        mutation.get("json_sha256") == sha256_file(ROOT / "MUTATION_RECEIPTS.json"),
        mutation.get("markdown_sha256") == sha256_file(ROOT / "MUTATION_RECEIPTS.md"),
        closure.get("json_sha256") == sha256_file(ROOT / "CLOSURE_PROBE_RECEIPT.json"),
    ])


def full_seed_replay() -> dict[str, bool]:
    with tempfile.TemporaryDirectory(prefix="pa-r024-replay-") as temporary:
        output = Path(temporary)
        mutation_processes = []
        closure_processes = []
        for seed in ("1", "2"):
            mutation_processes.append(run([
                "run_round26_mutations.py", "--full",
                "--output-json", str(output / f"mutation-{seed}.json"),
                "--output-md", str(output / f"mutation-{seed}.md"),
            ], seed))
            closure_processes.append(run([
                "run_round26_closure_probes.py",
                "--output-json", str(output / f"closure-{seed}.json"),
            ], seed))
        return {
            "mutation_seed_exit_zero": all(item.returncode == 0 for item in mutation_processes),
            "mutation_json_seed_identical": (
                (output / "mutation-1.json").read_bytes()
                == (output / "mutation-2.json").read_bytes()
            ),
            "mutation_markdown_seed_identical": (
                (output / "mutation-1.md").read_bytes()
                == (output / "mutation-2.md").read_bytes()
            ),
            "mutation_json_matches_shipped": (
                (output / "mutation-1.json").read_bytes()
                == (ROOT / "MUTATION_RECEIPTS.json").read_bytes()
            ),
            "mutation_markdown_matches_shipped": (
                (output / "mutation-1.md").read_bytes()
                == (ROOT / "MUTATION_RECEIPTS.md").read_bytes()
            ),
            "closure_seed_exit_zero": all(item.returncode == 0 for item in closure_processes),
            "closure_seed_identical": (
                (output / "closure-1.json").read_bytes()
                == (output / "closure-2.json").read_bytes()
            ),
            "closure_matches_shipped": (
                (output / "closure-1.json").read_bytes()
                == (ROOT / "CLOSURE_PROBE_RECEIPT.json").read_bytes()
            ),
        }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--full", action="store_true", help="also replay both seed suites")
    args = parser.parse_args()
    checks = {
        "semantic_receipt_live_match": stdout_matches(
            ["meta_validate_round26.py", "--semantic-only"],
            "SPEC_VALIDATION_RECEIPT.semantic.json",
        ),
        "full_receipt_live_match": stdout_matches(
            ["meta_validate_round26.py"], "SPEC_VALIDATION_RECEIPT.json"
        ),
        "oracle_receipt_live_match": stdout_matches(
            ["independent_oracle.py"], "ORACLE_RECEIPT.json"
        ),
        "transition_receipt_live_match": stdout_matches(
            ["transition_evaluator.py"], "TRANSITION_EVAL_RECEIPT.json"
        ),
        "export_generator_receipt_live_match": stdout_matches(
            ["export_generator.py"], "EXPORT_GENERATOR_RECEIPT.json"
        ),
        "export_verifier_receipt_live_match": stdout_matches(
            ["export_verifier.py"], "EXPORT_VERIFIER_RECEIPT.json"
        ),
        "round_checksum_manifest_valid": checksum_manifest_ok(),
        "execution_cross_hashes_valid": execution_cross_hashes_ok(),
        "determinism_cross_hashes_valid": determinism_cross_hashes_ok(),
    }
    if args.full:
        checks.update(full_seed_replay())
    ok = all(checks.values())
    output = {
        "schema_version": "pa.phase0a.round26_receipt_replay.v1",
        "mode": "full" if args.full else "quick",
        "status": "PASS" if ok else "FAIL",
        "checks": dict(sorted(checks.items())),
        "checks_passed": sum(checks.values()),
        "checks_total": len(checks),
    }
    sys.stdout.write(json.dumps(output, indent=2, sort_keys=True) + "\n")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
