#!/usr/bin/env python3
"""Round 026 mechanism-closure probes on disposable complete relay copies."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Callable

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
RELAY = HERE.parents[1]
sys.path.insert(0, str(HERE))

import run_round26_mutations as registry  # noqa: E402


def run_validator(round_dir: Path, semantic_only: bool = False) -> subprocess.CompletedProcess[str]:
    command = ["python3", "-S", str(round_dir / "meta_validate_round26.py"), "--root", str(round_dir)]
    if semantic_only:
        command.append("--semantic-only")
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env.setdefault("LC_ALL", "C")
    env.setdefault("TZ", "UTC")
    return subprocess.run(command, cwd=round_dir, env=env, capture_output=True, text=True, check=False)


def payload(process: subprocess.CompletedProcess[str]) -> dict:
    try:
        value = json.loads(process.stdout)
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def codes(process: subprocess.CompletedProcess[str]) -> list[str]:
    return sorted({
        value.split(":", 1)[0]
        for value in payload(process).get("errors", [])
        if isinstance(value, str)
    })


def mutate_nested_contract(round_dir: Path) -> None:
    path = round_dir / registry.CONTRACT
    value = registry.load(path)
    value["gates"][0]["stage_override"] = True
    registry.save(path, value)


def write_negative_context(round_dir: Path, executable: bool) -> None:
    relay = round_dir.parents[1]
    target = (
        relay / "03_EXCHANGE" / "ROUND_027_INDEPENDENT_PHASE0A_SPEC_REREVIEW"
        / "negative_context" / "authority_probe.negative.json"
    )
    target.parent.mkdir(parents=True, exist_ok=True)
    literal = registry.R23_AUTHORITY_PROSE
    registry.save(target, {
        "schema_version": "pa.phase0a.negative_context.v1",
        "context": "ADVERSARIAL_REJECTION_PROBE",
        "expected": "REJECT",
        "executable": executable,
        "payload_sha256": hashlib.sha256(literal.encode("utf-8")).hexdigest(),
        "payload": literal,
    })


PROBES: tuple[tuple[str, Callable[[Path], None], set[str], bool], ...] = (
    ("R25-F01-LATIN-SMALLCAP-MARKDOWN", registry.r25_p01_latin_smallcap_markdown, {"AUTHORITY_PROHIBITED_TEXT"}, True),
    ("R25-F01-LATIN-SMALLCAP-DAG", registry.r25_p02_latin_smallcap_dag, {"AUTHORITY_PROHIBITED_TEXT"}, True),
    ("R25-F01-CHEROKEE-MARKDOWN", registry.r25_p03_cherokee_markdown, {"AUTHORITY_PROHIBITED_TEXT"}, True),
    ("R25-F02-PROMPT-SCANNED", registry.r25_p04_prompt_to_execute, {"AUTHORITY_PROHIBITED_TEXT"}, True),
    ("R25-F03-VALIDATOR-DOCUMENT-PROJECTION", registry.r25_p05_validator_comment_projection, {"AUTHORITY_PROHIBITED_TEXT"}, True),
    ("R25-F04-HOLD-STRUCTURAL-TERMINAL", registry.r25_p07_hold_paraphrase, {"HOLD_UNSTRUCTURED_AUTHORITY_SURFACE"}, True),
    ("R25-C01-NESTED-CONTRACT-KEY-SPACE", mutate_nested_contract, {"ACCEPTANCE_CONTRACT_NESTED_KEYS_INVALID"}, True),
    ("R26-NEGATIVE-CONTEXT-MALFORMED-FAILS-CLOSED", lambda d: write_negative_context(d, True), {"AUTHORITY_PROHIBITED_TEXT"}, True),
    ("R26-NEGATIVE-CONTEXT-VALID-NONEXECUTABLE", lambda d: write_negative_context(d, False), set(), False),
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    clean = run_validator(HERE)
    clean_payload = payload(clean)
    baseline_count = clean_payload.get("authority_strings_scanned", 0)
    results = []
    for probe_id, mutator, expected, should_reject in PROBES:
        with tempfile.TemporaryDirectory(prefix="pa-r026-closure-") as temporary:
            relay_copy = Path(temporary) / "relay"
            shutil.copytree(RELAY, relay_copy, ignore=registry.copy_ignore)
            round_dir = relay_copy / registry.ROUND_RELATIVE
            mutator(round_dir)
            registry.coherent_probe_rebind(round_dir)
            semantic = run_validator(round_dir, True)
            full = run_validator(round_dir)
            observed = sorted(set(codes(semantic)) | set(codes(full)))
            full_count = payload(full).get("authority_strings_scanned", 0)
            rejected = semantic.returncode != 0 and full.returncode != 0
            passed = (
                rejected and expected <= set(observed)
                if should_reject
                else semantic.returncode == 0 and full.returncode == 0
            )
            count_increased = full_count > baseline_count if probe_id == "R25-F02-PROMPT-SCANNED" else None
            if count_increased is False:
                passed = False
            results.append({
                "probe_id": probe_id,
                "expected": "REJECT" if should_reject else "ACCEPT_AS_INERT_NEGATIVE_CONTEXT",
                "expected_reason_codes": sorted(expected),
                "observed_reason_codes": observed,
                "semantic_exit_code": semantic.returncode,
                "full_exit_code": full.returncode,
                "authority_strings_scanned": full_count,
                "authority_count_increased_vs_baseline": count_increased,
                "passed": passed,
            })
            print(f"{'PASS' if passed else 'FAIL'} {probe_id}", flush=True)
    receipt = {
        "schema_version": "pa.phase0a.round26_closure_receipt.v1",
        "round": "ROUND_026_CONTROLLING_PHASE0A_REPAIR",
        "source_tree_modified": False,
        "execution_boundary": "disposable /tmp complete-relay copies",
        "baseline_exit_code": clean.returncode,
        "baseline_authority_strings_scanned": baseline_count,
        "results": results,
        "summary": {
            "probes": len(results),
            "passed": sum(item["passed"] for item in results),
            "failed": sum(not item["passed"] for item in results),
            "material_findings_closed": ["R25-F01", "R25-F02", "R25-F03", "R25-F04"],
        },
    }
    args.output.write_text(json.dumps(receipt, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")
    return 0 if clean.returncode == 0 and all(item["passed"] for item in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
