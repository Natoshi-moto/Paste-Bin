# Incoming Round 027 negative-context protocol

An incoming probe may carry a decoded adversarial literal without base64 only
at this path shape:

`03_EXCHANGE/ROUND_027_*/negative_context/*.negative.json`

The JSON object must have exactly six fields: schema version, context, expected
result, executable flag, payload digest, and payload. The fixed values are
`pa.phase0a.negative_context.v1`, `ADVERSARIAL_REJECTION_PROBE`, `REJECT`, and
`false`; the SHA-256 must match the UTF-8 payload bytes.

Only the payload leaf receives negative-test treatment. Keys, paths, metadata,
and every malformed record remain scanned normally. The record is explicitly
non-executable and cannot authorize a builder action. The Round 026 closure
suite proves that a valid record is inert and that changing the executable flag
fails closed.

