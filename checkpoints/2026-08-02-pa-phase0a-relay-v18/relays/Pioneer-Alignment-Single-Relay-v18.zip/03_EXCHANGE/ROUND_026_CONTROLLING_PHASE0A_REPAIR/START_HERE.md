# Round 026 controlling Phase 0A repair

This directory supersedes Round 024 without mutating it. Run every command with
`PYTHONDONTWRITEBYTECODE=1 python3 -S` from this directory.

Verification order:

1. `meta_validate_round26.py --semantic-only`
2. `meta_validate_round26.py`
3. `independent_oracle.py PHASE0A_ACCEPTANCE_CONTRACT.v4.json`
4. `transition_evaluator.py`
5. `export_generator.py`
6. `export_verifier.py`
7. `run_round26_mutations.py --full --output-json MUTATION_RECEIPTS.json --output-md MUTATION_RECEIPTS.md`
8. `r26_closure_probes.py --output R026_CLOSURE_RECEIPT.json`
9. `verify_round26_receipts.py`

The package remains a specification repair only. There is no implementation
candidate and no host, provider, repository, deployment, credential, wallet,
DNS, or public-action authority.

HOLD is terminal. The sole authoritative review-state transitions are the
machine-readable transition table and the separately anchored HOLD policy.

