# Round 026 repair summary

Adjudication: `ROUND026_REPAIR_COMPLETE_AWAITING_INDEPENDENT_REREVIEW`

Round 026 closes all four material Round 025 findings at the mechanism level:

- R25-F02: the relay scan exemption was deleted. The control prompt is scanned
  as an always-live authority surface, and the closure receipt proves its added
  payload raises the scan counter and rejects.
- R25-F01: script detection now uses the shipped Unicode 17 UAX #24 Script
  property table. The digest-anchored confusable map permanently covers the
  Latin small-capital/IPA and Cherokee threat alphabets, while mixed-script
  rejection applies to Latin plus any non-Common/non-Inherited script.
- R25-F03: whole-document projection applies to the validator itself. An
  external manifest file pins the validator bytes, and v17's input manifest
  locks both files outside the validator.
- R25-F04: HOLD is terminal under an exact machine policy. Unstructured text
  cannot create a competing HOLD-stage transition channel.

The nested acceptance-contract record key spaces are exact. The mutation
registry preserves all 88 existing classes and adds the six material Round 025
false-green classes. Honest DEFERRED status, the slug and export floors, N80
reviewed-byte identity, and all external blockers remain unchanged.

