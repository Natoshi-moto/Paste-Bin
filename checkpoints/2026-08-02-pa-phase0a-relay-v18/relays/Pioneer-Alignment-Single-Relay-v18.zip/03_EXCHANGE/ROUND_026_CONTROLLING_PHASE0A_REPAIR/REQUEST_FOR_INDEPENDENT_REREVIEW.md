# Request for Round 027 independent Phase 0A rereview

Independently replay the Round 026 baseline, all 94 permanent mutation classes,
the legacy 43-negative closure floor, and `R026_CLOSURE_RECEIPT.json`. Verify
that seeds 1 and 2 produce byte-identical mutation receipts.

Invent new probes outside the permanent registry, especially script-property
edge cases, validator comment/literal composition, control-prompt scanning,
malformed negative-context records, nested contract keys, and alternate
attempts to create a prose transition around terminal review states.

Use only disposable complete relay copies. Do not build or deploy an
application, connect a provider, access credentials, mutate a repository, or
perform external actions.

