# Round 027 return summary

Adjudication: `HOLD_FOR_FURTHER_PHASE0A_SPEC_REPAIR`

Round 026's own work reproduces completely and honestly. The eight-tool baseline
is green on the sealed v17 input, the 94-class mutation registry rejects 94 of
94 with no false green and no wrong-reason rejection, the closure receipt
regenerates **byte-identically** to the shipped file, 43 of 43 legacy negatives
still reject for the intended reason, and 11 of 11 tracked findings remain
closed. Nothing in this review disputes any of that.

Eighteen independently invented probes, none of them in the permanent registry,
were run against disposable complete-relay copies under a coherent author
rebind whose no-op control reproduces the sealed tree byte for byte. Ten produce
material false greens: prohibited builder authority, or a bypass of the terminal
review state, ships in a packaged return relay while all eight tools exit 0.

Three of Round 025's four findings survive one step outside the exact
demonstration Round 026 repaired against:

- **R25-F01 open.** Combining marks are neither stripped nor treated as a script
  mixture, and a payload written wholly in one unmapped non-Latin block has no
  Latin to mix with. An enumerated confusable map cannot close an adversarially
  chosen space.
- **R25-F02 closed for the control prompt only.** The deleted exemption is
  genuinely gone. A regenerated input manifest, however, removes any other relay
  member from the scan entirely — the counter stays at the clean-tree value, so
  the payload is unscanned rather than unmatched.
- **R25-F03 open.** The validator's projection covers adjacent comment blocks
  only; non-adjacent comments and a two-`Name` composition are neither joined
  nor flagged.
- **R25-F04 open.** The structural terminal-state rule keys on one exact token
  and skips any file whose basename borrows one of ten machine-record names.

One new class was found beyond the Round 025 set: the acceptance-contract key
space is closed by set equality at exactly one nesting level, so an object one
level deeper carries a release-authorising assertion while the gate stays green.

Controls that held: the control prompt is scanned; the negative-context protocol
fails closed and exempts only the payload leaf; floors anchored outside the
validator survive reflexive removal; DEFERRED cannot launder a candidate pass;
N80 reviewed-byte identity, export identity and the four external blockers are
unchanged.

Candidate status remains `NO_IMPLEMENTATION_CANDIDATE`. The terminal review
state is preserved. The Phase 0A specification is **not** released to a bounded
local builder; Round 028 should close R27-F01 through R27-F05 and add all ten
material classes to the permanent registry.

Round 026 bytes and all prior-round bytes are unmodified in this return.
