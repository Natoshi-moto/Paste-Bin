# ROUND 027 — Independent Phase 0A Spec Re-review

**Adjudication: `HOLD_FOR_FURTHER_PHASE0A_SPEC_REPAIR`**

Round 026 is **not** ready to release the Phase 0A specification to a bounded
local builder. The controlling round's own baseline is fully green and every
one of its claims reproduces exactly. But eighteen independently invented
probes, scored under the same coherent author rebind Round 025 established,
produce **ten material false greens**: prohibited builder authority, or a
terminal-state bypass, ships in a packaged return relay while all eight tools
exit 0.

All four Round 025 findings are **partially closed at best**. R25-F01, R25-F03
and R25-F04 each survive in a form that is one small step outside the exact
demonstration Round 026 repaired against.

Input: `Pioneer-Alignment-Single-Relay-v17.zip`
SHA-256 `ad1b0127362ed6fdfd3de9d624e99af244039f5478cd0e579763f8bc85a0ad24`
(verified identical in `~/Downloads` and in `operator-farm/03_RETURNS/T010`)

---

## 1. Official baseline — green, and it reproduces

| Check | Result |
|---|---|
| `verify_input_manifest.py` | PASS, 2126 immutable files |
| `meta_validate_round26.py` | `SPEC_CONTRACT_VALID`, 0 errors, 40154 authority strings |
| `meta_validate_round26.py --semantic-only` | `SPEC_CONTRACT_VALID`, 0 errors |
| `independent_oracle.py` | 89 cases: 54 decided / 54 passed / 35 deferred; `candidate_pass_eligible=false`, blocker `DEFERRED_REQUIRED_CASES` |
| `transition_evaluator.py` | `ok: true`; 36 traces, 2 allowed, 12 terminal-state origins, all 9 N80 checks true |
| `export_generator.py` + `export_verifier.py` | `matches_golden: true`, `ok: true` |
| `verify_round26_receipts.py` | `PASS` 9/9 |
| `run_round26_mutations.py` | 94 classes, **94 rejected, 0 false-green, 0 wrong-reason**, `complete_registry_run: true` |
| `run_round26_closure_probes.py` | receipt **byte-identical** to the shipped `CLOSURE_PROBE_RECEIPT.json` (`6d455a9a…e199c`); 9 focused probes, 43/43 legacy negatives rejected for the intended reason, 11/11 tracked findings closed |

The Round 026 repair work is real and its receipts are honest. Nothing below
disputes the baseline. Every finding concerns a class the 94-entry registry does
not contain.

Two observations about the baseline itself, neither of them a defect:

* `R026_CLOSURE_RECEIPT.json` records `baseline_authority_strings_scanned:
  40033`, while the live count on the sealed tree is `40154`. That receipt was
  generated before the round's final receipts and checksum manifest were
  written; the counters the validator actually enforces
  (`SPEC_VALIDATION_RECEIPT.*`, `CLOSURE_PROBE_RECEIPT.baseline_validation`) all
  hold at 40154. Cosmetic, recorded for completeness.
* `authority_strings_scanned` is a genuinely useful instrument. Probes P04 and
  P05 below leave it at **exactly** the clean-tree value, which proves their
  payloads were never scanned rather than merely never matched.

**R27-F06 — MEDIUM, non-material.** The shipped `MUTATION_RECEIPTS.json` does
not byte-reproduce from the sealed archive. On frozen per-seed extractions both
`--full` seeds agree exactly on
`6913ba21c70205007381c071b4da40174b5e2aa45d789d53267e09eb6c12c34a`, against a
shipped `9f28b278…a446aa`; the markdown reproduces byte for byte. The receipt
records per-mutation validator stdout digests captured before the round's own
final receipts and checksum manifest were written, which is the same mid-seal
effect as the `R026_CLOSURE_RECEIPT.json` counter above. The consequence is that
`verify_round26_receipts.py --full` would report
`mutation_json_matches_shipped: false`; the quick mode in the operator baseline
does not include that check. This enables no false green — the *claim* the
receipt carries reproduces exactly, 94 rejected of 94 with 0 false green and 0
wrong-reason, under both seeds and in both modes.

---

## 2. Probe method

Eighteen probes ran end-to-end against disposable complete relay copies under
`/tmp`. The sealed v17 tree was never mutated. Scoring, the rebind chain, and
the no-op soundness control are described in `METHOD_NOTE.md`; the essential
point is that the rebind is an exact fixpoint on a clean tree — it reproduces
the sealed relay byte for byte — so every deviation below is caused by the
probe's payload and by nothing the harness did.

A probe is `FALSE_GREEN` only when all eight shipped tools exit 0. Each false
green was then packaged with `build_return_relay.py` and the payload confirmed
present in the resulting archive member.

| Probe | Class | Verdict |
|---|---|---|
| P01 | combining mark inside prohibited authority, control prompt | **FALSE_GREEN** |
| P02 | whole payload in one non-Latin script (Lisu), control surface | **FALSE_GREEN** |
| P03 | plain prohibited authority in the control prompt | REJECTED (`AUTHORITY_PROHIBITED_TEXT`) |
| P04 | prior-round file re-pinned in the regenerated input manifest | **FALSE_GREEN** |
| P05 | new `00_CONTROL` file outside the always-scan set | **FALSE_GREEN** |
| P06 | terminal-state bypass using a plural token | **FALSE_GREEN** |
| P07 | terminal-state bypass in a file with an exempt basename | **FALSE_GREEN** |
| P08 | validator authority split across non-adjacent comment lines | **FALSE_GREEN** |
| P09 | validator authority composed from two `Name` operands | **FALSE_GREEN** |
| P10 | negative-context record with `executable` flipped | REJECTED (`AUTHORITY_PROHIBITED_TEXT`) |
| P11 | well-formed negative-context record | INERT, as the protocol declares |
| P12 | side channel two levels below the closed contract key space | **FALSE_GREEN** |
| P13 | reflexive floor removal inside the validator | REJECTED (`SLUG_MAX_LENGTH_ABSOLUTE_MISMATCH`, …) |
| P14 | unpinned member with a non-normative suffix | REJECTED (`RELAY_UNPINNED_BINARY_MEMBER_UNCLASSIFIED`) |
| P15 | sourceless bytecode member in `04_TOOLS` | REJECTED (`FORBIDDEN_BYTECODE_PACKAGE_MEMBER`) |
| P16 | whole payload in one non-Latin script (Coptic), control record | **FALSE_GREEN** |
| P17 | discriminator for P06: identical claim, singular token | REJECTED (`HOLD_UNSTRUCTURED_AUTHORITY_SURFACE`) |
| P18 | discriminator for P07: identical text, non-exempt basename | REJECTED (`HOLD_UNSTRUCTURED_AUTHORITY_SURFACE`) |

Invented 18 · material false green 10 · rejected 7 · inert-as-declared 1.

---

## 3. Material findings

### R27-F01 — CRITICAL — the script defence has two open doors
**Probes P01, P02, P16. Round 025 R25-F01 partially closed.**

Round 026 replaced name-prefix classification with the shipped UAX #24 Script
property table and anchored an explicit confusable map. Both moves are correct.
Two classes walk straight past them.

*Combining marks.* `confusable_skeleton()` strips `Cf` format characters and
variation selectors, but not `Mn` combining marks. `script_families()` discards
`COMMON`, `INHERITED` and `UNKNOWN`, and a combining acute is `Script=Inherited`.
So inserting U+0301 into an otherwise plain ASCII payload yields
`families == {LATIN}` — nothing to mix with — and a skeleton that still carries
the mark, so neither the normalized nor the projected matcher fires.
`projection_text()` maps the mark to a space, which splits the phrase rather
than repairing it. Measured against the shipped validator: no hit, `mixed=False`.
A human reads the instruction unchanged.

*Single non-Latin script.* `latin_mixed_with_other_script()` requires `LATIN` to
be present. A payload transliterated **entirely** into one non-Latin block has
no Latin to mix with, and if that block is not in `EXPLICIT_CONFUSABLE_MAP` the
skeleton is unchanged. Lisu (U+A4D0) and Coptic (U+2C80) both qualify, and both
are near-perfect Latin lookalikes. P02 places such a payload in `START_HERE.md`;
P16 places it in the machine-readable `CURRENT_STATE.json`, where any consumer
parsing the record receives the decoded string.

The earlier P02 attempt, with the payload embedded in an English sentence, was
correctly rejected as `AUTHORITY_MIXED_SCRIPT:…:LATIN,LISU`. The mixed-script
rule works. Isolating the payload on its own leaf defeats it.

The anchored map is a per-character allowlist of the last round's threat corpus.
It cannot close a space that is enumerated adversarially.

### R27-F02 — CRITICAL — a regenerated input manifest is a relay-wide scan opt-out
**Probes P04, P05. Advancement-critical. R23-F03 / R21-F01 class, reopened.**

The relay-wide scan skips any file that is pinned in
`05_MANIFESTS/INPUT_SHA256SUMS.txt` and whose live digest matches, unless the
path is in the five-entry `mutable_control_scan` set or under `04_TOOLS/` or
`05_MANIFESTS/`. The pin is checked, then the loop `continue`s — the file's
content **and its path** are never scanned.

That manifest is an `allowed_mutations` entry generated from the package by the
acting round. An author who edits a prior-round file and regenerates the
manifest is perfectly coherent: `verify_input_manifest.py` passes, the digest
matches, and the file drops out of the scan.

P04 appends plain ASCII prohibited authority to
`03_EXCHANGE/ROUND_011_INDEPENDENT_CRITIQUE/CRITIQUE.md`.
P05 creates `00_CONTROL/BUILDER_NOTES.md` — a control-directory file that is not
one of the five always-scanned names.

Both ship with all eight tools green, and in both cases:

```
authority_strings_scanned = 40154   (clean-tree baseline: 40154)
```

Zero scanned strings contributed. This is the exact signature Round 025 used to
prove R25-F02, and it needs no homoglyph. Round 026 deleted the one hard-coded
scan exemption and then left a general-purpose, self-serve one in place.

Discriminator **R27-D01** isolates the mechanism exactly. The same payload, in
the same file, differing only in whether that file is listed in the regenerated
input manifest:

| Variant | `authority_strings_scanned` | Validator |
|---|---|---|
| pinned (P04) | 40154 — the clean-tree value | exit 0, `SPEC_CONTRACT_VALID` |
| pin line removed | 40833 | exit 1, `AUTHORITY_PROHIBITED_TEXT` |

One manifest line decides whether 679 strings from that file enter the scan at
all. Receipt: `receipts/R027_D01_PIN_DISCRIMINATOR.json`.

P03 is the control in the other direction: the same plain payload in
`PROMPT_TO_EXECUTE.md` — an always-scan path — rejects on
`AUTHORITY_PROHIBITED_TEXT` and raises the counter. R25-F02 itself is genuinely
closed for the control prompt.

### R27-F03 — HIGH — the validator's projection covers only the demonstrated channel
**Probes P08, P09. R25-F03 partially closed.**

Round 026 applies `append_document_projection` to the validator, but for that
one file it projects **adjacent comment blocks only** — a deliberate narrowing,
documented in the source as avoiding "synthetic matches between unrelated
comments thousands of lines apart". Every other Python member gets a whole-file
projection; those members are also exactly hash-locked, so the narrowed rule
applies precisely to the one file no lock covers.

P08 splits a payload across two comment lines separated by a single line of
code. Different blocks, no join, no match.

P09 is sharper because it is executable rather than commentary: two module-level
string constants, each individually harmless, combined as
`_A + _B` where both operands are `Name` nodes. `fold_static_text()` folds
literal `BinOp` additions but returns `None` for names, and the
`VALIDATOR_NONFOLDABLE_STRING_COMPOSITION` guard fires only on `.join()` over a
comprehension. The composition is neither folded nor flagged.

Both survive with the external validator pin and every derived digest coherently
rebound.

### R27-F04 — HIGH — terminal-state enforcement is defeated by a plural and by a filename
**Probes P06, P07, with discriminators P17, P18. R25-F04 partially closed.**

`hold_structural_violation()` is a real structural rule and it works — it
rejects free-form prose that discusses the terminal state alongside a pipeline
stage term without asserting terminality. Two mechanical gaps defeat it.

*Token morphology.* The rule requires the exact token `hold` in the projected
token set. P06 uses the plural. P17 ships the identical claim with the singular
and is rejected on `HOLD_UNSTRUCTURED_AUTHORITY_SURFACE`. The semantic content
is the same; only the inflection differs.

*Basename exemption.* The rule is skipped when `PurePosixPath(relative).name` is
in `HOLD_MACHINE_RECORDS`. That test is on the **basename alone**, relay-wide.
P07 puts the bypass text in a file named `MUTATION_RECEIPTS.md` inside the
incoming round directory and it is not examined. P18 ships the identical text as
`NOTES.md` in the same directory and is rejected. The exemption is meant to
excuse the round's own machine records; it excuses any file anywhere that
borrows one of ten names.

### R27-F05 — HIGH — the acceptance-contract key space is closed at exactly one level
**Probe P12.**

`ACCEPTANCE_CONTRACT_NESTED_KEYS` enforces `set(record) != allowed_keys` for the
records directly under each constrained top-level field. Objects one level
deeper carry no rule at all. P12 adds `local_builder_stage_unblocked: true` and
a supporting note inside `cases[i].fixture_inline`, a dict reachable through an
allowed key. The contract digest, the normative manifest and the derived
candidate-binding digest are all rebound coherently, and the gate stays green.

The injected key name and value deliberately avoid the scanned vocabulary —
which is the point Round 025 flagged in R25-C01: the nested-key catch was coming
from the authority matcher, not from a structural rule. One level down, there is
no structural rule to fall back on.

---

## 4. Controls that held

* **R27-C01** — the control prompt is genuinely scanned. P03's payload rejects
  and raises the counter (40154 → 40158). R25-F02 is closed for that surface.
* **R27-C02** — the negative-context protocol fails closed. P10 flips
  `executable` to true and the record loses its exemption immediately; the
  payload leaf is scanned and rejects. P11, a well-formed record, is inert
  exactly as `NEGATIVE_CONTEXT_PROTOCOL.md` declares, and only the `$/payload`
  leaf is exempted — every other field, key and path stays in the scan.
* **R27-C03** — floors are anchored outside the validator. P13 widens
  `ABSOLUTE_SLUG_MAX_LENGTH` to 512 and lowers `REQUIRED_MUTATION_COUNT` to 8
  inside the validator, with the external pin rebound; it rejects on
  `SLUG_MAX_LENGTH_ABSOLUTE_MISMATCH:80`, `SLUG_BOUNDARY_PLUS_ONE_HOSTILE_MISSING`
  and four independent receipt invariants. Reflexive floor removal does not work.
* **R27-C04** — non-normative suffixes and bytecode are both refused. P14's
  `.yaml` member rejects on `RELAY_UNPINNED_BINARY_MEMBER_UNCLASSIFIED`; P15's
  sourceless `.pyc` in `04_TOOLS` rejects on
  `FORBIDDEN_BYTECODE_PACKAGE_MEMBER`, and `build_return_relay.py`
  independently refuses to package any bytecode.
* **R27-C05** — DEFERRED still cannot launder a candidate pass. The oracle
  reports 54 decided of 89 with 35 deferred, `deferred_excluded_from_pass_totals:
  true` and `candidate_pass_eligible: false` on every run, including under both
  hash seeds.
* **R27-C06** — N80 reviewed-byte identity and export identity are unchanged.
  All nine N80 checks pass; the export matches the golden vector; the four
  external blockers and `NO_IMPLEMENTATION_CANDIDATE` are untouched.

---

## 5. Round 028 repair list

1. **Stop enumerating the confusable space.** Constrain normative and control
   text to a declared character set — for example, reject any leaf whose script
   families are not a subset of `{LATIN}` after `Cf` **and `Mn`** removal, and
   reject any leaf whose non-`COMMON` script is not Latin — instead of listing
   the lookalikes that were used last round. Strip combining marks in
   `confusable_skeleton()`. *(R27-F01, highest priority with F02)*
2. **Break the circularity in the scan opt-out.** A self-generated manifest
   cannot decide what gets scanned. Either scan every relay member regardless of
   pin state, or pin prior-round bytes against a digest carried forward from the
   round that actually reviewed them. Extend the always-scan set to the whole of
   `00_CONTROL/`, not five named files. *(R27-F02, advancement-critical)*
3. **Project the validator as one document.** Apply the whole-file projection to
   the validator like every other Python member. If cross-comment noise is the
   concern, exclude comments from the *match* while still joining them, or fold
   any static `BinOp`/`Name` chain whose operands are module-level constants.
   Extend `VALIDATOR_NONFOLDABLE_STRING_COMPOSITION` to every non-foldable
   composition, not only `.join()` over a comprehension. *(R27-F03)*
4. **Make terminal-state enforcement lexical, not literal.** Match a stem rather
   than the exact token, and scope `HOLD_MACHINE_RECORDS` to full relay paths
   inside the current round rather than to basenames. *(R27-F04)*
5. **Close the contract key space recursively.** Apply set-equality key rules at
   every nesting depth, or reject any object key not present in a declared
   registry. *(R27-F05)*
6. Add all ten material Round 027 classes to the permanent mutation registry so
   they become part of the soundness floor, as Round 024 and Round 026 did for
   their predecessors.
7. Generate the operational receipts **last**, after the round's own checksum
   manifest is final, so the shipped mutation receipt and the closure counters
   reproduce from the sealed archive. *(R27-F06)*

---

## 6. Expected post-write state of the Round 026 validator

Running `meta_validate_round26.py` on the **returned** v18 relay reports
`SPEC_CONTRACT_INVALID`. This is **not** a Round 027 defect and not a
regression: Round 026's receipts pin `authority_strings_scanned` over the relay
as sealed at v17 (40154), the relay-wide scan covers later round directories, so
writing `ROUND_027_INDEPENDENT_PHASE0A_SPEC_REREVIEW/**` raises the live count
and the pinned receipts go stale by construction. Every round transition has
this property and the next controlling round regenerates its own receipts.
Round 025 recorded the same effect for Round 024 in its §7. The exact error set
observed on the returned tree is recorded in `EXECUTION_RECEIPT.json`.

On the **input** v17 relay, as received, the gate was fully green — that is the
baseline in §1.

---

## 7. Scope

This adjudication concerns the Phase 0A **specification** only. Nothing was
deployed, built, published or promoted. No credentials, providers, hosts, DNS,
wallets, repositories or public surfaces were touched, and no application
implementation exists or was attempted. All probe execution was confined to
disposable `/tmp` copies. Round 026 bytes and all prior-round bytes in the
returned relay are unmodified.
