# Round 027 method note

## Rebind model

Round 025 established, and Round 026 carried forward, that a manifest an acting
round generates *from its own package* cannot be evidence against that same
author. Round 027 scores every probe under one model only:

**Coherent author rebind.** After a payload is applied to a disposable relay
copy, `r27_harness.reseal()` regenerates every pin an acting author can
regenerate, to a fixpoint:

1. `05_MANIFESTS/ROUND_026_VALIDATOR_SHA256.txt` (the external validator pin)
2. `PHASE0A_NORMATIVE_MANIFEST.v1.json` member digests, plus every record that
   pins that manifest's digest
3. `PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json` contract digest and
   the derived candidate-binding digest
4. the six live-stdout operational receipts
5. `CLOSURE_PROBE_RECEIPT.json` live authority counters
6. `MUTATION_DETERMINISM_RECEIPT.json` and `EXECUTION_RECEIPT.json` cross-hashes
7. the round `SHA256SUMS.txt`
8. `05_MANIFESTS/INPUT_SHA256SUMS.txt`, `CURRENT_SHA256SUMS.txt`,
   `FILE_INVENTORY.json`

A digest mismatch is never credited as a catch. Round 026's own registry is not
scored under this model — it is replayed as shipped.

## Harness soundness control

The rebind machinery is only trustworthy if it introduces nothing of its own.
Control `C00-NOOP-REBIND` applies **no** payload, runs the full rebind, and is
then compared byte-for-byte against the sealed v17 tree:

```
reseal passes: 1
(byte-identical to sealed)
all tools exit 0, authority_strings_scanned = 40154
```

The rebind is an exact fixpoint on a clean tree. Every deviation observed in a
probe is therefore caused by that probe's payload.

## Why receipt convergence needs a template

`meta_validate_round26.py` compares its live `authority_strings_scanned` against
the count pinned in three receipts, and the spec-validation receipts are the
validator's own stdout. A failing receipt carries an `errors` array of strings,
those strings are themselves scanned, and the counter never reaches a fixpoint.
The rebind therefore converges the two spec-validation receipts against the
sealed green template with the live count substituted. When the tree is
otherwise clean the next run reproduces those bytes exactly and the fixpoint is
reached; when the tree is not clean the tools stay red, which is the intended
outcome. No forged green receipt can survive `verify_round26_receipts.py`,
which compares receipt bytes against live stdout.

## Scoring rule

A probe is `FALSE_GREEN` only when **all eight** shipped tools exit 0 after the
rebind:

`verify_input_manifest.py`, `meta_validate_round26.py --semantic-only`,
`meta_validate_round26.py`, `independent_oracle.py`, `transition_evaluator.py`,
`export_generator.py`, `export_verifier.py`, `verify_round26_receipts.py`.

Every false-green was additionally packaged with `04_TOOLS/build_return_relay.py`
and the payload was confirmed present in the resulting archive member, so
"green" means shippable, not merely tolerated in a working tree.

## Operational hazard found while replaying the registry (not a defect)

`run_round26_mutations.py` re-runs `shutil.copytree(RELAY_ROOT, …)` for **every**
mutation class, so it reads the live relay 94 times over roughly half an hour.
It also skips the whole loop when its opening baseline is not green, emitting
`mutation_classes: 0, status: FAIL` rather than an explicit diagnostic.

A first replay of this review was therefore invalid: the Round 027 directory was
created while seeded runs were in flight, and only mutation results from index
78 onward diverged — precisely the classes copied after the write. The
`--full` replays started afterwards saw a relay whose Round 026 receipts had
gone stale and reported zero classes.

Every mutation figure reported here was regenerated on **frozen** trees
extracted fresh from the sealed v17 archive, one tree per seed, with no other
process writing to them. Round 028 should run the registry against a frozen
extraction for the same reason.

## Negative context

Payload literals are carried base64-encoded in `r27_probes.py` and decoded at
run time, per the Round 026 negative-context protocol and the Round 025
precedent. Decoded payload digests are recorded in `PAYLOAD_CLASSES.md`.

## Execution boundary

All probe execution was confined to disposable complete-relay copies under
`/tmp/pa-r027-probe/`. The sealed input tree was never mutated. No application
was built, no host, provider, credential, repository, deployment, DNS, wallet
or public action was touched.
