#!/usr/bin/env python3
"""Round 027 independent probe harness (development copy).

Creates a disposable complete-relay copy per probe, applies one adversarial
mutation, performs a coherent controlling-author rebind of every regenerable
pin, then runs the shipped tool set and classifies the outcome.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
from pathlib import Path
from fnmatch import fnmatchcase

SEALED = Path(os.environ.get("PA_SEALED_RELAY", "/tmp/pa-r027-work/relay"))
WORK = Path("/tmp/pa-r027-probe")
ROUND26 = "03_EXCHANGE/ROUND_026_CONTROLLING_PHASE0A_REPAIR"
VALIDATOR = f"{ROUND26}/meta_validate_round26.py"
PIN = "05_MANIFESTS/ROUND_026_VALIDATOR_SHA256.txt"

ENV = {
    **os.environ,
    "PYTHONDONTWRITEBYTECODE": "1",
    "PYTHONHASHSEED": "1",
    "LC_ALL": "C",
    "TZ": "UTC",
}


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(args: list[str], cwd: Path):
    return subprocess.run(
        ["python3", "-S", *args], cwd=str(cwd), env=ENV,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False,
    )


def write_if_changed(path: Path, data: bytes) -> bool:
    if path.is_file() and path.read_bytes() == data:
        return False
    path.write_bytes(data)
    return True


def dump(document) -> bytes:
    return (json.dumps(document, indent=2, sort_keys=True) + "\n").encode()


def fresh(probe_id: str) -> Path:
    target = WORK / probe_id
    if target.exists():
        shutil.rmtree(target)
    target.mkdir(parents=True)
    relay = target / "relay"
    shutil.copytree(SEALED, relay, symlinks=True)
    for junk in list(relay.rglob("__pycache__")):
        shutil.rmtree(junk, ignore_errors=True)
    return relay


# ---------------------------------------------------------------- reseal ----

def reseal_once(relay: Path) -> bool:
    """One controlling-author rebind pass.  Returns True if anything changed."""
    changed = False
    root = relay / ROUND26

    # 1. validator external digest pin (line format preserved)
    changed |= write_if_changed(
        relay / PIN,
        f"{sha256_file(relay / VALIDATOR)}  {VALIDATOR}\n".encode(),
    )

    # 2. normative member manifest and every record pinning its digest.
    #    Rewrites are surgical: only digest values move, formatting is preserved.
    normative_path = root / "PHASE0A_NORMATIVE_MANIFEST.v1.json"
    normative_text = normative_path.read_text(encoding="utf-8")
    normative = json.loads(normative_text)
    for member in normative.get("members") or []:
        member_path = root / member.get("path", "")
        if member_path.is_file():
            live = sha256_file(member_path)
            if member.get("sha256") != live:
                normative_text = normative_text.replace(member["sha256"], live)
                member["sha256"] = live
    changed |= write_if_changed(normative_path, normative_text.encode())
    normative_digest = sha256_file(normative_path)
    for path in sorted(root.rglob("*.json")):
        if path == normative_path or not path.is_file():
            continue
        text = path.read_text(encoding="utf-8")
        if "normative_manifest_sha256" not in text:
            continue
        new_text = re.sub(
            r'("normative_manifest_sha256"\s*:\s*")[0-9a-f]{64}(")',
            lambda match: match.group(1) + normative_digest + match.group(2),
            text,
        )
        changed |= write_if_changed(path, new_text.encode())

    # 2b. candidate-evidence validation vectors: contract digest and the
    #     derived binding digest the evidence record carries.
    vectors_path = root / "PHASE0A_CANDIDATE_EVIDENCE_VALIDATION_VECTORS.v1.json"
    if vectors_path.is_file():
        text = vectors_path.read_text(encoding="utf-8")
        contract_digest = sha256_file(root / "PHASE0A_ACCEPTANCE_CONTRACT.v4.json")
        text = re.sub(
            r'("contract_sha256"\s*:\s*")[0-9a-f]{64}(")',
            lambda match: match.group(1) + contract_digest + match.group(2),
            text,
        )
        document = json.loads(text)
        binding = ((document.get("positive_fixture") or {}).get("candidate_binding")) or {}
        if binding:
            import sys as _sys
            _sys.path.insert(0, str(root))
            from lib_phase0a import canonical_json_bytes  # type: ignore
            binding_digest = hashlib.sha256(canonical_json_bytes(binding)).hexdigest()
            text = re.sub(
                r'("candidate_binding_sha256"\s*:\s*")[0-9a-f]{64}(")',
                lambda match: match.group(1) + binding_digest + match.group(2),
                text,
            )
        changed |= write_if_changed(vectors_path, text.encode())

    # 3. live-stdout operational receipts.  The two spec-validation receipts are
    #    converged against a green template: writing a failing receipt would add
    #    error strings to the scanned corpus and the authority counter would
    #    never reach a fixpoint.
    for name, argv in (
        ("ORACLE_RECEIPT.json", ["independent_oracle.py"]),
        ("TRANSITION_EVAL_RECEIPT.json", ["transition_evaluator.py"]),
        ("EXPORT_GENERATOR_RECEIPT.json", ["export_generator.py"]),
        ("EXPORT_VERIFIER_RECEIPT.json", ["export_verifier.py"]),
    ):
        completed = run(argv, root)
        if completed.returncode == 0 and completed.stdout:
            changed |= write_if_changed(root / name, completed.stdout)

    count = None
    for name, argv in (
        ("SPEC_VALIDATION_RECEIPT.json", ["meta_validate_round26.py"]),
        ("SPEC_VALIDATION_RECEIPT.semantic.json",
         ["meta_validate_round26.py", "--semantic-only"]),
    ):
        completed = run(argv, root)
        if completed.returncode == 0:
            data = completed.stdout
        else:
            try:
                live = json.loads(completed.stdout.decode())["authority_strings_scanned"]
            except Exception:
                continue
            template = json.loads(
                (SEALED / ROUND26 / name).read_text(encoding="utf-8")
            )
            template["authority_strings_scanned"] = live
            data = (json.dumps(template, indent=2) + "\n").encode()
        changed |= write_if_changed(root / name, data)
        if name == "SPEC_VALIDATION_RECEIPT.json":
            try:
                count = json.loads(data.decode())["authority_strings_scanned"]
            except Exception:
                count = None

    # 4. closure receipt: the two live authority counters only
    closure_path = root / "CLOSURE_PROBE_RECEIPT.json"
    closure = json.loads(closure_path.read_text(encoding="utf-8"))
    if count is not None:
        closure.setdefault("baseline_validation", {})["authority_strings_scanned"] = count
        f04 = (closure.get("findings") or {}).get("R21-F04")
        if isinstance(f04, dict):
            f04["live_authority_strings_scanned"] = count
        changed |= write_if_changed(closure_path, dump(closure))

    # 5. determinism cross-hash for the closure receipt
    determinism_path = root / "MUTATION_DETERMINISM_RECEIPT.json"
    determinism = json.loads(determinism_path.read_text(encoding="utf-8"))
    determinism.setdefault("closure", {})["json_sha256"] = sha256_file(closure_path)
    changed |= write_if_changed(determinism_path, dump(determinism))

    # 6. execution receipt cross-hashes and command digests
    execution_path = root / "EXECUTION_RECEIPT.json"
    execution = json.loads(execution_path.read_text(encoding="utf-8"))
    for name in list(execution.get("receipt_sha256") or {}):
        if (root / name).is_file():
            execution["receipt_sha256"][name] = sha256_file(root / name)
    command_receipt_map = {
        "semantic_validation": "SPEC_VALIDATION_RECEIPT.semantic.json",
        "full_validation": "SPEC_VALIDATION_RECEIPT.json",
        "independent_oracle": "ORACLE_RECEIPT.json",
        "transition_evaluator": "TRANSITION_EVAL_RECEIPT.json",
        "export_generator": "EXPORT_GENERATOR_RECEIPT.json",
        "export_verifier": "EXPORT_VERIFIER_RECEIPT.json",
    }
    for command_name, receipt_name in command_receipt_map.items():
        entry = (execution.get("commands") or {}).get(command_name)
        if isinstance(entry, dict) and (root / receipt_name).is_file():
            entry["stdout_sha256"] = sha256_file(root / receipt_name)
    changed |= write_if_changed(execution_path, dump(execution))

    # 7. round checksum manifest
    manifest = root / "SHA256SUMS.txt"
    lines = [
        f"{sha256_file(path)}  {path.relative_to(root).as_posix()}"
        for path in sorted(root.rglob("*"), key=lambda i: i.relative_to(root).as_posix())
        if path.is_file() and path != manifest
        and "__pycache__" not in path.parts and path.suffix != ".pyc"
    ]
    changed |= write_if_changed(manifest, ("\n".join(lines) + "\n").encode())

    # 8. relay-level manifests
    state = json.loads(
        (relay / "00_CONTROL/CURRENT_STATE.json").read_text(encoding="utf-8")
    )
    mutable = state.get("allowed_mutations", [])
    files = [
        path for path in sorted(relay.rglob("*"))
        if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc"
    ]
    input_lines, current_lines, inventory, total = [], [], [], 0
    inventory_excluded = {
        "05_MANIFESTS/CURRENT_SHA256SUMS.txt", "05_MANIFESTS/FILE_INVENTORY.json",
    }
    for path in files:
        relative = path.relative_to(relay).as_posix()
        digest = sha256_file(path)
        if relative != "05_MANIFESTS/CURRENT_SHA256SUMS.txt":
            current_lines.append(f"{digest}  {relative}")
        if relative not in inventory_excluded:
            size = path.stat().st_size
            total += size
            inventory.append({"path": relative, "bytes": size, "sha256": digest})
        if not any(fnmatchcase(relative, pattern) for pattern in mutable):
            input_lines.append(f"{digest}  {relative}")
    changed |= write_if_changed(
        relay / "05_MANIFESTS/INPUT_SHA256SUMS.txt",
        ("\n".join(input_lines) + "\n").encode(),
    )
    inventory_path = relay / "05_MANIFESTS/FILE_INVENTORY.json"
    document = json.loads(inventory_path.read_text(encoding="utf-8"))
    document["files"] = inventory
    document["archive_file_count"] = len(files)
    document["covered_file_count"] = len(inventory)
    document["covered_total_bytes"] = total
    changed |= write_if_changed(
        inventory_path, (json.dumps(document, indent=2) + "\n").encode()
    )
    changed |= write_if_changed(
        relay / "05_MANIFESTS/CURRENT_SHA256SUMS.txt",
        ("\n".join(current_lines) + "\n").encode(),
    )
    return changed


def reseal(relay: Path, limit: int = 8) -> int:
    for iteration in range(1, limit + 1):
        if not reseal_once(relay):
            return iteration
    return limit


# ------------------------------------------------------------------ run -----

TOOLS = (
    ("verify_input_manifest", ["04_TOOLS/verify_input_manifest.py"], None),
    ("semantic_validation", ["meta_validate_round26.py", "--semantic-only"], ROUND26),
    ("full_validation", ["meta_validate_round26.py"], ROUND26),
    ("independent_oracle", ["independent_oracle.py"], ROUND26),
    ("transition_evaluator", ["transition_evaluator.py"], ROUND26),
    ("export_generator", ["export_generator.py"], ROUND26),
    ("export_verifier", ["export_verifier.py"], ROUND26),
    ("verify_round26_receipts", ["verify_round26_receipts.py"], ROUND26),
)


def evaluate(relay: Path) -> dict:
    results: dict = {"tools": {}}
    for name, argv, subdir in TOOLS:
        completed = run(argv, relay / subdir if subdir else relay)
        detail = ""
        if completed.returncode != 0:
            try:
                document = json.loads(completed.stdout.decode())
                detail = ";".join(sorted(set(document.get("errors") or []))[:8])
                if not detail:
                    detail = json.dumps(document.get("checks") or {})[:300]
            except Exception:
                detail = (completed.stdout.decode(errors="replace")
                          + completed.stderr.decode(errors="replace"))[:400]
        results["tools"][name] = {"exit": completed.returncode, "detail": detail}
    results["all_exit_zero"] = all(
        item["exit"] == 0 for item in results["tools"].values()
    )
    try:
        results["authority_strings_scanned"] = json.loads(
            (relay / ROUND26 / "SPEC_VALIDATION_RECEIPT.json").read_text(encoding="utf-8")
        )["authority_strings_scanned"]
    except Exception:
        results["authority_strings_scanned"] = None
    return results
