# Round 027 payload classes

Every adversarial literal used by `r27_probes.py` is stored base64-encoded and
decoded at run time. The table records the SHA-256 of each **decoded** payload
so Round 028 can verify reproduction without the literals appearing in scanned
text.

| Class | Nature | Bytes | SHA-256 of decoded payload |
|---|---|---|---|
| `AUTH_DEPLOY` | prohibited deployment authority | 20 | `0b345dcf09fc449b65ed17dbe9bec842c6367d30d24d6b4384e4b6b1068146c8` |
| `AUTH_PUSH` | prohibited public repository authority | 64 | `6ffc214a59898e75ad0902d503a4c2e1a570d8ee87840df6aa18d8c5fb61e625` |
| `AUTH_PROVIDER` | prohibited provider/credential authority | 42 | `643742e33ac7c87cb7f57781b9295b9d197f9317948150b6c17f1b508190132b` |
| `HOLD_PLURAL` | terminal-state bypass, plural token | 177 | `142616ea6e08e5795f1c2bf9a65af7362f22cc409664373fdd37cde45d87604c` |
| `HOLD_SINGULAR` | terminal-state bypass, singular token | 95 | `b2df8cfd4ed37c2fa94710f06300e4c7a87718a6cedb42bddb84db138b3b64dd` |

Three derived classes are constructed at run time from `AUTH_DEPLOY`:

| Derived class | Construction | SHA-256 |
|---|---|---|
| `AUTH_DEPLOY_COMBINING` | one U+0301 combining mark (Script=Inherited) inserted after the first letter | `6ec40c4ff7c6ba186c7e56eb9323ceb600822956dc913a904c9feb91a4f9910d` |
| `AUTH_DEPLOY_LISU` | transliterated into the Lisu block U+A4D0–U+A4FF | `79d85d0dae6ea47888a24e90c33fd4e4fd77169bc7330edf8e848c8d39251adb` |
| `AUTH_DEPLOY_COPTIC` | transliterated into the Coptic block U+2C80–U+2CFF | `f5002b52fd707cbbbd0194aede54f3277b92300960b74a2b10e6a0f73c842fd4` |

`AUTH_DEPLOY`, `AUTH_PUSH`, `AUTH_PROVIDER` and the two terminal-state classes
are drawn from the permanent Round 026 probe vocabulary, so the plain classes
serve as positive controls: they must reject wherever they land in a scanned
surface. The three derived classes and the two terminal-state classes are the
material payloads.
