# Round 023 — independent Phase 0A specification re-review of Round 022

Adjudication: **`HOLD_FOR_FURTHER_PHASE0A_SPEC_REPAIR`**

Actor: independent Round 023 Phase 0A specification/gate re-reviewer. Not the
Round 022 controller, not the application builder. No repository, host,
credential, provider, DNS, deployment, wallet, on-chain or public-state action
was taken, and no application was built.

Input archive `Pioneer-Alignment-Single-Relay-v13.zip` verified at
`2bec715b209dc16fef01fab76ac13c3329e61da4f89d6ca320bc4e9c1a68e60b` on both
supplied copies before anything was unpacked.

---

## 1. Round 022's own claims reproduce exactly

Every official command was re-run from a fresh unpack. Round 022 is not
exaggerating anything about its own suite — the reproduction is byte-exact.

| Check | Claimed | Reproduced |
|---|---|---|
| `verify_input_manifest.py` | 1240 immutable inputs PASS | PASS, 1240 files, exit 0 |
| `meta_validate_round22.py` | `SPEC_CONTRACT_VALID` | exit 0, stdout `58bf19bf…9457a` = shipped receipt |
| `--semantic-only` | `SPEC_CONTRACT_VALID` | exit 0, stdout `870e857e…1725` = shipped receipt |
| `independent_oracle.py` | 54 decided / 35 deferred, ineligible | exit 0, stdout `8010bb3a…2874` = shipped receipt |
| `transition_evaluator.py` | 36 traces, 2 allowed, 12 HOLD terminal | exit 0, stdout `b935eccb…d0be` = shipped receipt |
| `export_generator.py` / `export_verifier.py` | golden match | exit 0, both stdout hashes match shipped |
| `verify_round22_receipts.py` | 9/9 quick | 9/9 PASS |
| `verify_round22_receipts.py --full` | full replay | **17/17 PASS** |
| `run_round22_mutations.py` | 66 rejected, 0 false green | 66/66 rejected, 0 false green, 0 wrong reason |
| seed determinism | byte-identical under `PYTHONHASHSEED` 1 and 2 | byte-identical, both plain and `--full` |
| shipped mutation receipt bytes | — | `--full` seed 1 reproduces `MUTATION_RECEIPTS.json` `2dec0c63…78f0` and `.md` `917334d9…4e7d` exactly |
| `run_round22_closure_probes.py` | 43/43 intended reject, 11 findings closed | reproduced; seed 1 output reproduces shipped `CLOSURE_PROBE_RECEIPT.json` `db6b15ee…8972` exactly |

The immutable Round 021 harnesses were re-run unmodified. They target
`ROUND_020_…` and still report 12 probes / 3 false green and 8 unscanned
authority variants — i.e. they faithfully reproduce the *historic* Round 020
defects, confirming the harnesses were not doctored. Re-applied against the
Round 022 gate through the 66-class registry, all eleven of those classes
(`R21-P02`, `R21-P08`, `R21-P10`, `R21-AS01`–`R21-AS08`) now reject for their
intended reason codes.

Round 022's arithmetic is honest. The problem is what its controls do not
cover.

---

## 2. Independent probes — 14 invented, outside the 66-class registry

Every probe ran on a disposable complete relay copy under `/tmp`. The ship tree
was never mutated. A probe is scored `FALSE_GREEN` only when **all six**
documented tools exit 0 after coherent rebind: normative manifest, evidence
envelope, round checksum manifest, `SECURITY_CONSTANTS_SHA256` repin, the
validator's own `lib_phase0a.py` exact-hash lock, and — critically — full
operational-receipt recoherence so that `authority_strings_scanned` and every
cross-hash in `EXECUTION_RECEIPT.json` are recomputed rather than left stale.

Harness: `r23_probes.py`. Receipt: `receipts/r23_probes.json`.

| Probe | Result | Adjudication |
|---|---|---|
| R23-P01 authority via Cyrillic/Armenian confusables in Markdown | FALSE_GREEN | material |
| R23-P02 same payload in a normative JSON instruction leaf | FALSE_GREEN | material |
| R23-P03 authority split across adjacent JSON array elements | FALSE_GREEN | material |
| R23-P04 authority as a Markdown table | REJECTED `AUTHORITY_PROHIBITED_TEXT` | control held |
| R23-P05 authority composed by generator-expression join in the unlocked validator | FALSE_GREEN | material |
| R23-P06 authority in relay control files outside the round directory | FALSE_GREEN | material |
| R23-P07 slug maximum widened through every anchor incl. validator constant | REJECTED `SLUG_HOSTILE_ACCEPTED`, `SLUG_OVERLENGTH_HOSTILE_CORPUS_MISSING`, `SLUG_BOUNDARY_PLUS_ONE_HOSTILE_MISSING` | control held |
| R23-P08 all three export domains rebound incl. validator anchor | REJECTED `CANONICAL_*_DOMAIN`, `EXPORT_*_MISMATCH`, `EXPORT_VERIFY` | control held |
| R23-P09 new declared member with every counter recomputed | FALSE_GREEN | material (enabler) |
| R23-P10 release-authorising side-channel keys in the acceptance contract | FALSE_GREEN | material |
| R23-P11 terminal HOLD overridden in shipped prose | FALSE_GREEN | material |
| R23-P12 extra evidence member declared coherently | REJECTED `EVIDENCE_FIXTURE_SET_MISMATCH` | control held |
| R23-P13 nested archive inside the sole allowed ZIP fixture | REJECTED `PACKAGE_BINARY_ZIP_MEMBER_UNCLASSIFIED`, `ZIP_GOLDEN_MISMATCH`, `EXPORT_ZIP_HASH` | control held |
| R23-P14 authority in bytecode-named members | FALSE_GREEN at the gate | **not material** — `build_return_relay.py` excludes them; verified: 0 such entries in a rebuilt archive |

**invented = 14, false_green = 9, rejected = 5.** Of the nine, eight are
materially exploitable; R23-P14 greens the gate but cannot reach the shipped
archive.

An earlier pass of this harness scored P02, P03, P05, P09 and P10 as
"rejected". That was a harness defect on my side: my receipt recoherence did
not converge, so those runs died on `RECEIPT_AUTHORITY_COUNT_MISMATCH` —
exactly the kind of unpinned-crash artefact the brief forbids crediting as a
control. With recoherence fixed, all five green.

---

## 3. Findings

### R23-F01 — CRITICAL — the authority matcher is defeated by Unicode confusables

`meta_validate_round22.py:308 normalized_text` applies NFKC, strips `Cf`
format characters and variation selectors, casefolds and collapses whitespace.
NFKC does **not** fold Cyrillic, Greek or Armenian confusables onto their Latin
twins, and there is no confusable-skeleton or script-mixing check anywhere in
the package (`grep` for `ascii|confusable|skeleton` finds only unrelated hits).

Substituting one character per word — `Clоudflare` (U+043E), `repоsitory`,
`ԀNS` (U+0500), `0.0.0.Օ` (U+0555) — produces text that renders identically to
a full authority grant and matches **zero** reject substrings. Appended to
`REPAIR_SUMMARY.md` (P01) or added as a `PHASE0A_BUILD_DAG.v2.json` instruction
leaf (P02) after coherent rebind, all six tools exit 0 and the shipped receipt
reports `SPEC_CONTRACT_VALID`, `error_count: 0`.

Round 022's own `R21-P03-AUTHORITY-ZERO-WIDTH-HOMOGLYPH` appears to cover this,
but it does not: three of its four payloads use zero-width/NBSP tricks that NFKC
and the `Cf` strip do remove, and its one genuine Cyrillic substitution
(`DeepSeеk`) is caught only because the *rest* of that payload still
contains the intact reject substring `operator credentials`. Break every
substring and nothing fires.

### R23-F02 — CRITICAL — the matcher is defeated by fragmentation

Matching is per-leaf. Splitting a phrase across adjacent JSON array elements
(P03) means no single leaf contains a reject substring, while any human or
model reading the instruction list reads the grant. In Python, `fold_static_text`
folds `+`, `%`, `.format`, `.join([...])` and f-strings, but not a generator
expression: `"".join(f for f in [...])` in `meta_validate_round22.py` — the one
Python member no exact-hash lock covers, because a validator cannot pin itself —
ships an authority payload that greens every tool (P05).

The Markdown-table variant (P04) rejected only by luck: one cell happened to
retain `provider credentials` intact. The class is not closed.

### R23-F03 — HIGH — "package-wide" means round-directory-wide, not relay-wide

`meta_validate_round22.py:1583` roots the scan at `ROOT`, the Round 022
directory. Nothing scans `00_CONTROL/**`, `04_TOOLS/**`, `05_MANIFESTS/**`,
earlier exchange rounds, or the incoming round's own directory. `START_HERE.md`
and `PROMPT_TO_EXECUTE.md` are in `allowed_mutations`, so
`verify_input_manifest.py` deliberately excludes them from the immutable input
set as well (`04_TOOLS/verify_input_manifest.py:52-63`). P06 places a verbatim,
un-obfuscated authority grant in `00_CONTROL/START_HERE.md` and a new
`BUILDER_NOTES.md` — every tool exits 0. These are precisely the files the next
actor is told to read first.

### R23-F04 — HIGH — the acceptance contract accepts release-authorising side channels

P10 adds `n80_release_allowed_without_candidate_execution: true` and
`deferred_cases_may_be_treated_as_passing_by_builder: true` to
`PHASE0A_ACCEPTANCE_CONTRACT.v4.json`, resyncs the semantic corpus lock and
repins. All six tools exit 0. The oracle's own numbers stay honest — 54 decided,
35 deferred, `candidate_pass_eligible: false` — so the *machine* control is not
laundered, but the shipped normative document now instructs a builder to do
exactly what the machine forbids. Unknown top-level keys in the contract are
never rejected.

### R23-F05 — HIGH — terminal HOLD is machine-terminal but prose-overridable

The transition evaluator is sound: 36 traces, 2 allowed, all 12 HOLD-origin
traces `HOLD_TERMINAL` with `n80_eligible: false`, anchored in the exact-hash
locked `lib_phase0a.py`. But the authority vocabulary contains no term for
review bypass. P11 appends to `START_HERE.md`, inside the scanned round
directory, that "a HOLD recorded at N50 is advisory … the builder may clear a
HOLD without a further independent review and proceed directly to N80". Every
tool exits 0.

### R23-F06 — MEDIUM — receipt freshness deters staleness, not an attacker

R21-F04's control requires shipped counters to equal the live scan. P09 shows
this is recomputable arithmetic: add a member, recompute
`authority_strings_scanned` in both spec receipts, the closure baseline, the
`R21-F04` leaf and every `EXECUTION_RECEIPT.json` cross-hash, and the gate
greens. This is not a defect in isolation — it is the correct behaviour for a
coherent change — but it means freshness contributes nothing against a
determined author, and it is the enabler that let P02/P03/P05 through.

---

## 4. Hard questions

**1. Are R21-F01..F04 and residual R19-F02/F05 actually closed, or only closed
against the known 66-class registry?**

Mixed, and the split matters.

- **R21-F02 — genuinely CLOSED.** P07 widened `slug.max_length` to 4096 across
  the security constants, the note schema, the `lib_phase0a.py` pin, the
  validator's own `ABSOLUTE_SLUG_MAX_LENGTH`, and the validator's lock on the
  library — the strongest coherent rebind available — and it still rejected,
  because the hostile corpus now carries an 81-character boundary vector that
  must be refused. That is a real, independently-anchored floor, not a
  consistency check. **R19-F05 residual CLOSED** by succession.
- **R21-F03 — genuinely CLOSED.** P08 rebound all three export domains through
  spec, runtime, and validator anchor; rejected on `CANONICAL_*_DOMAIN`,
  `EXPORT_ID_MISMATCH`, `EXPORT_CONTENT_SET_MISMATCH`,
  `EXPORT_RECEIPT_HASH_MISMATCH` and `EXPORT_VERIFY`.
- **R21-F04 — CLOSED as specified.** 17/17 full replay, and my independent
  `--full` run reproduces the shipped receipts byte-for-byte. See R23-F06 for
  what that closure does and does not buy.
- **R21-F01 — NOT CLOSED.** Round 022 closed the *coverage* half of R021's
  closure test: package membership now defines the scan, undeclared members
  fail closed, executables are allowlisted and hash-locked. But R21-F01's title
  is "prohibited-authority text ships inside the package and greens every tool",
  and that is still true via R23-F01 and R23-F02. Coverage was widened; the
  matcher was not hardened. **R19-F02 residual therefore also OPEN.**

So: closed against the registry, and against coverage attacks. Not closed
against representation attacks.

**2. Can prohibited-authority text still ship green anywhere in the package?**

Yes, four independent ways: Unicode confusables (P01, P02), fragmentation across
leaves (P03), unfolded static composition in the one unlocked Python member
(P05), and any relay path outside the Round 022 directory (P06).

**3. Is DEFERRED still honest? Can it launder candidate PASS or release?**

The counts are honest and hold under attack. 54 decided / 35 deferred reproduce
exactly; `deferred_excluded_from_pass_totals` is enforced;
`candidate_pass_eligible` is false with blocker `DEFERRED_REQUIRED_CASES`;
`R21-P07` (deferred counted in pass total) and `R21-P09` (new reflexive
operation kind) both reject. My P10 did **not** move a single count. What P10
shows is a *documentary* laundering path: the contract can ship a key telling
the builder to treat deferred cases as passing while the numbers stay clean. The
oracle cannot be laundered; the document can.

**4. Is HOLD still terminal? Can N80 release non-reviewed bytes?**

HOLD is terminal in the evaluator, and N80 identity holds. All 12 HOLD-origin
traces are `HOLD_TERMINAL` / not `n80_eligible`; all nine N80 checks reject
their unsafe dimension (binding, tree, source manifest, evidence, remotes,
non-loopback bind, provider adapter, forbidden untracked). `WORKSPACE`,
`BRANCH` and `BIND` are literals inside exact-hash-locked `lib_phase0a.py`, so
they cannot be rebound without tripping `PACKAGE_PYTHON_MEMBER_HASH_MISMATCH`.
N80 cannot release non-reviewed bytes. The caveat is R23-F05: the shipped prose
can say otherwise and nothing objects.

**5. Did Round 022 break export identity or hashseed determinism?**

No. Export identity is intact and deterministic —
`export_161df160ab63e145d6347b0fc7d657c3`, content set
`1401e409…374b1`, receipt `01487ef2…0cd5a`, zip `9fbe23d0…33bd9`, golden match
true, verifier clean. Determinism is intact: mutation and closure receipts are
byte-identical under `PYTHONHASHSEED` 1 and 2 in both plain and `--full` mode,
and seed-1 `--full` reproduces the shipped bytes exactly.

**6. Exact adjudication and next actor/action**

`HOLD_FOR_FURTHER_PHASE0A_SPEC_REPAIR`. Eight material false greens; release
criteria are not met. Next actor: **controlling Round 024 Phase 0A repair**,
bounded to specification and executable-gate repair only.

Required closures for Round 024:

1. **R23-F01** — add a confusable-skeleton normalization (Unicode TR39 or an
   explicit confusable map) plus a script-mixing rejection for any leaf that
   mixes Latin with another script, and prove it with a registry class per
   script family.
2. **R23-F02** — match on a whole-document normalized projection in addition to
   per-leaf matching (join array siblings and table cells before matching), and
   either fold every static-composition form or reject non-foldable
   string-composition expressions in the validator outright.
3. **R23-F03** — extend the authority scan to the whole relay, explicitly
   including `00_CONTROL/**`, `04_TOOLS/**` and the incoming round directory,
   or state in `AUTHORITY.md` that those paths are outside the gate and pin
   them another way.
4. **R23-F04** — reject unknown top-level keys in the acceptance contract, and
   add reject terms for release/deferral-override vocabulary.
5. **R23-F05** — add review-bypass vocabulary ("clear a HOLD", "without a
   further independent review", "proceed directly to N80", "advisory HOLD") to
   the authority reject set.
6. **R23-F06** — no repair required; record explicitly that receipt freshness
   is an anti-staleness control, not an anti-adversary control.

Round 024 must re-run all 14 Round 023 probes as permanent registry classes.

---

## 5. Preserved posture

Unchanged and carried forward:

- `NO_IMPLEMENTATION_CANDIDATE` — no application exists, no application tests
  were run, no host preflight was run.
- All four external blockers preserved: missing exact canon snapshots for the
  wider architecture, no private GitHub backup authority, unverified writable
  Phase 0A host state, no application implementation evidence.
- Wider Rounds 3–10 architecture remains under separate HOLD and is not a
  Phase 0A build prerequisite.
- No repository mutation, deployment, credential use, provider connection,
  DNS/Cloudflare change, public wallet, on-chain, economy, federation or
  governance action was performed or authorised by this round.
