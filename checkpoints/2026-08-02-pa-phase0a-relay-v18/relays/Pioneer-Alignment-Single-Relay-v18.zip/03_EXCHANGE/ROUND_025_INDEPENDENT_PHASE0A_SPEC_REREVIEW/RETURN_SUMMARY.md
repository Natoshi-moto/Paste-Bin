# Round 025 — Return Summary

**Adjudication: `HOLD_FOR_FURTHER_PHASE0A_SPEC_REPAIR`**

## What was asked

Is Round 024 good enough to release the Phase 0A SPEC to a bounded local
builder, or is there a material false-green / unscanned authority path?

## Answer

There is an unscanned authority path, and there are three further material
false-green classes. Do not release yet.

The Round 024 baseline is genuinely green — 1679-file manifest, both validator
modes valid, oracle 54 decided / 35 honestly deferred, transition table intact,
export byte-identical to golden, receipts 9/9, and the 88-class mutation
registry rejecting 88/88 with zero wrong-reason rejects. The repair work is
real. The problem is what the registry does not contain.

Ten independently invented probes were executed end-to-end against disposable
complete relay copies. Six ship prohibited builder authority — or a HOLD bypass
— with **all eight** shipped tools exiting 0 after a coherent rebind.

## The four material findings

| ID | What ships green | Residual of |
|---|---|---|
| **R25-F02** | Verbatim prohibited authority in `00_CONTROL/PROMPT_TO_EXECUTE.md`, the file the next actor is told to execute. Exempted from the scan by a hash pin with no `ABSOLUTE_*` anchor, held in the one file that cannot hash-lock itself, targeting a file no manifest pins. `authority_strings_scanned` stays at 36137 — identical to baseline — so the payload is *unscanned*, not merely unmatched. | R23-F03 |
| **R25-F01** | Authority written in LATIN-block small-capital/IPA lookalikes, or in Cherokee. `script_families()` classifies by UCD name prefix, so small caps report `LATIN` and the mixed-script rule never fires; Cherokee is outside `MIXED_SCRIPT_FAMILIES` entirely. Worst variant lands in a normative build-DAG instruction leaf. | R23-F01 |
| **R25-F03** | Authority fragmented across adjacent comment lines of `meta_validate_round24.py`, which is explicitly excluded from `append_document_projection` — the very repair that closed cross-line fragmentation everywhere else. | R23-F02 |
| **R25-F04** | A HOLD bypass paraphrased around the literal reject vocabulary: HOLD informational, self-signoff at N70, no second reviewer, package before any candidate run. | R23-F05 |

**R25-F02 is advancement-critical and needs no homoglyph at all.**

## What held

DEFERRED cannot launder a candidate PASS. The 80-character slug floor and all
three export identity domains are independently anchored. N80 reviewed-byte
identity, `NO_IMPLEMENTATION_CANDIDATE` and the four external blockers are
unchanged. The nested acceptance-contract side channel was rejected — though by
the authority matcher catching key names, not by a structural rule.

## Method note worth carrying forward

Each probe was run under two rebind models. Under the weaker one — package
rebound but `INPUT_SHA256SUMS.txt` left sealed — eight probes reject with a bare
`MISMATCH` from `verify_input_manifest.py`. That is a checksum diff, not a
semantic control, and scoring it would have credited the authority scan with
catches it never made.

All 425 Round 024 members are pinned in that manifest, but the manifest is an
`allowed_mutations` entry generated *from* the package by the acting round. It
cannot be a control against the package's own author. The adjudication is scored
against the author model; both are shipped. See `METHOD_NOTE.md`.

## Round 026 repair list

1. **Delete `RELAY_SCAN_EXEMPT_SHA256`**, or make the exemption impossible to
   self-serve — anchor the digest in an `ABSOLUTE_*` constant *and* pin the file
   from outside the validator. *(R25-F02)*
2. Replace name-prefix script classification with a real per-character script
   property; restrict normative text to a declared character set or fold through
   a maintained confusables table. *(R25-F01)*
3. Apply `append_document_projection` to the validator and pin its bytes from
   outside itself. *(R25-F03)*
4. Enforce HOLD structurally as a terminal transition state, not by blacklisting
   phrasings. *(R25-F04)*
5. Add a structural rule for nested acceptance-contract key spaces.
6. Declare a supported negative-context path for incoming probe harnesses.

## Scope

Phase 0A **spec** only. Nothing was deployed, built, published or configured; no
credentials, providers, DNS, wallets or hosts were touched. All probe execution
was confined to disposable `/tmp` copies and the sealed v15 tree was never
mutated.
