# Round 025 — why two rebind models were run

Every probe was executed twice against disposable complete copies of the relay
under `/tmp`. The sealed v15 ship tree was never mutated.

## Model A — transit-tamper (`r25_probes.json`)

The mutation is applied and the Round 024 package is coherently rebound
(`repin_constants`, `relock_library`, `rebind_acyclic`,
`recohere_operational_receipts`), but `05_MANIFESTS/INPUT_SHA256SUMS.txt` is
left as sealed.

This models an actor who edits the package **after** v15 was sealed.

## Model B — package author (`r25_probes_author_model.json`)

Identical, plus `05_MANIFESTS/INPUT_SHA256SUMS.txt` is regenerated.

This models the actor who **wrote** Round 024 and produced v15.

## Why Model B is the load-bearing one

All 425 Round 024 members are pinned in `05_MANIFESTS/INPUT_SHA256SUMS.txt`.
That manifest is listed in `00_CONTROL/CURRENT_STATE.json` under
`allowed_mutations`, and it is generated *from* the round package by the acting
round. The Round 024 author therefore both wrote the package and emitted the
manifest that covers it.

Consequently the input manifest cannot be a control against the package's own
author. It is an integrity control against transit tampering only.

Under Model A almost every probe rejects with a bare `MISMATCH` emitted by
`04_TOOLS/verify_input_manifest.py` — a checksum diff, not a semantic control.
Scoring Model A alone would have recorded eight rejects and credited the
authority scan for catches it never made.

The release question asked whether the Round 024 **spec package** can carry an
unscanned authority path while its own gate reports green. That question is
about the author. Model B is therefore the model the adjudication is scored
against; Model A is retained as the weaker second layer and is reported
alongside it.

## Materiality scoring

A probe counts as FALSE_GREEN only when all eight shipped tools exit 0:

    verify_input_manifest, semantic_validator, full_validator,
    independent_oracle, transition_evaluator, export_generator,
    export_verifier, verify_round24_receipts

`APPLY_ERROR` is recorded separately and is never scored as a reject.
