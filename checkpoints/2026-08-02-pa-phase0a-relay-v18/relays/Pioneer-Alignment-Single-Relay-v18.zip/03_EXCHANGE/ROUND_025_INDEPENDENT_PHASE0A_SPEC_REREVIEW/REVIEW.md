# ROUND 025 — Independent Phase 0A Spec Re-review

**Adjudication: `HOLD_FOR_FURTHER_PHASE0A_SPEC_REPAIR`**

Round 024 is **not** ready to release the Phase 0A SPEC to a bounded local
builder. The official gate is green and its 88-class mutation registry is
sound, but six independently invented probes ship prohibited builder authority
— or a HOLD bypass — while all eight shipped tools exit 0 after a coherent
rebind.

Input: `Pioneer-Alignment-Single-Relay-v15.zip`
SHA-256 `195c4691dbe2cb64c963e0a8066e68c5685697acbdb3d3e218f7f7e83c70c601`

---

## 1. Official baseline — green

| Check | Result |
|---|---|
| `verify_input_manifest.py` | PASS, 1679 files |
| `meta_validate_round24.py` (full) | `SPEC_CONTRACT_VALID`, 0 errors, 36137 authority strings |
| `meta_validate_round24.py --semantic-only` | `SPEC_CONTRACT_VALID`, 0 errors |
| `independent_oracle.py` | 54 decided / 54 passed / 35 deferred; `candidate_pass_eligible=false`, blocker `DEFERRED_REQUIRED_CASES` |
| `transition_evaluator.py` | `ok: true`, all seven reject classes hold |
| `export_generator.py` + `export_verifier.py` | `matches_golden: true`, `ok: true` |
| `verify_round24_receipts.py` | `PASS` 9/9 |
| `run_round24_mutations.py` | 88 classes, **88 rejected, 0 false-green, 0 wrong-reason** (default, seed 1, seed 2 — all three) |

One declared property of the baseline does **not** hold. The mutation receipt
states `seed is intentionally not recorded; canonical receipt bytes must match
for seeds 1 and 2`. They do not:

```
PYTHONHASHSEED=1  c96a9ea7d4ecb863f9d6c06f2491087c7a0fe6c697e44a1c0fe41b207d43643c
PYTHONHASHSEED=2  960092c0fbff1d5c000b580bde371ccad928a5d6d56a269403da050dfc7d7cb8
```

The divergence is not ordering alone — the *number* of `observed_reason_codes`
per mutation differs (4 vs 6, 22 vs 24, 5 vs 7), as do the validator stdout
digests, indicating seed-dependent set iteration in error reporting.

This is **non-material** by the Round 025 standard: it enables no false green,
and verdicts are stable across all three runs with identical summary objects. It
is recorded because it is a declared-versus-enforced gap in the very artifact the
registry's credibility rests on — `rejected_wrong_reason: 0` is computed over a
reason-code set whose membership varies with the interpreter hash seed. See
`FINDING_CLOSURE.json` R25-P05.

The Round 024 repair work is real. Nothing below disputes the baseline; the
findings are about classes the registry does not contain.

---

## 2. Probe method

Ten probes were executed end-to-end against disposable complete relay copies
under `/tmp`. The sealed v15 tree was never mutated. Each probe was run under
**two** rebind models — see `METHOD_NOTE.md`.

* **Model A (transit-tamper)** — package rebound, `INPUT_SHA256SUMS.txt` left sealed.
* **Model B (package author)** — same, plus the input manifest regenerated.

Model B is the model the adjudication is scored against. All 425 Round 024
members are pinned in `05_MANIFESTS/INPUT_SHA256SUMS.txt`; that manifest is an
`allowed_mutations` entry generated *from* the package by the acting round, so
it cannot be a control against the package's own author. Under Model A eight
probes reject with a bare `MISMATCH` from `verify_input_manifest.py` — a
checksum diff, crediting the authority scan for catches it never made.

A probe is FALSE_GREEN only when **all eight** shipped tools exit 0.

| Probe | Model A | Model B (scored) |
|---|---|---|
| P01 LATIN-block homoglyph, Markdown | REJECTED (`MISMATCH`) | **FALSE_GREEN** |
| P02 LATIN-block homoglyph, build-DAG leaf | REJECTED (`MISMATCH`) | **FALSE_GREEN** |
| P03 Cherokee homoglyph, Markdown | REJECTED (`MISMATCH`) | **FALSE_GREEN** |
| P04 authority in scan-exempt control file | **FALSE_GREEN** | **FALSE_GREEN** |
| P05 validator comment fragmentation | REJECTED (`MISMATCH`) | **FALSE_GREEN** |
| P06 nested acceptance-contract side channel | APPLY_ERROR (fixed) | REJECTED (`AUTHORITY_PROHIBITED_TEXT`) |
| P07 HOLD-bypass paraphrase | REJECTED (`MISMATCH`) | **FALSE_GREEN** |
| P08 DEFERRED launders candidate PASS | REJECTED (semantic) | REJECTED (`DEFERRED_SPEC_PASS_CLAIM`, `ORACLE_*_COUNT_MISMATCH`) |
| P09 slug floor widened | REJECTED (semantic) | REJECTED (`SLUG_HOSTILE_ACCEPTED`, …) |
| P10 export identity domains rebound | REJECTED (semantic) | REJECTED (`CANONICAL_EXPORT_ID_DOMAIN`, …) |

---

## 3. Material findings

### R25-F01 — confusable defence does not cover LATIN-block or unlisted scripts
**Material. Probes P01, P02, P03.**

`script_families()` (validator ~389) classifies by UCD name prefix. Small-capital
and IPA letters (U+1D00–U+1D2B, U+0261, …) are *named* `LATIN …`, so a payload
built from them reports `{LATIN}` and `latin_mixed_with_other_script()` never
fires. `MIXED_SCRIPT_FAMILIES` is only `("GREEK","CYRILLIC","ARMENIAN")`, so a
Cherokee payload contributes no family at all and is likewise unmixed.
`EXPLICIT_CONFUSABLE_MAP` contains no entry for either class, and NFKC gives
these code points no decomposition.

Measured directly against the shipped validator:

```
smallcap  families=['LATIN']  mixed=False  fold-to-real-substring=False
cherokee  families=['LATIN']  mixed=False  fold-to-real-substring=False
```

P02 is the sharper variant: the payload is a normative `PHASE0A_BUILD_DAG.v2.json`
instruction leaf — text a builder executes, not prose.

R23-F01 is therefore closed only against the three mapped scripts.

### R25-F02 — scan-exempt control file carries unscanned authority
**Material. Probe P04. Advancement-critical.**

`RELAY_SCAN_EXEMPT_SHA256` (validator ~290) skips
`00_CONTROL/PROMPT_TO_EXECUTE.md` by hash and `continue`s before
`scan_authority_leaves`. That pin has **no `ABSOLUTE_*` anchor** — unlike
`ABSOLUTE_AUTHORITY_REJECT_SUBSTRINGS`, `ABSOLUTE_SLUG_MAX_LENGTH` and
`ABSOLUTE_EXPORT_DOMAINS` — and it lives in the one file that cannot hash-lock
itself. The target is absent from `INPUT_SHA256SUMS.txt` (an allowed mutation),
so nothing else pins it.

Repin the exempt digest, and verbatim plain-ASCII prohibited authority **and**
HOLD-bypass text ship in the file the next actor is instructed to execute:

```
verify_input_manifest      PASS (1679 files)
full validator             SPEC_CONTRACT_VALID, errors=0, authority_strings_scanned=36137
verify_round24_receipts    PASS 9/9
```

`authority_strings_scanned` is **36137 — identical to the clean baseline**. The
payload contributed zero scanned strings: it is *unscanned*, not merely
unmatched. This is an open R23-F03-class hole and needs no homoglyph at all.

### R25-F03 — validator is exempt from its own cross-line projection
**Material. Probe P05.**

`append_document_projection` is skipped when
`relative == "meta_validate_round24.py"` (~2065). Cross-line joining is exactly
the R23-F02 repair, and it does not apply to the one Python member no exact-hash
lock can cover. Authority fragmented across adjacent comment lines of the
validator ships with the gate green. R23-F02 residual confirmed live.

### R25-F04 — HOLD bypass survives paraphrase
**Material. Probe P07.**

The R23-F05 repair added literal reject substrings. Matching is literal-substring,
so prose carrying the same instruction — HOLD recorded for information only,
self-signoff at N70, no second reviewer, package before any candidate run —
matches none of them and ships green. HOLD is not terminal against a paraphrasing
author. R23-F05 residual confirmed live.

---

## 4. Controls that held

* **R25-C01** — nested acceptance-contract side channel **rejected**
  (`AUTHORITY_PROHIBITED_TEXT`). The top-level key set is closed by exact
  equality (~633) and, although nested key *spaces* are unconstrained, JSON key
  names are projected into the authority scan and were caught. Note the catch is
  from the authority matcher, not from a structural rule — a semantically
  equivalent key whose name avoids the vocabulary is untested.
* **R25-C02** — DEFERRED cannot launder candidate PASS. Rejected on
  `DEFERRED_SPEC_PASS_CLAIM` plus both oracle count invariants.
* **R25-C03** — the 80-character slug floor is independently anchored; widening
  every anchor including the validator still rejects.
* **R25-C04** — all three export identity domains are anchored; rebinding them
  breaks export identity and the R21-F03 closure receipt.
* **R25-C05** — N80 reviewed-byte identity and the four external blockers are
  unchanged; `NO_IMPLEMENTATION_CANDIDATE` holds and
  `candidate_pass_eligible=false`.

---

## 5. Round 026 repair list

1. **Fold the confusable space properly.** Replace name-prefix script
   classification with a real per-character script property, and either restrict
   normative text to a declared character set or fold via a maintained
   confusables table. Anchor whatever replaces `EXPLICIT_CONFUSABLE_MAP`.
   *(R25-F01)*
2. **Delete `RELAY_SCAN_EXEMPT_SHA256`, or make the exemption impossible to
   self-serve.** The exempted file must be scanned like every other member. If an
   exemption must exist, anchor its digest in an `ABSOLUTE_*` constant *and* pin
   the file outside the validator. *(R25-F02 — highest priority)*
3. **Remove the validator's projection exemption.** Apply
   `append_document_projection` to `meta_validate_round24.py` and pin the
   validator's bytes from outside itself. *(R25-F03)*
4. **Stop relying on literal-substring matching for HOLD semantics.** Enforce
   HOLD structurally — terminal state in the transition table with no prose path
   around it — rather than by blacklisting phrasings. *(R25-F04)*
5. Add a structural rule for nested acceptance-contract keys so R25-C01 does not
   depend on key names happening to contain scanned vocabulary.
6. Declare a negative-context path for incoming probe harnesses (§6).

---

## 6. Process finding — harness negative context

The relay-wide scan covers `03_EXCHANGE/ROUND_025_*/**`: those files are not the
validator's current round and are excluded from `INPUT_SHA256SUMS.txt` as an
allowed mutation, so they fall through to `scan_authority_leaves`. A probe
harness containing payload literals would therefore make the returned relay
reject under Round 024's own validator.

To keep v16 clean while remaining reproducible, the shipped harness carries its
payloads base64-encoded and decodes them at runtime; `PAYLOAD_CLASSES.md` records
the SHA-256 of each decoded literal so Round 026 can verify reproduction without
the literals appearing in scanned text. Round 026 should declare a supported
negative-context path so future reviewers need no such workaround.

---

## 7. Expected post-write state of the Round 024 validator

Running `meta_validate_round24.py` on the **returned** relay reports
`SPEC_CONTRACT_INVALID` with exactly four errors:

```
CLOSURE_RECEIPT_R21_F04_INVALID
RECEIPT_AUTHORITY_COUNT_MISMATCH:CLOSURE_PROBE_RECEIPT.json
RECEIPT_AUTHORITY_COUNT_MISMATCH:SPEC_VALIDATION_RECEIPT.json
RECEIPT_AUTHORITY_COUNT_MISMATCH:SPEC_VALIDATION_RECEIPT.semantic.json
```

This is **not** a Round 025 defect and not a regression. Round 024's receipts pin
`authority_strings_scanned` over the relay as sealed at v15 (36137). The
relay-wide scan covers later round directories, so writing
`ROUND_025_INDEPENDENT_PHASE0A_SPEC_REREVIEW/**` raises the live count to 38192
and the pinned receipts go stale by construction. Every round transition has this
property; the next controlling round regenerates its own receipts.

Worth noting for Round 026 regardless: it makes a controlling round's validator
receipts single-shot, so "the gate is green" is only ever a statement about the
relay at seal time. On the **input** v15 relay, as received, the gate was fully
green — that is the baseline in §1.

Two further consequences of the relay-wide scan showed up while packaging this
return, both recorded in §6:

* Round 024's error strings quote the matched phrase back
  (`AUTHORITY_PROHIBITED_TEXT:<path>:<pointer>:<phrase>`), so any receipt that
  captures validator stdout carries the literal. The probe receipts therefore
  ship with their reject evidence base64-wrapped.
* Round 024's **own** mutation-class identifiers are prohibited-authority
  substrings, so its official mutation receipts cannot be shipped anywhere
  outside Round 024's own current-round prefix. They are recorded here by digest
  and summary in `receipts/round24_mutation_digests.json` instead.

Receipt text files are shipped with a `.txt` suffix because `.log` is not in
`NORMATIVE_TEXTUAL_SUFFIXES` and is otherwise rejected as an unclassified binary
member.

## 8. Scope

This adjudication concerns the Phase 0A **spec** only. Nothing here was
deployed, built, or published; no credentials, providers, DNS, wallets or hosts
were touched. All probe execution was confined to disposable `/tmp` copies.
