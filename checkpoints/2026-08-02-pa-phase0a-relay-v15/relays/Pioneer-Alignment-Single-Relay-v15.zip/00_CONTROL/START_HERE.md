# START HERE — Pioneer Alignment Single-ZIP Relay v15

Current state: `AWAITING_INDEPENDENT_PHASE0A_SPEC_REREVIEW`

Current actor: independent Round 025 Phase 0A specification/gate rereviewer.

Round 024 adjudicated
`ROUND024_REPAIR_COMPLETE_AWAITING_INDEPENDENT_REREVIEW`. That is a repair
handoff, not release authority.

The controlling repair permanently carries 88 mutation classes: all 66 Round
022 classes, all 14 Round 023 probes, and 8 additional closure probes. Its
shipped evidence records 88 intended semantic rejections, zero false greens,
zero wrong-reason rejections, byte-identical seed-1/seed-2 receipts, 43 of 43
legacy closure negatives, and 11 of 11 tracked closure findings. The oracle
remains 54 decided / 35 honestly deferred / candidate-ineligible.

Round 024 claims closure of `R23-F01` through `R23-F06`, `R21-F01`, and residual
`R19-F02`. Independently verify those claims. In particular, exercise the
confusable skeleton and mixed-script rule, whole-document and value-only
projections, non-foldable validator composition rejection, relay-wide scan and
immutable pin coverage, closed acceptance-contract keys, terminal review
language, and coherent receipt rebinding.

Read in order:

1. `00_CONTROL/CURRENT_STATE.json`
2. `00_CONTROL/AUTHORITY.md`
3. `00_CONTROL/PROMPT_TO_EXECUTE.md`
4. `03_EXCHANGE/ROUND_024_CONTROLLING_PHASE0A_REPAIR/RETURN_SUMMARY.md`
5. `03_EXCHANGE/ROUND_024_CONTROLLING_PHASE0A_REPAIR/REPAIR_SUMMARY.md`
6. `03_EXCHANGE/ROUND_024_CONTROLLING_PHASE0A_REPAIR/REQUEST_FOR_INDEPENDENT_REREVIEW.md`
7. `03_EXCHANGE/ROUND_024_CONTROLLING_PHASE0A_REPAIR/FINDING_CLOSURE.json`
8. `03_EXCHANGE/ROUND_024_CONTROLLING_PHASE0A_REPAIR/EXECUTION_RECEIPT.json`

First command on a fresh unpack:

```text
PYTHONDONTWRITEBYTECODE=1 python3 -S 04_TOOLS/verify_input_manifest.py
```

Then replay the Round 024 validator, oracle, closure, mutation, export,
transition, and receipt-verification tools from a clean disposable copy.
Import failure, a digest mismatch, or an unconverged coherent rebind is a
harness failure, not an intended semantic rejection.

All Python entry points must use `PYTHONDONTWRITEBYTECODE=1 python3 -S`.

Return one full relay named `Pioneer-Alignment-Single-Relay-v16.zip`.
Do not build the application or expand authority.
