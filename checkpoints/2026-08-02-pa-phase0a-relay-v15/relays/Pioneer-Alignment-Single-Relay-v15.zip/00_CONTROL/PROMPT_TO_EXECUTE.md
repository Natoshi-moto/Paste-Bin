# Round 025 independent Phase 0A specification/gate rereview

Act as an independent adversarial rereviewer, not the Round 024 author and not
the application builder. Verify the v15 immutable-input manifest before running
any other tool. Use `PYTHONDONTWRITEBYTECODE=1 python3 -S` for every Python
invocation and use complete disposable relay copies for mutations.

Scope: `INDEPENDENT_PHASE0A_SPECIFICATION_REREVIEW_OF_ROUND_024_ONLY`. Do not
build an application, mutate a repository, perform host preflight, use
credentials, connect providers, deploy, or take external action. Independently
adjudicate the repair evidence; do not inherit Round 024's conclusion merely
because its own suite is green.

First reproduce the shipped evidence exactly:

- both validator modes report `SPEC_CONTRACT_VALID`;
- oracle remains 54 decided / 35 honestly deferred / candidate-ineligible;
- all 88 registry mutations reject for their intended reason, with zero false
  greens and zero wrong-reason rejections;
- both hash seeds produce byte-identical mutation and closure receipts;
- all 43 legacy closure negatives reject and all 11 tracked findings close;
- transition, deterministic export, manifest, and 17/17 full receipt replay
  pass from a clean extraction.

Then invent fresh probes outside the Round 024 registry. At minimum test:

- Greek, Cyrillic, Armenian, and mixed-script confusables that NFKC alone does
  not fold;
- prohibited phrases fragmented across array elements, sibling object values,
  table cells, Markdown lines, and static or non-foldable Python composition;
- policy text placed in `00_CONTROL/**`, `04_TOOLS/**`, prior and incoming
  exchange directories, manifests, binary-like names, and extra package paths;
- unknown acceptance-contract top-level keys that imply release or override a
  deferral;
- prose attempting to clear a HOLD, skip independent review, jump to N80, make
  a HOLD advisory, count deferred cases as passing, or release without candidate
  execution;
- a maximal coherent rebind of security constants, exact Python locks,
  manifests, and operational receipts.

An import failure, unpinned-digest crash, stale receipt, or unconverged rebind is
a harness failure, not an intended semantic rejection. Receipt freshness is an
anti-staleness check only; it is not adversarial proof.

Confirm that the validator's own bytes cannot be self-hash-locked and instead
become immutable only through the next relay-level input manifest. Confirm that
any `__pycache__/**` or `*.pyc` source member is unshippable even though archive
exclusion remains as a backstop.

Preserve `NO_IMPLEMENTATION_CANDIDATE`, all four external blockers, terminal
HOLD semantics, N80 reviewed-byte identity, honest deferral, deterministic
export identity, and the separate Rounds 3–10 architecture HOLD.

Return exactly one complete `Pioneer-Alignment-Single-Relay-v16.zip`, one
detached outer SHA-256, and exactly one adjudication.
