# One-ZIP policy — relay v15 to v16

The only return artifact is one complete
`Pioneer-Alignment-Single-Relay-v16.zip`. It must contain all numbered relay
directories at archive root and no wrapper directory.

Do not return a delta, loose receipt, second archive, cache, bytecode, database,
dependency directory, credential, or temporary file. Any source member under
`__pycache__/**`, or named `*.pyc`, makes the relay unshippable and causes the
builder to abort. Those names also remain excluded from every checksum,
inventory, and archive walk as a backstop. Symlinks are prohibited.

Round 023 probe `R23-P14-BYTECODE-NAMED-AUTHORITY-MEMBER` demonstrated why
silent exclusion is insufficient: excluded authority bytes cannot be reviewed
as shipped evidence. Round 024 therefore rejects their presence in the gate and
in the builder. Archive exclusion is retained, but exclusion never turns such a
source tree into a shippable relay.

The outer ZIP SHA-256 is detached and reported out of band because an archive
cannot contain its own hash without self-reference.
